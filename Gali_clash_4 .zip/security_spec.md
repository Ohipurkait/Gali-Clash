# Firestore Security Specification — Gali Clash

## 1. Data Invariants
1. **Identity Binding**: `/players/{userId}`, `/players/{userId}/private/account`, and `/leaderboard/{userId}` MUST belong to `request.auth.uid == userId`. `/globalChat/{msgId}` documents MUST carry `uid == request.auth.uid`.
2. **Verified Gmail Only for Writes**: All create/update mutations require `request.auth != null && request.auth.token.email_verified == true`.
3. **PII Isolation**: Email addresses live exclusively in `/players/{userId}/private/account` (`allow get` owner-only, `allow list: if false`). Neither `/leaderboard` nor `/globalChat` ever stores PII.
4. **Bounded Query Enforcement**: `list` on public non-PII `/leaderboard` and `/globalChat` enforces `request.query.limit <= 50` (`>= 1`) to prevent unbounded scraping while supporting ordered leaderboard/chat queries (`orderBy(..., 'desc'), limit(...)`).
5. **Server Timestamps & Strict Keys**: Every create/update validates `keys().hasAll(...) && keys().hasOnly(...)` and enforces `request.time` for `createdAt`/`updatedAt`.
6. **Monotonic Leaderboard Rank**: `rankPoints` on `/leaderboard/{userId}` is bounded (`0..100000000`) and tied cleanly to `wins * 100 + bestCombo * 5`.
7. **Dual-Currency & Cosmetic Integrity**: Free `futiKodi` may only increase via bounded single-match rewards (`<= +95`) and spend on free cosmetics (`>= 15 FK`). Paid `gota` MUST start at `0` on create and may NEVER increase on client writes (`incoming.gota <= existing.gota`) except when unlocking verified Developer Mode via `/players/{userId}/private/dev`; only trusted Admin SDK webhooks may credit regular `gota` after payment verification. `equippedSkinIds` is bounded (`<= 10`) and every equipped skin/aura MUST exist in `unlockedCosmetics`.
8. **Developer Mode & Badge Integrity**: `isDeveloper` starts strictly `false` on account creation and may only become `true` alongside a verified `/players/{userId}/private/dev` secret unlock claim. Public `/leaderboard/{userId}` and `/globalChat/{msgId}` `isDeveloper` flags must match the author's `/players/{userId}.data.isDeveloper` flag.

## 2. Adversarial "Dirty Dozen" Payloads (All Must Yield PERMISSION_DENIED)
1. Unauthenticated write to `/players/userA`, `/leaderboard/userA`, or `/globalChat/msg1`.
2. Cross-user read on `/players/userA` or `/players/userA/private/account`.
3. Cross-user write on `/leaderboard/userA` by `userB`.
4. Spoofed `uid` in `/globalChat/msg1` (`uid: "userB"` signed in as `userA`).
5. Ghost/shadow field injection (`isAdmin: true`) in any collection.
6. Client-spoofed `createdAt` or `updatedAt` timestamps instead of `request.time`.
7. Oversized global chat text (`> 180` chars) or oversized `akharaName` (`> 32` chars).
8. Fake inflated `rankPoints` on `/leaderboard/{userId}` (`rankPoints != wins * 100 + bestCombo * 5`).
9. Unbounded `list` scraping query (`limit > 50` or no limit) on `/globalChat` or `/leaderboard`.
10. Unverified email write (`email_verified: false`).
11. Negative `wins` / `losses` / `bestCombo` or single-match win jump (`wins + 10`) on `/players/{userId}`.
12. Inflating paid `gota` (`gota: 1000`), inflating `futiKodi` (`futiKodi + 500`), or equipping unowned skin IDs from the client SDK on `/players/{userId}`.
