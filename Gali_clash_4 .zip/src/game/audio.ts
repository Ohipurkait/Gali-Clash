const BGM_TRACK_URL = '/assets/aistudio/gali_claim_the_akhara_c9e9da02.wav';

export type UiSfxKind = 'tap' | 'select' | 'unlock' | 'dev_on' | 'dev_off' | 'locked';

function clampUnit(val: number, fallback: number): number {
  if (!Number.isFinite(val)) return fallback;
  return Math.max(0, Math.min(1, val));
}

function safeGet(key: string, fallback: string): string {
  try {
    const v = window.localStorage.getItem(key);
    return v !== null ? v : fallback;
  } catch {
    return fallback;
  }
}

function safeSet(key: string, val: string): void {
  try {
    window.localStorage.setItem(key, val);
  } catch {
    // ignore storage quota errors
  }
}

class SoundEngine {
  private ctx: AudioContext | null = null;
  private sfxMasterGain: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private crowdNoiseBuf: AudioBuffer | null = null;
  private bgmEl: HTMLAudioElement | null = null;
  private lastCrowdAt = 0;
  private ambienceActive = false;
  private ambienceExcitement = 0.35;
  private ambienceNodes: {
    src1: AudioBufferSourceNode;
    src2: AudioBufferSourceNode;
    lfo: OscillatorNode;
    masterGain: GainNode;
  } | null = null;

  public bgmOn = safeGet('scc_bgm', '1') === '1';
  public sfxOn = safeGet('scc_sfx', '1') === '1';
  public voiceOn = safeGet('scc_voice', '1') === '1';
  public bgmVolume = clampUnit(parseFloat(safeGet('scc_bgm_vol', '0.6')), 0.6);
  public sfxVolume = clampUnit(parseFloat(safeGet('scc_sfx_vol', '0.85')), 0.85);

  private createNoiseBuffer(ac: AudioContext, seconds = 0.5): AudioBuffer | null {
    try {
      const len = Math.floor(ac.sampleRate * seconds);
      const buf = ac.createBuffer(1, len, ac.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < len; i++) {
        data[i] = Math.random() * 2 - 1;
      }
      return buf;
    } catch {
      return null;
    }
  }

  private getSfxDestination(ac: AudioContext): AudioNode {
    if (!this.sfxMasterGain) {
      this.sfxMasterGain = ac.createGain();
      this.sfxMasterGain.gain.value = this.sfxOn ? this.sfxVolume : 0;
      this.sfxMasterGain.connect(ac.destination);
    }
    return this.sfxMasterGain;
  }

  private ensureBgmElement(): HTMLAudioElement | null {
    if (typeof window === 'undefined' || typeof Audio === 'undefined') return null;
    if (!this.bgmEl) {
      try {
        const el = new Audio(BGM_TRACK_URL);
        el.loop = true;
        el.preload = 'auto';
        el.volume = this.bgmOn ? this.bgmVolume : 0;
        this.bgmEl = el;
      } catch {
        return null;
      }
    }
    return this.bgmEl;
  }

  private syncBgmPlayback(): void {
    const el = this.ensureBgmElement();
    if (!el) return;
    const effectiveVol = this.bgmOn ? clampUnit(this.bgmVolume, 0.6) : 0;
    try {
      el.volume = effectiveVol;
      if (this.bgmOn && effectiveVol > 0) {
        if (el.paused) {
          const p = el.play();
          if (p && typeof p.catch === 'function') {
            p.catch(() => {
              // Autoplay blocked until next user gesture; ensureAudio() will retry
            });
          }
        }
      } else {
        el.pause();
      }
    } catch {
      // ignore playback restriction errors
    }
  }

  private syncSfxMasterGain(): void {
    if (!this.ctx || !this.sfxMasterGain) return;
    try {
      const target = this.sfxOn ? clampUnit(this.sfxVolume, 0.85) : 0;
      this.sfxMasterGain.gain.setTargetAtTime(target, this.ctx.currentTime, 0.015);
    } catch {
      // ignore
    }
  }

  public ensureAudio(): void {
    if (!this.ctx) {
      try {
        const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        if (AC) {
          this.ctx = new AC();
          this.sfxMasterGain = this.ctx.createGain();
          this.sfxMasterGain.gain.value = this.sfxOn ? this.sfxVolume : 0;
          this.sfxMasterGain.connect(this.ctx.destination);
          this.noiseBuf = this.createNoiseBuffer(this.ctx, 0.5);
          this.crowdNoiseBuf = this.createNoiseBuffer(this.ctx, 2.2);
        }
      } catch {
        // ignore
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      try {
        void this.ctx.resume();
      } catch {
        // ignore
      }
    }
    if (this.bgmOn) {
      this.syncBgmPlayback();
    }
  }

  public setBgm(on: boolean): void {
    this.bgmOn = on;
    safeSet('scc_bgm', on ? '1' : '0');
    if (on) {
      this.ensureAudio();
    }
    this.syncBgmPlayback();
  }

  public setBgmVolume(vol: number): void {
    this.bgmVolume = clampUnit(vol, 0.6);
    safeSet('scc_bgm_vol', String(this.bgmVolume));
    this.ensureAudio();
    this.syncBgmPlayback();
  }

  public setSfx(on: boolean): void {
    this.sfxOn = on;
    safeSet('scc_sfx', on ? '1' : '0');
    this.syncSfxMasterGain();
    if (!on) {
      this.stopAmbienceNodes();
    } else if (this.ambienceActive) {
      this.startAmbienceNodes();
    }
  }

  public setSfxVolume(vol: number): void {
    this.sfxVolume = clampUnit(vol, 0.85);
    safeSet('scc_sfx_vol', String(this.sfxVolume));
    this.ensureAudio();
    this.syncSfxMasterGain();
  }

  public setVoice(on: boolean): void {
    this.voiceOn = on;
    safeSet('scc_voice', on ? '1' : '0');
    if (on) this.playVictoryStinger('munna_bhaiya');
  }

  private playTone(freq: number, endFreq: number, dur: number, type: OscillatorType, vol: number, delay = 0): void {
    if (!this.sfxOn || this.sfxVolume <= 0) return;
    this.ensureAudio();
    const ac = this.ctx;
    if (!ac) return;
    try {
      const now = ac.currentTime + delay;
      const osc = ac.createOscillator();
      const gain = ac.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(Math.max(20, freq), now);
      if (endFreq) osc.frequency.exponentialRampToValueAtTime(Math.max(20, endFreq), now + dur);
      gain.gain.setValueAtTime(vol, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + dur);
      osc.connect(gain);
      gain.connect(this.getSfxDestination(ac));
      osc.start(now);
      osc.stop(now + dur);
    } catch {
      // ignore
    }
  }

  private playNoise(dur: number, filterFreq: number, filterType: BiquadFilterType, vol: number, delay = 0): void {
    if (!this.sfxOn || this.sfxVolume <= 0) return;
    this.ensureAudio();
    const ac = this.ctx;
    if (!ac || !this.noiseBuf) return;
    try {
      const now = ac.currentTime + delay;
      const src = ac.createBufferSource();
      src.buffer = this.noiseBuf;
      const filt = ac.createBiquadFilter();
      filt.type = filterType;
      filt.frequency.setValueAtTime(filterFreq, now);
      const gain = ac.createGain();
      gain.gain.setValueAtTime(vol, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + dur);
      src.connect(filt);
      filt.connect(gain);
      gain.connect(this.getSfxDestination(ac));
      src.start(now);
      src.stop(now + dur);
    } catch {
      // ignore
    }
  }

  private stopAmbienceNodes(): void {
    if (!this.ambienceNodes) return;
    try {
      const ac = this.ctx;
      const nodes = this.ambienceNodes;
      this.ambienceNodes = null;
      if (ac) {
        const now = ac.currentTime;
        nodes.masterGain.gain.cancelScheduledValues(now);
        nodes.masterGain.gain.setTargetAtTime(0.0001, now, 0.08);
        window.setTimeout(() => {
          try {
            nodes.src1.stop();
            nodes.src2.stop();
            nodes.lfo.stop();
          } catch {
            // ignore
          }
        }, 280);
      } else {
        nodes.src1.stop();
        nodes.src2.stop();
        nodes.lfo.stop();
      }
    } catch {
      this.ambienceNodes = null;
    }
  }

  private startAmbienceNodes(): void {
    if (!this.sfxOn || this.sfxVolume <= 0 || this.ambienceNodes) return;
    this.ensureAudio();
    const ac = this.ctx;
    if (!ac || !this.crowdNoiseBuf) return;
    try {
      const now = ac.currentTime;
      const src1 = ac.createBufferSource();
      src1.buffer = this.crowdNoiseBuf;
      src1.loop = true;

      const src2 = ac.createBufferSource();
      src2.buffer = this.crowdNoiseBuf;
      src2.loop = true;

      const bpLow = ac.createBiquadFilter();
      bpLow.type = 'bandpass';
      bpLow.frequency.setValueAtTime(360, now);
      bpLow.Q.setValueAtTime(1.4, now);

      const bpHigh = ac.createBiquadFilter();
      bpHigh.type = 'bandpass';
      bpHigh.frequency.setValueAtTime(980, now);
      bpHigh.Q.setValueAtTime(1.8, now);

      const gHigh = ac.createGain();
      gHigh.gain.setValueAtTime(0.55, now);

      // Slow organic breathing LFO so stadium crowd murmur swells naturally
      const lfo = ac.createOscillator();
      lfo.type = 'sine';
      lfo.frequency.setValueAtTime(0.32, now);
      const lfoGain = ac.createGain();
      lfoGain.gain.setValueAtTime(0.009, now);

      const masterGain = ac.createGain();
      const targetVol = 0.022 + Math.min(1, this.ambienceExcitement) * 0.032;
      masterGain.gain.setValueAtTime(0.0005, now);
      masterGain.gain.linearRampToValueAtTime(targetVol, now + 0.45);

      src1.connect(bpLow);
      bpLow.connect(masterGain);

      src2.connect(bpHigh);
      bpHigh.connect(gHigh);
      gHigh.connect(masterGain);

      lfo.connect(lfoGain);
      lfoGain.connect(masterGain.gain);

      masterGain.connect(this.getSfxDestination(ac));

      src1.start(now, 0.1);
      src2.start(now, 0.85);
      lfo.start(now);

      this.ambienceNodes = { src1, src2, lfo, masterGain };
    } catch {
      // ignore
    }
  }

  public setArenaAmbience(active: boolean, excitement = 0.35): void {
    this.ambienceActive = active;
    this.ambienceExcitement = Math.max(0, Math.min(1.2, excitement));
    if (!active || !this.sfxOn) {
      this.stopAmbienceNodes();
      return;
    }
    if (!this.ambienceNodes) {
      this.startAmbienceNodes();
    } else if (this.ctx) {
      try {
        const now = this.ctx.currentTime;
        const targetVol = 0.022 + Math.min(1, this.ambienceExcitement) * 0.034;
        this.ambienceNodes.masterGain.gain.setTargetAtTime(targetVol, now, 0.25);
      } catch {
        // ignore
      }
    }
  }

  // Indian Akhara Audience Cheer / Shouts ("HOOO / MAARO / SHABAASH") / Whistle / Applause during fight
  public playCrowdCheer(intensity: 'normal' | 'hype' | 'ko' = 'normal'): void {
    if (!this.sfxOn || this.sfxVolume <= 0) return;
    const nowMs = performance.now();
    if (intensity === 'normal' && nowMs - this.lastCrowdAt < 2100) return;
    if (intensity === 'hype' && nowMs - this.lastCrowdAt < 1100) return;
    this.lastCrowdAt = nowMs;

    this.ensureAudio();
    const ac = this.ctx;
    if (!ac || !this.crowdNoiseBuf) return;

    try {
      const now = ac.currentTime;
      const dur = intensity === 'ko' ? 2.05 : intensity === 'hype' ? 1.45 : 1.1;
      const masterVol = intensity === 'ko' ? 0.26 : intensity === 'hype' ? 0.2 : 0.145;
      const sfxDest = this.getSfxDestination(ac);

      // 1. Multi-voice Indian stadium shouting formants ("HOOOAAH / MAARO / SHABAASH!")
      const voices = [
        { delay: 0.0, startF: 360, peakF: 580, endF: 380, q: 3.1, vol: masterVol * 0.85 },
        { delay: 0.04, startF: 680, peakF: 1050, endF: 720, q: 3.6, vol: masterVol * 0.72 },
        { delay: 0.09, startF: 1220, peakF: 1680, endF: 1120, q: 3.4, vol: masterVol * 0.52 },
      ];
      for (const fm of voices) {
        const t0 = now + fm.delay;
        const src = ac.createBufferSource();
        src.buffer = this.crowdNoiseBuf;
        src.loop = true;

        const bp = ac.createBiquadFilter();
        bp.type = 'bandpass';
        bp.Q.setValueAtTime(fm.q, t0);
        bp.frequency.setValueAtTime(fm.startF, t0);
        bp.frequency.linearRampToValueAtTime(fm.peakF, t0 + dur * 0.25);
        bp.frequency.exponentialRampToValueAtTime(fm.endF, t0 + dur);

        const g = ac.createGain();
        g.gain.setValueAtTime(0.001, t0);
        g.gain.linearRampToValueAtTime(fm.vol, t0 + dur * 0.14);
        g.gain.setValueAtTime(fm.vol * 0.88, t0 + dur * 0.45);
        g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);

        src.connect(bp);
        bp.connect(g);
        g.connect(sfxDest);
        src.start(t0, Math.random() * 0.5);
        src.stop(t0 + dur + 0.05);
      }

      // 2. Rhythmic crowd clapping bursts (taaliyan)
      const clapCount = intensity === 'ko' ? 10 : intensity === 'hype' ? 7 : 4;
      for (let i = 0; i < clapCount; i++) {
        const delay = 0.04 + i * (0.075 + Math.random() * 0.045);
        this.playNoise(0.045, 1650 + Math.random() * 800, 'bandpass', masterVol * 0.36, delay);
      }

      // 3. Desi stadium whistle (Seeti!) + Dhol hype thump on hype/KO moments
      if (intensity === 'hype' || intensity === 'ko') {
        const wDelay = 0.08;
        const wDur = intensity === 'ko' ? 0.52 : 0.34;
        const osc = ac.createOscillator();
        const wg = ac.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(1950, now + wDelay);
        osc.frequency.exponentialRampToValueAtTime(2720, now + wDelay + wDur * 0.38);
        osc.frequency.exponentialRampToValueAtTime(2320, now + wDelay + wDur);
        wg.gain.setValueAtTime(0.0005, now + wDelay);
        wg.gain.linearRampToValueAtTime(masterVol * 0.3, now + wDelay + 0.04);
        wg.gain.exponentialRampToValueAtTime(0.0005, now + wDelay + wDur);
        osc.connect(wg);
        wg.connect(sfxDest);
        osc.start(now + wDelay);
        osc.stop(now + wDelay + wDur + 0.03);

        this.playTone(155, 62, 0.16, 'sine', masterVol * 0.32, 0.04);
        this.playTone(155, 62, 0.16, 'sine', masterVol * 0.28, 0.22);
      }
    } catch {
      // ignore
    }
  }

  public playSfx(kind: string): void {
    if (!this.sfxOn || this.sfxVolume <= 0) return;
    this.ensureAudio();
    if (kind === 'tap') {
      this.playTone(620, 880, 0.04, 'sine', 0.07);
      this.playTone(1240, 1600, 0.03, 'triangle', 0.04);
    } else if (kind === 'whoosh') {
      this.playNoise(0.14, 1400, 'bandpass', 0.16);
      this.playNoise(0.10, 600, 'lowpass', 0.08);
      this.playTone(280, 90, 0.11, 'sine', 0.06);
    } else if (kind === 'punch') {
      this.playNoise(0.07, 1800, 'bandpass', 0.22);
      this.playNoise(0.05, 400, 'lowpass', 0.14);
      this.playTone(220, 48, 0.11, 'triangle', 0.26);
      this.playTone(110, 40, 0.09, 'sine', 0.12, 0.02);
    } else if (kind === 'kick') {
      this.playNoise(0.12, 1100, 'lowpass', 0.26);
      this.playNoise(0.08, 2800, 'highpass', 0.10);
      this.playTone(185, 38, 0.15, 'sawtooth', 0.28);
      this.playTone(95, 32, 0.12, 'sine', 0.16, 0.03);
    } else if (kind === 'heavy_hit') {
      this.playNoise(0.18, 700, 'lowpass', 0.32);
      this.playNoise(0.10, 1600, 'bandpass', 0.14);
      this.playTone(150, 28, 0.26, 'sawtooth', 0.32);
      this.playTone(85, 22, 0.30, 'sine', 0.34);
      this.playTone(55, 30, 0.22, 'triangle', 0.18, 0.04);
    } else if (kind === 'block') {
      this.playTone(920, 480, 0.08, 'square', 0.16);
      this.playTone(1380, 720, 0.07, 'triangle', 0.14);
      this.playNoise(0.06, 2800, 'highpass', 0.14);
    } else if (kind === 'dash') {
      this.playNoise(0.16, 1800, 'bandpass', 0.20);
      this.playTone(360, 720, 0.12, 'sine', 0.14);
    } else if (kind === 'katta') {
      this.playNoise(0.08, 2200, 'highpass', 0.28);
      this.playNoise(0.22, 800, 'lowpass', 0.36);
      this.playTone(200, 40, 0.26, 'sawtooth', 0.34);
      this.playTone(680, 90, 0.12, 'square', 0.22);
    } else if (kind === 'chappal') {
      this.playNoise(0.07, 2600, 'bandpass', 0.30);
      this.playTone(480, 140, 0.08, 'square', 0.24);
    } else if (kind === 'fart') {
      this.playTone(160, 42, 0.36, 'sawtooth', 0.28);
      this.playTone(105, 35, 0.34, 'square', 0.18);
      this.playNoise(0.28, 380, 'lowpass', 0.20);
    } else if (kind === 'tawa') {
      this.playTone(580, 180, 0.22, 'square', 0.24);
      this.playTone(860, 360, 0.18, 'triangle', 0.20);
      this.playNoise(0.16, 3000, 'bandpass', 0.22);
    } else if (kind === 'mantra') {
      this.playTone(432, 648, 0.32, 'sine', 0.22);
      this.playTone(648, 864, 0.30, 'triangle', 0.16);
    } else if (kind === 'horn') {
      this.playTone(380, 410, 0.12, 'sawtooth', 0.24, 0);
      this.playTone(480, 510, 0.12, 'sawtooth', 0.20, 0);
      this.playTone(380, 410, 0.14, 'sawtooth', 0.24, 0.14);
      this.playTone(480, 510, 0.14, 'sawtooth', 0.20, 0.14);
    } else if (kind === 'laser') {
      this.playTone(900, 1800, 0.16, 'sine', 0.20);
      this.playTone(1400, 2800, 0.12, 'triangle', 0.14);
      this.playNoise(0.10, 3500, 'highpass', 0.12);
    } else if (kind === 'gong') {
      this.playTone(105, 52, 0.65, 'sine', 0.36);
      this.playTone(158, 78, 0.55, 'triangle', 0.26);
      this.playNoise(0.40, 160, 'lowpass', 0.20);
    } else if (kind === 'boing') {
      this.playTone(300, 700, 0.10, 'sine', 0.20);
      this.playTone(500, 220, 0.16, 'triangle', 0.16);
    } else if (kind === 'counter') {
      this.playTone(780, 1560, 0.08, 'square', 0.22);
      this.playTone(1040, 520, 0.11, 'sawtooth', 0.18);
      this.playNoise(0.07, 2000, 'bandpass', 0.16);
    }
  }

  public playUiSfx(kind: UiSfxKind): void {
    if (!this.sfxOn || this.sfxVolume <= 0) return;
    this.ensureAudio();
    const ac = this.ctx;
    if (!ac) return;

    if (kind === 'tap') {
      // Crisp wooden / bamboo click-tap
      this.playNoise(0.028, 1750, 'bandpass', 0.09);
      this.playTone(860, 420, 0.036, 'triangle', 0.11);
      this.playTone(1480, 920, 0.024, 'sine', 0.06, 0.004);
    } else if (kind === 'select') {
      // Punchy whoosh / select chime
      this.playNoise(0.075, 1150, 'bandpass', 0.08);
      this.playTone(460, 720, 0.065, 'triangle', 0.11);
      this.playTone(740, 1080, 0.085, 'sine', 0.09, 0.032);
    } else if (kind === 'unlock') {
      // Rich golden coin / chime fanfare
      this.playTone(659, 659, 0.09, 'triangle', 0.13, 0);
      this.playTone(880, 880, 0.10, 'triangle', 0.13, 0.055);
      this.playTone(1175, 1175, 0.12, 'sine', 0.14, 0.11);
      this.playTone(1568, 1620, 0.22, 'sine', 0.15, 0.165);
      this.playTone(2350, 2400, 0.18, 'sine', 0.06, 0.17);
      this.playNoise(0.045, 3400, 'highpass', 0.04, 0.11);
    } else if (kind === 'dev_on') {
      // Rising synth chime on Developer Mode Activate
      this.playTone(330, 660, 0.11, 'sawtooth', 0.09, 0);
      this.playTone(494, 988, 0.12, 'triangle', 0.12, 0.07);
      this.playTone(740, 1480, 0.16, 'sine', 0.13, 0.14);
      this.playTone(1319, 1340, 0.24, 'sine', 0.11, 0.22);
    } else if (kind === 'dev_off') {
      // Descending synth tone on Developer Mode Deactivate
      this.playTone(780, 520, 0.09, 'triangle', 0.12, 0);
      this.playTone(520, 310, 0.12, 'triangle', 0.11, 0.075);
      this.playTone(310, 175, 0.15, 'sine', 0.10, 0.15);
    } else if (kind === 'locked') {
      // Subtle low thud on locked item / insufficient funds / error
      this.playNoise(0.045, 290, 'lowpass', 0.12, 0);
      this.playTone(145, 62, 0.11, 'triangle', 0.16, 0);
      this.playTone(95, 52, 0.10, 'sine', 0.11, 0.03);
    }
  }

  public playVictoryStinger(fighterId: string): void {
    if (!this.voiceOn || !this.sfxOn || this.sfxVolume <= 0) return;
    this.ensureAudio();
    const ac = this.ctx;
    if (!ac) return;
    try {
      const now = ac.currentTime;
      const sfxDest = this.getSfxDestination(ac);
      const tone = (freq: number, end: number, dur: number, type: OscillatorType, vol: number, delay: number) => {
        const osc = ac.createOscillator();
        const gain = ac.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(freq, now + delay);
        if (end) osc.frequency.exponentialRampToValueAtTime(Math.max(30, end), now + delay + dur);
        gain.gain.setValueAtTime(0.0001, now + delay);
        gain.gain.exponentialRampToValueAtTime(vol, now + delay + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + delay + dur);
        osc.connect(gain);
        gain.connect(sfxDest);
        osc.start(now + delay);
        osc.stop(now + delay + dur + 0.05);
      };
      this.playCrowdCheer('ko');
      this.playNoise(0.25, 400, 'bandpass', 0.22, 0);
      tone(120, 60, 0.35, 'sawtooth', 0.22, 0);
      const motifs: Record<string, number[]> = {
        munna_bhaiya: [392, 494, 587, 784],
        chappal_chacha: [523, 392, 523, 659],
        lota_lal: [175, 147, 130, 98],
        belan_bhabhi: [440, 554, 659, 880],
        babaji_boom: [262, 330, 392, 523],
        raju_rickshaw: [349, 349, 440, 523],
        sharmaji_beta: [880, 988, 1175, 1319],
        pados_aunty: [587, 523, 659, 784],
        traffic_mama: [294, 330, 349, 392],
        gym_bunty: [196, 247, 294, 392],
      };
      const notes = motifs[fighterId] || [392, 494, 587, 784];
      for (let i = 0; i < notes.length; i++) {
        tone(notes[i], notes[i] * 1.02, 0.18, i % 2 ? 'triangle' : 'square', 0.14, 0.18 + i * 0.14);
        tone(notes[i] / 2, notes[i] / 2, 0.2, 'sine', 0.08, 0.18 + i * 0.14);
      }
      tone(523, 523, 0.45, 'triangle', 0.16, 0.85);
      tone(659, 659, 0.45, 'triangle', 0.12, 0.85);
      tone(784, 784, 0.5, 'sine', 0.14, 0.85);
    } catch {
      // ignore
    }
  }
}

export const sound = new SoundEngine();
