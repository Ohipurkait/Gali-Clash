export type CosmeticCategory = 'skin' | 'aura';
export type CosmeticCurrency = 'futi_kodi' | 'gota';

export interface SkinPaletteOverride {
  tunic: string;
  tunicDark: string;
  pants: string;
  pantsDark: string;
  trim: string;
  aura: string;
  glow: string;
  eye?: string;
  boot?: string;
  shadesRim?: string;
  shiny?: boolean;
  motif?: 'zari' | 'bandhani' | 'bhangra' | 'vibhuti' | 'neon' | 'royal';
}

export interface SkinDef {
  id: string;
  category: 'skin';
  fighterId: string; // specific warrior this cultural skin belongs to
  name: string;
  subtitle: string;
  currency: CosmeticCurrency; // primary tier ('futi_kodi' = Standard/Mid dual-currency, 'gota' = Premium Crown Gota-only)
  price: number;
  fkPrice: number | null; // null for Premium Crown Gota-only skins
  gotaPrice: number; // ALL skins are purchasable with Gota
  palette: SkinPaletteOverride;
  isDevUnreleased?: boolean;
}

export interface AuraDef {
  id: string;
  category: 'aura';
  name: string;
  subtitle: string;
  currency: CosmeticCurrency; // primary tier ('futi_kodi' = Standard dual-currency, 'gota' = Premium Crown Gota-only)
  price: number;
  fkPrice: number | null; // null for Premium Crown Gota-only auras
  gotaPrice: number; // ALL unlockable auras are purchasable with Gota
  ringColor: string;
  sparkColor: string;
  secondaryColor?: string;
  style: 'none' | 'gulal' | 'diya' | 'chakra' | 'morpankh' | 'lotus_vip' | 'trishul_vip';
  isDevUnreleased?: boolean;
}

export type CosmeticItem = SkinDef | AuraDef;

export interface GotaPack {
  id: string;
  name: string;
  gotaAmount: number;
  bonusText: string;
  inrPrice: number;
  paymentUrl: string;
  popular?: boolean;
}

export const DEFAULT_AURA_ID = 'aura_classic';

export const GOTA_PACKS: GotaPack[] = [
  {
    id: 'gota_50',
    name: 'Starter Potli',
    gotaAmount: 50,
    bonusText: 'Starter Value',
    inrPrice: 15,
    paymentUrl: 'https://rzp.io/rzp/3o5QeINS',
  },
  {
    id: 'gota_165',
    name: 'Gali Champion Pack',
    gotaAmount: 165,
    bonusText: '150 + 15 Bonus Gota',
    inrPrice: 45,
    paymentUrl: 'https://rzp.io/rzp/NU3mnKM',
    popular: true,
  },
  {
    id: 'gota_400',
    name: 'Maharaja Treasury Pack',
    gotaAmount: 400,
    bonusText: '330 + 70 Bonus Gota',
    inrPrice: 99,
    paymentUrl: 'https://rzp.io/rzp/xp4jfGml',
  },
];

export const SKINS: SkinDef[] = [
  // 1. MUNNA BHAIYA
  {
    id: 'skin_munna_velvet',
    category: 'skin',
    fighterId: 'munna_bhaiya',
    name: 'Mirzapur Velvet',
    subtitle: 'Wine velvet kurta & golden button zari',
    currency: 'futi_kodi',
    price: 680,
    fkPrice: 680,
    gotaPrice: 20,
    palette: {
      tunic: '#881337',
      tunicDark: '#3b0719',
      pants: '#1e1b4b',
      pantsDark: '#09071a',
      trim: '#fbbf24',
      aura: '#fb7185',
      glow: '#fde047',
      eye: '#fde047',
      shadesRim: '#fbbf24',
      shiny: true,
      motif: 'zari',
    },
  },
  {
    id: 'skin_munna_gold_gota',
    category: 'skin',
    fighterId: 'munna_bhaiya',
    name: '24K Sone Ka Don',
    subtitle: 'Mirror-gold sherwani & diamond shades',
    currency: 'gota',
    price: 35,
    fkPrice: null,
    gotaPrice: 35,
    palette: {
      tunic: '#eab308',
      tunicDark: '#713f12',
      pants: '#18181b',
      pantsDark: '#09090b',
      trim: '#fef9c3',
      aura: '#facc15',
      glow: '#ffffff',
      eye: '#fef08a',
      boot: '#713f12',
      shadesRim: '#ffffff',
      shiny: true,
      motif: 'royal',
    },
  },

  // 2. CHAPPAL CHACHA
  {
    id: 'skin_chacha_bhangra',
    category: 'skin',
    fighterId: 'chappal_chacha',
    name: 'Punjabi Bhangra',
    subtitle: 'Vibrant parrot-green & kesari phulkari',
    currency: 'futi_kodi',
    price: 480,
    fkPrice: 480,
    gotaPrice: 15,
    palette: {
      tunic: '#15803d',
      tunicDark: '#052e16',
      pants: '#ea580c',
      pantsDark: '#7c2d12',
      trim: '#fde047',
      aura: '#4ade80',
      glow: '#fef08a',
      eye: '#fde047',
      shiny: true,
      motif: 'bhangra',
    },
  },
  {
    id: 'skin_chacha_kolhapuri_gota',
    category: 'skin',
    fighterId: 'chappal_chacha',
    name: 'Kolhapuri Maharaja',
    subtitle: 'Emerald silk dhoti & neon magenta trim',
    currency: 'gota',
    price: 30,
    fkPrice: null,
    gotaPrice: 30,
    palette: {
      tunic: '#0f766e',
      tunicDark: '#042f2e',
      pants: '#be185d',
      pantsDark: '#500724',
      trim: '#facc15',
      aura: '#2dd4bf',
      glow: '#f9a8d4',
      eye: '#22d3ee',
      boot: '#78350f',
      shiny: true,
      motif: 'zari',
    },
  },

  // 3. LOTA LAL
  {
    id: 'skin_lota_haldi',
    category: 'skin',
    fighterId: 'lota_lal',
    name: 'Kashi Haldi Swag',
    subtitle: 'Bright turmeric dhoti & marigold border',
    currency: 'futi_kodi',
    price: 480,
    fkPrice: 480,
    gotaPrice: 15,
    palette: {
      tunic: '#d97706',
      tunicDark: '#78350f',
      pants: '#ca8a04',
      pantsDark: '#422006',
      trim: '#bef264',
      aura: '#facc15',
      glow: '#d9f99d',
      eye: '#bef264',
      shiny: true,
      motif: 'zari',
    },
  },
  {
    id: 'skin_lota_bhasma_gota',
    category: 'skin',
    fighterId: 'lota_lal',
    name: 'Tandav Bhasma Chrome',
    subtitle: 'Silver ash metallic glow & toxic emerald',
    currency: 'gota',
    price: 25,
    fkPrice: null,
    gotaPrice: 25,
    palette: {
      tunic: '#cbd5e1',
      tunicDark: '#334155',
      pants: '#1e293b',
      pantsDark: '#020617',
      trim: '#a3e635',
      aura: '#84cc16',
      glow: '#ffffff',
      eye: '#a3e635',
      shiny: true,
      motif: 'vibhuti',
    },
  },

  // 4. BELAN BHABHI
  {
    id: 'skin_belan_dulhan',
    category: 'skin',
    fighterId: 'belan_bhabhi',
    name: 'Banarasi Zari Queen',
    subtitle: 'Royal sindoori red silk with gold pallu',
    currency: 'futi_kodi',
    price: 680,
    fkPrice: 680,
    gotaPrice: 20,
    palette: {
      tunic: '#dc2626',
      tunicDark: '#7f1d1d',
      pants: '#991b1b',
      pantsDark: '#450a0a',
      trim: '#fde047',
      aura: '#f97316',
      glow: '#fef08a',
      eye: '#fde047',
      shiny: true,
      motif: 'zari',
    },
  },
  {
    id: 'skin_belan_kundan_gota',
    category: 'skin',
    fighterId: 'belan_bhabhi',
    name: 'Kundan Maharani',
    subtitle: 'Pearl-ivory & magenta royal kundan shimmer',
    currency: 'gota',
    price: 45,
    fkPrice: null,
    gotaPrice: 45,
    palette: {
      tunic: '#db2777',
      tunicDark: '#500724',
      pants: '#f8fafc',
      pantsDark: '#64748b',
      trim: '#facc15',
      aura: '#f472b6',
      glow: '#fef9c3',
      eye: '#fef08a',
      shiny: true,
      motif: 'royal',
    },
  },

  // 5. BABAJI BOOM
  {
    id: 'skin_babaji_kumbh',
    category: 'skin',
    fighterId: 'babaji_boom',
    name: 'Kumbh Agni Robe',
    subtitle: 'Sacred bhagwa silk & golden rudraksha trim',
    currency: 'futi_kodi',
    price: 680,
    fkPrice: 680,
    gotaPrice: 20,
    palette: {
      tunic: '#f97316',
      tunicDark: '#7c2d12',
      pants: '#c2410c',
      pantsDark: '#431407',
      trim: '#fef08a',
      aura: '#fb923c',
      glow: '#fef9c3',
      eye: '#fde047',
      shiny: true,
      motif: 'vibhuti',
    },
  },
  {
    id: 'skin_babaji_kailash_gota',
    category: 'skin',
    fighterId: 'babaji_boom',
    name: 'Kailash Astral Cosmic',
    subtitle: 'Celestial violet-gold astral robe',
    currency: 'gota',
    price: 45,
    fkPrice: null,
    gotaPrice: 45,
    palette: {
      tunic: '#7e22ce',
      tunicDark: '#2e1065',
      pants: '#3b0764',
      pantsDark: '#17032b',
      trim: '#38bdf8',
      aura: '#c084fc',
      glow: '#e0f2fe',
      eye: '#7dd3fc',
      shiny: true,
      motif: 'royal',
    },
  },

  // 6. RAJU RICKSHAW
  {
    id: 'skin_raju_kaalipeeli',
    category: 'skin',
    fighterId: 'raju_rickshaw',
    name: 'Mumbai Kaali-Peeli',
    subtitle: 'Classic taxi yellow & glossy black leather',
    currency: 'futi_kodi',
    price: 480,
    fkPrice: 480,
    gotaPrice: 15,
    palette: {
      tunic: '#eab308',
      tunicDark: '#713f12',
      pants: '#18181b',
      pantsDark: '#09090b',
      trim: '#fef08a',
      aura: '#facc15',
      glow: '#ffffff',
      eye: '#facc15',
      shiny: true,
      motif: 'neon',
    },
  },
  {
    id: 'skin_raju_disco_gota',
    category: 'skin',
    fighterId: 'raju_rickshaw',
    name: 'Mithun Disco Chrome',
    subtitle: 'Holographic silver-purple 80s Bollywood gleam',
    currency: 'gota',
    price: 30,
    fkPrice: null,
    gotaPrice: 30,
    palette: {
      tunic: '#9333ea',
      tunicDark: '#3b0764',
      pants: '#e2e8f0',
      pantsDark: '#475569',
      trim: '#22d3ee',
      aura: '#e879f9',
      glow: '#67e8f9',
      eye: '#22d3ee',
      shiny: true,
      motif: 'neon',
    },
  },

  // 7. SHARMAJI BETA
  {
    id: 'skin_sharma_goldmedal',
    category: 'skin',
    fighterId: 'sharmaji_beta',
    name: 'IIT Blazer Topper',
    subtitle: 'Navy honor blazer with golden medal sash',
    currency: 'futi_kodi',
    price: 480,
    fkPrice: 480,
    gotaPrice: 15,
    palette: {
      tunic: '#1e3a8a',
      tunicDark: '#0f172a',
      pants: '#334155',
      pantsDark: '#0f172a',
      trim: '#facc15',
      aura: '#60a5fa',
      glow: '#fde047',
      eye: '#38bdf8',
      shadesRim: '#facc15',
      shiny: true,
      motif: 'zari',
    },
  },
  {
    id: 'skin_sharma_quantum_gota',
    category: 'skin',
    fighterId: 'sharmaji_beta',
    name: 'Quantum Cyber 100%',
    subtitle: 'Glowing ice-cyan holo circuit suit',
    currency: 'gota',
    price: 40,
    fkPrice: null,
    gotaPrice: 40,
    palette: {
      tunic: '#0284c7',
      tunicDark: '#082f49',
      pants: '#0f172a',
      pantsDark: '#020617',
      trim: '#67e8f9',
      aura: '#22d3ee',
      glow: '#ffffff',
      eye: '#a5f3fc',
      shadesRim: '#22d3ee',
      shiny: true,
      motif: 'neon',
    },
  },

  // 8. PADOS AUNTY
  {
    id: 'skin_aunty_bandhani',
    category: 'skin',
    fighterId: 'pados_aunty',
    name: 'Jaipuri Bandhani',
    subtitle: 'Rajasthani tie-dye rani pink & mirror border',
    currency: 'futi_kodi',
    price: 480,
    fkPrice: 480,
    gotaPrice: 15,
    palette: {
      tunic: '#e11d48',
      tunicDark: '#881337',
      pants: '#be185d',
      pantsDark: '#500724',
      trim: '#fde047',
      aura: '#fb7185',
      glow: '#fef08a',
      eye: '#fbcfe8',
      shiny: true,
      motif: 'bandhani',
    },
  },
  {
    id: 'skin_aunty_diamond_gota',
    category: 'skin',
    fighterId: 'pados_aunty',
    name: 'Kitty Queen Diamond',
    subtitle: 'Shining champagne-pearl & rose-gold saree',
    currency: 'gota',
    price: 35,
    fkPrice: null,
    gotaPrice: 35,
    palette: {
      tunic: '#f43f5e',
      tunicDark: '#4c0519',
      pants: '#f1f5f9',
      pantsDark: '#64748b',
      trim: '#fef08a',
      aura: '#fda4af',
      glow: '#ffffff',
      eye: '#ffffff',
      shiny: true,
      motif: 'royal',
    },
  },

  // 9. TRAFFIC MAMA
  {
    id: 'skin_mama_daroga',
    category: 'skin',
    fighterId: 'traffic_mama',
    name: 'Royal Khaki Sardar',
    subtitle: 'Crisp ceremonial khaki & brass star trim',
    currency: 'futi_kodi',
    price: 480,
    fkPrice: 480,
    gotaPrice: 15,
    palette: {
      tunic: '#a16207',
      tunicDark: '#422006',
      pants: '#713f12',
      pantsDark: '#271003',
      trim: '#fef08a',
      aura: '#facc15',
      glow: '#fef9c3',
      eye: '#fef08a',
      shiny: true,
      motif: 'zari',
    },
  },
  {
    id: 'skin_mama_cyber_gota',
    category: 'skin',
    fighterId: 'traffic_mama',
    name: 'Cyber Challan Neon',
    subtitle: 'Glowing reflector vest & red-green signal aura',
    currency: 'gota',
    price: 25,
    fkPrice: null,
    gotaPrice: 25,
    palette: {
      tunic: '#84cc16',
      tunicDark: '#1a2e05',
      pants: '#0f172a',
      pantsDark: '#020617',
      trim: '#38bdf8',
      aura: '#a3e635',
      glow: '#ffffff',
      eye: '#f43f5e',
      shiny: true,
      motif: 'neon',
    },
  },

  // 10. GYM BUNTY
  {
    id: 'skin_bunty_akhara',
    category: 'skin',
    fighterId: 'gym_bunty',
    name: 'Mitti Akhara Langot',
    subtitle: 'Traditional kesari pehelwan & clay red vest',
    currency: 'futi_kodi',
    price: 480,
    fkPrice: 480,
    gotaPrice: 15,
    palette: {
      tunic: '#c2410c',
      tunicDark: '#431407',
      pants: '#9a3412',
      pantsDark: '#431407',
      trim: '#fde047',
      aura: '#fb923c',
      glow: '#fed7aa',
      eye: '#fde047',
      shiny: true,
      motif: 'bhangra',
    },
  },
  {
    id: 'skin_bunty_bharat_gota',
    category: 'skin',
    fighterId: 'gym_bunty',
    name: 'Mr. Bharat 24K Armor',
    subtitle: 'Metallic gold champion belt & fiery orange',
    currency: 'gota',
    price: 40,
    fkPrice: null,
    gotaPrice: 40,
    palette: {
      tunic: '#f59e0b',
      tunicDark: '#78350f',
      pants: '#18181b',
      pantsDark: '#09090b',
      trim: '#ffffff',
      aura: '#facc15',
      glow: '#ffffff',
      eye: '#fef08a',
      shiny: true,
      motif: 'royal',
    },
  },
];

export const AURAS: AuraDef[] = [
  {
    id: 'aura_classic',
    category: 'aura',
    name: 'Asli Chamak',
    subtitle: 'Clean fighter default aura',
    currency: 'futi_kodi',
    price: 0,
    fkPrice: 0,
    gotaPrice: 0,
    ringColor: '#f59e0b',
    sparkColor: '#fde047',
    style: 'none',
  },
  {
    id: 'aura_gulal',
    category: 'aura',
    name: 'Holi Gulal Splash',
    subtitle: 'Flying pink, yellow & cyan holi sparks',
    currency: 'futi_kodi',
    price: 550,
    fkPrice: 550,
    gotaPrice: 15,
    ringColor: '#ec4899',
    sparkColor: '#fde047',
    secondaryColor: '#22d3ee',
    style: 'gulal',
  },
  {
    id: 'aura_diya',
    category: 'aura',
    name: 'Diwali Fuljhadi',
    subtitle: 'Warm golden sparkles & festive embers',
    currency: 'futi_kodi',
    price: 550,
    fkPrice: 550,
    gotaPrice: 15,
    ringColor: '#fb923c',
    sparkColor: '#fef08a',
    style: 'diya',
  },
  {
    id: 'aura_chakra',
    category: 'aura',
    name: 'Neela Sudarshan',
    subtitle: 'Spinning sacred blue energy ring',
    currency: 'futi_kodi',
    price: 550,
    fkPrice: 550,
    gotaPrice: 15,
    ringColor: '#38bdf8',
    sparkColor: '#bae6fd',
    style: 'chakra',
  },
  {
    id: 'aura_morpankh_gota',
    category: 'aura',
    name: 'Mor Pankh Shimmer',
    subtitle: 'Iridescent peacock teal-gold feathers',
    currency: 'gota',
    price: 25,
    fkPrice: null,
    gotaPrice: 25,
    ringColor: '#14b8a6',
    sparkColor: '#fde047',
    secondaryColor: '#3b82f6',
    style: 'morpankh',
  },
  {
    id: 'aura_lotus_gota',
    category: 'aura',
    name: 'Maharaja Kamal Gold',
    subtitle: 'Radiant golden lotus mandala halo',
    currency: 'gota',
    price: 30,
    fkPrice: null,
    gotaPrice: 30,
    ringColor: '#facc15',
    sparkColor: '#ffffff',
    style: 'lotus_vip',
  },
  {
    id: 'aura_trishul_gota',
    category: 'aura',
    name: 'Rudra Tandav Halo',
    subtitle: 'Blazing crimson-gold solar lightning',
    currency: 'gota',
    price: 35,
    fkPrice: null,
    gotaPrice: 35,
    ringColor: '#f43f5e',
    sparkColor: '#fde047',
    style: 'trishul_vip',
  },
];

export const ALL_COSMETICS: CosmeticItem[] = [...SKINS, ...AURAS];

export const ALL_SKIN_IDS: string[] = SKINS.map((s) => s.id);
export const FREE_COSMETIC_IDS: string[] = ALL_COSMETICS.filter((c) => c.fkPrice !== null).map((c) => c.id);
export const ALL_COSMETIC_IDS: string[] = ALL_COSMETICS.map((c) => c.id);

// Runtime-only registry populated EXCLUSIVELY during an active Developer Mode session.
// Kept empty for regular players so production bundles & Firestore payloads stay clean.
let runtimeDevSkins: SkinDef[] = [];
let runtimeDevAuras: AuraDef[] = [];
let runtimeDevPreviewSkin: SkinDef | null = null;
let runtimeDevPreviewAura: AuraDef | null = null;

export function setDevStagePreviewCosmetic(skin: SkinDef | null, aura: AuraDef | null): void {
  runtimeDevPreviewSkin = skin;
  runtimeDevPreviewAura = aura;
}

export function setDevUnreleasedCosmetics(items: CosmeticItem[]): void {
  runtimeDevSkins = items.filter((item): item is SkinDef => item.category === 'skin');
  runtimeDevAuras = items.filter((item): item is AuraDef => item.category === 'aura');
}

export function getAllSkins(includeDev = false): SkinDef[] {
  return includeDev && runtimeDevSkins.length > 0 ? [...SKINS, ...runtimeDevSkins] : SKINS;
}

export function getAllAuras(includeDev = false): AuraDef[] {
  return includeDev && runtimeDevAuras.length > 0 ? [...AURAS, ...runtimeDevAuras] : AURAS;
}

export function getAllCosmetics(includeDev = false): CosmeticItem[] {
  return includeDev ? [...getAllSkins(true), ...getAllAuras(true)] : ALL_COSMETICS;
}

export function isDevUnreleasedCosmeticId(id?: string | null): boolean {
  if (!id) return false;
  return runtimeDevSkins.some((s) => s.id === id) || runtimeDevAuras.some((a) => a.id === id) || id.startsWith('dev_');
}

export function getSkinById(id?: string | null): SkinDef | undefined {
  if (!id) return undefined;
  if (runtimeDevPreviewSkin && runtimeDevPreviewSkin.id === id) return runtimeDevPreviewSkin;
  return SKINS.find((s) => s.id === id) || runtimeDevSkins.find((s) => s.id === id);
}

export function getEquippedSkinForFighter(equippedSkinIds: string[] | undefined, fighterId: string): SkinDef | undefined {
  if (!Array.isArray(equippedSkinIds) || equippedSkinIds.length === 0) return undefined;
  return (
    runtimeDevSkins.find((s) => s.fighterId === fighterId && equippedSkinIds.includes(s.id)) ||
    SKINS.find((s) => s.fighterId === fighterId && equippedSkinIds.includes(s.id))
  );
}

export function getAuraById(id?: string | null): AuraDef {
  if (id && runtimeDevPreviewAura && runtimeDevPreviewAura.id === id) return runtimeDevPreviewAura;
  return (
    AURAS.find((a) => a.id === id) ||
    runtimeDevAuras.find((a) => a.id === id) ||
    AURAS[0]
  );
}
