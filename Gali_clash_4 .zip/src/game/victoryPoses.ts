export interface VictoryPoseDef {
  id: string;
  fighterId: string;
  poseName: string;
  vibe: string;
  kinematicKey:
    | 'hero_raise'
    | 'crane_kick'
    | 'levitate_blessing'
    | 'lotus_float'
    | 'tandav_nataraja'
    | 'double_bicep'
    | 'bodybuilder_knee'
    | 'katta_swagger'
    | 'throne_aim'
    | 'guard_salute'
    | 'glasses_push'
    | 'hip_pop_crown'
    | 'akhara_horse'
    | 'wheelie_lean'
    | 'baton_halt';
}

export const FIGHTER_VICTORY_POSES: Record<string, VictoryPoseDef[]> = {
  munna_bhaiya: [
    {
      id: 'gaddi_salute',
      fighterId: 'munna_bhaiya',
      poseName: 'Gaddi Salute',
      vibe: 'Skyward Katta & King Swagger',
      kinematicKey: 'katta_swagger',
    },
    {
      id: 'mirzapur_throne',
      fighterId: 'munna_bhaiya',
      poseName: 'Gali Throne Aim',
      vibe: 'Wide Power Stance & Deadeye Aim',
      kinematicKey: 'throne_aim',
    },
    {
      id: 'baahubali_raise',
      fighterId: 'munna_bhaiya',
      poseName: 'Baahubali Boss Raise',
      vibe: 'Twin-Arm Royal Akhara Salute',
      kinematicKey: 'hero_raise',
    },
  ],
  chappal_chacha: [
    {
      id: 'chappal_crane',
      fighterId: 'chappal_chacha',
      poseName: 'Flying Chappal Crane',
      vibe: 'One-Legged Samurai Balance',
      kinematicKey: 'crane_kick',
    },
    {
      id: 'sanskari_horse',
      fighterId: 'chappal_chacha',
      poseName: 'Sanskari Horse Stance',
      vibe: 'Deep Akhara Kung-Fu Guard',
      kinematicKey: 'akhara_horse',
    },
    {
      id: 'chacha_triumph',
      fighterId: 'chappal_chacha',
      poseName: 'Chowk Master Salute',
      vibe: 'High Chappal Crown Flourish',
      kinematicKey: 'hero_raise',
    },
  ],
  lota_lal: [
    {
      id: 'lota_flex',
      fighterId: 'lota_lal',
      poseName: 'Lota Victory Flex',
      vibe: 'Wide Sumo Champion Stance',
      kinematicKey: 'double_bicep',
    },
    {
      id: 'brass_abhishek',
      fighterId: 'lota_lal',
      poseName: 'Shahi Lota Hoist',
      vibe: 'Skyward Hammered Brass Raise',
      kinematicKey: 'hero_raise',
    },
    {
      id: 'akhara_thump',
      fighterId: 'lota_lal',
      poseName: 'Pehalwan Thigh Roar',
      vibe: 'Deep Kushti Victory Squat',
      kinematicKey: 'akhara_horse',
    },
  ],
  belan_bhabhi: [
    {
      id: 'tawa_triumph',
      fighterId: 'belan_bhabhi',
      poseName: 'Tawa Queen Triumph',
      vibe: 'Overhead Belan Crown Hold',
      kinematicKey: 'hero_raise',
    },
    {
      id: 'rasoi_warrior',
      fighterId: 'belan_bhabhi',
      poseName: 'Rasoi Warrior Crane',
      vibe: 'Fierce High-Knee Belan Strike',
      kinematicKey: 'crane_kick',
    },
    {
      id: 'maharani_swag',
      fighterId: 'belan_bhabhi',
      poseName: 'Maharani Hip Crown',
      vibe: 'Regal One-Hand Hip Victory',
      kinematicKey: 'hip_pop_crown',
    },
  ],
  babaji_boom: [
    {
      id: 'brahmastra_levitate',
      fighterId: 'babaji_boom',
      poseName: 'Brahmastra Levitation',
      vibe: 'Twin-Arm Cosmic Blessing',
      kinematicKey: 'levitate_blessing',
    },
    {
      id: 'padmasana_float',
      fighterId: 'babaji_boom',
      poseName: 'Lotus Chakra Float',
      vibe: 'Mid-Air Cross-Legged Meditation',
      kinematicKey: 'lotus_float',
    },
    {
      id: 'trishul_tandav',
      fighterId: 'babaji_boom',
      poseName: 'Tandav Nataraja Pose',
      vibe: 'Sacred One-Leg Cosmic Dance',
      kinematicKey: 'tandav_nataraja',
    },
  ],
  raju_rickshaw: [
    {
      id: 'meter_down_raise',
      fighterId: 'raju_rickshaw',
      poseName: 'Meter Down Horn Raise',
      vibe: 'Street Racer Finish',
      kinematicKey: 'hero_raise',
    },
    {
      id: 'wheelie_swag',
      fighterId: 'raju_rickshaw',
      poseName: 'Auto Wheelie Lean',
      vibe: 'Turbo Drift Back-Lean Swagger',
      kinematicKey: 'wheelie_lean',
    },
    {
      id: 'chowk_hypeman',
      fighterId: 'raju_rickshaw',
      poseName: 'Chowk Boss Point',
      vibe: 'Crossed Stance Deadeye Point',
      kinematicKey: 'throne_aim',
    },
  ],
  sharmaji_beta: [
    {
      id: 'topper_v_sign',
      fighterId: 'sharmaji_beta',
      poseName: 'Topper V-Sign',
      vibe: '99.9% Scholar Perfection',
      kinematicKey: 'guard_salute',
    },
    {
      id: 'anime_glasses_push',
      fighterId: 'sharmaji_beta',
      poseName: 'Genius Specs Adjust',
      vibe: 'Cool Scholar Frame Glint',
      kinematicKey: 'glasses_push',
    },
    {
      id: 'gold_medal_raise',
      fighterId: 'sharmaji_beta',
      poseName: 'All-India Rank #1',
      vibe: 'Skyward Gold Plaque Hoist',
      kinematicKey: 'hero_raise',
    },
  ],
  pados_aunty: [
    {
      id: 'society_queen',
      fighterId: 'pados_aunty',
      poseName: 'Society Queen Pose',
      vibe: 'Purse-High Gossip Crown',
      kinematicKey: 'hip_pop_crown',
    },
    {
      id: 'mohalla_champ',
      fighterId: 'pados_aunty',
      poseName: 'Mohalla Purse Raise',
      vibe: 'High Sequined Clutch Victory',
      kinematicKey: 'hero_raise',
    },
    {
      id: 'kitty_party_crane',
      fighterId: 'pados_aunty',
      poseName: 'Kitty Party Runway',
      vibe: 'Confident High-Step Runway Stance',
      kinematicKey: 'crane_kick',
    },
  ],
  traffic_mama: [
    {
      id: 'red_light_command',
      fighterId: 'traffic_mama',
      poseName: 'Red Light Command',
      vibe: 'Whistle Halt Stance',
      kinematicKey: 'baton_halt',
    },
    {
      id: 'challan_salute',
      fighterId: 'traffic_mama',
      poseName: 'Challan Parade Salute',
      vibe: 'Crisp Uniform Officer Salute',
      kinematicKey: 'guard_salute',
    },
    {
      id: 'chowk_inspector',
      fighterId: 'traffic_mama',
      poseName: 'Chowk Inspector Stance',
      vibe: 'Wide Guard & Whistle Hoist',
      kinematicKey: 'hero_raise',
    },
  ],
  gym_bunty: [
    {
      id: 'most_muscular',
      fighterId: 'gym_bunty',
      poseName: 'Most Muscular Bro',
      vibe: 'Double Bicep Protein Flex',
      kinematicKey: 'double_bicep',
    },
    {
      id: 'olympia_knee_pose',
      fighterId: 'gym_bunty',
      poseName: 'Mr. Akhara Knee Flex',
      vibe: 'Classic Bodybuilding Victory Knee',
      kinematicKey: 'bodybuilder_knee',
    },
    {
      id: 'heavy_press_raise',
      fighterId: 'gym_bunty',
      poseName: 'Max PR Dumbbell Press',
      vibe: 'Single-Arm Overhead Steel Hoist',
      kinematicKey: 'hero_raise',
    },
  ],
};

const POSE_STORAGE_KEY = 'gali_clash_victory_poses_v1';

export interface VictoryPosePrice {
  index: 1 | 2 | 3;
  isFreeDefault: boolean;
  fkPrice: number;
  gotaPrice: number;
}

export const ALL_UNLOCKABLE_POSE_IDS: string[] = Object.values(FIGHTER_VICTORY_POSES).flatMap((list) =>
  list.slice(1).map((p) => p.id),
);

export function getVictoryPosesForFighter(fighterId: string): VictoryPoseDef[] {
  return FIGHTER_VICTORY_POSES[fighterId] || FIGHTER_VICTORY_POSES.munna_bhaiya;
}

export function getVictoryPoseById(fighterId: string, poseId?: string | null): VictoryPoseDef {
  const list = getVictoryPosesForFighter(fighterId);
  if (!poseId) return list[0];
  return list.find((p) => p.id === poseId) || list[0];
}

export function getVictoryPosePrice(fighterId: string, poseId: string): VictoryPosePrice {
  const list = getVictoryPosesForFighter(fighterId);
  const idx = list.findIndex((p) => p.id === poseId);
  if (idx === 1) return { index: 2, isFreeDefault: false, fkPrice: 400, gotaPrice: 12 };
  if (idx === 2) return { index: 3, isFreeDefault: false, fkPrice: 650, gotaPrice: 18 };
  return { index: 1, isFreeDefault: true, fkPrice: 0, gotaPrice: 0 };
}

export function isVictoryPoseUnlocked(
  fighterId: string,
  poseId: string,
  unlockedPoses?: string[] | null,
): boolean {
  const price = getVictoryPosePrice(fighterId, poseId);
  if (price.isFreeDefault) return true;
  return Array.isArray(unlockedPoses) && unlockedPoses.includes(poseId);
}

export function loadSelectedVictoryPoses(): Record<string, string> {
  try {
    const raw = window.localStorage.getItem(POSE_STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as unknown;
    if (!parsed || typeof parsed !== 'object') return {};
    return parsed as Record<string, string>;
  } catch {
    return {};
  }
}

export function getSelectedVictoryPoseId(fighterId: string): string {
  const map = loadSelectedVictoryPoses();
  return getVictoryPoseById(fighterId, map[fighterId]).id;
}

export function saveSelectedVictoryPoseId(fighterId: string, poseId: string): void {
  try {
    const map = loadSelectedVictoryPoses();
    map[fighterId] = poseId;
    window.localStorage.setItem(POSE_STORAGE_KEY, JSON.stringify(map));
  } catch {
    // ignore storage quota errors
  }
}
