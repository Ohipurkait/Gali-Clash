import { DEFAULT_KEY_BINDS } from './data';
import { CombatButtonKind, ControlLayoutConfig } from './types';

const STORAGE_KEY = 'scc_controls_config_v3';

export const DEFAULT_CONTROL_CONFIG: ControlLayoutConfig = {
  scale: 1.0,
  opacity: 0.94,
  touchMode: 'always',
  dpadScale: 1.0,
  dpadOffset: { x: 0, y: 0 },
  clusterOffset: { x: 0, y: 0 },
  buttonOffsets: {},
  buttonScales: {},
  showLabels: true,
  showKeyHints: true,
  snapToGrid: false,
  keyBinds: { ...DEFAULT_KEY_BINDS },
};

export function loadControlConfig(): ControlLayoutConfig {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return cloneDefaultConfig();
    const parsed = JSON.parse(raw) as Partial<ControlLayoutConfig>;
    return {
      scale: typeof parsed.scale === 'number' ? Math.max(0.75, Math.min(1.35, parsed.scale)) : 1.0,
      opacity: typeof parsed.opacity === 'number' ? Math.max(0.35, Math.min(1.0, parsed.opacity)) : 0.94,
      touchMode: parsed.touchMode === 'auto' || parsed.touchMode === 'compact' ? parsed.touchMode : 'always',
      dpadScale: typeof parsed.dpadScale === 'number' ? Math.max(0.75, Math.min(1.45, parsed.dpadScale)) : 1.0,
      dpadOffset:
        parsed.dpadOffset && typeof parsed.dpadOffset.x === 'number' && typeof parsed.dpadOffset.y === 'number'
          ? parsed.dpadOffset
          : { x: 0, y: 0 },
      clusterOffset:
        parsed.clusterOffset && typeof parsed.clusterOffset.x === 'number' && typeof parsed.clusterOffset.y === 'number'
          ? parsed.clusterOffset
          : { x: 0, y: 0 },
      buttonOffsets: parsed.buttonOffsets && typeof parsed.buttonOffsets === 'object' ? parsed.buttonOffsets : {},
      buttonScales: parsed.buttonScales && typeof parsed.buttonScales === 'object' ? parsed.buttonScales : {},
      showLabels: typeof parsed.showLabels === 'boolean' ? parsed.showLabels : true,
      showKeyHints: typeof parsed.showKeyHints === 'boolean' ? parsed.showKeyHints : true,
      snapToGrid: typeof parsed.snapToGrid === 'boolean' ? parsed.snapToGrid : false,
      keyBinds: {
        basic: parsed.keyBinds?.basic || DEFAULT_KEY_BINDS.basic,
        sp1: parsed.keyBinds?.sp1 || DEFAULT_KEY_BINDS.sp1,
        sp2: parsed.keyBinds?.sp2 || DEFAULT_KEY_BINDS.sp2,
        dash: parsed.keyBinds?.dash || DEFAULT_KEY_BINDS.dash,
        shield: parsed.keyBinds?.shield || DEFAULT_KEY_BINDS.shield,
        rage: parsed.keyBinds?.rage || DEFAULT_KEY_BINDS.rage,
      },
    };
  } catch {
    return cloneDefaultConfig();
  }
}

export function saveControlConfig(cfg: ControlLayoutConfig): void {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(cfg));
  } catch {
    // ignore storage quota errors
  }
}

export function cloneDefaultConfig(): ControlLayoutConfig {
  return {
    scale: DEFAULT_CONTROL_CONFIG.scale,
    opacity: DEFAULT_CONTROL_CONFIG.opacity,
    touchMode: DEFAULT_CONTROL_CONFIG.touchMode,
    dpadScale: DEFAULT_CONTROL_CONFIG.dpadScale,
    dpadOffset: { ...DEFAULT_CONTROL_CONFIG.dpadOffset },
    clusterOffset: { ...DEFAULT_CONTROL_CONFIG.clusterOffset },
    buttonOffsets: {},
    buttonScales: {},
    showLabels: DEFAULT_CONTROL_CONFIG.showLabels,
    showKeyHints: DEFAULT_CONTROL_CONFIG.showKeyHints,
    snapToGrid: DEFAULT_CONTROL_CONFIG.snapToGrid,
    keyBinds: { ...DEFAULT_KEY_BINDS },
  };
}

export function formatKeyLabel(key: string): string {
  if (key === ' ') return 'SPC';
  if (key === 'arrowup') return '↑';
  if (key === 'arrowdown') return '↓';
  if (key === 'arrowleft') return '←';
  if (key === 'arrowright') return '→';
  if (key === 'shift') return 'SHF';
  return key.toUpperCase().slice(0, 3);
}

export const ACTION_LABELS: Record<CombatButtonKind, { name: string; desc: string }> = {
  basic: { name: 'BASIC', desc: 'Punch + Kick 3-Hit Combo (+Dir = Sweep / High)' },
  sp1: { name: 'SKILL 1', desc: 'Long-Range Projectile Attack' },
  sp2: { name: 'SKILL 2', desc: 'Close-Range Burst Strike' },
  dash: { name: 'DASH', desc: 'Quick Dodge / Air Dash' },
  shield: { name: 'SHIELD', desc: 'Hold to Guard · Tap on Impact to Parry!' },
  rage: { name: 'ULTIMATE', desc: 'Chakra Finisher (100% Energy)' },
};
