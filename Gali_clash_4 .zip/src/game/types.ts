export type ScreenId = 'menu' | 'mp' | 'select' | 'combat';
export type GameMode = 'bot' | 'mp';
export type Difficulty = 'easy' | 'normal' | 'hard';
export type ArenaId = 'chandni' | 'howrah' | 'banaras';
export type MatchPhase = 'MENU' | 'INTRO' | 'FIGHT' | 'ROUND_END' | 'MATCH_OVER';

export type MoveSpecial = false | 'SP1' | 'SP2' | 'RAGE' | 'THROW';

export interface MoveDef {
  key: string;
  startup: number;
  active: number;
  recovery: number;
  dmg: number;
  knockX: number;
  knockY: number;
  range: number;
  special: MoveSpecial;
  antiAir?: boolean;
  low?: boolean;
  projectile?: boolean;
  dashSpeed?: number;
  waveDmg?: number;
}

export interface FighterConfig {
  id: string;
  name: string;
  title: string;
  prop: string;
  eye: string;
  aura: string;
  glow: string;
  speed: number;
  sp1Name: string;
  sp2Name: string;
  rageName: string;
  sp1Sfx: string;
  sp2Sfx: string;
  quote: string;
}

export interface ArenaTheme {
  id: ArenaId;
  name: string;
  skyTop: string;
  skyMid: string;
  skyBot: string;
  floorTop: string;
  floorBot: string;
  rim: string;
  moonCol: string;
}

export interface HudSnapshot {
  p1Name: string;
  p2Name: string;
  p1Hp: number;
  p1MaxHp: number;
  p2Hp: number;
  p2MaxHp: number;
  p1Rage: number;
  p2Rage: number;
  p1Awakened: boolean;
  p2Awakened: boolean;
  p1Wins: number;
  p2Wins: number;
  round: number;
  timer: number;
  p1Sp1Cd: number;
  p1Sp2Cd: number;
  p1DashCd: number;
  p2Sp1Cd: number;
  p2Sp2Cd: number;
  p2DashCd: number;
  localSlot: 1 | 2;
  practice: boolean;
  comboCount: number;
  comboDamage: number;
  maxCombo: number;
  mpPingMs: number | null;
}

export interface SkinLoadout {
  skinId: string;
  auraId: string;
}

export interface VictoryInfo {
  winnerId: string;
  loserId: string;
  winnerName: string;
  winnerTitle: string;
  loserName: string;
  loserTitle: string;
  quote: string;
  winnerSlot: 1 | 2;
  localSlot: 1 | 2;
  p1Wins: number;
  p2Wins: number;
  localMaxCombo: number;
  mode: GameMode;
  arenaId: ArenaId;
  p1SkinId?: string;
  p2SkinId?: string;
  p1AuraId?: string;
  p2AuraId?: string;
}

export type StickerEmoteId = 'namaste' | 'chappal' | 'chai' | 'fire' | 'op' | 'cry';

export interface StickerEmoteDef {
  id: StickerEmoteId;
  emoji: string;
  label: string;
  accent: string;
  keyHint: string;
}

export type CombatButtonKind = 'basic' | 'sp1' | 'sp2' | 'dash' | 'shield' | 'rage';

export type CustomizableControlTarget = 'dpad' | CombatButtonKind;

export type TouchDisplayMode = 'auto' | 'always' | 'compact';

export interface PointOffset {
  x: number;
  y: number;
}

export interface ControlLayoutConfig {
  scale: number;
  opacity: number;
  touchMode: TouchDisplayMode;
  dpadScale: number;
  dpadOffset: PointOffset;
  clusterOffset: PointOffset;
  buttonOffsets: Partial<Record<CombatButtonKind, PointOffset>>;
  buttonScales: Partial<Record<CombatButtonKind, number>>;
  showLabels: boolean;
  showKeyHints: boolean;
  snapToGrid: boolean;
  keyBinds: Record<CombatButtonKind, string>;
}
