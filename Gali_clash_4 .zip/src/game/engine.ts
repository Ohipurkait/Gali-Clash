import { sound } from './audio';
import { AuraDef, DEFAULT_AURA_ID, getAuraById, getSkinById, SkinPaletteOverride } from './cosmetics';
import { ARENAS, CHAR_MOVES, FIGHTERS, getCfgById, MOVES, STICKER_EMOTES, WORLD } from './data';
import { getSelectedVictoryPoseId, getVictoryPoseById, VictoryPoseDef } from './victoryPoses';
import { LobbyThemeId } from '../services/devCms';
import { cleanupActiveRoomLifecycle, registerActiveRoomLifecycle } from '../services/roomCleanup';
import {
  ArenaId,
  CombatButtonKind,
  Difficulty,
  FighterConfig,
  GameMode,
  HudSnapshot,
  MatchPhase,
  MoveDef,
  StickerEmoteId,
  VictoryInfo,
} from './types';

function adjustHexColor(hex: string, amount: number): string {
  if (!hex || hex.charAt(0) !== '#') return hex || '#d89b6e';
  let c = hex.slice(1);
  if (c.length === 3) c = c[0] + c[0] + c[1] + c[1] + c[2] + c[2];
  const n = parseInt(c, 16);
  const r = Math.max(0, Math.min(255, ((n >> 16) & 255) + amount));
  const g = Math.max(0, Math.min(255, ((n >> 8) & 255) + Math.round(amount * 0.9)));
  const b = Math.max(0, Math.min(255, (n & 255) + Math.round(amount * 0.78)));
  return `rgb(${r},${g},${b})`;
}

function hexToRgba(hex: string, alpha: number): string {
  if (!hex || hex.charAt(0) !== '#') return `rgba(244,63,94,${alpha})`;
  let c = hex.slice(1);
  if (c.length === 3) c = c[0] + c[0] + c[1] + c[1] + c[2] + c[2];
  const n = parseInt(c, 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${alpha})`;
}

interface CharacterLook {
  skin: string;
  skinDark: string;
  tunic: string;
  tunicDark: string;
  pants: string;
  pantsDark: string;
  trim: string;
  hair: string;
  bareArms: boolean;
  hasBeard?: 'stubble' | 'long' | 'moustache';
  headgear?: 'shades' | 'specs' | 'cap' | 'bandana' | 'headband' | 'bun' | 'jata' | 'bald';
  shadesRim?: string;
  shiny?: boolean;
  motif?: SkinPaletteOverride['motif'];
}

const CHARACTER_LOOKS: Record<string, CharacterLook> = {
  munna_bhaiya: {
    skin: '#c48356', skinDark: '#78462a',
    tunic: '#5c1828', tunicDark: '#260a12',
    pants: '#252236', pantsDark: '#0f0e1a',
    trim: '#fbbf24', hair: '#18141e',
    bareArms: false, hasBeard: 'stubble', headgear: 'shades',
  },
  chappal_chacha: {
    skin: '#b8764b', skinDark: '#6e3f22',
    tunic: '#312e59', tunicDark: '#15132b',
    pants: '#221f35', pantsDark: '#0d0c18',
    trim: '#f472b6', hair: '#94a3b8',
    bareArms: false, hasBeard: 'moustache',
  },
  lota_lal: {
    skin: '#cc8d5e', skinDark: '#824d2b',
    tunic: '#854d0e', tunicDark: '#3f2205',
    pants: '#ca8a04', pantsDark: '#593b04',
    trim: '#a3e635', hair: '#2c252c',
    bareArms: true, hasBeard: 'moustache', headgear: 'bald',
  },
  belan_bhabhi: {
    skin: '#cf9369', skinDark: '#855132',
    tunic: '#c2410c', tunicDark: '#571905',
    pants: '#7c2d12', pantsDark: '#361206',
    trim: '#fde047', hair: '#15111a',
    bareArms: false, headgear: 'bun',
  },
  babaji_boom: {
    skin: '#b8794d', skinDark: '#704124',
    tunic: '#d97706', tunicDark: '#6b3204',
    pants: '#b45309', pantsDark: '#4a1f04',
    trim: '#fde047', hair: '#cbd5e1',
    bareArms: true, hasBeard: 'long', headgear: 'jata',
  },
  raju_rickshaw: {
    skin: '#b57348', skinDark: '#6b3c1f',
    tunic: '#4d5d2d', tunicDark: '#202812',
    pants: '#27272a', pantsDark: '#101014',
    trim: '#facc15', hair: '#17141d',
    bareArms: false, headgear: 'bandana',
  },
  sharmaji_beta: {
    skin: '#d1986e', skinDark: '#875436',
    tunic: '#1d4ed8', tunicDark: '#0e225c',
    pants: '#1e293b', pantsDark: '#0b101b',
    trim: '#e0f2fe', hair: '#171520',
    bareArms: false, headgear: 'specs',
  },
  pados_aunty: {
    skin: '#ca8c62', skinDark: '#7f4c2d',
    tunic: '#be123c', tunicDark: '#54061b',
    pants: '#881337', pantsDark: '#3b0718',
    trim: '#fbcfe8', hair: '#27202b',
    bareArms: false, headgear: 'bun',
  },
  traffic_mama: {
    skin: '#b9774b', skinDark: '#6e3f22',
    tunic: '#cbd5e1', tunicDark: '#475569',
    pants: '#3f3f46', pantsDark: '#18181b',
    trim: '#facc15', hair: '#1e1b24',
    bareArms: false, hasBeard: 'moustache', headgear: 'cap',
  },
  gym_bunty: {
    skin: '#c58355', skinDark: '#7a4626',
    tunic: '#ea580c', tunicDark: '#6b2304',
    pants: '#1e293b', pantsDark: '#090d16',
    trim: '#fed7aa', hair: '#17131d',
    bareArms: true, headgear: 'headband',
  },
};

function getCharacterLook(id: string, skinId?: string | null): CharacterLook {
  const base = CHARACTER_LOOKS[id] || CHARACTER_LOOKS.munna_bhaiya;
  const skin = getSkinById(skinId);
  if (!skin || skin.fighterId !== id) return base;
  return {
    ...base,
    tunic: skin.palette.tunic,
    tunicDark: skin.palette.tunicDark,
    pants: skin.palette.pants,
    pantsDark: skin.palette.pantsDark,
    trim: skin.palette.trim,
    shadesRim: skin.palette.shadesRim,
    shiny: skin.palette.shiny,
    motif: skin.palette.motif,
  };
}

function getFighterVisualPalette(cfg: FighterConfig, skinId?: string | null, auraId?: string | null) {
  const rawSkin = getSkinById(skinId);
  const skin = rawSkin && rawSkin.fighterId === cfg.id ? rawSkin : undefined;
  const auraDef = getAuraById(auraId);
  return {
    auraCol: skin?.palette.aura || cfg.aura,
    glowCol: skin?.palette.glow || cfg.glow,
    eyeCol: skin?.palette.eye || cfg.eye,
    bootOverride: skin?.palette.boot,
    auraDef,
  };
}

function drawCosmeticAuraStage(
  ctx: CanvasRenderingContext2D,
  cx: number,
  groundY: number,
  t: number,
  scaleX: number,
  aura: AuraDef,
): void {
  if (aura.style === 'none') return;
  ctx.save();
  if (aura.style === 'gulal') {
    const pulse = 0.9 + Math.sin(t * 5.2) * 0.1;
    ctx.strokeStyle = hexToRgba(aura.ringColor, 0.78);
    ctx.lineWidth = 2.6;
    ctx.beginPath();
    ctx.ellipse(cx, groundY + 2, 48 * scaleX * pulse, 11 * scaleX * pulse, 0, 0, Math.PI * 2);
    ctx.stroke();
    const cols = [aura.ringColor, aura.sparkColor, aura.secondaryColor || '#22d3ee'];
    for (let i = 0; i < 9; i++) {
      const ang = t * 2.1 + (i * Math.PI * 2) / 9;
      const fx = cx + Math.cos(ang) * (28 + (i % 3) * 8) * scaleX;
      const fy = groundY - (10 + ((t * 40 + i * 17) % 72)) * scaleX;
      ctx.fillStyle = hexToRgba(cols[i % cols.length], 0.76);
      ctx.beginPath();
      ctx.arc(fx, fy, (3.2 + (i % 2) * 1.4) * scaleX, 0, Math.PI * 2);
      ctx.fill();
    }
  } else if (aura.style === 'diya') {
    const pulse = 0.88 + Math.sin(t * 7.5) * 0.11;
    const grad = ctx.createRadialGradient(cx, groundY + 2, 3, cx, groundY + 2, 54 * scaleX);
    grad.addColorStop(0, hexToRgba(aura.sparkColor, 0.36));
    grad.addColorStop(0.65, hexToRgba(aura.ringColor, 0.22));
    grad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.ellipse(cx, groundY + 2, 54 * scaleX * pulse, 13 * scaleX, 0, 0, Math.PI * 2);
    ctx.fill();
    for (let i = 0; i < 8; i++) {
      const ang = t * 2.9 + (i * Math.PI * 2) / 8;
      const fx = cx + Math.cos(ang) * 34 * scaleX;
      const fy = groundY - (8 + ((t * 56 + i * 19) % 78)) * scaleX;
      ctx.fillStyle = i % 2 === 0 ? hexToRgba(aura.sparkColor, 0.9) : hexToRgba(aura.ringColor, 0.8);
      ctx.beginPath();
      ctx.arc(fx, fy, 2.6 * scaleX, 0, Math.PI * 2);
      ctx.fill();
    }
  } else if (aura.style === 'chakra') {
    ctx.save();
    ctx.translate(cx, groundY - 76 * scaleX);
    ctx.rotate(t * 0.95);
    ctx.strokeStyle = hexToRgba(aura.ringColor, 0.65);
    ctx.lineWidth = 2.4 * scaleX;
    ctx.setLineDash([10 * scaleX, 6 * scaleX]);
    ctx.beginPath();
    ctx.arc(0, 0, 56 * scaleX, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();
    ctx.strokeStyle = hexToRgba(aura.sparkColor, 0.72);
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    ctx.ellipse(cx, groundY + 2, 48 * scaleX, 11 * scaleX, 0, 0, Math.PI * 2);
    ctx.stroke();
  } else if (aura.style === 'morpankh') {
    ctx.strokeStyle = hexToRgba(aura.ringColor, 0.8);
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.ellipse(cx, groundY + 2, 52 * scaleX, 12 * scaleX, 0, 0, Math.PI * 2);
    ctx.stroke();
    for (let i = 0; i < 6; i++) {
      const ang = t * 1.4 + (i * Math.PI * 2) / 6;
      const px = cx + Math.cos(ang) * 40 * scaleX;
      const py = groundY - (48 + Math.sin(ang * 2) * 28) * scaleX;
      ctx.fillStyle = hexToRgba(aura.ringColor, 0.75);
      ctx.beginPath();
      ctx.ellipse(px, py, 5.5 * scaleX, 3.2 * scaleX, ang, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = hexToRgba(aura.secondaryColor || '#3b82f6', 0.9);
      ctx.beginPath();
      ctx.arc(px, py, 2.2 * scaleX, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = hexToRgba(aura.sparkColor, 0.95);
      ctx.beginPath();
      ctx.arc(px + 0.5, py, 1.0 * scaleX, 0, Math.PI * 2);
      ctx.fill();
    }
  } else if (aura.style === 'lotus_vip') {
    const grad = ctx.createRadialGradient(cx, groundY + 2, 4, cx, groundY + 2, 60 * scaleX);
    grad.addColorStop(0, hexToRgba(aura.sparkColor, 0.45));
    grad.addColorStop(0.65, hexToRgba(aura.ringColor, 0.34));
    grad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.ellipse(cx, groundY + 2, 60 * scaleX, 14 * scaleX, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.save();
    ctx.translate(cx, groundY - 76 * scaleX);
    ctx.rotate(t * 0.55);
    ctx.strokeStyle = hexToRgba(aura.ringColor, 0.65);
    ctx.lineWidth = 1.8 * scaleX;
    for (let p = 0; p < 8; p++) {
      const a = (p * Math.PI * 2) / 8;
      ctx.save();
      ctx.rotate(a);
      ctx.beginPath();
      ctx.ellipse(0, -48 * scaleX, 7 * scaleX, 15 * scaleX, 0, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }
    ctx.restore();
    for (let i = 0; i < 8; i++) {
      const ang = t * 2.0 + (i * Math.PI * 2) / 8;
      const sx = cx + Math.cos(ang) * 42 * scaleX;
      const sy = groundY - (44 + Math.sin(ang * 2) * 30) * scaleX;
      ctx.fillStyle = hexToRgba(aura.sparkColor, 0.92);
      ctx.beginPath();
      ctx.arc(sx, sy, 2.3 * scaleX, 0, Math.PI * 2);
      ctx.fill();
    }
  } else if (aura.style === 'trishul_vip') {
    ctx.save();
    ctx.translate(cx, groundY - 78 * scaleX);
    ctx.rotate(t * 0.75);
    ctx.strokeStyle = hexToRgba(aura.sparkColor, 0.72);
    ctx.lineWidth = 2.2 * scaleX;
    ctx.beginPath();
    ctx.arc(0, 0, 58 * scaleX, 0, Math.PI * 2);
    ctx.stroke();
    for (let r = 0; r < 8; r++) {
      const a = (r * Math.PI * 2) / 8;
      ctx.beginPath();
      ctx.moveTo(Math.cos(a) * 48 * scaleX, Math.sin(a) * 48 * scaleX);
      ctx.lineTo(Math.cos(a) * 66 * scaleX, Math.sin(a) * 66 * scaleX);
      ctx.stroke();
    }
    ctx.restore();
    ctx.strokeStyle = hexToRgba(aura.ringColor, 0.85);
    ctx.lineWidth = 2.6;
    ctx.beginPath();
    ctx.ellipse(cx, groundY + 2, 54 * scaleX, 12.5 * scaleX, 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.strokeStyle = hexToRgba(aura.sparkColor, 0.9);
    ctx.lineWidth = 1.6;
    for (let b = 0; b < 3; b++) {
      const bx = cx + Math.sin(t * 14 + b * 2.1) * 32 * scaleX;
      const by = groundY - (20 + b * 28) * scaleX;
      ctx.beginPath();
      ctx.moveTo(bx - 5 * scaleX, by + 8 * scaleX);
      ctx.lineTo(bx + 4 * scaleX, by);
      ctx.lineTo(bx - 3 * scaleX, by - 10 * scaleX);
      ctx.stroke();
    }
  }
  ctx.restore();
}

function drawRealisticLimbSegment(
  ctx: CanvasRenderingContext2D,
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  rStart: number,
  rMid: number,
  rEnd: number,
  bulgeShift: number,
  rimColor: string,
  glowColor: string,
  depthDim: boolean,
  baseColor: string,
  darkColor: string,
  cuffColor?: string
): void {
  const dx = x2 - x1;
  const dy = y2 - y1;
  const len = Math.hypot(dx, dy);
  if (len < 0.5) return;
  const ux = dx / len;
  const uy = dy / len;
  const nx = -uy;
  const ny = ux;
  const mx = x1 + dx * 0.42;
  const my = y1 + dy * 0.42;

  const f1x = x1 + nx * rStart;
  const f1y = y1 + ny * rStart;
  const fmx = mx + nx * (rMid + bulgeShift);
  const fmy = my + ny * (rMid + bulgeShift);
  const f2x = x2 + nx * rEnd;
  const f2y = y2 + ny * rEnd;

  const b1x = x1 - nx * rStart;
  const b1y = y1 - ny * rStart;
  const bmx = mx - nx * (rMid - bulgeShift * 0.42);
  const bmy = my - ny * (rMid - bulgeShift * 0.42);
  const b2x = x2 - nx * rEnd;
  const b2y = y2 - ny * rEnd;

  ctx.save();
  const warmHighlight = adjustHexColor(baseColor, 34);
  const grad = ctx.createLinearGradient(bmx, bmy, fmx, fmy);
  if (depthDim) {
    grad.addColorStop(0, '#090710');
    grad.addColorStop(0.55, darkColor);
    grad.addColorStop(1, adjustHexColor(darkColor, 20));
  } else {
    grad.addColorStop(0, darkColor);
    grad.addColorStop(0.42, baseColor);
    grad.addColorStop(0.84, warmHighlight);
    grad.addColorStop(1, adjustHexColor(baseColor, 46));
  }

  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.moveTo(f1x, f1y);
  ctx.quadraticCurveTo(fmx, fmy, f2x, f2y);
  ctx.arc(x2, y2, rEnd, Math.atan2(ny, nx), Math.atan2(-ny, -nx), false);
  ctx.quadraticCurveTo(bmx, bmy, b1x, b1y);
  ctx.arc(x1, y1, rStart, Math.atan2(-ny, -nx), Math.atan2(ny, nx), false);
  ctx.closePath();
  ctx.fill();

  if (!depthDim) {
    // Soft anatomical muscle tendon / cloth highlight plane
    ctx.fillStyle = warmHighlight;
    ctx.globalAlpha = 0.28;
    ctx.beginPath();
    ctx.moveTo(x1 + nx * rStart * 0.16, y1 + ny * rStart * 0.16);
    ctx.quadraticCurveTo(
      mx + nx * (rMid + bulgeShift) * 0.68,
      my + ny * (rMid + bulgeShift) * 0.68,
      x2 + nx * rEnd * 0.35,
      y2 + ny * rEnd * 0.35
    );
    ctx.lineTo(x2 - nx * rEnd * 0.12, y2 - ny * rEnd * 0.12);
    ctx.quadraticCurveTo(mx - nx * rMid * 0.12, my - ny * rMid * 0.12, x1 - nx * rStart * 0.12, y1 - ny * rStart * 0.12);
    ctx.closePath();
    ctx.fill();
    ctx.globalAlpha = 1;

    // Subtle rim light
    ctx.strokeStyle = hexToRgba(glowColor, 0.34);
    ctx.lineWidth = 1.25;
    ctx.beginPath();
    ctx.moveTo(f1x - nx * 0.5, f1y - ny * 0.5);
    ctx.quadraticCurveTo(fmx - nx * 0.5, fmy - ny * 0.5, f2x - nx * 0.5, f2y - ny * 0.5);
    ctx.stroke();
  }

  // Optional sleeve/trouser cuff near joint end
  if (cuffColor) {
    const cx1 = x2 - ux * 3.5 + nx * (rEnd + 0.8);
    const cy1 = y2 - uy * 3.5 + ny * (rEnd + 0.8);
    const cx2 = x2 - ux * 3.5 - nx * (rEnd + 0.8);
    const cy2 = y2 - uy * 3.5 - ny * (rEnd + 0.8);
    ctx.strokeStyle = depthDim ? adjustHexColor(darkColor, 14) : cuffColor;
    ctx.lineWidth = 2.0;
    ctx.beginPath();
    ctx.moveTo(cx1, cy1);
    ctx.lineTo(cx2, cy2);
    ctx.stroke();
  }

  // Subtle fabric/joint crease at mid-joint
  ctx.strokeStyle = depthDim ? 'rgba(0,0,0,0.52)' : hexToRgba(darkColor, 0.45);
  ctx.lineWidth = 1.05;
  ctx.beginPath();
  ctx.moveTo(x1 + dx * 0.14 - nx * rStart * 0.35, y1 + dy * 0.14 - ny * rStart * 0.35);
  ctx.quadraticCurveTo(mx - nx * rMid * 0.15, my - ny * rMid * 0.15, x1 + dx * 0.82 - nx * rEnd * 0.3, y1 + dy * 0.82 - ny * rEnd * 0.3);
  ctx.stroke();

  // Crisp anatomical outline
  ctx.strokeStyle = depthDim ? 'rgba(0,0,0,0.68)' : hexToRgba(rimColor, 0.52);
  ctx.lineWidth = depthDim ? 1.0 : 1.2;
  ctx.beginPath();
  ctx.moveTo(f1x, f1y);
  ctx.quadraticCurveTo(fmx, fmy, f2x, f2y);
  ctx.stroke();

  // Blended joint cap
  ctx.fillStyle = depthDim ? darkColor : baseColor;
  ctx.beginPath();
  ctx.arc(x1, y1, rStart * 0.82, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawRealisticHand(
  ctx: CanvasRenderingContext2D,
  hx: number,
  hy: number,
  armAngle: number,
  bulk: number,
  rimColor: string,
  glowColor: string,
  depthDim: boolean,
  skinColor: string,
  skinDark: string,
  handStyle: 'fist' | 'peace' | 'open' = 'fist'
): void {
  ctx.save();
  ctx.translate(hx, hy);
  ctx.rotate(Math.PI * 0.5 - armAngle);
  const s = bulk;
  const skinHi = adjustHexColor(skinColor, 26);

  // Wrist strap / golden kada / cloth band
  ctx.fillStyle = depthDim ? '#1e1b2e' : hexToRgba(glowColor, 0.88);
  ctx.beginPath();
  ctx.roundRect(-3.8 * s, -3.7 * s, 3.4 * s, 7.4 * s, 1.2 * s);
  ctx.fill();
  if (!depthDim) {
    ctx.strokeStyle = 'rgba(0,0,0,0.45)';
    ctx.lineWidth = 0.8;
    ctx.stroke();
  }

  // Sculpted Palm gradient
  const palmGrad = ctx.createLinearGradient(0, -4.5 * s, 7.5 * s, 4.5 * s);
  if (depthDim) {
    palmGrad.addColorStop(0, skinDark);
    palmGrad.addColorStop(1, adjustHexColor(skinDark, 14));
  } else {
    palmGrad.addColorStop(0, skinDark);
    palmGrad.addColorStop(0.55, skinColor);
    palmGrad.addColorStop(1, skinHi);
  }
  ctx.fillStyle = palmGrad;
  ctx.strokeStyle = depthDim ? 'rgba(0,0,0,0.65)' : hexToRgba(rimColor, 0.72);
  ctx.lineWidth = depthDim ? 0.95 : 1.2;

  if (handStyle === 'peace') {
    // Palm base + two victory V fingers
    ctx.beginPath();
    ctx.roundRect(-0.6 * s, -3.6 * s, 5.6 * s, 7.2 * s, 2.4 * s);
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.roundRect(3.8 * s, -4.4 * s, 6.2 * s, 2.3 * s, 1.1 * s);
    ctx.roundRect(3.8 * s, -0.5 * s, 6.5 * s, 2.3 * s, 1.1 * s);
    ctx.fill();
    ctx.stroke();
  } else if (handStyle === 'open') {
    ctx.beginPath();
    ctx.roundRect(-0.6 * s, -4.1 * s, 6.2 * s, 8.2 * s, 2.6 * s);
    ctx.fill();
    ctx.stroke();
    // Extended graceful fingers
    for (let fi = 0; fi < 4; fi++) {
      const fy = (-3.4 + fi * 2.15) * s;
      ctx.beginPath();
      ctx.roundRect(4.2 * s, fy, 4.8 * s, 1.8 * s, 0.9 * s);
      ctx.fill();
      ctx.stroke();
    }
  } else {
    // Clenched fist with thumb wrap + 4 knuckle ridges
    ctx.beginPath();
    ctx.roundRect(-0.6 * s, -4.3 * s, 8.1 * s, 8.8 * s, 3.0 * s);
    ctx.fill();
    ctx.stroke();

    // Thumb curl overlapping top edge
    ctx.fillStyle = depthDim ? skinDark : skinHi;
    ctx.beginPath();
    ctx.roundRect(0.6 * s, -5.0 * s, 5.4 * s, 2.8 * s, 1.4 * s);
    ctx.fill();
    ctx.stroke();

    // Curled finger knuckle separation lines
    if (!depthDim) {
      ctx.strokeStyle = hexToRgba(skinDark, 0.65);
      ctx.lineWidth = 0.95;
      for (let k = 1; k <= 3; k++) {
        const ky = (-4.0 + k * 2.15) * s;
        ctx.beginPath();
        ctx.moveTo(4.0 * s, ky);
        ctx.lineTo(7.1 * s, ky);
        ctx.stroke();
      }
      ctx.fillStyle = 'rgba(255,245,235,0.24)';
      ctx.fillRect(3.6 * s, -2.5 * s, 2.0 * s, 5.4 * s);
    }
  }
  ctx.restore();
}

function drawRealisticFoot(
  ctx: CanvasRenderingContext2D,
  ax: number,
  ay: number,
  shinTilt: number,
  bulk: number,
  rimColor: string,
  glowColor: string,
  depthDim: boolean,
  bootColor: string,
  propType?: string
): void {
  ctx.save();
  ctx.translate(ax, ay);
  const plantTilt = Math.max(-0.55, Math.min(0.45, -shinTilt * 0.35));
  ctx.rotate(plantTilt);
  const b = bulk;

  // Ankle cuff / sock trim
  ctx.fillStyle = depthDim ? '#090812' : adjustHexColor(bootColor, 18);
  ctx.beginPath();
  ctx.roundRect(-4.6 * b, -3.5, 8.0 * b, 3.4, 1.5);
  ctx.fill();

  const bootHi = adjustHexColor(bootColor, 28);
  const shoeGrad = ctx.createLinearGradient(-4 * b, -2, 10 * b, 4);
  if (depthDim) {
    shoeGrad.addColorStop(0, '#07060d');
    shoeGrad.addColorStop(1, '#141222');
  } else {
    shoeGrad.addColorStop(0, adjustHexColor(bootColor, -18));
    shoeGrad.addColorStop(0.6, bootColor);
    shoeGrad.addColorStop(1, bootHi);
  }

  ctx.fillStyle = shoeGrad;
  ctx.strokeStyle = depthDim ? 'rgba(0,0,0,0.75)' : hexToRgba(rimColor, 0.72);
  ctx.lineWidth = depthDim ? 1.0 : 1.35;

  // Contoured boot / Desi jutti with sculpted instep & subtle curled toe tip
  const hasJuttiCurl = propType === 'lota' || propType === 'kamandalu' || propType === 'belan' || propType === 'purse';
  ctx.beginPath();
  ctx.moveTo(-4.8 * b, -1.7);
  ctx.lineTo(3.6 * b, -1.9);
  ctx.quadraticCurveTo(9.8 * b, -0.7, 13.8 * b, hasJuttiCurl ? 0.6 : 2.1);
  ctx.quadraticCurveTo(14.5 * b, 4.4, 9.8 * b, 4.7);
  ctx.lineTo(-4.9 * b, 4.6);
  ctx.quadraticCurveTo(-6.3 * b, 1.6, -4.8 * b, -1.7);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // Layered thick rubber / leather outsole + heel block
  ctx.fillStyle = propType === 'dumbbell' && !depthDim ? '#e2e8f0' : '#08070f';
  ctx.fillRect(-4.7 * b, 3.1, 16.6 * b, 1.6);
  ctx.fillStyle = '#050409';
  ctx.fillRect(-4.9 * b, 3.4, 5.2 * b, 1.6);

  if (!depthDim) {
    // Tongue / strap / lace lines
    ctx.strokeStyle = hexToRgba(glowColor, 0.7);
    ctx.lineWidth = 1.25;
    ctx.beginPath();
    ctx.moveTo(-3.6 * b, -2.5);
    ctx.lineTo(3.4 * b, -2.5);
    ctx.stroke();

    ctx.strokeStyle = 'rgba(255,255,255,0.34)';
    ctx.lineWidth = 0.9;
    ctx.beginPath();
    ctx.moveTo(4.2 * b, -0.4);
    ctx.lineTo(6.2 * b, 0.5);
    ctx.moveTo(6.2 * b, 0.1);
    ctx.lineTo(8.1 * b, 1.0);
    ctx.stroke();
  }
  ctx.restore();
}

function drawRealisticTorso(
  ctx: CanvasRenderingContext2D,
  look: CharacterLook,
  prop: string,
  auraCol: string,
  glowCol: string,
  isHeavy: boolean,
  isSlimFem: boolean,
  bulk: number,
  awakened: boolean,
  nowSec: number
): void {
  const skinHi = adjustHexColor(look.skin, 28);
  // Shaded Neck column with trapezius & collarbone shadow
  const neckGrad = ctx.createLinearGradient(-5, -46, 6, -46);
  neckGrad.addColorStop(0, look.skinDark);
  neckGrad.addColorStop(0.65, look.skin);
  neckGrad.addColorStop(1, skinHi);
  ctx.fillStyle = neckGrad;
  ctx.strokeStyle = hexToRgba(auraCol, 0.6);
  ctx.lineWidth = 1.15;
  ctx.beginPath();
  ctx.moveTo(-5.0, -40.5);
  ctx.lineTo(-4.1, -52.5);
  ctx.lineTo(4.5, -52.5);
  ctx.lineTo(5.8, -39.5);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // Sternocleidomastoid / chin cast shadow on neck
  ctx.fillStyle = hexToRgba(look.skinDark, 0.42);
  ctx.beginPath();
  ctx.moveTo(-4.0, -52);
  ctx.lineTo(4.4, -52);
  ctx.lineTo(2.0, -47);
  ctx.lineTo(-4.2, -47);
  ctx.closePath();
  ctx.fill();

  const chestW = isHeavy ? 18.0 : isSlimFem ? 13.4 : 16.0;
  const waistW = prop === 'lota' ? 21.8 : isSlimFem ? 8.2 : 10.9;
  const hipW = isSlimFem ? 12.9 : 11.7 * bulk;
  const tunicHi = adjustHexColor(look.tunic, 26);

  const torsoGrad = ctx.createLinearGradient(-chestW, -20, chestW, -20);
  torsoGrad.addColorStop(0, look.tunicDark);
  torsoGrad.addColorStop(0.48, look.tunic);
  torsoGrad.addColorStop(0.86, tunicHi);
  torsoGrad.addColorStop(1, awakened ? glowCol : adjustHexColor(look.tunic, 42));

  ctx.fillStyle = torsoGrad;
  ctx.strokeStyle = awakened ? glowCol : hexToRgba(auraCol, 0.78);
  ctx.lineWidth = awakened ? 2.0 : 1.4;
  ctx.beginPath();
  ctx.moveTo(-chestW * 0.85, -41);
  ctx.quadraticCurveTo(0, -45.5, chestW, -40);
  if (prop === 'lota') {
    ctx.bezierCurveTo(chestW + 4.2, -28, waistW + 5.2, -14, hipW + 2, 4);
  } else {
    ctx.bezierCurveTo(chestW + 2.6, -28, waistW + 2.4, -14, hipW, 4);
  }
  ctx.quadraticCurveTo(0, 8.2, -hipW, 4);
  ctx.bezierCurveTo(-waistW - 1.5, -14, -chestW * 0.95, -28, -chestW * 0.85, -41);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // Cultural Motifs & Animated Metallic Specular Sheen
  if (look.shiny || look.motif) {
    ctx.save();
    ctx.clip();
    if (look.motif === 'zari' || look.motif === 'royal') {
      ctx.fillStyle = hexToRgba(look.trim, 0.72);
      for (let dy = -34; dy <= -6; dy += 11) {
        ctx.beginPath();
        ctx.moveTo(0, dy - 2.6);
        ctx.lineTo(3, dy);
        ctx.lineTo(0, dy + 2.6);
        ctx.lineTo(-3, dy);
        ctx.closePath();
        ctx.fill();
      }
    } else if (look.motif === 'bandhani') {
      ctx.fillStyle = hexToRgba(look.trim, 0.78);
      for (let dx = -8; dx <= 8; dx += 8) {
        for (let dy = -33; dy <= -8; dy += 9) {
          ctx.beginPath();
          ctx.arc(dx + (dy % 2) * 2, dy, 1.8, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    } else if (look.motif === 'bhangra') {
      ctx.strokeStyle = hexToRgba(look.trim, 0.8);
      ctx.lineWidth = 2;
      for (let dy = -30; dy <= -10; dy += 10) {
        ctx.beginPath();
        ctx.moveTo(-12, dy);
        ctx.lineTo(0, dy + 5);
        ctx.lineTo(12, dy);
        ctx.stroke();
      }
    } else if (look.motif === 'vibhuti') {
      ctx.strokeStyle = hexToRgba('#ffffff', 0.72);
      ctx.lineWidth = 1.6;
      for (let dy = -30; dy <= -22; dy += 4) {
        ctx.beginPath();
        ctx.moveTo(-9, dy);
        ctx.lineTo(9, dy);
        ctx.stroke();
      }
    } else if (look.motif === 'neon') {
      ctx.strokeStyle = hexToRgba(glowCol, 0.9);
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.moveTo(-8, -36);
      ctx.lineTo(0, -24);
      ctx.lineTo(9, -34);
      ctx.stroke();
    }
    if (look.shiny) {
      const sweep = ((nowSec * 42) % 72) - 36;
      const sheen = ctx.createLinearGradient(sweep - 12, -45, sweep + 12, 8);
      sheen.addColorStop(0, 'rgba(255,255,255,0)');
      sheen.addColorStop(0.5, 'rgba(255,255,255,0.4)');
      sheen.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = sheen;
      ctx.fillRect(-chestW - 6, -46, (chestW + 6) * 2, 56);
    }
    ctx.restore();
  }

  // Anatomical pectoral & clothing drape tailoring
  if (look.bareArms) {
    // Exposed skin chest + collarbone + pectoral muscle definition
    const chestSkin = ctx.createLinearGradient(-5, -42, 9, -22);
    chestSkin.addColorStop(0, look.skinDark);
    chestSkin.addColorStop(0.6, look.skin);
    chestSkin.addColorStop(1, skinHi);
    ctx.fillStyle = chestSkin;
    ctx.beginPath();
    ctx.moveTo(-4.5, -42);
    ctx.lineTo(9.5, -40);
    ctx.lineTo(5.5, -21);
    ctx.lineTo(-2.5, -24);
    ctx.closePath();
    ctx.fill();

    ctx.strokeStyle = hexToRgba(look.skinDark, 0.55);
    ctx.lineWidth = 1.1;
    ctx.beginPath();
    ctx.moveTo(-2, -31);
    ctx.quadraticCurveTo(4, -29, 8.5, -31);
    ctx.stroke();
  } else {
    // Kurta collar / waistcoat lapel + stitched buttons + fabric fold creases
    ctx.strokeStyle = hexToRgba(look.trim, 0.9);
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(-5, -42);
    ctx.lineTo(2, -31);
    ctx.lineTo(9, -40);
    ctx.moveTo(2, -31);
    ctx.lineTo(2, -12);
    ctx.stroke();

    // Small kurta buttons
    ctx.fillStyle = look.trim;
    for (let by = -27; by <= -17; by += 5) {
      ctx.beginPath();
      ctx.arc(2, by, 1.0, 0, Math.PI * 2);
      ctx.fill();
    }

    // Subtle fabric fold lines across waist
    ctx.strokeStyle = hexToRgba(look.tunicDark, 0.52);
    ctx.lineWidth = 1.0;
    ctx.beginPath();
    ctx.moveTo(-chestW * 0.5, -18);
    ctx.quadraticCurveTo(0, -14, chestW * 0.45, -19);
    ctx.stroke();
  }

  // Character-specific garment accents (Traffic Mama badge, Sharmaji Topper medal, Sari/Pallu sash)
  if (prop === 'whistle') {
    ctx.fillStyle = '#fde047';
    ctx.beginPath();
    ctx.arc(-5, -30, 2.4, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 1.0;
    ctx.beginPath();
    ctx.moveTo(4, -39);
    ctx.lineTo(-6, -24);
    ctx.stroke();
  } else if (prop === 'glasses') {
    // Gold medal ribbon on scholar chest
    ctx.strokeStyle = '#f43f5e';
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(-4, -40);
    ctx.lineTo(2, -26);
    ctx.lineTo(8, -39);
    ctx.stroke();
    ctx.fillStyle = '#fbbf24';
    ctx.beginPath();
    ctx.arc(2, -25, 2.6, 0, Math.PI * 2);
    ctx.fill();
  } else if (isSlimFem) {
    // Diagonal Silk Sari Pallu / Dupatta across shoulder
    ctx.strokeStyle = hexToRgba(look.trim, 0.85);
    ctx.lineWidth = 3.2;
    ctx.beginPath();
    ctx.moveTo(-chestW * 0.72, -40);
    ctx.quadraticCurveTo(0, -24, hipW * 0.9, -4);
    ctx.stroke();
  }

  // Desi Kamarbandh / Waist Sash & Hanging Cloth Fold
  ctx.fillStyle = look.trim;
  ctx.strokeStyle = '#090712';
  ctx.lineWidth = 1.1;
  ctx.beginPath();
  ctx.roundRect(-hipW * 0.96, -5.5, hipW * 1.98, 6.2, 2.4);
  ctx.fill();
  ctx.stroke();

  if (isSlimFem || prop === 'kamandalu' || prop === 'lota') {
    ctx.fillStyle = look.tunic;
    ctx.strokeStyle = hexToRgba(look.trim, 0.78);
    ctx.lineWidth = 1.3;
    ctx.beginPath();
    ctx.moveTo(-hipW * 0.95, 2);
    ctx.lineTo(hipW * 1.05, 2);
    ctx.lineTo(hipW * 1.18, 16);
    ctx.quadraticCurveTo(0, 20, -hipW * 1.05, 15);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }
}

function drawRealisticHead(
  ctx: CanvasRenderingContext2D,
  look: CharacterLook,
  eyeCol: string,
  auraCol: string,
  glowCol: string,
  awakened: boolean,
  expression: 'fierce' | 'victory' | 'defeat' = 'fierce'
): void {
  const skinHi = adjustHexColor(look.skin, 30);
  const headSkin = ctx.createLinearGradient(-12, -11, 14, 9);
  headSkin.addColorStop(0, look.skinDark);
  headSkin.addColorStop(0.58, look.skin);
  headSkin.addColorStop(1, skinHi);

  ctx.fillStyle = headSkin;
  ctx.strokeStyle = awakened ? glowCol : hexToRgba(auraCol, 0.72);
  ctx.lineWidth = 1.45;
  ctx.beginPath();
  ctx.moveTo(-4.5, 11);
  ctx.bezierCurveTo(-13.5, 7, -14.5, -8, -4.5, -14.2);
  ctx.bezierCurveTo(3.5, -16.6, 11.5, -12, 11.8, -5.4);
  ctx.lineTo(14.8, -0.8); // sculpted nose bridge & tip
  ctx.lineTo(11.6, 1.3);
  ctx.lineTo(12.3, 4.4); // lips
  ctx.lineTo(10.8, 9.1); // defined jawline & chin
  ctx.quadraticCurveTo(4.5, 12.4, -4.5, 11);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // Warm cheekbone blush / subsurface contour + jaw shadow
  ctx.fillStyle = hexToRgba(look.skinDark, 0.25);
  ctx.beginPath();
  ctx.ellipse(3.5, 5.5, 5.2, 2.6, -0.25, 0, Math.PI * 2);
  ctx.fill();

  // Sculpted Ear + inner helix crease
  ctx.fillStyle = look.skin;
  ctx.strokeStyle = look.skinDark;
  ctx.lineWidth = 1.0;
  ctx.beginPath();
  ctx.ellipse(-3.6, 0.5, 2.3, 3.8, -0.1, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(-3.5, 0.5, 1.0, -0.8, 1.8);
  ctx.stroke();

  // Nose bridge highlight & nostril shadow
  ctx.fillStyle = hexToRgba(look.skinDark, 0.55);
  ctx.beginPath();
  ctx.arc(11.6, 0.5, 0.85, 0, Math.PI * 2);
  ctx.fill();

  // Expressive Mouth (confident grin on Victory, gritted frown on Defeat, fierce set line in Combat)
  ctx.strokeStyle = hexToRgba('#4a1f16', 0.82);
  ctx.lineWidth = 1.25;
  ctx.beginPath();
  if (expression === 'victory') {
    ctx.moveTo(7.4, 4.4);
    ctx.quadraticCurveTo(10.2, 6.2, 12.1, 4.1);
  } else if (expression === 'defeat') {
    ctx.moveTo(7.6, 5.4);
    ctx.quadraticCurveTo(10.0, 3.8, 12.0, 5.2);
  } else {
    ctx.moveTo(7.8, 4.8);
    ctx.lineTo(12.0, 4.4);
  }
  ctx.stroke();

  // Realistic Layered Hair & Cultural Headgear
  ctx.fillStyle = look.hair;
  if (look.headgear === 'bun') {
    ctx.beginPath();
    ctx.moveTo(-12.5, -2);
    ctx.bezierCurveTo(-13.5, -14.5, 4, -17, 11.2, -9);
    ctx.quadraticCurveTo(2, -10.2, -4.5, -4);
    ctx.closePath();
    ctx.fill();
    ctx.beginPath();
    ctx.arc(-13.5, -4, 7.2, 0, Math.PI * 2);
    ctx.fill();
    // White mogra gajra flowers + bindi
    ctx.fillStyle = '#fffbeb';
    ctx.beginPath();
    ctx.arc(-10, -8, 1.7, 0, Math.PI * 2);
    ctx.arc(-11.6, -4, 1.7, 0, Math.PI * 2);
    ctx.arc(-10, 0, 1.7, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#fb7185';
    ctx.beginPath();
    ctx.arc(10.6, -5.8, 1.5, 0, Math.PI * 2);
    ctx.fill();
  } else if (look.headgear === 'jata') {
    ctx.beginPath();
    ctx.ellipse(-2, -12, 10.8, 4.6, -0.15, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(-4.5, -17.2, 5.5, 0, Math.PI * 2);
    ctx.fill();
    // Sacred vibhuti tilak
    ctx.fillStyle = '#fffbeb';
    ctx.fillRect(8.5, -7.8, 3.3, 1.2);
    ctx.fillRect(8.5, -5.8, 3.3, 1.2);
    ctx.fillStyle = '#f43f5e';
    ctx.beginPath();
    ctx.arc(10.2, -6.4, 0.9, 0, Math.PI * 2);
    ctx.fill();
  } else if (look.headgear === 'cap') {
    ctx.fillStyle = look.tunicDark;
    ctx.strokeStyle = look.trim;
    ctx.lineWidth = 1.3;
    ctx.beginPath();
    ctx.moveTo(-11.5, -10.5);
    ctx.lineTo(17.2, -10.5);
    ctx.lineTo(8.5, -18.0);
    ctx.lineTo(-9.5, -17.5);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    // Gold officer badge emblem on cap
    ctx.fillStyle = '#fbbf24';
    ctx.beginPath();
    ctx.arc(6.5, -14, 1.7, 0, Math.PI * 2);
    ctx.fill();
  } else if (look.headgear === 'bandana' || look.headgear === 'headband') {
    ctx.beginPath();
    ctx.moveTo(-11.5, -2.5);
    ctx.bezierCurveTo(-13, -15, 4, -18, 11.4, -9);
    ctx.quadraticCurveTo(3, -10, -4, -5);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = look.trim;
    ctx.fillRect(-11.5, -10.8, 22.2, 3.8);
    // Trailing knot tail
    ctx.beginPath();
    ctx.moveTo(-11.5, -9.5);
    ctx.lineTo(-16.5, -6.5);
    ctx.lineTo(-15.5, -11.5);
    ctx.closePath();
    ctx.fill();
  } else if (look.headgear === 'bald') {
    ctx.fillStyle = look.hair;
    ctx.beginPath();
    ctx.arc(-9, -3, 4.6, 1.2, 4.6);
    ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.28)';
    ctx.beginPath();
    ctx.ellipse(2, -11.2, 5.0, 2.0, -0.2, 0, Math.PI * 2);
    ctx.fill();
  } else {
    ctx.beginPath();
    ctx.moveTo(-11.8, -1.8);
    ctx.bezierCurveTo(-13.2, -15.5, 4.5, -18.4, 11.8, -9);
    ctx.quadraticCurveTo(3.5, -10.4, -3.8, -4.5);
    ctx.closePath();
    ctx.fill();
    // Sideburn lock
    ctx.beginPath();
    ctx.moveTo(-5.5, -5);
    ctx.lineTo(-3.2, -5);
    ctx.lineTo(-4.0, 0.5);
    ctx.lineTo(-6.2, -1);
    ctx.closePath();
    ctx.fill();
  }

  // Facial hair (Beard / Moustache / Stubble)
  if (look.hasBeard === 'long') {
    ctx.fillStyle = look.hair;
    ctx.beginPath();
    ctx.moveTo(5, 7);
    ctx.lineTo(15.2, 21.5);
    ctx.lineTo(1, 19);
    ctx.closePath();
    ctx.fill();
  } else if (look.hasBeard === 'moustache') {
    ctx.fillStyle = look.hair;
    ctx.beginPath();
    ctx.ellipse(10.5, 3.3, 4.7, 1.7, 0.22, 0, Math.PI * 2);
    ctx.fill();
  } else if (look.hasBeard === 'stubble') {
    ctx.fillStyle = 'rgba(24,20,30,0.34)';
    ctx.beginPath();
    ctx.moveTo(-0.5, 5.5);
    ctx.lineTo(11, 5.5);
    ctx.lineTo(10, 10.2);
    ctx.lineTo(1, 11);
    ctx.closePath();
    ctx.fill();
  }

  // Realistic Layered Eye (White Sclera + Iris + Pupil + Catchlight + Sculpted Eyebrow)
  ctx.fillStyle = '#f8fafc';
  ctx.beginPath();
  ctx.ellipse(6.8, -3.2, 3.6, 1.9, -0.1, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = awakened ? eyeCol : '#451a03';
  ctx.beginPath();
  ctx.arc(7.6, -3.2, 1.45, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#090712';
  ctx.beginPath();
  ctx.arc(7.8, -3.2, 0.72, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(8.2, -3.7, 0.45, 0, Math.PI * 2);
  ctx.fill();

  // Eyebrow arch (fierce, raised smile, or pained tilt)
  ctx.strokeStyle = look.hair;
  ctx.lineWidth = 1.45;
  ctx.beginPath();
  if (expression === 'victory') {
    ctx.moveTo(3.2, -5.6);
    ctx.quadraticCurveTo(6.8, -6.9, 10.4, -5.2);
  } else if (expression === 'defeat') {
    ctx.moveTo(3.2, -5.0);
    ctx.lineTo(10.2, -6.2);
  } else {
    ctx.moveTo(3.0, -6.0);
    ctx.lineTo(10.6, -4.5);
  }
  ctx.stroke();

  // Shades / Specs with diagonal glass sheen
  if (look.headgear === 'shades') {
    ctx.fillStyle = 'rgba(9,7,18,0.92)';
    ctx.strokeStyle = look.shadesRim || '#fde047';
    ctx.lineWidth = 1.45;
    ctx.beginPath();
    ctx.roundRect(2.4, -6.3, 9.6, 4.7, 1.2);
    ctx.fill();
    ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.45)';
    ctx.lineWidth = 1.0;
    ctx.beginPath();
    ctx.moveTo(4.0, -5.4);
    ctx.lineTo(6.2, -2.2);
    ctx.stroke();
  } else if (look.headgear === 'specs') {
    ctx.fillStyle = 'rgba(186,230,253,0.18)';
    ctx.strokeStyle = look.shadesRim || '#fef08a';
    ctx.lineWidth = 1.5;
    ctx.fillRect(2.8, -6.3, 8.6, 5.0);
    ctx.strokeRect(2.8, -6.3, 8.6, 5.0);
    ctx.strokeStyle = 'rgba(255,255,255,0.55)';
    ctx.lineWidth = 0.9;
    ctx.beginPath();
    ctx.moveTo(4.2, -5.5);
    ctx.lineTo(6.0, -2.0);
    ctx.stroke();
  }
}

function drawDetailedWeapon(
  ctx: CanvasRenderingContext2D,
  prop: string,
  glowCol: string,
  trimCol: string
): void {
  ctx.strokeStyle = glowCol;
  ctx.lineWidth = 1.75;

  if (prop === 'chappal') {
    // Detailed Kolhapuri leather sandal
    const cg = ctx.createLinearGradient(-2, -5, 22, 5);
    cg.addColorStop(0, '#7c2d12');
    cg.addColorStop(1, '#be185d');
    ctx.fillStyle = cg;
    ctx.beginPath();
    ctx.ellipse(10.5, 0, 12.5, 5.4, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.strokeStyle = '#fde047';
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.arc(8.5, 0, 4.4, -1.25, 1.25);
    ctx.stroke();
  } else if (prop === 'lota') {
    // Hammered gleaming brass Lota pot with flared rim
    const lg = ctx.createRadialGradient(7, 2, 1, 9, 4, 9.5);
    lg.addColorStop(0, '#fef08a');
    lg.addColorStop(0.55, '#d97706');
    lg.addColorStop(1, '#78350f');
    ctx.fillStyle = lg;
    ctx.beginPath();
    ctx.arc(9, 4, 8.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#f59e0b';
    ctx.fillRect(5.5, -5.5, 7, 2.8);
    ctx.strokeRect(5.5, -5.5, 7, 2.8);
  } else if (prop === 'belan') {
    // Turned teak wooden rolling pin with dual grip handles
    const wg = ctx.createLinearGradient(0, -4, 0, 4);
    wg.addColorStop(0, '#f59e0b');
    wg.addColorStop(0.5, '#b45309');
    wg.addColorStop(1, '#78350f');
    ctx.fillStyle = wg;
    ctx.fillRect(-5, -1.8, 34, 3.6);
    ctx.beginPath();
    ctx.roundRect(0, -4.0, 23, 8.0, 2.8);
    ctx.fill();
    ctx.stroke();
  } else if (prop === 'kamandalu') {
    // Sacred golden Trishul staff + brass pot
    ctx.strokeStyle = '#fde047';
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.moveTo(-6, 0);
    ctx.lineTo(31, 0);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(24, 0, 6.5, -1.45, 1.45);
    ctx.stroke();
    ctx.fillStyle = '#ef4444';
    ctx.fillRect(15, -2.5, 3, 5);
  } else if (prop === 'horn') {
    // Classic brass auto-rickshaw bulb horn
    ctx.fillStyle = '#0f172a';
    ctx.beginPath();
    ctx.arc(-1, 0, 4.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#eab308';
    ctx.beginPath();
    ctx.moveTo(2, -1.6);
    ctx.lineTo(18, -6.5);
    ctx.lineTo(18, 6.5);
    ctx.lineTo(2, 1.6);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  } else if (prop === 'glasses') {
    // Scholar A+ Report Plaque / Trophy Frame
    ctx.fillStyle = '#1e3a8a';
    ctx.strokeStyle = '#fde047';
    ctx.fillRect(1, -6.5, 14, 15);
    ctx.strokeRect(1, -6.5, 14, 15);
    ctx.fillStyle = '#fde047';
    ctx.fillRect(4, -3, 8, 2.2);
    ctx.fillRect(4, 1, 6, 2);
  } else if (prop === 'purse') {
    // Sequined royal Desi clutch bag with clasp & strap
    ctx.strokeStyle = '#fde047';
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.arc(8, -1, 5, Math.PI, 0);
    ctx.stroke();
    ctx.fillStyle = '#be123c';
    ctx.beginPath();
    ctx.roundRect(1, 0, 15, 11.5, 2.5);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#fde047';
    ctx.fillRect(6.5, 0.5, 4, 2.5);
  } else if (prop === 'whistle') {
    // Silver traffic whistle + striped traffic baton
    ctx.fillStyle = '#e2e8f0';
    ctx.strokeStyle = '#38bdf8';
    ctx.beginPath();
    ctx.roundRect(-2, -2.5, 24, 5, 2.2);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(7, -2.5, 4, 5);
    ctx.fillRect(15, -2.5, 4, 5);
    ctx.fillStyle = '#cbd5e1';
    ctx.beginPath();
    ctx.arc(0, 5.5, 4.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  } else if (prop === 'dumbbell') {
    // Heavy steel gym dumbbell with beveled hex plates
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 2.6;
    ctx.beginPath();
    ctx.moveTo(-7, 0);
    ctx.lineTo(15, 0);
    ctx.stroke();
    ctx.fillStyle = '#1e293b';
    ctx.strokeStyle = glowCol;
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.roundRect(-11, -7.5, 5.5, 15, 1.5);
    ctx.roundRect(13.5, -7.5, 5.5, 15, 1.5);
    ctx.fill();
    ctx.stroke();
  } else if (prop === 'katta') {
    // Gunmetal country katta pistol with teak wood grip
    ctx.fillStyle = '#334155';
    ctx.strokeStyle = '#fde047';
    ctx.fillRect(0, -4.2, 20, 6);
    ctx.strokeRect(0, -4.2, 20, 6);
    ctx.fillStyle = '#78350f';
    ctx.fillRect(0, 1.8, 6.2, 10);
    ctx.strokeRect(0, 1.8, 6.2, 10);
  } else {
    ctx.fillStyle = trimCol;
    ctx.beginPath();
    ctx.arc(10, 0, 8, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  }
}

export function drawCharFace(canvas: HTMLCanvasElement, cfg: FighterConfig, skinId?: string | null): void {
  const s = 72;
  canvas.width = s;
  canvas.height = s;
  const c = canvas.getContext('2d');
  if (!c) return;
  const look = getCharacterLook(cfg.id, skinId);
  const vis = getFighterVisualPalette(cfg, skinId, DEFAULT_AURA_ID);

  const g = c.createRadialGradient(s * 0.38, s * 0.32, 4, s * 0.5, s * 0.5, s * 0.52);
  g.addColorStop(0, vis.glowCol || '#fde047');
  g.addColorStop(0.55, vis.auraCol || '#f43f5e');
  g.addColorStop(1, '#090712');
  c.fillStyle = g;
  c.beginPath();
  c.arc(s / 2, s / 2, s / 2 - 1, 0, Math.PI * 2);
  c.fill();

  // Shoulders hint
  c.fillStyle = look.tunic;
  c.beginPath();
  c.ellipse(s / 2 - 2, s - 4, 24, 14, 0, Math.PI, 0);
  c.fill();

  // Sculpted realistic human head silhouette
  c.save();
  c.translate(s / 2 - 1, s / 2 + 2);
  c.scale(1.42, 1.42);
  drawRealisticHead(c, look, vis.eyeCol || '#fde047', vis.auraCol, vis.glowCol, false, 'victory');
  c.restore();

  c.save();
  c.translate(s / 2 - 15, s / 2 + 16);
  c.scale(0.68, 0.68);
  drawDetailedWeapon(c, cfg.prop || '', vis.glowCol || '#fde047', look.trim);
  c.restore();

  c.fillStyle = 'rgba(255,255,255,0.12)';
  c.beginPath();
  c.ellipse(s / 2 - 6, s / 2 - 9, 8, 4, -0.5, 0, Math.PI * 2);
  c.fill();
}

export function getCharMove(fighter: Fighter, key: string): MoveDef | null {
  const base = MOVES[key];
  if (!base) return null;
  const mv: MoveDef = { ...base };
  if (key === 'SP1' || key === 'SP2' || key === 'RAGE') {
    const pack = CHAR_MOVES[fighter.cfg.id];
    const override = pack?.[key];
    if (override) Object.assign(mv, override);
  }
  return mv;
}

export function resolveBasicAttack(fighter: Fighter, joyX: number, joyY: number): string {
  const fx = fighter.facing || 1;
  const airborne = fighter.y < WORLD.groundY - 20;
  if (airborne) return 'BASIC_AIR';
  if (joyY > 0.45) return 'BASIC_LOW';
  if (joyY < -0.45) return 'BASIC_UP';
  if (joyX * fx > 0.45) return 'BASIC_FWD';
  if (fighter.basicChainTimer > 0 && fighter.basicChainStep === 1) return 'BASIC_2';
  if (fighter.basicChainTimer > 0 && fighter.basicChainStep === 2) return 'BASIC_3';
  return 'BASIC_1';
}

interface Afterimage {
  x: number;
  y: number;
  facing: number;
  scaleX: number;
  scaleY: number;
  alpha: number;
  pose: { hipY: number; lean: number; spin: number };
}

interface RemoteInput {
  moveX: number;
  moveY: number;
  block: boolean;
  action: string | null;
}

export class Fighter {
  slot: 1 | 2;
  cfg: FighterConfig;
  skinId: string;
  auraId: string;
  x: number;
  y: number;
  vx = 0;
  vy = 0;
  facing: number;
  hp = 1000;
  maxHp = 1000;
  rage = 0;
  awakened = false;
  state: 'IDLE' | 'WALK' | 'CROUCH' | 'JUMP' | 'DASH' | 'ATTACK' | 'HURT' | 'BLOCKSTUN' | 'KO' = 'IDLE';
  stateTimer = 0;
  move: MoveDef | null = null;
  moveFrame = 0;
  hasHit = false;
  rageWavesHit = [false, false, false];
  blocking = false;
  crouching = false;
  parryTimer = 0;
  parryFlashTimer = 0;
  wasBackHeld = false;
  stepDustAcc = 0;
  basicChainStep = 0;
  basicChainTimer = 0;
  lowHpCheerDone = false;
  invuln = 0;
  consecutiveHitsTaken = 0;
  slowTimer = 0;
  stinkTimer = 0;
  stinkTickAcc = 0;
  sp1Cd = 0;
  sp2Cd = 0;
  dashCd = 0;
  airDashed = false;
  comboCount = 0;
  comboDamage = 0;
  maxCombo = 0;
  comboTimer = 0;
  idleRegenTimer = 0;
  scaleX = 1;
  scaleY = 1;
  t = 0;
  remoteInput: RemoteInput = { moveX: 0, moveY: 0, block: false, action: null };
  inputBuffer: { key: string | null; timer: number } = { key: null, timer: 0 };
  afterimages: Afterimage[] = [];
  afterimageAcc = 0;
  awakeParticleAcc = 0;
  aiTimer = 0;
  aiAction = 'IDLE';
  aiReactedMoveKey = '';
  cloth: { x: number; y: number }[] = [];
  pose = {
    hipY: -58,
    lean: 0,
    spin: 0,
    fThigh: 0.25,
    fShin: 0.25,
    bThigh: -0.25,
    bShin: 0.2,
    fShoulder: -0.45,
    fElbow: -1.1,
    bShoulder: 0.35,
    bElbow: -0.9,
    propRot: -0.3,
  };

  constructor(slot: 1 | 2, cfg: FighterConfig, x: number, facing: number, skinId = '', auraId = DEFAULT_AURA_ID) {
    this.slot = slot;
    this.cfg = cfg;
    this.skinId = skinId;
    this.auraId = auraId;
    this.x = x;
    this.y = WORLD.groundY;
    this.facing = facing;
    for (let i = 0; i < 6; i++) {
      this.cloth.push({ x: x - facing * i * 9, y: WORLD.groundY - 115 });
    }
  }

  recordAfterimage(engineFacing?: number): void {
    this.afterimages.push({
      x: this.x,
      y: this.y,
      facing: engineFacing ?? this.facing,
      scaleX: this.scaleX,
      scaleY: this.scaleY,
      alpha: 0.46,
      pose: {
        hipY: this.pose.hipY,
        lean: this.pose.lean,
        spin: this.pose.spin,
      },
    });
    if (this.afterimages.length > 5) this.afterimages.shift();
  }
}

interface Projectile {
  owner: Fighter;
  kind: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  dir: number;
  dmg: number;
  hasHit: boolean;
  life: number;
  age: number;
  rot: number;
  col: string;
  glow: string;
}

interface VfxEffect {
  kind: string;
  x: number;
  y: number;
  facing: number;
  col: string;
  glow: string;
  life: number;
  maxLife: number;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  col: string;
}

interface Popup {
  x: number;
  y: number;
  vx: number;
  vy: number;
  text: string;
  col: string;
  life: number;
  maxLife: number;
  scale: number;
  rot: number;
  style: 'dmg' | 'big' | 'counter' | 'ko' | 'info';
}

interface ActiveSticker {
  slot: 1 | 2;
  emoteId: StickerEmoteId;
  life: number;
  maxLife: number;
}

interface NetMsg {
  type: string;
  code?: string;
  sender?: 'host' | 'guest' | null;
  seq?: number;
  ts?: number;
  p1Id?: string;
  p2Id?: string;
  p1SkinId?: string;
  p2SkinId?: string;
  p1AuraId?: string;
  p2AuraId?: string;
  arenaId?: ArenaId;
  timer?: number;
  round?: number;
  p1Wins?: number;
  p2Wins?: number;
  f1?: SerializedFighter | null;
  f2?: SerializedFighter | null;
  input?: RemoteInput;
  x?: number;
  y?: number;
  emoteId?: StickerEmoteId;
  emoteSlot?: 1 | 2;
  pingTs?: number;
}

interface SerializedFighter {
  x: number;
  y: number;
  vx: number;
  vy: number;
  facing: number;
  hp: number;
  rage: number;
  state: Fighter['state'];
  moveKey: string | null;
  moveFrame: number;
  blocking: boolean;
  crouching: boolean;
  sp1Cd: number;
  sp2Cd: number;
  dashCd: number;
}

export interface EngineCallbacks {
  onHudUpdate: (hud: HudSnapshot) => void;
  onAnnounce: (text: string | null) => void;
  onToast: (msg: string) => void;
  onVictory: (info: VictoryInfo) => void;
  onMpConnected: (role: 'host' | 'guest', p1Id: string, p2Id: string, arenaId: ArenaId) => void;
  onMpSelectSync: (p1Id: string, p2Id: string, arenaId: ArenaId) => void;
  onMpStartMatch: (p1Id: string, p2Id: string, arenaId: ArenaId) => void;
  onMpStatusText: (target: 'host' | 'guest', text: string, color: string) => void;
  onQuestMetric?: (metric: { kind: 'basic_hit' | 'special_use' | 'counter_hit'; fighterId: string; arenaId: ArenaId }) => void;
}

declare global {
  interface Window {
    Peer?: new (id: string, opts?: unknown) => PeerInstance;
  }
}

interface PeerInstance {
  on(ev: string, cb: (...args: unknown[]) => void): void;
  connect(targetId: string, opts?: unknown): PeerConn;
  destroy(): void;
}

interface PeerConn {
  open: boolean;
  on(ev: string, cb: (...args: unknown[]) => void): void;
  send(data: unknown): void;
  close(): void;
}

export class GameEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private cb: EngineCallbacks;
  private rafId = 0;
  private lastTime = performance.now();

  public mode: GameMode = 'bot';
  public practice = false;
  public difficulty: Difficulty = 'normal';
  public arenaId: ArenaId = 'chandni';
  public p1Id = 'munna_bhaiya';
  public p2Id = 'chappal_chacha';
  public p1SkinId = '';
  public p2SkinId = '';
  public p1AuraId = DEFAULT_AURA_ID;
  public p2AuraId = DEFAULT_AURA_ID;
  public lobbyTheme: LobbyThemeId = 'normal_night';
  public phase: MatchPhase = 'MENU';
  public paused = false;
  public round = 1;
  public p1Wins = 0;
  public p2Wins = 0;
  public timer = 60;

  private timerAcc = 0;
  private slowMoTimer = 0;
  private hitStop = 0;
  private shake = 0;
  private camX = 0;
  private camZoom = 1.06;

  public f1: Fighter | null = null;
  public f2: Fighter | null = null;
  private projectiles: Projectile[] = [];
  private vfxEffects: VfxEffect[] = [];
  private particles: Particle[] = [];
  private popups: Popup[] = [];
  private activeStickers: ActiveSticker[] = [];

  private kites: { x: number; y: number; vy: number; sway: number; col: string }[] = [];
  private pigeons: { x: number; y: number; vx: number; flap: number }[] = [];
  private ferries: { x: number; vx: number }[] = [];
  private diyas: { x: number; y: number; vx: number; phase: number }[] = [];
  private stars: { x: number; y: number; r: number; tw: number }[] = [];
  private lanterns: { x: number; y: number; phase: number; col: string }[] = [];
  private crowd: { side: number; bob: number; col: string }[] = [];
  private lightningTimer = 0;
  private roundStartTimer: number | null = null;
  private announcerTimer: number | null = null;
  private hudThrottleAcc = 0;
  private crowdCheerTimer = 3.8;
  private crowdExcitement = 0;

  // Input state
  public joyX = 0;
  public joyY = 0;
  public blockHeld = false;
  public keys: Record<string, boolean> = {};
  private lastTapLeft = 0;
  private lastTapRight = 0;
  private prevMoveX = 0;

  // Multiplayer state
  public mpRole: 'host' | 'guest' | null = null;
  public mpCode = 'SHD-88K';
  public mpConnected = false;
  public mpPingMs: number | null = null;
  private bc: BroadcastChannel | null = null;
  private peer: PeerInstance | null = null;
  private peerConn: PeerConn | null = null;
  private peerLibLoading = false;
  private netSyncAcc = 0;
  private pingIntervalAcc = 0;
  private lastPacketSeq = 0;
  private lastRemoteStateSeq = 0;
  private lastRemoteInputSeq = 0;
  private lastSentMoveX = 0;
  private lastSentMoveY = 0;
  private lastSentBlock = false;
  private handshakeRetryTimer: number | null = null;
  private seenPacketKeys = new Set<string>();
  private boundUnloadCleanup = () => {
    this.cleanupPeerSession();
  };

  constructor(canvas: HTMLCanvasElement, callbacks: EngineCallbacks) {
    this.canvas = canvas;
    const context = canvas.getContext('2d');
    if (!context) throw new Error('2D context unavailable');
    this.ctx = context;
    this.cb = callbacks;
    this.mpCode = this.generateRoomCode();

    this.initArenaDecor();
    this.setupMenuDemoFighters();
    this.setupMessaging();
    this.resize();
    this.startLoop();
    window.addEventListener('beforeunload', this.boundUnloadCleanup);
    window.addEventListener('pagehide', this.boundUnloadCleanup);
  }

  public destroy(): void {
    window.cancelAnimationFrame(this.rafId);
    window.removeEventListener('beforeunload', this.boundUnloadCleanup);
    window.removeEventListener('pagehide', this.boundUnloadCleanup);
    if (this.roundStartTimer !== null) window.clearTimeout(this.roundStartTimer);
    if (this.announcerTimer !== null) window.clearTimeout(this.announcerTimer);
    sound.setArenaAmbience(false);
    this.cleanupPeerSession();
    if (this.bc) {
      try {
        this.bc.close();
      } catch {
        // ignore
      }
    }
  }

  public resize(): void {
    const vw = window.visualViewport ? window.visualViewport.width : window.innerWidth;
    const vh = window.visualViewport ? window.visualViewport.height : window.innerHeight;
    const dpr = Math.min(window.devicePixelRatio || 1, 3);
    this.canvas.width = Math.max(1, Math.round(vw * dpr));
    this.canvas.height = Math.max(1, Math.round(vh * dpr));
    this.ctx.imageSmoothingEnabled = true;
    this.ctx.imageSmoothingQuality = 'high';
  }

  private startLoop(): void {
    const loop = (now: number) => {
      const dt = (now - this.lastTime) * 0.001;
      this.lastTime = now;
      this.updateSimulation(dt);
      this.renderScene(now * 0.001);
      this.rafId = window.requestAnimationFrame(loop);
    };
    this.rafId = window.requestAnimationFrame(loop);
  }

  // ==================== MULTIPLAYER ====================
  public generateRoomCode(): string {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let code = 'SHD-';
    for (let i = 0; i < 3; i++) code += chars.charAt(Math.floor(Math.random() * chars.length));
    return code;
  }

  private normalizeRoomCode(raw: string): string {
    const clean = String(raw || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (clean.startsWith('SHD') && clean.length === 6) return 'SHD-' + clean.slice(3);
    if (clean.length === 3) return 'SHD-' + clean;
    if (clean.length >= 6) return clean.slice(0, 3) + '-' + clean.slice(3, 6);
    return String(raw || '').toUpperCase().trim();
  }

  private codeToPeerId(code: string, role: string): string {
    return 'scc-room-' + code.toLowerCase().replace(/[^a-z0-9]/g, '') + '-' + role;
  }

  private setupMessaging(): void {
    try {
      if ('BroadcastChannel' in window) {
        this.bc = new BroadcastChannel('scc_team_room_v2');
        this.bc.onmessage = (ev) => this.handleNetMsg(ev.data as NetMsg);
      }
    } catch {
      // ignore
    }
    window.addEventListener('storage', (ev) => {
      if (ev.key === 'scc_net_packet_v2' && ev.newValue) {
        try {
          this.handleNetMsg(JSON.parse(ev.newValue) as NetMsg);
        } catch {
          // ignore
        }
      }
    });
  }

  private ensurePeerJsLoaded(callback: (ok: boolean) => void): void {
    if (window.Peer) {
      callback(true);
      return;
    }
    if (this.peerLibLoading) {
      const id = window.setInterval(() => {
        if (window.Peer) {
          window.clearInterval(id);
          callback(true);
        }
      }, 120);
      window.setTimeout(() => window.clearInterval(id), 8000);
      return;
    }
    this.peerLibLoading = true;
    const sc = document.createElement('script');
    sc.src = 'https://unpkg.com/peerjs@1.5.4/dist/peerjs.min.js';
    sc.async = true;
    sc.onload = () => {
      this.peerLibLoading = false;
      callback(!!window.Peer);
    };
    sc.onerror = () => {
      this.peerLibLoading = false;
      callback(false);
    };
    document.head.appendChild(sc);
  }

  public cleanupPeerSession(): void {
    if (this.handshakeRetryTimer !== null) {
      window.clearInterval(this.handshakeRetryTimer);
      this.handshakeRetryTimer = null;
    }
    this.mpPingMs = null;
    this.lastRemoteStateSeq = 0;
    this.lastRemoteInputSeq = 0;
    if (this.peerConn) {
      try {
        this.peerConn.close();
      } catch {
        // ignore
      }
      this.peerConn = null;
    }
    if (this.peer) {
      try {
        this.peer.destroy();
      } catch {
        // ignore
      }
      this.peer = null;
    }
    void cleanupActiveRoomLifecycle(this.mpCode);
  }

  private setupPeerConnectionHandlers(conn: PeerConn): void {
    this.peerConn = conn;
    conn.on('open', () => {
      this.mpConnected = true;
      if (this.handshakeRetryTimer !== null) {
        window.clearInterval(this.handshakeRetryTimer);
        this.handshakeRetryTimer = null;
      }
      if (this.mpRole === 'guest') {
        this.cb.onMpStatusText('guest', 'Ultra-fast channel open · Syncing room...', '#4ade80');
        this.sendNetMsg({ type: 'JOIN_REQ', p2Id: this.p2Id });
      } else if (this.mpRole === 'host') {
        this.cb.onMpStatusText('host', 'Rival connected! Lock your fighters.', '#4ade80');
        this.sendNetMsg({ type: 'JOIN_ACK', p1Id: this.p1Id, p2Id: this.p2Id, arenaId: this.arenaId });
      }
      this.sendNetMsg({ type: 'PING', pingTs: Date.now() });
    });
    conn.on('data', (data) => this.handleNetMsg(data as NetMsg));
    conn.on('close', () => {
      if (this.mode === 'mp' && this.mpConnected) {
        this.mpConnected = false;
        this.mpPingMs = null;
        this.cb.onToast('Rival disconnected from room.');
      }
    });
  }

  public initHostMultiplayerRoom(): void {
    this.mode = 'mp';
    this.mpRole = 'host';
    this.mpConnected = false;
    this.cleanupPeerSession();
    void registerActiveRoomLifecycle(this.mpCode, 'host');
    this.cb.onMpStatusText('host', `Setting up low-latency room ${this.mpCode}...`, '#fde047');

    this.ensurePeerJsLoaded((ok) => {
      if (!ok || !window.Peer) {
        this.cb.onMpStatusText('host', 'Local/tab relay ready · Share code with friend', '#4ade80');
        return;
      }
      try {
        const peer = new window.Peer(this.codeToPeerId(this.mpCode, 'host'), {
          config: {
            iceServers: [
              { urls: 'stun:stun.l.google.com:19302' },
              { urls: 'stun:stun1.l.google.com:19302' },
              { urls: 'stun:stun.cloudflare.com:3478' },
              { urls: 'stun:global.stun.twilio.com:3478' },
            ],
          },
        });
        this.peer = peer;
        peer.on('open', () => {
          if (!this.mpConnected) {
            this.cb.onMpStatusText('host', 'Low-latency WebRTC ready · Share code with friend', '#4ade80');
          }
        });
        peer.on('connection', (conn) => this.setupPeerConnectionHandlers(conn as PeerConn));
        peer.on('error', (err) => {
          const e = err as { type?: string };
          if (e?.type === 'unavailable-id') {
            this.mpCode = this.generateRoomCode();
            this.initHostMultiplayerRoom();
          } else if (!this.mpConnected) {
            this.cb.onMpStatusText('host', 'Local/tab relay ready · Share code with friend', '#4ade80');
          }
        });
      } catch {
        this.cb.onMpStatusText('host', 'Local/tab relay ready · Share code with friend', '#4ade80');
      }
    });
  }

  public joinGuestMultiplayerRoom(rawCode: string): void {
    const formatted = this.normalizeRoomCode(rawCode);
    if (formatted.length < 5) {
      this.cb.onToast('Enter a valid 6-character Team Code (e.g. SHD-88K)');
      return;
    }
    this.mode = 'mp';
    this.mpRole = 'guest';
    this.mpCode = formatted;
    this.mpConnected = false;
    this.cleanupPeerSession();
    void registerActiveRoomLifecycle(formatted, 'guest');
    this.cb.onMpStatusText('guest', `Connecting to room ${formatted}...`, '#fde047');
    this.sendNetMsg({
      type: 'JOIN_REQ',
      p2Id: this.p2Id,
      p2SkinId: this.p2SkinId,
      p2AuraId: this.p2AuraId,
    });

    this.ensurePeerJsLoaded((ok) => {
      if (!ok || !window.Peer || this.mpConnected) return;
      try {
        const guestPeerId = `${this.codeToPeerId(formatted, 'guest')}-${Math.floor(Math.random() * 900 + 100)}`;
        const peer = new window.Peer(guestPeerId, {
          config: {
            iceServers: [
              { urls: 'stun:stun.l.google.com:19302' },
              { urls: 'stun:stun1.l.google.com:19302' },
              { urls: 'stun:stun.cloudflare.com:3478' },
              { urls: 'stun:global.stun.twilio.com:3478' },
            ],
          },
        });
        this.peer = peer;
        peer.on('open', () => {
          if (this.mpConnected) return;
          // Unreliable/unordered data channel eliminates TCP-like head-of-line packet stalls
          const conn = peer.connect(this.codeToPeerId(formatted, 'host'), {
            reliable: false,
            serialization: 'json',
          });
          this.setupPeerConnectionHandlers(conn);

          let retries = 0;
          this.handshakeRetryTimer = window.setInterval(() => {
            retries++;
            if (this.mpConnected || retries > 10) {
              if (this.handshakeRetryTimer !== null) {
                window.clearInterval(this.handshakeRetryTimer);
                this.handshakeRetryTimer = null;
              }
              return;
            }
            if (conn.open) {
              this.sendNetMsg({
                type: 'JOIN_REQ',
                p2Id: this.p2Id,
                p2SkinId: this.p2SkinId,
                p2AuraId: this.p2AuraId,
              });
            }
          }, 550);
        });
        peer.on('error', () => {
          if (!this.mpConnected) {
            this.cb.onMpStatusText('guest', `Could not reach room ${formatted}. Check code & retry.`, '#fb7185');
          }
        });
      } catch {
        // ignore
      }
    });
  }

  public sendNetMsg(payload: NetMsg): void {
    if (!this.mpCode) return;
    payload.code = this.mpCode;
    payload.sender = this.mpRole;
    payload.seq = ++this.lastPacketSeq;
    payload.ts = Date.now();
    if (payload.type === 'SELECT_SYNC' || payload.type === 'START_MATCH' || payload.type === 'REMATCH_SYNC') {
      payload.p1SkinId = payload.p1SkinId ?? this.p1SkinId;
      payload.p2SkinId = payload.p2SkinId ?? this.p2SkinId;
      payload.p1AuraId = payload.p1AuraId ?? this.p1AuraId;
      payload.p2AuraId = payload.p2AuraId ?? this.p2AuraId;
    }

    const isCriticalEvent =
      payload.type === 'START_MATCH' ||
      payload.type === 'REMATCH_SYNC' ||
      payload.type === 'JOIN_ACK' ||
      payload.type === 'JOIN_REQ' ||
      payload.type === 'SELECT_SYNC' ||
      payload.type === 'EMOTE';

    if (this.peerConn && this.peerConn.open) {
      try {
        this.peerConn.send(payload);
        // Redundant echo for critical discrete packets over unreliable DataChannel (receiver deduplicates by seq)
        if (isCriticalEvent) {
          window.setTimeout(() => {
            if (this.peerConn && this.peerConn.open) {
              try {
                this.peerConn.send(payload);
              } catch {
                // ignore
              }
            }
          }, 70);
        }
      } catch {
        // ignore
      }
      return;
    }

    // Same-browser tab fallback only when direct WebRTC channel is not open
    if (this.bc) {
      try {
        this.bc.postMessage(payload);
      } catch {
        // ignore
      }
    }
    try {
      window.localStorage.setItem('scc_net_packet_v2', JSON.stringify(payload));
    } catch {
      // ignore
    }
  }

  private handleNetMsg(msg: NetMsg): void {
    if (!msg || !msg.code || this.normalizeRoomCode(msg.code) !== this.normalizeRoomCode(this.mpCode)) return;
    if (msg.sender === this.mpRole) return;

    if (msg.type === 'PING' && typeof msg.pingTs === 'number') {
      this.sendNetMsg({ type: 'PONG', pingTs: msg.pingTs });
      return;
    }
    if (msg.type === 'PONG' && typeof msg.pingTs === 'number') {
      const rtt = Math.max(1, Math.min(999, Math.round(Date.now() - msg.pingTs)));
      this.mpPingMs = this.mpPingMs === null ? rtt : Math.round(this.mpPingMs * 0.65 + rtt * 0.35);
      return;
    }

    // Deduplicate identical packets arriving over multiple transports or redundant echoes
    if (msg.seq !== undefined && msg.sender) {
      const dedupKey = `${msg.sender}:${msg.type}:${msg.seq}`;
      if (this.seenPacketKeys.has(dedupKey)) return;
      this.seenPacketKeys.add(dedupKey);
      if (this.seenPacketKeys.size > 400) {
        const first = this.seenPacketKeys.values().next().value;
        if (first) this.seenPacketKeys.delete(first);
      }
    }

    if (msg.type === 'JOIN_REQ' && this.mpRole === 'host') {
      this.mpConnected = true;
      if (msg.p2Id && msg.p2Id !== this.p1Id) this.p2Id = msg.p2Id;
      else if (this.p2Id === this.p1Id) this.p2Id = FIGHTERS[0].id === this.p1Id ? FIGHTERS[1].id : FIGHTERS[0].id;
      if (msg.p2SkinId) this.p2SkinId = msg.p2SkinId;
      if (msg.p2AuraId) this.p2AuraId = msg.p2AuraId;
      this.cb.onMpStatusText('host', 'Rival connected! Lock your fighters.', '#4ade80');
      this.sendNetMsg({
        type: 'JOIN_ACK',
        p1Id: this.p1Id,
        p2Id: this.p2Id,
        p1SkinId: this.p1SkinId,
        p2SkinId: this.p2SkinId,
        p1AuraId: this.p1AuraId,
        p2AuraId: this.p2AuraId,
        arenaId: this.arenaId,
      });
      window.setTimeout(() => this.cb.onMpConnected('host', this.p1Id, this.p2Id, this.arenaId), 220);
    } else if (msg.type === 'JOIN_ACK' && this.mpRole === 'guest') {
      this.mpConnected = true;
      if (msg.p1Id) this.p1Id = msg.p1Id;
      if (msg.p1SkinId) this.p1SkinId = msg.p1SkinId;
      if (msg.p1AuraId) this.p1AuraId = msg.p1AuraId;
      if (msg.arenaId) this.arenaId = msg.arenaId;
      if (msg.p2Id && msg.p2Id !== this.p1Id) this.p2Id = msg.p2Id;
      else if (this.p2Id === this.p1Id) this.p2Id = FIGHTERS[0].id === this.p1Id ? FIGHTERS[1].id : FIGHTERS[0].id;
      this.cb.onMpStatusText('guest', 'Connected! Entering fighter select...', '#4ade80');
      this.sendNetMsg({
        type: 'SELECT_SYNC',
        p1Id: this.p1Id,
        p2Id: this.p2Id,
        p1SkinId: this.p1SkinId,
        p2SkinId: this.p2SkinId,
        p1AuraId: this.p1AuraId,
        p2AuraId: this.p2AuraId,
        arenaId: this.arenaId,
      });
      window.setTimeout(() => this.cb.onMpConnected('guest', this.p1Id, this.p2Id, this.arenaId), 220);
    } else if (msg.type === 'SELECT_SYNC') {
      if (this.mpRole === 'host') {
        if (msg.p2Id && msg.p2Id !== this.p1Id) this.p2Id = msg.p2Id;
        if (msg.p2SkinId) this.p2SkinId = msg.p2SkinId;
        if (msg.p2AuraId) this.p2AuraId = msg.p2AuraId;
        if (msg.arenaId) this.arenaId = msg.arenaId;
      } else {
        if (msg.p1Id) this.p1Id = msg.p1Id;
        if (msg.p1SkinId) this.p1SkinId = msg.p1SkinId;
        if (msg.p1AuraId) this.p1AuraId = msg.p1AuraId;
        if (msg.arenaId) this.arenaId = msg.arenaId;
        if (this.p2Id === this.p1Id) this.p2Id = FIGHTERS[0].id === this.p1Id ? FIGHTERS[1].id : FIGHTERS[0].id;
      }
      this.cb.onMpSelectSync(this.p1Id, this.p2Id, this.arenaId);
    } else if (msg.type === 'START_MATCH') {
      if (msg.p1Id) this.p1Id = msg.p1Id;
      if (msg.p2Id) this.p2Id = msg.p2Id;
      if (msg.p1SkinId) this.p1SkinId = msg.p1SkinId;
      if (msg.p2SkinId) this.p2SkinId = msg.p2SkinId;
      if (msg.p1AuraId) this.p1AuraId = msg.p1AuraId;
      if (msg.p2AuraId) this.p2AuraId = msg.p2AuraId;
      if (msg.arenaId) this.arenaId = msg.arenaId;
      this.cb.onMpStartMatch(this.p1Id, this.p2Id, this.arenaId);
    } else if (msg.type === 'INPUT_SYNC' && this.phase === 'FIGHT') {
      if (typeof msg.seq === 'number') {
        if (msg.seq <= this.lastRemoteInputSeq) return;
        this.lastRemoteInputSeq = msg.seq;
      }
      const remoteF = this.mpRole === 'host' ? this.f2 : this.f1;
      if (remoteF && msg.input) {
        remoteF.remoteInput = {
          moveX: msg.input.moveX,
          moveY: msg.input.moveY,
          block: msg.input.block,
          action: msg.input.action || remoteF.remoteInput.action,
        };
        if (typeof msg.x === 'number' && typeof msg.y === 'number') {
          const lead = Math.min(0.04, (this.mpPingMs ?? 20) * 0.0005);
          const predX = msg.x + remoteF.vx * lead;
          remoteF.x += (predX - remoteF.x) * 0.55;
          remoteF.y += (msg.y - remoteF.y) * 0.55;
        }
      }
    } else if (msg.type === 'STATE_SYNC' && this.mpRole === 'guest' && this.phase === 'FIGHT') {
      if (typeof msg.seq === 'number') {
        if (msg.seq <= this.lastRemoteStateSeq) return;
        this.lastRemoteStateSeq = msg.seq;
      }
      if (this.f1 && msg.f1) this.applyAuthoritativeFighterState(this.f1, msg.f1, true);
      if (this.f2 && msg.f2) this.applyAuthoritativeFighterState(this.f2, msg.f2, false);
      if (typeof msg.timer === 'number') this.timer = msg.timer;
      if (typeof msg.p1Wins === 'number') this.p1Wins = msg.p1Wins;
      if (typeof msg.p2Wins === 'number') this.p2Wins = msg.p2Wins;
      if (this.f1 && this.f2) {
        if (this.f1.hp <= 0) this.handleRoundKO(this.f2, this.f1);
        else if (this.f2.hp <= 0) this.handleRoundKO(this.f1, this.f2);
      }
    } else if (msg.type === 'EMOTE' && msg.emoteId && msg.emoteSlot) {
      this.spawnStickerBubble(msg.emoteSlot, msg.emoteId);
    } else if (msg.type === 'REMATCH_SYNC') {
      this.beginMatch();
    }
  }

  private serializeFighterState(f: Fighter | null): SerializedFighter | null {
    if (!f) return null;
    return {
      x: Math.round(f.x * 10) / 10,
      y: Math.round(f.y * 10) / 10,
      vx: Math.round(f.vx),
      vy: Math.round(f.vy),
      facing: f.facing,
      hp: f.hp,
      rage: Math.round(f.rage),
      state: f.state,
      moveKey: f.move ? f.move.key : null,
      moveFrame: Math.round(f.moveFrame),
      blocking: f.blocking,
      crouching: f.crouching,
      sp1Cd: Math.round(f.sp1Cd * 10) / 10,
      sp2Cd: Math.round(f.sp2Cd * 10) / 10,
      dashCd: Math.round(f.dashCd * 10) / 10,
    };
  }

  private applyAuthoritativeFighterState(f: Fighter, s: SerializedFighter, isRemoteAvatar: boolean): void {
    const halfRttSec = Math.min(0.055, (this.mpPingMs ?? 24) * 0.0005);
    const predX = s.x + s.vx * halfRttSec;
    const predY = Math.min(WORLD.groundY, s.y + s.vy * halfRttSec);

    if (isRemoteAvatar) {
      const errX = predX - f.x;
      if (Math.abs(errX) > 110) {
        f.x = predX;
      } else {
        f.x += errX * 0.68;
      }
      f.y += (predY - f.y) * 0.68;
    } else {
      const errX = s.x - f.x;
      if (Math.abs(errX) > 95) {
        f.x = s.x;
      } else if (Math.abs(errX) > 26) {
        f.x += errX * 0.42;
      }
      if (Math.abs(s.y - f.y) > 26) {
        f.y += (s.y - f.y) * 0.42;
      }
    }
    f.vx = s.vx;
    f.vy = s.vy;
    f.facing = s.facing;
    f.hp = s.hp;
    f.rage = s.rage;
    f.blocking = s.blocking;
    f.crouching = s.crouching;
    f.sp1Cd = s.sp1Cd;
    f.sp2Cd = s.sp2Cd;
    f.dashCd = s.dashCd;
    if (isRemoteAvatar && s.state !== f.state) {
      f.state = s.state;
      if (s.moveKey && !f.move) {
        f.move = getCharMove(f, s.moveKey);
        f.moveFrame = s.moveFrame;
      }
    }
  }

  public setCosmetics(slot: 1 | 2, skinId: string, auraId: string): void {
    if (slot === 1) {
      this.p1SkinId = skinId || '';
      this.p1AuraId = auraId || DEFAULT_AURA_ID;
      if (this.f1) {
        this.f1.skinId = this.p1SkinId;
        this.f1.auraId = this.p1AuraId;
      }
    } else {
      this.p2SkinId = skinId || '';
      this.p2AuraId = auraId || DEFAULT_AURA_ID;
      if (this.f2) {
        this.f2.skinId = this.p2SkinId;
        this.f2.auraId = this.p2AuraId;
      }
    }
  }

  // ==================== MATCH LIFECYCLE ====================
  public setLobbyTheme(theme: LobbyThemeId): void {
    this.lobbyTheme = theme;
  }

  public setLobbyShowcase(fighterId: string, skinId: string, auraId: string): void {
    this.p1Id = fighterId || this.p1Id;
    this.p1SkinId = skinId || '';
    this.p1AuraId = auraId || DEFAULT_AURA_ID;
    if (this.phase !== 'MENU') return;
    const cfg = getCfgById(this.p1Id);
    if (!this.f1 || this.f1.cfg.id !== cfg.id) {
      this.f1 = new Fighter(1, cfg, -190, 1, this.p1SkinId, this.p1AuraId);
    } else {
      this.f1.skinId = this.p1SkinId;
      this.f1.auraId = this.p1AuraId;
      this.f1.x = -190;
      this.f1.y = WORLD.groundY;
      this.f1.facing = 1;
    }
  }

  public setupMenuDemoFighters(): void {
    if (this.roundStartTimer !== null) {
      window.clearTimeout(this.roundStartTimer);
      this.roundStartTimer = null;
    }
    this.phase = 'MENU';
    sound.setArenaAmbience(false);
    this.camX = 0;
    this.camZoom = 1.08;
    const c1 = getCfgById(this.p1Id);
    const c2 = getCfgById(this.p2Id);
    this.f1 = new Fighter(1, c1, -190, 1, this.p1SkinId, this.p1AuraId);
    this.f2 = new Fighter(2, c2, 215, -1, this.p2SkinId, this.p2AuraId);
    this.projectiles = [];
    this.vfxEffects = [];
    this.particles = [];
    this.popups = [];
    this.activeStickers = [];
  }

  public beginMatch(): void {
    if (this.roundStartTimer !== null) window.clearTimeout(this.roundStartTimer);
    this.paused = false;
    this.resetInputs();
    this.round = 1;
    this.p1Wins = 0;
    this.p2Wins = 0;
    if (this.mode === 'bot' && this.p2Id === this.p1Id) {
      this.p2Id = FIGHTERS[0].id === this.p1Id ? FIGHTERS[1].id : FIGHTERS[0].id;
    }
    this.beginRound();
  }

  private beginRound(): void {
    if (this.roundStartTimer !== null) window.clearTimeout(this.roundStartTimer);
    this.resetInputs();
    const c1 = getCfgById(this.p1Id);
    const c2 = getCfgById(this.p2Id);
    this.f1 = new Fighter(1, c1, -210, 1, this.p1SkinId, this.p1AuraId);
    this.f2 = new Fighter(2, c2, 210, -1, this.p2SkinId, this.p2AuraId);
    this.projectiles = [];
    this.vfxEffects = [];
    this.particles = [];
    this.popups = [];
    this.activeStickers = [];
    this.timer = 60;
    this.timerAcc = 0;
    this.slowMoTimer = 0;
    this.camX = 0;
    this.camZoom = 1.06;
    this.phase = 'INTRO';

    this.pushHudSnapshot();
    this.showAnnouncer(`ROUND ${this.round}`);
    this.roundStartTimer = window.setTimeout(() => {
      this.phase = 'FIGHT';
      this.crowdCheerTimer = 2.8 + Math.random() * 1.8;
      this.crowdExcitement = 1.0;
      this.showAnnouncer(this.practice ? 'PRACTICE!' : 'YUDH!');
      sound.playSfx('gong');
      sound.playCrowdCheer('hype');
      sound.setArenaAmbience(true, 0.55);
    }, 1050);
  }

  private showAnnouncer(text: string): void {
    this.cb.onAnnounce(text);
    if (this.announcerTimer !== null) window.clearTimeout(this.announcerTimer);
    this.announcerTimer = window.setTimeout(() => this.cb.onAnnounce(null), 1200);
  }

  public getLocalFighter(): Fighter | null {
    if (this.mode === 'mp' && this.mpRole === 'guest') return this.f2;
    return this.f1;
  }

  public resetInputs(): void {
    this.joyX = 0;
    this.joyY = 0;
    this.blockHeld = false;
    this.keys = {};
    this.prevMoveX = 0;
  }

  public setJoystick(nx: number, ny: number): void {
    this.joyX = nx;
    this.joyY = ny;
    // Hysteresis prevents thumb jitter around 0.45 from falsely triggering double-tap dash
    const dir = nx > 0.58 ? 1 : nx < -0.58 ? -1 : Math.abs(nx) < 0.25 ? 0 : this.prevMoveX;
    if (dir !== 0 && this.prevMoveX === 0) {
      const now = performance.now();
      const lf = this.getLocalFighter();
      if (lf && this.phase === 'FIGHT' && !this.paused) {
        if (dir === -1) {
          if (now - this.lastTapLeft < 260) this.triggerDash(lf, -1);
          this.lastTapLeft = now;
        } else {
          if (now - this.lastTapRight < 260) this.triggerDash(lf, 1);
          this.lastTapRight = now;
        }
      }
    }
    this.prevMoveX = dir;

    if (
      this.mode === 'mp' &&
      this.mpConnected &&
      this.phase === 'FIGHT' &&
      (Math.abs(nx - this.lastSentMoveX) > 0.14 || Math.abs(ny - this.lastSentMoveY) > 0.14)
    ) {
      this.lastSentMoveX = nx;
      this.lastSentMoveY = ny;
      const lf = this.getLocalFighter();
      if (lf) {
        this.sendNetMsg({
          type: 'INPUT_SYNC',
          input: { moveX: nx, moveY: ny, block: this.blockHeld, action: null },
          x: lf.x,
          y: lf.y,
        });
      }
    }
  }

  private getEffectiveInputAxis(): { mx: number; my: number } {
    let mx = this.joyX;
    let my = this.joyY;
    if (this.keys['a'] || this.keys['arrowleft']) mx = -1;
    if (this.keys['d'] || this.keys['arrowright']) mx = 1;
    if (this.keys['w'] || this.keys['arrowup']) my = -1;
    if (this.keys['s'] || this.keys['arrowdown']) my = 1;
    return { mx, my };
  }

  public setShieldHeld(held: boolean): void {
    const wasHeld = this.blockHeld;
    this.blockHeld = held;
    if (held && !wasHeld && this.phase === 'FIGHT' && !this.paused) {
      sound.ensureAudio();
      const lf = this.getLocalFighter();
      if (lf && (lf.state === 'IDLE' || lf.state === 'WALK' || lf.state === 'CROUCH')) {
        lf.parryTimer = 0.16;
      }
    }
    if (this.mode === 'mp' && this.mpConnected && held !== this.lastSentBlock && this.phase === 'FIGHT') {
      this.lastSentBlock = held;
      const lf = this.getLocalFighter();
      if (lf) {
        const { mx, my } = this.getEffectiveInputAxis();
        this.sendNetMsg({
          type: 'INPUT_SYNC',
          input: {
            moveX: mx,
            moveY: my,
            block: held,
            action: held ? 'shield' : null,
          },
          x: lf.x,
          y: lf.y,
        });
      }
    }
  }

  private spawnStickerBubble(slot: 1 | 2, emoteId: StickerEmoteId): void {
    this.activeStickers = this.activeStickers.filter((s) => s.slot !== slot);
    this.activeStickers.push({
      slot,
      emoteId,
      life: 2.35,
      maxLife: 2.35,
    });
  }

  public triggerEmote(emoteId: StickerEmoteId): void {
    if (this.phase === 'MENU') return;
    sound.ensureAudio();
    const localSlot: 1 | 2 = this.mode === 'mp' && this.mpRole === 'guest' ? 2 : 1;
    this.spawnStickerBubble(localSlot, emoteId);
    sound.playSfx('boing');
    if (this.mode === 'mp' && this.mpConnected) {
      this.sendNetMsg({
        type: 'EMOTE',
        emoteId,
        emoteSlot: localSlot,
      });
    }
  }

  public triggerCombatAction(btnType: CombatButtonKind): void {
    sound.ensureAudio();
    if (this.phase !== 'FIGHT' || this.paused) return;
    const f = this.getLocalFighter();
    if (!f) return;
    const { mx, my } = this.getEffectiveInputAxis();

    let resolvedAction: string = btnType;
    if (btnType === 'dash') {
      const dashDir = Math.abs(mx) > 0.2 ? (mx > 0 ? 1 : -1) : f.facing;
      this.triggerDash(f, dashDir);
    } else if (btnType === 'basic') {
      resolvedAction = resolveBasicAttack(f, mx, my);
      this.queueOrStartAttack(f, resolvedAction);
    } else if (btnType === 'sp1') {
      this.queueOrStartAttack(f, 'SP1');
    } else if (btnType === 'sp2') {
      this.queueOrStartAttack(f, 'SP2');
    } else if (btnType === 'rage') {
      this.queueOrStartAttack(f, 'RAGE');
    } else if (btnType === 'shield') {
      this.setShieldHeld(true);
      return;
    }

    if (this.mode === 'mp') {
      this.sendNetMsg({
        type: 'INPUT_SYNC',
        input: {
          moveX: mx,
          moveY: my,
          block: this.blockHeld,
          action: resolvedAction,
        },
        x: f.x,
        y: f.y,
      });
    }
  }

  // ==================== FIGHTER ACTIONS (COMPETITIVE SMOOTH COMBAT) ====================
  public triggerDash(f: Fighter, dir: number): void {
    if (f.dashCd > 0) return;
    if (f.state === 'HURT' || f.state === 'BLOCKSTUN' || f.state === 'KO') return;
    // Allow smooth hit-confirm dash cancel on normals after hit, or normal recovery dash
    if (f.state === 'ATTACK' && f.move) {
      const recoveryStart = f.move.startup + f.move.active;
      const canHitCancel = !f.move.special && f.hasHit && f.moveFrame >= f.move.startup + 2;
      if (!canHitCancel && (!f.hasHit || f.moveFrame < recoveryStart)) return;
    }
    const airborne = f.y < WORLD.groundY - 6;
    if (airborne && f.airDashed) return;
    if (airborne) f.airDashed = true;

    f.state = 'DASH';
    f.stateTimer = 0.15;
    f.invuln = 0.10;
    f.dashCd = 0.95;
    f.move = null;
    f.vx = dir * 700;
    f.scaleX = 1.24;
    f.scaleY = 0.82;
    f.recordAfterimage();
    sound.playSfx('dash');
    this.addParticles(f.x, f.y - 30, f.cfg.aura, 10, 3, 6);
    if (!airborne) {
      this.addParticles(f.x - dir * 10, WORLD.groundY, '#cbd5e1', 6, 1.4, 3.2);
    }
  }

  public queueOrStartAttack(f: Fighter, key: string): void {
    f.inputBuffer.key = key;
    f.inputBuffer.timer = 0.22;
    this.tryExecuteBufferedAttack(f);
  }

  private tryExecuteBufferedAttack(f: Fighter): void {
    if (!f.inputBuffer.key || f.inputBuffer.timer <= 0) return;
    if (f.state === 'HURT' || f.state === 'BLOCKSTUN' || f.state === 'KO' || f.state === 'DASH') return;
    const nextKey = f.inputBuffer.key;
    if (f.state === 'ATTACK' && f.move) {
      const mv = f.move;
      const isSpecialNext = nextKey === 'SP1' || nextKey === 'SP2' || nextKey === 'RAGE';
      const isChainBasic =
        (mv.key === 'BASIC_1' && nextKey === 'BASIC_2') ||
        (mv.key === 'BASIC_2' && nextKey === 'BASIC_3');
      // Crisp hit-confirm target chains: Basic 1->2->3 & Basic->Skill cancel right after connecting!
      const canChainCancel = !mv.special && f.hasHit && (isSpecialNext || isChainBasic) && f.moveFrame >= mv.startup + 2;
      // Enforce full 16f recovery on heavy finishers (BASIC_3 & BASIC_FWD) if blocked or whiffed
      const cancelPoint = mv.special
        ? mv.startup + mv.active + mv.recovery * 0.68
        : mv.key === 'BASIC_3' || mv.key === 'BASIC_FWD'
          ? mv.startup + mv.active + mv.recovery
          : mv.startup + mv.active + 1;
      if (!canChainCancel && f.moveFrame < cancelPoint) return;
    }

    const key = f.inputBuffer.key;
    if (key === 'SP1' && f.sp1Cd > 0) return;
    if (key === 'SP2' && f.sp2Cd > 0) return;
    if (key === 'RAGE' && f.rage < 100) return;

    const mv = getCharMove(f, key);
    if (!mv) return;

    f.inputBuffer.key = null;
    f.inputBuffer.timer = 0;
    f.state = 'ATTACK';
    f.move = mv;
    f.moveFrame = 0;
    f.hasHit = false;
    f.rageWavesHit = [false, false, false];
    f.blocking = false;
    f.crouching = false;

    if (key === 'BASIC_1') {
      f.basicChainStep = 1;
      f.basicChainTimer = 0.48;
    } else if (key === 'BASIC_2') {
      f.basicChainStep = 2;
      f.basicChainTimer = 0.48;
    } else {
      f.basicChainStep = 0;
      f.basicChainTimer = 0;
    }

    if (key === 'SP1') {
      f.sp1Cd = 3.6;
      sound.playSfx(f.cfg.sp1Sfx || 'whoosh');
      this.addPopup(f.x, f.y - 175, f.cfg.sp1Name.toUpperCase() + '!', f.cfg.glow, 'big');
    } else if (key === 'SP2') {
      f.sp2Cd = 4.8;
      sound.playSfx(f.cfg.sp2Sfx || 'kick');
      f.recordAfterimage();
      this.addPopup(f.x, f.y - 175, f.cfg.sp2Name.toUpperCase() + '!', f.cfg.aura, 'big');
    } else if (key === 'RAGE') {
      f.rage = 0;
      // Invulnerable all the way past startup into active window
      f.invuln = 0.34;
      this.shake = 12;
      f.recordAfterimage();
      this.addVfx('telegraph_flash', f.x, f.y - 92, f.facing, '#fde047', f.cfg.aura, 0.30);
      sound.playSfx('gong');
      sound.playSfx(f.cfg.sp1Sfx || 'heavy_hit');
      sound.playCrowdCheer('hype');
      this.crowdExcitement = Math.max(this.crowdExcitement, 1.25);
      this.addPopup(f.x, f.y - 195, `${f.cfg.rageName.toUpperCase()}!`, '#fde047', 'ko');
    } else {
      const isKickSound =
        key === 'BASIC_3' ||
        key === 'BASIC_FWD' ||
        key === 'BASIC_LOW' ||
        key === 'BASIC_UP' ||
        key === 'BASIC_AIR' ||
        key === 'BASIC_BACK';
      sound.playSfx(isKickSound ? 'kick' : 'whoosh');
    }

    if (!this.practice && (key === 'SP1' || key === 'SP2' || key === 'RAGE') && f === this.getLocalFighter()) {
      this.cb.onQuestMetric?.({
        kind: 'special_use',
        fighterId: f.cfg.id,
        arenaId: this.arenaId,
      });
    }
  }

  // ==================== HIT RESOLUTION ====================
  private applyHit(
    attacker: Fighter,
    defender: Fighter,
    rawDmg: number,
    knockX: number,
    knockY: number,
    isSpecial: boolean,
    specialTag: string | null,
    moveMeta?: { low?: boolean; antiAir?: boolean }
  ): void {
    if (defender.invuln > 0 || defender.state === 'KO') return;

    const isCounter =
      defender.state === 'ATTACK' &&
      !!defender.move &&
      (defender.moveFrame < defender.move.startup ||
        (defender.move.special === 'SP2' && defender.moveFrame > defender.move.startup + defender.move.active));

    // Fair Combo Scaling: 100% -> 78% -> 58%, decaying cleanly for longer juggles
    const comboScale =
      attacker.comboCount === 0 ? 1.0 : attacker.comboCount === 1 ? 0.78 : attacker.comboCount === 2 ? 0.58 : attacker.comboCount === 3 ? 0.46 : 0.38;
    let dmg = rawDmg * comboScale;

    if (moveMeta?.antiAir && defender.y < WORLD.groundY - 14) {
      dmg *= 1.2;
      this.addPopup(defender.x, defender.y - 210, 'ANTI-AIR! +20%', '#38bdf8', 'counter');
      sound.playCrowdCheer('hype');
      this.crowdExcitement = Math.max(this.crowdExcitement, 1.05);
    }

    if (isCounter) {
      dmg *= 1.25;
      this.addPopup(defender.x, defender.y - 195, 'COUNTER! +25%', '#fb7185', 'counter');
      sound.playSfx('counter');
      sound.playCrowdCheer('hype');
      this.crowdExcitement = Math.max(this.crowdExcitement, 1.1);
    }

    // Skill-Based Perfect Guard / Parry (0.16s window: negates chip damage, gold flash & +12% Chakra)
    if (defender.blocking && defender.parryTimer > 0 && specialTag !== 'THROW' && specialTag !== 'RAGE_WAVE') {
      defender.parryTimer = 0;
      defender.parryFlashTimer = 0.28;
      defender.invuln = 0.16;
      defender.rage = Math.min(100, defender.rage + 12);
      defender.state = 'IDLE';
      defender.blocking = false;
      if (specialTag !== 'PROJECTILE') {
        attacker.state = 'HURT';
        attacker.stateTimer = 0.42;
        attacker.move = null;
        attacker.blocking = false;
        attacker.vx = -attacker.facing * 200;
        attacker.vy = -80;
        this.addVfx('hit_spark', attacker.x, attacker.y - 92, -attacker.facing, '#fde047', '#facc15', 0.24);
      }
      sound.playSfx('counter');
      sound.playCrowdCheer('hype');
      this.crowdExcitement = Math.max(this.crowdExcitement, 1.18);
      this.addPopup(defender.x, defender.y - 185, 'PARRY! +12%', '#fde047', 'counter');
      this.addVfx('block_ring', defender.x + defender.facing * 16, defender.y - 94, attacker.facing, '#fde047', '#fef08a', 0.34);
      this.addParticles(defender.x + defender.facing * 18, defender.y - 95, '#fde047', 16, 3, 7);
      this.hitStop = 0.065;
      this.shake = 8;
      return;
    }

    // Low attacks beat standing block (must crouch-block to guard lows!)
    const blockBrokenByLow = !!(moveMeta?.low && defender.blocking && !defender.crouching);
    if (blockBrokenByLow) {
      this.addPopup(defender.x, defender.y - 178, 'LOW HIT!', '#fbbf24', 'counter');
    }

    if (defender.blocking && !isCounter && !blockBrokenByLow && specialTag !== 'THROW') {
      const chipDmg = Math.max(1, Math.round(dmg * 0.15));
      defender.hp = Math.max(0, defender.hp - chipDmg);
      defender.vx = attacker.facing * (knockX * 0.22);
      defender.rage = Math.min(100, defender.rage + 7);
      defender.state = 'BLOCKSTUN';
      defender.stateTimer = 0.15;
      defender.move = null;
      sound.playSfx('block');
      this.addPopup(defender.x, defender.y - 160, `SHIELD -${chipDmg}`, '#7dd3fc', 'info');
      this.addVfx('block_ring', defender.x + defender.facing * 12, defender.y - 92, attacker.facing, '#7dd3fc', '#fde047', 0.22);
      this.addParticles(defender.x - attacker.facing * 20, defender.y - 95, '#7dd3fc', 10, 2, 5);
      this.hitStop = 0.036;
      this.shake = 3;
      if (defender.hp <= 0) this.handleRoundKO(attacker, defender);
      return;
    }

    dmg = Math.round(dmg);
    defender.hp = Math.max(0, defender.hp - dmg);
    defender.state = 'HURT';
    let stun = 0.25 + Math.min(0.20, dmg / 430);
    if (isSpecial) stun += 0.05;
    if (specialTag === 'THROW') stun = 0.52;
    defender.stateTimer = stun;
    defender.vx = attacker.facing * knockX;
    defender.vy = knockY;
    defender.scaleX = 0.80;
    defender.scaleY = 1.22;
    defender.move = null;
    defender.blocking = false;

    attacker.comboCount++;
    attacker.comboDamage += dmg;
    if (attacker.comboCount > attacker.maxCombo) attacker.maxCombo = attacker.comboCount;
    attacker.comboTimer = 1.5;
    defender.idleRegenTimer = 0;
    defender.consecutiveHitsTaken += 1;

    if (!this.practice && attacker === this.getLocalFighter()) {
      if (!isSpecial) {
        this.cb.onQuestMetric?.({
          kind: 'basic_hit',
          fighterId: attacker.cfg.id,
          arenaId: this.arenaId,
        });
      }
      if (isCounter) {
        this.cb.onQuestMetric?.({
          kind: 'counter_hit',
          fighterId: attacker.cfg.id,
          arenaId: this.arenaId,
        });
      }
    }

    if (attacker.comboCount === 3 || attacker.comboCount === 4 || attacker.comboCount === 6 || attacker.comboCount === 8) {
      const rankText = attacker.comboCount >= 8 ? 'LEGENDARY!' : attacker.comboCount >= 6 ? 'DESI FIRE!' : attacker.comboCount >= 4 ? 'SHABAASH!' : 'NICE!';
      const rankCol = attacker.comboCount >= 8 ? '#fde047' : attacker.comboCount >= 6 ? '#fb7185' : '#4ade80';
      this.addPopup(attacker.x, attacker.y - 200, rankText, rankCol, 'big');
      sound.playCrowdCheer('hype');
      this.crowdExcitement = Math.max(this.crowdExcitement, 1.15);
    } else if (!defender.lowHpCheerDone && defender.hp > 0 && defender.hp < 280) {
      defender.lowHpCheerDone = true;
      sound.playCrowdCheer('hype');
      this.crowdExcitement = Math.max(this.crowdExcitement, 1.15);
    }

    // Do not break attacker's multi-wave RAGE ultimate with mid-combo tech roll
    if (defender.consecutiveHitsTaken >= 4 && specialTag !== 'RAGE_WAVE') {
      defender.consecutiveHitsTaken = 0;
      attacker.comboCount = 0;
      defender.invuln = 0.55;
      defender.vx = attacker.facing * 440;
      defender.vy = -290;
      this.addPopup(defender.x, defender.y - 215, 'TECH ROLL!', '#38bdf8', 'info');
    }

    attacker.rage = Math.min(100, attacker.rage + (isSpecial ? 10 : 12));
    defender.rage = Math.min(100, defender.rage + 14);

    if (specialTag === 'THROW') sound.playSfx('heavy_hit');
    else sound.playSfx(isSpecial ? 'heavy_hit' : rawDmg >= 66 ? 'kick' : 'punch');

    if (specialTag === 'SLOW') {
      defender.slowTimer = 0.75;
      this.addPopup(defender.x, defender.y - 210, 'SLOWED!', '#38bdf8', 'info');
    }
    if (attacker.cfg.id === 'lota_lal' && isSpecial && specialTag !== 'THROW' && specialTag !== 'RAGE_WAVE') {
      defender.stinkTimer = 2.2;
      defender.stinkTickAcc = 0;
      this.addPopup(defender.x, defender.y - 215, 'BADBOO!', '#84cc16', 'info');
    }

    this.hitStop = specialTag === 'THROW' ? 0.075 : isSpecial ? 0.056 : rawDmg >= 66 ? 0.046 : 0.036;
    this.shake = specialTag === 'THROW' ? 14 : isSpecial ? 10 : 6;
    this.addVfx('hit_spark', defender.x, defender.y - 92, attacker.facing, attacker.cfg.glow, attacker.cfg.aura, 0.24);
    this.addVfx('impact_ring', defender.x, defender.y - 92, attacker.facing, attacker.cfg.aura, attacker.cfg.glow, isSpecial ? 0.34 : 0.24);
    this.addParticles(defender.x, defender.y - 90, attacker.cfg.glow, specialTag === 'THROW' ? 20 : 14, 3, 8);

    if (specialTag === 'THROW') {
      this.addPopup(defender.x, defender.y - 165, `PATKHA! -${dmg}`, '#f472b6', 'big');
    } else {
      this.addPopup(
        defender.x,
        defender.y - 148,
        `-${dmg}${attacker.comboCount > 1 ? ` x${attacker.comboCount}` : ''}`,
        '#fde047',
        attacker.comboCount > 2 ? 'big' : 'dmg'
      );
    }

    if (defender.hp <= 0) this.handleRoundKO(attacker, defender);
  }

  private handleRoundKO(winner: Fighter, loser: Fighter, reason: 'ko' | 'time' = 'ko'): void {
    if (this.phase !== 'FIGHT') return;

    if (this.practice) {
      loser.state = 'KO';
      loser.vx = winner.facing * 420;
      loser.vy = -380;
      this.shake = 10;
      this.slowMoTimer = 0.55;
      sound.playSfx('gong');
      this.showAnnouncer('RESET!');
      if (this.roundStartTimer !== null) window.clearTimeout(this.roundStartTimer);
      this.roundStartTimer = window.setTimeout(() => {
        [this.f1, this.f2].forEach((fg, idx) => {
          if (!fg) return;
          fg.hp = fg.maxHp;
          fg.rage = idx === 0 ? Math.min(fg.rage, 50) : 0;
          fg.state = 'IDLE';
          fg.move = null;
          fg.inputBuffer = { key: null, timer: 0 };
          fg.slowTimer = 0;
          fg.parryTimer = 0;
          fg.parryFlashTimer = 0;
          fg.wasBackHeld = false;
          fg.stepDustAcc = 0;
          fg.basicChainStep = 0;
          fg.basicChainTimer = 0;
          fg.stinkTimer = 0;
          fg.x = idx === 0 ? -210 : 210;
          fg.y = WORLD.groundY;
          fg.vx = 0;
          fg.vy = 0;
          fg.invuln = 0.3;
          fg.comboCount = 0;
          fg.comboDamage = 0;
        });
        this.projectiles = [];
        this.phase = 'FIGHT';
        this.showAnnouncer('PRACTICE!');
      }, 1050);
      return;
    }

    this.phase = 'ROUND_END';
    sound.setArenaAmbience(true, 1.0);
    loser.state = 'KO';
    loser.vx = winner.facing * 520;
    loser.vy = -520;
    this.slowMoTimer = 1.35;
    this.shake = 15;
    sound.playSfx('gong');
    sound.playCrowdCheer('ko');
    this.crowdExcitement = 1.5;

    if (winner.slot === 1) this.p1Wins++;
    else this.p2Wins++;
    this.pushHudSnapshot();
    this.showAnnouncer(reason === 'time' ? 'TIME UP!' : 'DHAMAKA KO!');

    if (this.roundStartTimer !== null) window.clearTimeout(this.roundStartTimer);
    this.roundStartTimer = window.setTimeout(() => {
      if (this.p1Wins >= 2 || this.p2Wins >= 2) {
        this.finishMatch(winner);
      } else {
        this.round++;
        this.beginRound();
      }
    }, 2050);
  }

  private finishMatch(winner: Fighter): void {
    if (this.phase === 'MATCH_OVER') return;
    this.phase = 'MATCH_OVER';
    sound.setArenaAmbience(false);
    this.cb.onAnnounce(null);
    sound.playVictoryStinger(winner.cfg.id);
    const localFighter = this.getLocalFighter();
    const localSlot: 1 | 2 = localFighter ? localFighter.slot : 1;
    const loser = winner.slot === 1 ? this.f2 : this.f1;
    this.cb.onVictory({
      winnerId: winner.cfg.id,
      loserId: loser ? loser.cfg.id : winner.cfg.id,
      winnerName: winner.cfg.name,
      winnerTitle: winner.cfg.title,
      loserName: loser ? loser.cfg.name : 'RIVAL',
      loserTitle: loser ? loser.cfg.title : 'Challenger',
      quote: winner.cfg.quote,
      winnerSlot: winner.slot,
      localSlot,
      p1Wins: this.p1Wins,
      p2Wins: this.p2Wins,
      localMaxCombo: localFighter ? localFighter.maxCombo : 0,
      mode: this.mode,
      arenaId: this.arenaId,
      p1SkinId: this.f1?.skinId,
      p2SkinId: this.f2?.skinId,
      p1AuraId: this.f1?.auraId,
      p2AuraId: this.f2?.auraId,
    });
  }

  // ==================== VFX, PARTICLES & POPUPS ====================
  private addParticles(x: number, y: number, col: string, count: number, minSpd: number, maxSpd: number): void {
    if (this.particles.length > 120) return;
    for (let i = 0; i < count; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = minSpd + Math.random() * (maxSpd - minSpd);
      this.particles.push({
        x,
        y,
        vx: Math.cos(a) * s * 62,
        vy: Math.sin(a) * s * 62 - 45,
        life: 0.32 + Math.random() * 0.28,
        maxLife: 0.6,
        size: 3 + Math.random() * 4.5,
        col,
      });
    }
  }

  private addVfx(kind: string, x: number, y: number, facing: number, col: string, glow: string, dur: number): void {
    this.vfxEffects.push({ kind, x, y, facing, col, glow, life: dur, maxLife: dur });
  }

  private addPopup(x: number, y: number, text: string, col: string, style: Popup['style']): void {
    const scale0 = style === 'big' || style === 'ko' ? 1.65 : style === 'counter' ? 1.4 : style === 'info' ? 0.95 : 1.0;
    const life0 = style === 'big' || style === 'ko' ? 1.35 : style === 'counter' ? 1.2 : 1.05;
    this.popups.push({
      x: x + (Math.random() - 0.5) * 18,
      y,
      vy: style === 'ko' ? -42 : -68,
      vx: (Math.random() - 0.5) * 40,
      text,
      col,
      life: life0,
      maxLife: life0,
      scale: scale0,
      rot: (Math.random() - 0.5) * 0.28,
      style,
    });
  }

  private spawnCharacterSkill1(owner: Fighter): void {
    const dir = owner.facing;
    const fx = owner.x + dir * 56;
    // Fixed: y - 98 so crouching fighters can duck cleanly under high projectiles!
    const fy = owner.y - 98;
    if (owner.cfg.id === 'munna_bhaiya') {
      this.addVfx('muzzle_flash', fx, fy, dir, '#fde047', '#f43f5e', 0.25);
      this.addParticles(fx, fy, '#fde047', 10, 3, 6);
    }
    const speedMap: Record<string, number> = {
      munna_bhaiya: 625,
      sharmaji_beta: 650,
      chappal_chacha: 560,
      raju_rickshaw: 575,
      belan_bhabhi: 495,
      gym_bunty: 495,
    };
    const pSpeed = speedMap[owner.cfg.id] || 525;
    this.projectiles.push({
      owner,
      kind: owner.cfg.id,
      x: fx,
      y: fy,
      vx: dir * pSpeed,
      vy: 0,
      radius: 22,
      dir,
      dmg: (owner.move && owner.move.dmg) || getCharMove(owner, 'SP1')!.dmg,
      hasHit: false,
      life: 1.55,
      age: 0,
      rot: 0,
      col: owner.cfg.aura,
      glow: owner.cfg.glow,
    });
  }

  private triggerCharacterUltimateVfx(attacker: Fighter, defender: Fighter): void {
    const tx = Math.abs(defender.x - attacker.x) < 340 ? defender.x : attacker.x + attacker.facing * 210;
    this.addVfx(`ult_${attacker.cfg.id}`, tx, WORLD.groundY, attacker.facing, attacker.cfg.aura, attacker.cfg.glow, 0.75);
    this.addParticles(tx, WORLD.groundY - 70, attacker.cfg.glow, 18, 4, 9);
  }

  // ==================== SIMULATION ====================
  private updateFighter(f: Fighter, opp: Fighter, dt: number): void {
    f.t += dt;
    const scaleSpring = Math.min(1, dt * 11);
    f.scaleX += (1 - f.scaleX) * scaleSpring;
    f.scaleY += (1 - f.scaleY) * scaleSpring;
    if (Math.abs(f.scaleX - 1) < 0.04) f.scaleX = 1;
    if (Math.abs(f.scaleY - 1) < 0.04) f.scaleY = 1;

    if (f.invuln > 0) f.invuln = Math.max(0, f.invuln - dt);
    if (f.parryTimer > 0) f.parryTimer = Math.max(0, f.parryTimer - dt);
    if (f.parryFlashTimer > 0) f.parryFlashTimer = Math.max(0, f.parryFlashTimer - dt);
    if (f.stepDustAcc > 0) f.stepDustAcc = Math.max(0, f.stepDustAcc - dt);
    if (f.basicChainTimer > 0) {
      f.basicChainTimer = Math.max(0, f.basicChainTimer - dt);
      if (f.basicChainTimer <= 0) f.basicChainStep = 0;
    }
    if (f.sp1Cd > 0) f.sp1Cd = Math.max(0, f.sp1Cd - dt);
    if (f.sp2Cd > 0) f.sp2Cd = Math.max(0, f.sp2Cd - dt);
    if (f.dashCd > 0) f.dashCd = Math.max(0, f.dashCd - dt);
    if (f.slowTimer > 0) f.slowTimer = Math.max(0, f.slowTimer - dt);

    // Balanced Lota Lal Stink Debuff mechanic (bubbles + capped fair DoT)
    if (f.stinkTimer > 0) {
      f.stinkTimer = Math.max(0, f.stinkTimer - dt);
      f.stinkTickAcc += dt;
      if (f.stinkTickAcc >= 0.7) {
        f.stinkTickAcc = 0;
        this.addParticles(f.x + (Math.random() - 0.5) * 30, f.y - 75, '#84cc16', 3, 1, 2.5);
        if (f.hp > 15 && this.phase === 'FIGHT') {
          f.hp = Math.max(1, f.hp - 4);
        }
      }
    }

    if (f.inputBuffer.timer > 0) {
      f.inputBuffer.timer = Math.max(0, f.inputBuffer.timer - dt);
      this.tryExecuteBufferedAttack(f);
    }

    for (let ai = f.afterimages.length - 1; ai >= 0; ai--) {
      f.afterimages[ai].alpha -= dt * 2.4;
      if (f.afterimages[ai].alpha <= 0) f.afterimages.splice(ai, 1);
    }
    const isFartJet = f.cfg.id === 'lota_lal' && f.state === 'ATTACK' && f.move?.special === 'SP2';
    const visualFacing = isFartJet ? -f.facing : f.facing;
    if (f.state === 'DASH' || f.state === 'JUMP' || (f.state === 'ATTACK' && f.move && f.move.special)) {
      f.afterimageAcc += dt;
      if (f.afterimageAcc >= 0.038) {
        f.afterimageAcc = 0;
        f.recordAfterimage(visualFacing);
      }
    }

    f.awakened = f.rage >= 70;
    const equippedAura = getAuraById(f.auraId);
    // Moved awakened & cosmetic aura particle spawning out of renderFighter into updateFighter!
    if (f.awakened || equippedAura.style !== 'none') {
      f.awakeParticleAcc += dt;
      const interval = f.awakened ? 0.06 : 0.12;
      if (f.awakeParticleAcc >= interval) {
        f.awakeParticleAcc = 0;
        const pCol =
          equippedAura.style !== 'none'
            ? equippedAura.secondaryColor && Math.random() > 0.5
              ? equippedAura.secondaryColor
              : Math.random() > 0.4
                ? equippedAura.sparkColor
                : equippedAura.ringColor
            : f.cfg.glow;
        this.addParticles(f.x + (Math.random() - 0.5) * 44, f.y - 25 - Math.random() * 115, pCol, 1, 2.0, 2.7);
      }
    }

    if (f.comboTimer > 0) {
      f.comboTimer -= dt;
      if (f.comboTimer <= 0) {
        f.comboCount = 0;
        f.comboDamage = 0;
      }
    }

    // Practice mode dummy auto-regenerates HP cleanly after 2.2s out of hitstun
    if (this.practice && f.slot === 2 && f.state !== 'HURT' && f.state !== 'KO' && f.hp < f.maxHp) {
      f.idleRegenTimer += dt;
      if (f.idleRegenTimer >= 2.2) {
        f.hp = Math.min(f.maxHp, f.hp + Math.round(dt * 650));
      }
    } else {
      f.idleRegenTimer = 0;
    }

    let moveX = 0;
    let moveY = 0;
    let wantBlock = false;

    const isLocalControlled =
      (this.mode === 'bot' && f.slot === 1) ||
      (this.mode === 'mp' && ((this.mpRole === 'host' && f.slot === 1) || (this.mpRole === 'guest' && f.slot === 2)));

    if (this.phase === 'FIGHT') {
      if (isLocalControlled) {
        const axis = this.getEffectiveInputAxis();
        moveX = axis.mx;
        moveY = axis.my;
        // Shadow Fight feel: holding Back (away from rival) auto-guards chips, OR Shield button guards + enables 0.16s Perfect Guard!
        const backHeld = moveX * f.facing < -0.55;
        const holdingAway = backHeld && opp.state === 'ATTACK' && Math.abs(opp.x - f.x) < 220;
        if (backHeld && !f.wasBackHeld && (f.state === 'IDLE' || f.state === 'WALK' || f.state === 'CROUCH')) {
          f.parryTimer = 0.16;
        }
        f.wasBackHeld = backHeld;
        wantBlock = this.blockHeld || holdingAway;
      } else if (this.mode === 'mp') {
        moveX = f.remoteInput.moveX || 0;
        moveY = f.remoteInput.moveY || 0;
        wantBlock = !!f.remoteInput.block;
        if (f.remoteInput.action) {
          const act = f.remoteInput.action;
          f.remoteInput.action = null;
          if (act === 'dash') this.triggerDash(f, f.facing);
          else if (act === 'shield') {
            wantBlock = true;
            f.parryTimer = 0.16;
          } else if (act === 'basic') this.queueOrStartAttack(f, resolveBasicAttack(f, moveX, moveY));
          else if (act === 'sp1') this.queueOrStartAttack(f, 'SP1');
          else if (act === 'sp2') this.queueOrStartAttack(f, 'SP2');
          else if (act === 'rage') this.queueOrStartAttack(f, 'RAGE');
          else if (MOVES[act]) this.queueOrStartAttack(f, act);
        }
      } else if (this.practice) {
        f.aiTimer -= dt;
        const pdist = Math.abs(opp.x - f.x);
        if (f.aiTimer <= 0) {
          f.aiTimer = 0.45 + Math.random() * 0.4;
          const pr = Math.random();
          if (opp.state === 'ATTACK' && pdist < 160 && pr < 0.45) f.aiAction = 'BLOCK';
          else if (pr < 0.12) f.aiAction = 'RETREAT';
          else if (pr < 0.25) f.aiAction = 'APPROACH';
          else f.aiAction = 'IDLE';
        }
        if (f.aiAction === 'BLOCK') wantBlock = true;
        else if (f.aiAction === 'APPROACH') moveX = (opp.x >= f.x ? 1 : -1) * 0.5;
        else if (f.aiAction === 'RETREAT') moveX = (opp.x >= f.x ? -1 : 1) * 0.5;
      } else {
        // Skill-based Shadow Fight Bot AI (evaluates spacing, 3-hit combos, sweeps, anti-airs & blocks)
        f.aiTimer -= dt;
        const dist = Math.abs(opp.x - f.x);
        const dirToOpp = opp.x >= f.x ? 1 : -1;
        const oppAttacking = opp.state === 'ATTACK' && !!opp.move;
        const oppInAir = opp.y < WORLD.groundY - 20;
        const meInCorner = Math.abs(f.x) > WORLD.arenaHalfWidth - 120;

        const params =
          this.difficulty === 'easy'
            ? { react: 0.52, jitter: 0.24, block: 0.16, parryChance: 0.0, antiAir: 0.10, sp1Far: 0.22, sp2Mid: 0.16, rage: 0.22, basic: 0.48, retreat: 0.32, dash: 0.06, jump: 0.04, aggress: 0.42, whiff: 0.22, holdBlock: 0.25 }
            : this.difficulty === 'hard'
              ? { react: 0.14, jitter: 0.07, block: 0.65, parryChance: 0.22, antiAir: 0.58, sp1Far: 0.52, sp2Mid: 0.48, rage: 0.80, basic: 0.64, retreat: 0.14, dash: 0.26, jump: 0.12, aggress: 0.82, whiff: 0.0, holdBlock: 0.58 }
              : { react: 0.28, jitter: 0.12, block: 0.38, parryChance: 0.08, antiAir: 0.28, sp1Far: 0.36, sp2Mid: 0.32, rage: 0.50, basic: 0.58, retreat: 0.22, dash: 0.13, jump: 0.07, aggress: 0.60, whiff: 0.08, holdBlock: 0.40 };

        const currentOppMoveSig = oppAttacking ? `${opp.move!.key}:${Math.floor(opp.t * 2)}` : '';
        if (!oppAttacking) f.aiReactedMoveKey = '';

        if (oppAttacking && dist < 175 && f.aiReactedMoveKey !== currentOppMoveSig) {
          f.aiReactedMoveKey = currentOppMoveSig;
          if (Math.random() < params.block) {
            f.aiAction = 'BLOCK';
            f.aiTimer = 0.22;
            if (Math.random() < params.parryChance) f.parryTimer = 0.16;
          }
        }

        if (f.aiTimer <= 0) {
          f.aiTimer = params.react + Math.random() * params.jitter;
          const r = Math.random();
          if (r < params.whiff) {
            f.aiAction = Math.random() < 0.5 ? 'IDLE' : 'RETREAT';
          } else if (oppInAir && dist < 175 && r < params.antiAir) {
            f.aiAction = f.sp2Cd <= 0 ? 'SP2' : 'BASIC_UP';
          } else if (dist > 340) {
            if (f.sp1Cd <= 0 && r < params.sp1Far) f.aiAction = 'SP1';
            else if (r < params.dash + 0.15) f.aiAction = 'DASH_IN';
            else if (r < params.jump + 0.25) f.aiAction = 'JUMP_IN';
            else f.aiAction = 'APPROACH';
          } else if (dist > 140) {
            if (f.sp2Cd <= 0 && r < params.sp2Mid) f.aiAction = 'SP2';
            else if (f.sp1Cd <= 0 && r < params.sp1Far * 0.65) f.aiAction = 'SP1';
            else if (r < params.dash) f.aiAction = 'DASH_IN';
            else if (r < params.aggress) f.aiAction = 'APPROACH';
            else f.aiAction = 'RETREAT';
          } else {
            if (f.rage >= 100 && r < params.rage) f.aiAction = 'RAGE';
            else if (opp.blocking && !opp.crouching && r < params.basic * 0.55) f.aiAction = 'BASIC_LOW';
            else if (r < params.basic) {
              f.aiAction =
                f.basicChainTimer > 0 && f.basicChainStep === 1
                  ? 'BASIC_2'
                  : f.basicChainTimer > 0 && f.basicChainStep === 2
                    ? 'BASIC_3'
                    : Math.random() < 0.24
                      ? 'BASIC_FWD'
                      : 'BASIC_1';
            } else if (f.sp2Cd <= 0 && r < 0.78) f.aiAction = 'SP2';
            else if (meInCorner || r < params.retreat) f.aiAction = 'RETREAT';
            else f.aiAction = 'BASIC_1';
          }
        }

        if (f.aiAction === 'APPROACH') moveX = dirToOpp;
        else if (f.aiAction === 'RETREAT') {
          moveX = -dirToOpp;
          if (this.difficulty === 'easy' && meInCorner && Math.random() < 0.4) moveX = 0;
        } else if (f.aiAction === 'BLOCK') {
          wantBlock = true;
          if (!oppAttacking && Math.random() > params.holdBlock) f.aiAction = 'IDLE';
        } else if (f.aiAction === 'DASH_IN') {
          this.triggerDash(f, dirToOpp);
          f.aiAction = 'APPROACH';
        } else if (f.aiAction === 'JUMP_IN') {
          moveY = -1;
          moveX = dirToOpp * 0.7;
          f.aiAction = 'APPROACH';
        } else if (f.aiAction !== 'IDLE') {
          this.queueOrStartAttack(f, f.aiAction);
          f.aiAction = 'IDLE';
        }
      }
    }

    if (f.state === 'IDLE' || f.state === 'WALK' || f.state === 'CROUCH') {
      f.facing = opp.x >= f.x ? 1 : -1;
    }

    const speedMult =
      (f.slowTimer > 0 ? 0.72 : 1.0) *
      (f.stinkTimer > 0 ? 0.90 : 1.0) *
      (f.awakened ? 1.07 : 1.0);

    if (f.state === 'DASH') {
      f.stateTimer -= dt;
      if (f.stateTimer <= 0) {
        f.state = f.y < WORLD.groundY - 2 ? 'JUMP' : 'IDLE';
        f.vx *= 0.35;
      }
    } else if (f.state === 'BLOCKSTUN') {
      f.stateTimer -= dt;
      f.blocking = wantBlock;
      f.vx *= Math.pow(0.6, dt * 60);
      if (f.stateTimer <= 0) {
        f.state = 'IDLE';
      }
    } else if (f.state === 'HURT') {
      f.stateTimer -= dt;
      if (f.stateTimer <= 0 && f.y >= WORLD.groundY - 2) {
        f.state = 'IDLE';
        f.consecutiveHitsTaken = 0;
      }
    } else if (f.state === 'ATTACK' && f.move) {
      f.moveFrame += dt * 60;
      const mv = f.move;
      if (mv.special === 'SP2' && f.moveFrame >= mv.startup && f.moveFrame <= mv.startup + mv.active) {
        f.vx = f.facing * (mv.dashSpeed || 420);
        if (f.cfg.id === 'lota_lal' && Math.random() < 0.5) {
          this.addParticles(f.x - f.facing * 32, f.y - 68, '#84cc16', 2, 2, 5);
        } else if (f.cfg.id === 'raju_rickshaw' && Math.random() < 0.5) {
          this.addParticles(f.x - f.facing * 28, f.y - 12, '#cbd5e1', 2, 2, 4);
        }
      } else if (mv.key === 'BASIC_FWD' && f.moveFrame >= mv.startup * 0.35 && f.moveFrame <= mv.startup + mv.active) {
        // Forward Lunge Knee / Step-In Kick momentum during startup/active
        f.vx = f.facing * (mv.dashSpeed || 310);
      } else {
        f.vx *= 0.82;
      }

      if (mv.special === 'RAGE') {
        const waveFrames = [mv.startup, mv.startup + 5, mv.startup + 10];
        for (let wIdx = 0; wIdx < 3; wIdx++) {
          if (!f.rageWavesHit[wIdx] && f.moveFrame >= waveFrames[wIdx]) {
            f.rageWavesHit[wIdx] = true;
            if (wIdx === 0) this.triggerCharacterUltimateVfx(f, opp);
            const rDist = Math.abs(opp.x - f.x);
            const rFront = (opp.x - f.x) * f.facing >= -40;
            const rYDiff = Math.abs(opp.y - f.y);
            if (rFront && rDist <= mv.range && rYDiff < 145) {
              const kX = wIdx === 2 ? mv.knockX : 150;
              const kY = wIdx === 2 ? mv.knockY : -110;
              this.applyHit(f, opp, mv.waveDmg || 70, kX, kY, true, wIdx < 2 ? 'RAGE_WAVE' : null);
            }
          }
        }
      } else if (!f.hasHit && f.moveFrame >= mv.startup && f.moveFrame <= mv.startup + mv.active) {
        if (mv.projectile) {
          f.hasHit = true;
          this.spawnCharacterSkill1(f);
        } else if (mv.special === 'THROW') {
          const tReach = Math.abs(opp.x - f.x);
          const tY = Math.abs(opp.y - f.y);
          if (tReach <= mv.range && tY < 100 && opp.y >= WORLD.groundY - 18 && opp.invuln <= 0 && opp.state !== 'DASH') {
            f.hasHit = true;
            f.facing = opp.x >= f.x ? 1 : -1;
            this.applyHit(f, opp, mv.dmg, mv.knockX, mv.knockY, true, 'THROW');
            f.scaleX = 1.15;
            f.scaleY = 0.88;
          }
        } else {
          if (mv.special === 'SP2' && f.cfg.id === 'belan_bhabhi' && f.moveFrame < mv.startup + 2) {
            this.addVfx('tawa_slam', f.x + f.facing * 65, WORLD.groundY, f.facing, '#f97316', '#fde047', 0.42);
          }
          // Mutual melee overlap clash check before hit lands
          if (!this.checkWeaponClash()) {
            const reach = Math.abs(opp.x - f.x);
            const inFront = (opp.x - f.x) * f.facing >= -30;
            const yDiff = Math.abs(opp.y - f.y);
            const maxYDiff = mv.antiAir ? 175 : 115;
            // High attacks (non-low, non-special) can be crouched under at edge of range
            const crouchedUnder = opp.crouching && !mv.low && !mv.special && Math.abs(opp.x - f.x) > mv.range * 0.70;
            if (inFront && reach <= mv.range && yDiff < maxYDiff && !crouchedUnder) {
              f.hasHit = true;
              const applySlow = mv.special === 'SP2' && (f.cfg.id === 'pados_aunty' || f.cfg.id === 'traffic_mama');
              this.applyHit(f, opp, mv.dmg, mv.knockX, mv.knockY, !!mv.special, applySlow ? 'SLOW' : null, {
                low: mv.low,
                antiAir: mv.antiAir,
              });
            }
          }
        }
      }

      if (f.moveFrame >= mv.startup + mv.active + mv.recovery) {
        f.state = f.y < WORLD.groundY - 4 ? 'JUMP' : 'IDLE';
        f.move = null;
        if (f.inputBuffer.timer > 0) this.tryExecuteBufferedAttack(f);
      }
    } else if (f.state !== 'KO') {
      const onGround = f.y >= WORLD.groundY - 1.5 && f.vy >= 0;
      f.blocking = wantBlock && onGround;
      f.crouching = moveY > 0.54 && onGround;

      if (f.blocking) {
        f.vx *= Math.pow(0.55, dt * 60);
        if (onGround) f.state = f.crouching ? 'CROUCH' : 'IDLE';
      } else if (f.crouching) {
        f.vx *= Math.pow(0.60, dt * 60);
        if (onGround) f.state = 'CROUCH';
      } else {
        if (moveY < -0.58 && onGround && f.state !== 'JUMP') {
          f.vy = -720;
          f.y = WORLD.groundY - 0.5;
          f.state = 'JUMP';
          f.scaleX = 0.78;
          f.scaleY = 1.28;
          sound.playSfx('whoosh');
          this.addParticles(f.x, WORLD.groundY, '#cbd5e1', 8, 1.8, 4.2);
        }
        if (Math.abs(moveX) > 0.08) {
          const analogScale = Math.min(1, Math.abs(moveX) * 1.15);
          const dirSign = moveX > 0 ? 1 : -1;
          const targetVx = dirSign * analogScale * f.cfg.speed * speedMult;
          const reversing = f.vx * dirSign < 0;
          if (onGround) {
            if (reversing && Math.abs(f.vx) > 95 && f.stepDustAcc <= 0) {
              this.addParticles(f.x, WORLD.groundY, '#cbd5e1', 4, 1.2, 2.8);
              f.stepDustAcc = 0.14;
            } else if (Math.abs(f.vx) > 125 && f.stepDustAcc <= 0) {
              this.addParticles(f.x - f.facing * 8, WORLD.groundY, '#94a3b8', 2, 0.8, 2.0);
              f.stepDustAcc = 0.25;
            }
            f.vx += (targetVx - f.vx) * Math.min(1, dt * (reversing ? 30 : 22));
            f.state = 'WALK';
          } else {
            f.vx += (targetVx - f.vx) * Math.min(1, dt * 8.5);
          }
        } else {
          if (onGround) {
            f.vx *= Math.pow(0.70, dt * 60);
            if (Math.abs(f.vx) < 12) f.vx = 0;
            f.state = 'IDLE';
          } else {
            f.vx *= Math.pow(0.92, dt * 60);
          }
        }
      }
    }

    f.x += f.vx * dt;
    if (f.y < WORLD.groundY || f.vy < 0) {
      const g = WORLD.gravity * (f.vy > 0 ? 1.18 : 1.0);
      f.vy += g * dt;
      if (f.vy > 1100) f.vy = 1100;
      f.y += f.vy * dt;
      if (f.y >= WORLD.groundY) {
        const impact = Math.min(1, Math.abs(f.vy) / 900);
        f.y = WORLD.groundY;
        f.vy = 0;
        f.airDashed = false;
        f.scaleX = 1.12 + impact * 0.22;
        f.scaleY = 0.88 - impact * 0.14;
        if (impact > 0.12) {
          this.addParticles(f.x, WORLD.groundY, '#cbd5e1', 3 + Math.floor(impact * 6), 1.2, 3.4);
        }
        if (f.state === 'JUMP') f.state = 'IDLE';
      }
    } else {
      f.y = WORLD.groundY;
      f.airDashed = false;
      if (f.vy > 0) f.vy = 0;
    }

    const limit = WORLD.arenaHalfWidth - 45;
    if (f.x < -limit) {
      f.x = -limit;
      if (this.arenaId === 'banaras' && f.state === 'HURT') {
        f.hp = Math.max(1, f.hp - 12);
        this.addPopup(f.x, f.y - 150, 'AGNI -12', '#fb923c', 'info');
      }
    } else if (f.x > limit) {
      f.x = limit;
      if (this.arenaId === 'banaras' && f.state === 'HURT') {
        f.hp = Math.max(1, f.hp - 12);
        this.addPopup(f.x, f.y - 150, 'AGNI -12', '#fb923c', 'info');
      }
    }

    this.updateFighterPose(f, dt, visualFacing);
  }

  private updateFighterPose(f: Fighter, dt: number, visualFacing: number): void {
    const p = f.pose;
    const breathe = Math.sin(f.t * 3.6);
    const sway = Math.sin(f.t * 2.1);
    const onGroundPose = f.y >= WORLD.groundY - 2;
    const airT = Math.max(0, Math.min(1, (WORLD.groundY - f.y) / 180));

    // Natural martial-arts Akhara guard idle (positive angles = forward toward opponent!)
    let targetHip = -63 + breathe * 1.8;
    let targetLean = 0.08 + (f.vx / 520) * 0.2 + breathe * 0.02 + sway * 0.025;
    const targetSpin = f.state === 'KO' ? p.spin + dt * 10 : 0;
    let fThigh = 0.28 + breathe * 0.03 + sway * 0.03;
    let fShin = 0.34 + breathe * 0.02;
    let bThigh = -0.32 - breathe * 0.03 + sway * 0.03;
    let bShin = 0.22;
    // Front arm: upper arm forward-down, elbow bent forward-up guarding face/chin
    let fSh = 0.42 + breathe * 0.04;
    let fEl = 1.46 + breathe * 0.04;
    // Rear arm: tucked near ribs, fist guarding jaw
    let bSh = 0.22 - breathe * 0.03;
    let bEl = 1.62;
    let propR = -0.18;

    if (f.blocking || f.state === 'BLOCKSTUN') {
      // Crossed forearms raised high in front of face
      fSh = 0.96;
      fEl = 1.64;
      bSh = 0.82;
      bEl = 1.68;
      targetHip = f.crouching ? -37 : -58;
      targetLean = -0.04;
      fThigh = f.crouching ? 1.02 : 0.38;
      fShin = f.crouching ? 1.42 : 0.42;
      bThigh = f.crouching ? 0.88 : -0.22;
      bShin = f.crouching ? 1.32 : 0.26;
    } else if (f.crouching && onGroundPose) {
      targetHip = -36 + breathe * 1.0;
      targetLean = 0.16 + breathe * 0.02;
      fThigh = 1.08;
      fShin = 1.46;
      bThigh = 0.96;
      bShin = 1.36;
      fSh = 0.38;
      fEl = 1.56;
      bSh = 0.18;
      bEl = 1.58;
      propR = -0.15;
    } else if (f.state === 'JUMP' || f.y < WORLD.groundY - 6) {
      const rising = f.vy < -40;
      targetHip = -66 + airT * 4;
      if (rising) {
        fThigh = -0.95;
        fShin = 1.28;
        bThigh = 0.42;
        bShin = 0.88;
        fSh = 0.85;
        fEl = 1.32;
        bSh = -0.35;
        bEl = 1.25;
        targetLean = 0.1;
      } else {
        fThigh = -0.24;
        fShin = 0.44;
        bThigh = 0.22;
        bShin = 0.46;
        fSh = 0.58;
        fEl = 1.05;
        bSh = -0.28;
        bEl = 1.1;
        targetLean = -0.05;
      }
    } else if (f.state === 'DASH') {
      targetLean = 0.44;
      targetHip = -56;
      fThigh = -0.58;
      fShin = 0.28;
      bThigh = 0.72;
      bShin = 0.55;
      fSh = -0.45;
      fEl = 1.32;
      bSh = 0.65;
      bEl = 1.15;
    } else if (f.state === 'HURT') {
      targetLean = -0.44;
      targetHip = -58;
      fSh = -0.55;
      fEl = 0.85;
      bSh = -0.35;
      bEl = 0.92;
      fThigh = 0.34;
      fShin = 0.22;
      bThigh = -0.46;
      bShin = 0.34;
    } else if (f.state === 'WALK' && onGroundPose) {
      const walkDir = f.vx * visualFacing >= 0 ? 1 : -1;
      const phase = f.t * 10.6 * walkDir;
      const stride = Math.sin(phase);
      const strideCos = Math.cos(phase);
      const stride2 = Math.sin(phase + Math.PI);
      const stride2Cos = Math.cos(phase + Math.PI);
      // Human bipedal gait: vertical pelvis bounce + distinct swing knee curl + contralateral guard
      targetHip = -61 + Math.abs(strideCos) * 4.2;
      fThigh = stride * 0.66 + 0.08;
      fShin = 0.22 + Math.max(0, strideCos * 0.68) + Math.max(0, -stride * 0.35);
      bThigh = stride2 * 0.66 - 0.08;
      bShin = 0.22 + Math.max(0, stride2Cos * 0.68) + Math.max(0, -stride2 * 0.35);
      fSh = 0.36 - stride * 0.34;
      fEl = 1.38 + stride * 0.16;
      bSh = 0.24 + stride * 0.38;
      bEl = 1.48 - stride * 0.16;
      targetLean = 0.09 + (f.vx / 440) * 0.18;
    } else if (f.state === 'ATTACK' && f.move) {
      const prog = Math.min(1, f.moveFrame / Math.max(1, f.move.startup + f.move.active));
      let swing = Math.sin(prog * Math.PI);
      if (f.moveFrame > f.move.startup + f.move.active) {
        const recProg = (f.moveFrame - f.move.startup - f.move.active) / Math.max(1, f.move.recovery);
        swing *= Math.max(0, 1 - recProg * 1.4);
      }
      // Realistic chamber-then-snap factor for kicks/punches
      const snap = prog < 0.34 ? (prog / 0.34) * 0.45 : Math.min(1, 0.45 + ((prog - 0.34) / 0.38) * 0.55);
      const mk = f.move.key || '';
      if (mk === 'BASIC_3' || mk === 'BASIC_LOW' || mk === 'BASIC_UP' || mk === 'BASIC_AIR' || mk === 'BASIC_BACK' || mk === 'BASIC_FWD') {
        const chamberKnee = prog < 0.32 ? 1.15 : 0.12;
        if (mk === 'BASIC_LOW') {
          // Low sweeping leg kick: drops hips low and snaps front shin forward
          fThigh = 1.24 * swing;
          fShin = Math.max(0.12, 0.52 * (1 - snap * 0.72));
          bThigh = -0.76 * swing;
          bShin = 1.16 * swing;
          targetHip = -42;
          targetLean = 0.22 * swing;
          fSh = 0.42;
          fEl = 1.54;
          bSh = -0.35;
          bEl = 1.58;
        } else if (mk === 'BASIC_UP') {
          // Rising anti-air uppercut + high flip kick
          fThigh = 1.84 * swing;
          fShin = chamberKnee * (1 - snap * 0.88);
          bThigh = -0.44;
          bShin = 0.42;
          targetHip = -68 - 4 * swing;
          targetLean = -0.46 * swing;
          fSh = 0.55 + 1.45 * swing;
          fEl = 1.42 - 1.1 * snap * swing;
          bSh = -0.28;
          bEl = 1.62;
        } else if (mk === 'BASIC_AIR') {
          // Jumping axe kick: lifts leg high then chops downward
          const axeArc = prog < 0.42 ? 1.88 * (prog / 0.42) : 1.88 - ((prog - 0.42) / 0.58) * 0.92;
          fThigh = axeArc * (swing > 0.15 ? 1 : swing * 4);
          fShin = 0.12;
          bThigh = 0.35;
          bShin = 0.85;
          targetHip = -64;
          targetLean = (prog < 0.42 ? -0.26 : 0.30) * swing;
          fSh = 0.65;
          fEl = 1.45;
          bSh = -0.35;
          bEl = 1.4;
        } else if (mk === 'BASIC_FWD') {
          // Forward Lunge Knee / Step-In Kick
          const kneeFold = prog < 0.45 ? 1.52 : 0.26;
          fThigh = 1.66 * swing;
          fShin = kneeFold;
          bThigh = -0.52;
          bShin = 0.34;
          targetHip = -58;
          targetLean = 0.36 * swing;
          fSh = 0.68 * swing;
          fEl = 1.42;
          bSh = -0.32;
          bEl = 1.65;
          propR = 0.22 * swing;
        } else if (mk === 'BASIC_BACK') {
          // Spinning back kick / check
          fThigh = 1.38 * swing;
          fShin = chamberKnee * (1 - snap * 0.78);
          bThigh = -0.34;
          bShin = 0.32;
          targetHip = -60;
          targetLean = -0.34 * swing;
          fSh = 0.48;
          fEl = 1.52;
          bSh = -0.25;
          bEl = 1.58;
        } else {
          // BASIC_3: Akhara Roundhouse Kick Finisher
          fThigh = 1.62 * swing;
          fShin = chamberKnee * (1 - snap * 0.88);
          bThigh = -0.38;
          bShin = 0.34;
          targetHip = -63 - 3 * swing;
          targetLean = -0.34 * swing;
          fSh = 0.52;
          fEl = 1.52;
          bSh = -0.28;
          bEl = 1.58;
        }
      } else if (mk === 'SP2') {
        targetLean = 0.42 * swing;
        fSh = 1.82 * swing;
        fEl = 0.12;
        bSh = -0.38;
        bEl = 1.62;
        propR = -0.55 * swing;
        targetHip = -62;
      } else if (mk === 'RAGE') {
        targetHip = -68;
        targetLean = 0.32 * swing;
        fSh = 2.02 * swing;
        bSh = 1.68 * swing;
        fEl = 0.12;
        bEl = 0.45;
        propR = -0.65 * swing;
      } else if (mk === 'BASIC_2') {
        // Step 2: Spinning Backfist / Weapon Slash
        const wind = prog < 0.32 ? -0.95 * (prog / 0.32) : -0.95 + ((prog - 0.32) / 0.68) * 2.85;
        fSh = wind * Math.min(1, swing * 1.4 + 0.15);
        fEl = 1.48 - 1.32 * snap * swing;
        bSh = -0.72 * swing;
        bEl = 1.52;
        targetLean = (prog < 0.32 ? -0.24 : 0.38) * swing;
        targetHip = -59;
        propR = (prog < 0.32 ? -1.1 : 1.15) * swing;
        fThigh = 0.46;
        fShin = 0.48;
        bThigh = -0.44;
        bShin = 0.28;
      } else {
        // BASIC_1: Fast Jab
        fSh = 0.42 + 1.18 * swing;
        fEl = 1.46 - 1.38 * snap * swing;
        bSh = -0.18;
        bEl = 1.76;
        propR = 0.22 * swing;
        targetLean = 0.26 * swing;
        targetHip = -61;
        fThigh = 0.32;
        fShin = 0.38;
        bThigh = -0.36;
        bShin = 0.24;
      }
    }

    const baseLerp = f.state === 'ATTACK' || f.state === 'HURT' || f.state === 'DASH' ? 24 : 15;
    const lerpAmt = Math.min(1, dt * baseLerp);
    p.hipY += (targetHip - p.hipY) * lerpAmt;
    p.lean += (targetLean - p.lean) * lerpAmt;
    p.spin = targetSpin;
    p.fThigh += (fThigh - p.fThigh) * lerpAmt;
    p.fShin += (fShin - p.fShin) * lerpAmt;
    p.bThigh += (bThigh - p.bThigh) * lerpAmt;
    p.bShin += (bShin - p.bShin) * lerpAmt;
    p.fShoulder += (fSh - p.fShoulder) * lerpAmt;
    p.fElbow += (fEl - p.fElbow) * lerpAmt;
    p.bShoulder += (bSh - p.bShoulder) * lerpAmt;
    p.bElbow += (bEl - p.bElbow) * lerpAmt;
    p.propRot += (propR - p.propRot) * lerpAmt;

    f.cloth[0].x = f.x - visualFacing * 11;
    f.cloth[0].y = f.y + (p.hipY - 38) * WORLD.charScale;
    for (let c = 1; c < f.cloth.length; c++) {
      const prev = f.cloth[c - 1];
      const cur = f.cloth[c];
      const lag = 0.014 + c * 0.004;
      cur.x += (prev.x - visualFacing * (8 + c * 1.2) - f.vx * lag - cur.x) * Math.min(1, dt * (14 - c));
      cur.y += (prev.y + 5 + Math.sin(f.t * 7 + c * 1.3) * 3.2 - cur.y) * Math.min(1, dt * (13 - c));
    }
  }

  private resolveFighterSeparation(a: Fighter, b: Fighter): void {
    if (a.state === 'DASH' || b.state === 'DASH') return;
    const dx = b.x - a.x;
    const dy = Math.abs(b.y - a.y);
    const minSep = 74;
    if (dy < 100 && Math.abs(dx) < minSep) {
      const push = (minSep - Math.abs(dx)) * 0.5;
      const dir = dx >= 0 ? 1 : -1;
      a.x -= dir * push;
      b.x += dir * push;
    }
  }

  private checkWeaponClash(): boolean {
    const a = this.f1;
    const b = this.f2;
    if (!a || !b) return false;
    if (a.state !== 'ATTACK' || b.state !== 'ATTACK') return false;
    if (!a.move || !b.move) return false;
    const mv1 = a.move;
    const mv2 = b.move;
    if (mv1.projectile || mv2.projectile) return false;
    if (mv1.special === 'THROW' || mv1.special === 'RAGE' || mv2.special === 'THROW' || mv2.special === 'RAGE') return false;
    if (a.hasHit || b.hasHit) return false;
    const aActive = a.moveFrame >= mv1.startup - 0.5 && a.moveFrame <= mv1.startup + mv1.active;
    const bActive = b.moveFrame >= mv2.startup - 0.5 && b.moveFrame <= mv2.startup + mv2.active;
    if (!aActive || !bActive) return false;
    if (Math.abs(a.x - b.x) > 85 || Math.abs(a.y - b.y) >= 110) return false;
    if ((b.x - a.x) * a.facing < -20 || (a.x - b.x) * b.facing < -20) return false;

    a.hasHit = true;
    b.hasHit = true;
    this.hitStop = 0.05;
    this.shake = Math.max(this.shake, 7);
    const dir = b.x >= a.x ? 1 : -1;
    a.vx = -dir * 240;
    b.vx = dir * 240;
    sound.playSfx('block');
    const mx = (a.x + b.x) * 0.5;
    const my = Math.min(a.y, b.y) - 92;
    this.addVfx('hit_spark', mx, my, dir, '#fde047', '#22d3ee', 0.28);
    this.addVfx('block_ring', mx, my, dir, '#fde047', '#38bdf8', 0.28);
    this.addParticles(mx, my, '#fde047', 16, 3, 7);
    this.addPopup(mx, my - 46, 'TAKKAR!', '#fde047', 'big');
    return true;
  }

  private updateSimulation(rawDt: number): void {
    let dt = Math.min(0.033, rawDt);
    if (this.paused) {
      sound.setArenaAmbience(false);
      return;
    }

    if (this.slowMoTimer > 0) {
      this.slowMoTimer -= dt;
      dt *= 0.35;
    }
    if (this.shake > 0) this.shake = Math.max(0, this.shake - dt * 42);
    if (this.hitStop > 0) {
      this.hitStop -= dt;
      return;
    }

    for (const kt of this.kites) {
      kt.y += kt.vy * dt;
      if (kt.y > WORLD.groundY - 25) {
        kt.y = 90 + Math.random() * 80;
        kt.x = (Math.random() - 0.5) * 1400;
      }
    }

    for (const pg of this.pigeons) {
      pg.x += pg.vx * dt;
      if (pg.x > 1200) pg.x = -1200;
    }
    for (const fr of this.ferries) {
      fr.x += fr.vx * dt;
      if (fr.x > 1200) fr.x = -1200;
      if (fr.x < -1200) fr.x = 1200;
    }
    for (const dy of this.diyas) {
      dy.x += dy.vx * dt;
      if (dy.x > 1300) dy.x = -1300;
    }

    if (this.arenaId === 'howrah' && this.phase === 'FIGHT') {
      if (this.lightningTimer > 0) this.lightningTimer = Math.max(0, this.lightningTimer - dt);
      else if (Math.random() < dt * 0.12) {
        this.lightningTimer = 0.3;
      }
    }

    if (!this.f1 || !this.f2) return;

    if (this.crowdExcitement > 0) {
      this.crowdExcitement = Math.max(0, this.crowdExcitement - dt * 0.6);
    }

    if (this.phase === 'FIGHT') {
      const lowHpTension = Math.min(this.f1.hp, this.f2.hp) < 280 ? 0.35 : 0;
      sound.setArenaAmbience(true, 0.35 + lowHpTension + this.crowdExcitement * 0.5);

      // Continuous lively Indian Akhara audience shouts & cheers from background stands!
      this.crowdCheerTimer -= dt;
      if (this.crowdCheerTimer <= 0) {
        this.crowdCheerTimer = 2.6 + Math.random() * 2.2;
        sound.playCrowdCheer(lowHpTension > 0 ? 'hype' : 'normal');
        this.crowdExcitement = Math.max(this.crowdExcitement, lowHpTension > 0 ? 1.05 : 0.85);
      }

      this.timerAcc += dt;
      if (this.timerAcc >= 1.0) {
        this.timerAcc -= 1.0;
        this.timer = Math.max(0, this.timer - 1);
        if (this.timer <= 0) {
          if (this.practice) {
            this.timer = 60;
            this.f1.hp = this.f1.maxHp;
            this.f2.hp = this.f2.maxHp;
          } else {
            const w = this.f1.hp >= this.f2.hp ? this.f1 : this.f2;
            const l = w === this.f1 ? this.f2 : this.f1;
            this.handleRoundKO(w, l, 'time');
          }
        }
      }
    } else if (this.phase !== 'ROUND_END') {
      sound.setArenaAmbience(false);
    }

    if (this.phase === 'MENU') {
      sound.setArenaAmbience(false);
      this.updateLobbyShowcaseFighter(this.f1, dt);
    } else {
      if (this.phase === 'FIGHT') this.checkWeaponClash();
      this.updateFighter(this.f1, this.f2, dt);
      this.updateFighter(this.f2, this.f1, dt);
      this.resolveFighterSeparation(this.f1, this.f2);
    }

    if (this.mode === 'mp' && this.mpConnected) {
      this.pingIntervalAcc += dt;
      if (this.pingIntervalAcc >= 1.2) {
        this.pingIntervalAcc = 0;
        this.sendNetMsg({ type: 'PING', pingTs: Date.now() });
      }
    }

    if (this.mode === 'mp' && this.mpConnected && this.phase === 'FIGHT') {
      this.netSyncAcc += dt;
      if (this.netSyncAcc >= 0.016) {
        this.netSyncAcc = 0;
        const { mx, my } = this.getEffectiveInputAxis();
        if (this.mpRole === 'host') {
          this.sendNetMsg({
            type: 'STATE_SYNC',
            timer: this.timer,
            round: this.round,
            p1Wins: this.p1Wins,
            p2Wins: this.p2Wins,
            f1: this.serializeFighterState(this.f1),
            f2: this.serializeFighterState(this.f2),
            input: { moveX: mx, moveY: my, block: this.blockHeld, action: null },
            x: this.f1.x,
            y: this.f1.y,
          });
        } else if (this.mpRole === 'guest') {
          this.sendNetMsg({
            type: 'INPUT_SYNC',
            input: { moveX: mx, moveY: my, block: this.blockHeld, action: null },
            x: this.f2.x,
            y: this.f2.y,
          });
        }
      }
    }

    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const pr = this.projectiles[i];
      pr.age += dt;
      pr.x += pr.vx * dt;
      pr.y += pr.vy * dt;
      pr.rot += dt * 15;
      pr.life -= dt;
      const target = pr.owner === this.f1 ? this.f2 : this.f1;
      // Crouching lowers top of hurtbox to (y - 72), letting players duck under high projectiles (y - 98, r 22 => bottom y - 76)!
      const targetCenterY = target.crouching ? target.y - 40 : target.y - 84;
      const targetHalfH = target.crouching ? 32 : 58;
      if (!pr.hasHit && Math.abs(pr.x - target.x) <= pr.radius + 22 && Math.abs(pr.y - targetCenterY) <= pr.radius + targetHalfH) {
        pr.hasHit = true;
        const isSlow = pr.kind === 'traffic_mama' || pr.kind === 'pados_aunty';
        if (pr.kind === 'lota_lal') {
          this.addParticles(pr.x, pr.y, '#84cc16', 18, 3, 8);
          sound.playSfx('fart');
        }
        this.applyHit(pr.owner, target, pr.dmg, 330, -220, true, isSlow ? 'SLOW' : 'PROJECTILE');
        this.projectiles.splice(i, 1);
        continue;
      }
      if (pr.life <= 0 || Math.abs(pr.x) > WORLD.arenaHalfWidth + 80) {
        this.projectiles.splice(i, 1);
      }
    }

    for (let v = this.vfxEffects.length - 1; v >= 0; v--) {
      this.vfxEffects[v].life -= dt;
      if (this.vfxEffects[v].life <= 0) this.vfxEffects.splice(v, 1);
    }

    for (let p = this.particles.length - 1; p >= 0; p--) {
      const par = this.particles[p];
      par.x += par.vx * dt;
      par.y += par.vy * dt;
      par.vy += 460 * dt;
      par.life -= dt;
      if (par.life <= 0) this.particles.splice(p, 1);
    }

    for (let u = this.popups.length - 1; u >= 0; u--) {
      const pop = this.popups[u];
      pop.vy += 95 * dt;
      pop.y += pop.vy * dt;
      pop.x += pop.vx * dt;
      pop.life -= dt;
      const t = 1 - pop.life / pop.maxLife;
      if (t < 0.12) {
        pop.scale = (pop.style === 'ko' || pop.style === 'big' ? 1.65 : pop.style === 'counter' ? 1.4 : 1.15) * (1 + t * 2.2);
      } else {
        pop.scale += (1.0 - pop.scale) * Math.min(1, dt * 9);
      }
      pop.rot *= 1 - dt * 2.5;
      if (pop.life <= 0) this.popups.splice(u, 1);
    }

    for (let s = this.activeStickers.length - 1; s >= 0; s--) {
      this.activeStickers[s].life -= dt;
      if (this.activeStickers[s].life <= 0) this.activeStickers.splice(s, 1);
    }

    if (this.phase === 'MENU') {
      this.camX += (0 - this.camX) * Math.min(1, dt * 6);
      this.camZoom += (1.08 - this.camZoom) * Math.min(1, dt * 6);
    } else {
      const midX = (this.f1.x + this.f2.x) * 0.5;
      this.camX += (midX - this.camX) * Math.min(1, dt * 8);
      const sep = Math.abs(this.f1.x - this.f2.x);
      const targetZoom = sep > 480 ? Math.max(0.92, 1.06 - (sep - 480) / 1450) : 1.06;
      this.camZoom += (targetZoom - this.camZoom) * Math.min(1, dt * 6);
    }

    this.hudThrottleAcc += dt;
    if (this.hudThrottleAcc >= 0.032) {
      this.hudThrottleAcc = 0;
      this.pushHudSnapshot();
    }
  }

  private updateLobbyShowcaseFighter(f: Fighter, dt: number): void {
    f.t += dt;
    f.x = -190;
    f.y = WORLD.groundY;
    f.vx = 0;
    f.vy = 0;
    f.facing = 1;
    f.state = 'IDLE';

    // Equipped Aura ambience particles while standing in Victoria Memorial lobby
    const aura = getAuraById(f.auraId);
    if (aura && aura.id !== DEFAULT_AURA_ID && Math.random() < dt * 11) {
      const col =
        Math.random() < 0.3 ? aura.secondaryColor || aura.sparkColor : Math.random() < 0.6 ? aura.sparkColor : aura.ringColor;
      this.addParticles(f.x + (Math.random() - 0.5) * 48, f.y - 18 - Math.random() * 110, col, 1, 1.8, 2.4);
    }

    // Cycle every 3.6 seconds across 5 distinct autonomous lobby movements
    const cycleLen = 3.6;
    const cycleIdx = Math.floor(f.t / cycleLen) % 5;
    const localT = (f.t % cycleLen) / cycleLen; // 0..1
    const env = Math.sin(localT * Math.PI); // smooth 0 -> 1 -> 0 envelope
    const breathe = Math.sin(f.t * 3.4);
    const p = f.pose;

    let targetHip = -63 + breathe * 1.6;
    let targetLean = 0.04 + breathe * 0.015;
    let fThigh = 0.25 + breathe * 0.025;
    let fShin = 0.30 + breathe * 0.02;
    let bThigh = -0.28 - breathe * 0.025;
    let bShin = 0.20;
    let fSh = 0.38 + breathe * 0.035;
    let fEl = 1.46 + breathe * 0.035;
    let bSh = 0.20 - breathe * 0.03;
    let bEl = 1.60;
    let propR = -0.15;

    if (cycleIdx === 1) {
      // Autonomous Shadow-Boxing 1-2 Jab-Cross Warmup
      const pulse = Math.max(0, Math.sin(localT * Math.PI * 3));
      const punchAlt = Math.floor(localT * 3) % 2;
      targetHip = -61 - pulse * 2.5;
      targetLean = 0.14 * pulse;
      fThigh = 0.34;
      fShin = 0.36;
      bThigh = -0.36;
      bShin = 0.24;
      if (punchAlt === 0) {
        fSh = 0.44 + 1.15 * pulse;
        fEl = 1.48 - 1.32 * pulse;
        bSh = 0.22;
        bEl = 1.65;
      } else {
        bSh = 0.35 + 1.2 * pulse;
        bEl = 1.56 - 1.34 * pulse;
        fSh = 0.32;
        fEl = 1.58;
      }
      propR = 0.16 * pulse;
    } else if (cycleIdx === 2) {
      // Weapon Showcase / Prop Twirl & Shoulder Stretch
      targetHip = -64 + breathe * 1.4;
      targetLean = -0.06 * env;
      fSh = 0.48 + 1.48 * env;
      fEl = 1.35 - 0.85 * env;
      bSh = 0.18 - 0.35 * env;
      bEl = 1.48;
      propR = Math.sin(localT * Math.PI * 4) * 0.65 * env;
    } else if (cycleIdx === 3) {
      // Weight Shift, Guard Check & Calm Bounce
      const shift = Math.sin(localT * Math.PI * 2);
      targetHip = -60 + Math.abs(shift) * 3.0;
      targetLean = 0.08 + shift * 0.08;
      fThigh = 0.32 + shift * 0.18;
      bThigh = -0.32 + shift * 0.14;
      fSh = 0.72 * env + 0.38 * (1 - env);
      fEl = 1.58;
      bSh = 0.56 * env + 0.2 * (1 - env);
      bEl = 1.64;
      propR = -0.22;
    } else if (cycleIdx === 4) {
      // Confident Mini Victory Salute
      targetHip = -65 + breathe * 1.5;
      targetLean = -0.1 * env;
      fThigh = 0.34;
      fShin = 0.24;
      bThigh = -0.32;
      bShin = 0.2;
      fSh = 0.4 + 2.05 * env;
      fEl = 1.42 - 1.15 * env;
      bSh = 0.22 + 0.45 * env;
      bEl = 1.52;
      propR = -0.28 * env;
    }

    const lerpAmt = Math.min(1, dt * 9.5);
    p.hipY += (targetHip - p.hipY) * lerpAmt;
    p.lean += (targetLean - p.lean) * lerpAmt;
    p.spin = 0;
    p.fThigh += (fThigh - p.fThigh) * lerpAmt;
    p.fShin += (fShin - p.fShin) * lerpAmt;
    p.bThigh += (bThigh - p.bThigh) * lerpAmt;
    p.bShin += (bShin - p.bShin) * lerpAmt;
    p.fShoulder += (fSh - p.fShoulder) * lerpAmt;
    p.fElbow += (fEl - p.fElbow) * lerpAmt;
    p.bShoulder += (bSh - p.bShoulder) * lerpAmt;
    p.bElbow += (bEl - p.bElbow) * lerpAmt;
    p.propRot += (propR - p.propRot) * lerpAmt;

    f.cloth[0].x = f.x - 11;
    f.cloth[0].y = f.y + (p.hipY - 38) * WORLD.charScale;
    for (let c = 1; c < f.cloth.length; c++) {
      const prev = f.cloth[c - 1];
      const cur = f.cloth[c];
      cur.x += (prev.x - (8 + c * 1.2) - cur.x) * Math.min(1, dt * (12 - c));
      cur.y += (prev.y + 5 + Math.sin(f.t * 4.5 + c * 1.1) * 2.5 - cur.y) * Math.min(1, dt * (11 - c));
    }
  }

  public pushHudSnapshot(): void {
    if (!this.f1 || !this.f2) return;
    const localSlot: 1 | 2 = this.mode === 'mp' && this.mpRole === 'guest' ? 2 : 1;
    const localF = localSlot === 1 ? this.f1 : this.f2;
    this.cb.onHudUpdate({
      p1Name: this.f1.cfg.name,
      p2Name: this.practice ? `${this.f2.cfg.name} · DUMMY` : this.mode === 'bot' ? `${this.f2.cfg.name} · BOT` : this.f2.cfg.name,
      p1Hp: this.f1.hp,
      p1MaxHp: this.f1.maxHp,
      p2Hp: this.f2.hp,
      p2MaxHp: this.f2.maxHp,
      p1Rage: this.f1.rage,
      p2Rage: this.f2.rage,
      p1Awakened: this.f1.awakened,
      p2Awakened: this.f2.awakened,
      p1Wins: this.p1Wins,
      p2Wins: this.p2Wins,
      round: this.round,
      timer: this.timer,
      p1Sp1Cd: this.f1.sp1Cd,
      p1Sp2Cd: this.f1.sp2Cd,
      p1DashCd: this.f1.dashCd,
      p2Sp1Cd: this.f2.sp1Cd,
      p2Sp2Cd: this.f2.sp2Cd,
      p2DashCd: this.f2.dashCd,
      localSlot,
      practice: this.practice,
      comboCount: localF.comboCount,
      comboDamage: localF.comboDamage,
      maxCombo: localF.maxCombo,
      mpPingMs: this.mode === 'mp' && this.mpConnected ? this.mpPingMs : null,
    });
  }

  // ==================== ARENA DECOR & RENDERER ====================
  private initArenaDecor(): void {
    this.kites = Array.from({ length: 10 }, (_, i) => ({
      x: (Math.random() - 0.5) * 1600,
      y: 90 + Math.random() * 240,
      vy: 14 + Math.random() * 16,
      sway: Math.random() * 6,
      col: ['#f43f5e', '#facc15', '#38bdf8', '#4ade80', '#fb7185', '#c084fc'][i % 6],
    }));
    this.pigeons = Array.from({ length: 10 }, (_, p) => ({
      x: -1000 + p * 220,
      y: 120 + (p % 4) * 40,
      vx: 55 + (p % 3) * 28,
      flap: p * 1.1,
    }));
    this.ferries = Array.from({ length: 4 }, (_, f) => ({
      x: -900 + f * 600,
      vx: (f % 2 === 0 ? 1 : -1) * (36 + f * 4),
    }));
    this.diyas = Array.from({ length: 40 }, (_, d) => ({
      x: -1300 + d * 70,
      y: WORLD.groundY + 14 + (d % 5) * 12,
      vx: 12 + (d % 4) * 4,
      phase: d * 0.55,
    }));
    this.stars = Array.from({ length: 55 }, () => ({
      x: (Math.random() - 0.5) * 2400,
      y: 40 + Math.random() * 280,
      r: 0.8 + Math.random() * 1.8,
      tw: Math.random() * Math.PI * 2,
    }));
    this.lanterns = Array.from({ length: 12 }, (_, ln) => ({
      x: -1100 + ln * 200,
      y: 160 + (ln % 3) * 30,
      phase: ln * 0.9,
      col: ln % 2 === 0 ? '#fbbf24' : '#fb7185',
    }));
    this.crowd = Array.from({ length: 16 }, (_, cr) => ({
      side: cr < 8 ? -1 : 1,
      bob: Math.random() * 4,
      col: ['#f43f5e', '#38bdf8', '#facc15', '#4ade80', '#c084fc'][cr % 5],
    }));
  }

  private drawHumanMuscleSegment(
    x1: number,
    y1: number,
    x2: number,
    y2: number,
    rStart: number,
    rMid: number,
    rEnd: number,
    bulgeShift: number,
    rimColor: string,
    glowColor: string,
    depthDim: boolean,
    baseColor = '#1e1b33',
    darkColor = '#0b0a16',
    overrideCtx?: CanvasRenderingContext2D,
    cuffColor?: string
  ): void {
    const ctx = overrideCtx || this.ctx;
    drawRealisticLimbSegment(
      ctx,
      x1,
      y1,
      x2,
      y2,
      rStart,
      rMid,
      rEnd,
      bulgeShift,
      rimColor,
      glowColor,
      depthDim,
      baseColor,
      darkColor,
      cuffColor
    );
  }

  private drawHumanHand(
    hx: number,
    hy: number,
    armAngle: number,
    bulk: number,
    rimColor: string,
    glowColor: string,
    depthDim: boolean,
    skinColor: string,
    skinDark: string,
    overrideCtx?: CanvasRenderingContext2D
  ): void {
    const ctx = overrideCtx || this.ctx;
    drawRealisticHand(ctx, hx, hy, armAngle, bulk, rimColor, glowColor, depthDim, skinColor, skinDark, 'fist');
  }

  private drawHumanFoot(
    ax: number,
    ay: number,
    shinTilt: number,
    bulk: number,
    rimColor: string,
    glowColor: string,
    depthDim: boolean,
    bootColor: string,
    overrideCtx?: CanvasRenderingContext2D,
    propType?: string
  ): void {
    const ctx = overrideCtx || this.ctx;
    drawRealisticFoot(ctx, ax, ay, shinTilt, bulk, rimColor, glowColor, depthDim, bootColor, propType);
  }

  private renderFighter(f: Fighter, overrideCtx?: CanvasRenderingContext2D): void {
    const ctx = overrideCtx || this.ctx;
    const prevCtx = this.ctx;
    if (overrideCtx) this.ctx = overrideCtx;
    try {
    ctx.save();
    const vis = getFighterVisualPalette(f.cfg, f.skinId, f.auraId);
    const auraCol = vis.auraCol;
    const glowCol = vis.glowCol;
    const look = getCharacterLook(f.cfg.id, f.skinId);
    const cs = WORLD.charScale;

    for (const ghost of f.afterimages) {
      ctx.save();
      ctx.globalAlpha = ghost.alpha * 0.34;
      ctx.translate(ghost.x, ghost.y + ghost.pose.hipY * cs * ghost.scaleY);
      ctx.scale(ghost.facing * ghost.scaleX * cs, ghost.scaleY * cs);
      ctx.rotate(ghost.pose.lean);
      ctx.fillStyle = auraCol;
      ctx.beginPath();
      ctx.arc(1, -59, 10.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(-14, -42);
      ctx.quadraticCurveTo(0, -47, 15, -42);
      ctx.lineTo(10, 4);
      ctx.lineTo(14, 58);
      ctx.lineTo(5, 58);
      ctx.lineTo(0, 10);
      ctx.lineTo(-7, 58);
      ctx.lineTo(-15, 58);
      ctx.lineTo(-10, 4);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }

    // Layered realistic 2.5D ground contact shadow
    const heightAboveGround = Math.max(0, WORLD.groundY - f.y);
    const shadowScale = Math.max(0.35, 1 - heightAboveGround / 300);
    const shadowAlpha = Math.max(0.18, 0.68 * shadowScale);

    const shGrad = ctx.createRadialGradient(f.x, WORLD.groundY + 4, 4, f.x, WORLD.groundY + 4, 62 * shadowScale * f.scaleX);
    shGrad.addColorStop(0, `rgba(0,0,0,${shadowAlpha})`);
    shGrad.addColorStop(0.6, `rgba(0,0,0,${shadowAlpha * 0.45})`);
    shGrad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = shGrad;
    ctx.beginPath();
    ctx.ellipse(f.x, WORLD.groundY + 4, 62 * shadowScale * f.scaleX, 14 * shadowScale, 0, 0, Math.PI * 2);
    ctx.fill();

    drawCosmeticAuraStage(ctx, f.x, f.y, f.t, f.scaleX, vis.auraDef);

    if (f.awakened) {
      ctx.save();
      ctx.translate(f.x, f.y - 88 * f.scaleY);
      ctx.rotate(f.t * 0.45);
      ctx.strokeStyle = auraCol;
      ctx.lineWidth = 3.2;
      ctx.setLineDash([16, 10]);
      ctx.beginPath();
      ctx.arc(0, 0, 80 * f.scaleX, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.restore();
    }

    if (f.stinkTimer > 0) {
      ctx.save();
      ctx.strokeStyle = 'rgba(132, 204, 22, 0.45)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(f.x, f.y - 78, 36 + Math.sin(f.t * 8) * 4, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }

    // Flowing 2.5D dupatta / gamcha / cape scarf with shaded fold
    ctx.save();
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = look.tunicDark;
    ctx.lineWidth = f.cfg.prop === 'belan' || f.cfg.prop === 'katta' ? 14 : 10;
    ctx.beginPath();
    ctx.moveTo(f.cloth[0].x, f.cloth[0].y);
    for (let i = 1; i < f.cloth.length; i++) ctx.lineTo(f.cloth[i].x, f.cloth[i].y);
    ctx.stroke();
    ctx.strokeStyle = hexToRgba(look.trim, 0.85);
    ctx.lineWidth = f.cfg.prop === 'belan' || f.cfg.prop === 'katta' ? 7 : 4.5;
    ctx.stroke();
    ctx.restore();

    const p = f.pose;
    const isFartJet = f.cfg.id === 'lota_lal' && f.state === 'ATTACK' && f.move?.special === 'SP2';
    const dir = isFartJet ? -f.facing : f.facing;

    ctx.translate(f.x, f.y + p.hipY * cs * f.scaleY);
    if (p.spin !== 0) ctx.rotate(p.spin);
    ctx.scale(dir * f.scaleX * cs, f.scaleY * cs);

    if (f.state === 'DASH') ctx.globalAlpha = 0.76;
    const isHeavy = f.cfg.prop === 'lota' || f.cfg.prop === 'dumbbell';
    const isSlimFem = f.cfg.prop === 'belan' || f.cfg.prop === 'purse';
    const bulk = isHeavy ? 1.15 : isSlimFem ? 0.94 : 1.02;

    const upperArmCol = look.bareArms ? look.skin : look.tunic;
    const upperArmDark = look.bareArms ? look.skinDark : look.tunicDark;
    const forearmCol = look.skin;
    const forearmDark = look.skinDark;
    const bootCol = vis.bootOverride || (f.cfg.prop === 'chappal' ? '#7c2d12' : '#1e1b2e');

    // Back leg (shaded dhoti/trouser thigh & calf + boot)
    const thighLen = 31;
    const shinLen = 30;
    const bKx = -2 + Math.sin(p.bThigh) * thighLen;
    const bKy = Math.cos(p.bThigh) * thighLen;
    const bLegAngle = p.bThigh - p.bShin;
    const bFx = bKx + Math.sin(bLegAngle) * shinLen;
    const bFy = bKy + Math.cos(bLegAngle) * shinLen;
    this.drawHumanMuscleSegment(-2, 0, bKx, bKy, 8.4 * bulk, 8.0 * bulk, 5.5 * bulk, 1.4, auraCol, glowCol, true, look.pants, look.pantsDark);
    this.drawHumanMuscleSegment(bKx, bKy, bFx, bFy, 5.4 * bulk, 6.2 * bulk, 3.7 * bulk, -1.2, auraCol, glowCol, true, look.pants, look.pantsDark, undefined, look.trim);
    this.drawHumanFoot(bFx, bFy, bLegAngle, bulk, auraCol, glowCol, true, bootCol, undefined, f.cfg.prop);

    // Back arm (sleeve/bare bicep + skin forearm + fist)
    const nx = Math.sin(p.lean) * 42;
    const ny = -Math.cos(p.lean) * 42;
    const bShX = nx - Math.cos(p.lean) * 4;
    const bShY = ny + Math.sin(p.lean) * 4 + 5;
    const bEx = bShX + Math.sin(p.bShoulder) * 22;
    const bEy = bShY + Math.cos(p.bShoulder) * 22;
    const bArmAng = p.bShoulder + p.bElbow;
    const bHx = bEx + Math.sin(bArmAng) * 20;
    const bHy = bEy + Math.cos(bArmAng) * 20;
    this.drawHumanMuscleSegment(bShX, bShY, bEx, bEy, 5.9 * bulk, 5.7 * bulk, 4.4 * bulk, 1.0, auraCol, glowCol, true, upperArmCol, upperArmDark, undefined, look.bareArms ? undefined : look.trim);
    this.drawHumanMuscleSegment(bEx, bEy, bHx, bHy, 4.4 * bulk, 4.8 * bulk, 3.4 * bulk, 0.8, auraCol, glowCol, true, forearmCol, forearmDark);
    this.drawHumanHand(bHx, bHy, bArmAng, bulk * 0.92, auraCol, glowCol, true, look.skin, look.skinDark);

    // Sculpted 2.5D Human Torso + Shaded Skin Neck + Desi Garment
    ctx.save();
    ctx.rotate(p.lean);
    drawRealisticTorso(ctx, look, f.cfg.prop, auraCol, glowCol, isHeavy, isSlimFem, bulk, f.awakened, f.t);
    ctx.restore();

    // Sculpted 2.5D Human Head Profile (Realistic Skin, Cranium, Nose, Jawline, Hair & Accessories)
    const headBaseX = nx + Math.sin(p.lean) * 14;
    const headBaseY = ny - Math.cos(p.lean) * 14;
    ctx.save();
    ctx.translate(headBaseX, headBaseY);
    ctx.rotate(p.lean * 0.48);
    const faceExpr =
      f.state === 'HURT' || f.state === 'KO'
        ? 'defeat'
        : this.phase === 'MENU' && Math.floor(f.t / 3.6) % 5 !== 1
          ? 'victory'
          : 'fierce';
    drawRealisticHead(ctx, look, vis.eyeCol, auraCol, glowCol, f.awakened, faceExpr);
    ctx.restore();

    // Front leg (shaded dhoti/trouser quad, knee, calf & boot)
    const fKx = 2 + Math.sin(p.fThigh) * thighLen;
    const fKy = Math.cos(p.fThigh) * thighLen;
    const fLegAngle = p.fThigh - p.fShin;
    const fFx = fKx + Math.sin(fLegAngle) * shinLen;
    const fFy = fKy + Math.cos(fLegAngle) * shinLen;
    this.drawHumanMuscleSegment(2, 0, fKx, fKy, 8.8 * bulk, 8.4 * bulk, 5.8 * bulk, 1.6, auraCol, glowCol, false, look.pants, look.pantsDark);
    this.drawHumanMuscleSegment(fKx, fKy, fFx, fFy, 5.7 * bulk, 6.7 * bulk, 3.9 * bulk, -1.4, auraCol, glowCol, false, look.pants, look.pantsDark, undefined, look.trim);
    this.drawHumanFoot(fFx, fFy, fLegAngle, bulk, auraCol, glowCol, false, bootCol, undefined, f.cfg.prop);

    // Front arm (shaded sleeve/bare bicep + skin forearm + clenched fist)
    const fShX = nx + Math.cos(p.lean) * 3;
    const fShY = ny + Math.sin(p.lean) * 3 + 5;
    const fEx = fShX + Math.sin(p.fShoulder) * 22;
    const fEy = fShY + Math.cos(p.fShoulder) * 22;
    const fArmAng = p.fShoulder + p.fElbow;
    const fHx = fEx + Math.sin(fArmAng) * 20;
    const fHy = fEy + Math.cos(fArmAng) * 20;
    this.drawHumanMuscleSegment(fShX, fShY, fEx, fEy, 6.5 * bulk, 6.2 * bulk, 4.7 * bulk, 1.3, auraCol, glowCol, false, upperArmCol, upperArmDark, undefined, look.bareArms ? undefined : look.trim);
    this.drawHumanMuscleSegment(fEx, fEy, fHx, fHy, 4.7 * bulk, 5.1 * bulk, 3.7 * bulk, 1.0, auraCol, glowCol, false, forearmCol, forearmDark);
    this.drawHumanHand(fHx, fHy, fArmAng, bulk, auraCol, glowCol, false, look.skin, look.skinDark);

    // Signature comedy prop & weapon swing arc
    ctx.save();
    ctx.translate(fHx, fHy);
    ctx.rotate(Math.PI * 0.5 - (p.fShoulder + p.fElbow) + p.propRot);
    drawDetailedWeapon(ctx, f.cfg.prop, glowCol, look.trim);

    if (f.state === 'ATTACK' && f.move && f.moveFrame >= f.move.startup - 2 && f.moveFrame <= f.move.startup + f.move.active + 2) {
      ctx.strokeStyle = hexToRgba(glowCol, 0.9);
      ctx.lineWidth = f.move.special ? 9.5 : 6.5;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.arc(10, 0, f.move.special ? 46 : 38, -1.25, 0.85);
      ctx.stroke();
    }
    ctx.restore();

    if (f.parryFlashTimer > 0) {
      const pf = Math.min(1, f.parryFlashTimer / 0.28);
      ctx.save();
      ctx.globalAlpha = pf * 0.88;
      ctx.strokeStyle = '#fde047';
      ctx.fillStyle = 'rgba(253, 224, 71, 0.28)';
      ctx.lineWidth = 4.2;
      ctx.beginPath();
      ctx.arc(10, -14, 48 + (1 - pf) * 18, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }

    if (f.blocking || f.state === 'BLOCKSTUN') {
      ctx.strokeStyle = '#fbbf24';
      ctx.fillStyle = 'rgba(251, 191, 36, 0.18)';
      ctx.lineWidth = 2.8;
      ctx.beginPath();
      ctx.arc(20, -16, 37, -1.05, 1.05);
      ctx.fill();
      ctx.stroke();
    }

    ctx.restore();
    } finally {
      this.ctx = prevCtx;
    }
  }

  private renderArenaBackground(nowSec: number): void {
    const ctx = this.ctx;
    const ar = ARENAS[this.arenaId] || ARENAS.chandni;
    const span = 2200;

    // 1. Deep Atmospheric Sky Gradient
    const sky = ctx.createLinearGradient(0, -900, 0, WORLD.groundY);
    sky.addColorStop(0, ar.skyTop);
    sky.addColorStop(0.55, ar.skyMid);
    sky.addColorStop(1, ar.skyBot);
    ctx.fillStyle = sky;
    ctx.fillRect(-span, -1400, span * 2, WORLD.groundY + 1450);

    // 2. Parallax Stars & Volumetric Moon + Atmospheric Halo
    for (const st of this.stars) {
      ctx.globalAlpha = 0.25 + 0.65 * Math.abs(Math.sin(nowSec * 2.2 + st.tw));
      ctx.fillStyle = '#f8fafc';
      ctx.beginPath();
      ctx.arc(st.x + this.camX * 0.88, st.y, st.r, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;

    ctx.save();
    const moonX = this.camX * 0.72;
    const moonY = 175;
    // Outer atmospheric moonlight bloom
    const mHalo = ctx.createRadialGradient(moonX, moonY, 18, moonX, moonY, 240);
    mHalo.addColorStop(0, hexToRgba(ar.moonCol, 0.52));
    mHalo.addColorStop(0.35, hexToRgba(ar.moonCol, 0.22));
    mHalo.addColorStop(1, hexToRgba(ar.moonCol, 0));
    ctx.fillStyle = mHalo;
    ctx.beginPath();
    ctx.arc(moonX, moonY, 240, 0, Math.PI * 2);
    ctx.fill();
    // Crisp lunar disc with soft crater shadow
    const moonDisc = ctx.createRadialGradient(moonX - 12, moonY - 12, 6, moonX, moonY, 56);
    moonDisc.addColorStop(0, '#ffffff');
    moonDisc.addColorStop(0.75, ar.moonCol);
    moonDisc.addColorStop(1, hexToRgba(ar.moonCol, 0.75));
    ctx.fillStyle = moonDisc;
    ctx.beginPath();
    ctx.arc(moonX, moonY, 56, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // Soft drifting clouds (2.5D parallax layer)
    ctx.save();
    for (let cl = 0; cl < 6; cl++) {
      const cx = ((cl * 420 + nowSec * (8 + (cl % 3) * 4) + this.camX * 0.6) % 2400) - 1200;
      const cy = 120 + (cl % 3) * 58;
      ctx.fillStyle = hexToRgba(ar.skyMid, 0.42);
      ctx.beginPath();
      ctx.ellipse(cx, cy, 130 + (cl % 2) * 40, 24, 0, 0, Math.PI * 2);
      ctx.ellipse(cx + 55, cy - 10, 80, 20, 0, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();

    // 3. Distant City / Monument Skyline (0.45x Parallax Silhouette Layer)
    ctx.save();
    const farShift = this.camX * 0.45;
    ctx.translate(farShift, 0);
    ctx.fillStyle = this.arenaId === 'banaras' ? '#1e0b16' : this.arenaId === 'howrah' ? '#071322' : '#0f0a22';
    for (let sx = -1600; sx <= 1600; sx += 190) {
      const h = 110 + Math.abs((sx * 17) % 120);
      ctx.fillRect(sx - 80, WORLD.groundY - h, 160, h);
      if (this.arenaId === 'chandni' && Math.abs(sx) % 380 === 0) {
        // Distant Mughal dome & finial
        ctx.beginPath();
        ctx.arc(sx, WORLD.groundY - h, 46, Math.PI, 0);
        ctx.fill();
        ctx.fillRect(sx - 2, WORLD.groundY - h - 62, 4, 22);
      } else if (this.arenaId === 'banaras' && Math.abs(sx) % 380 === 0) {
        // Distant temple shikhara spire
        ctx.beginPath();
        ctx.moveTo(sx - 42, WORLD.groundY - h);
        ctx.quadraticCurveTo(sx - 18, WORLD.groundY - h - 75, sx, WORLD.groundY - h - 105);
        ctx.quadraticCurveTo(sx + 18, WORLD.groundY - h - 75, sx + 42, WORLD.groundY - h);
        ctx.closePath();
        ctx.fill();
      }
    }
    ctx.restore();

    // 4. Midground Realistic Indian Architecture (0.2x Parallax Depth)
    ctx.save();
    const midShift = this.camX * 0.2;
    ctx.translate(midShift, 0);

    if (this.arenaId === 'chandni') {
      // Ornate Old Delhi Haveli Facades + Jharokha Arches + Market Awnings + Fairy Lights
      for (let bx = -1350; bx <= 1350; bx += 360) {
        const wallGrad = ctx.createLinearGradient(bx - 120, WORLD.groundY - 260, bx + 120, WORLD.groundY);
        wallGrad.addColorStop(0, '#1e143a');
        wallGrad.addColorStop(1, '#110b24');
        ctx.fillStyle = wallGrad;
        ctx.fillRect(bx - 125, WORLD.groundY - 250, 250, 250);

        // Carved sandstone arch trim & scalloped Mughal chhajja eaves
        ctx.fillStyle = '#33205e';
        ctx.fillRect(bx - 134, WORLD.groundY - 262, 268, 15);
        ctx.fillStyle = '#1b1138';
        for (let sc = -124; sc <= 112; sc += 22) {
          ctx.beginPath();
          ctx.arc(bx + sc + 11, WORLD.groundY - 247, 11, 0, Math.PI);
          ctx.fill();
        }
        // Side carved pillars with warm brass capitals
        ctx.fillStyle = '#140d2b';
        ctx.fillRect(bx - 122, WORLD.groundY - 255, 16, 255);
        ctx.fillRect(bx + 106, WORLD.groundY - 255, 16, 255);
        ctx.fillStyle = 'rgba(251, 191, 36, 0.35)';
        ctx.fillRect(bx - 124, WORLD.groundY - 248, 20, 4);
        ctx.fillRect(bx + 104, WORLD.groundY - 248, 20, 4);

        // Cusped Mughal Jharokha Windows with warm interior light
        for (let wx = -1; wx <= 1; wx++) {
          const jx = bx + wx * 66;
          const jy = WORLD.groundY - 195;
          ctx.fillStyle = '#090614';
          ctx.beginPath();
          ctx.roundRect(jx - 20, jy, 40, 58, [20, 20, 2, 2]);
          ctx.fill();
          const winGlow = 0.55 + 0.2 * Math.sin(nowSec * 2.5 + wx + bx);
          ctx.fillStyle = `rgba(251, 191, 36, ${winGlow})`;
          ctx.beginPath();
          ctx.roundRect(jx - 14, jy + 8, 28, 42, [14, 14, 1, 1]);
          ctx.fill();
          // Lattice jaali bars
          ctx.strokeStyle = '#1a1133';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(jx, jy + 8);
          ctx.lineTo(jx, jy + 50);
          ctx.moveTo(jx - 14, jy + 29);
          ctx.lineTo(jx + 14, jy + 29);
          ctx.stroke();
        }

        // Warm bazaar neon sign plaque above awning
        ctx.fillStyle = '#140b24';
        ctx.strokeStyle = 'rgba(244, 63, 94, 0.65)';
        ctx.lineWidth = 1.6;
        ctx.fillRect(bx - 64, WORLD.groundY - 129, 128, 18);
        ctx.strokeRect(bx - 64, WORLD.groundY - 129, 128, 18);
        ctx.fillStyle = 'rgba(253, 224, 71, 0.72)';
        ctx.fillRect(bx - 48, WORLD.groundY - 122, 96, 4);

        // Ground-floor glowing bazaar shopfront & striped cloth awning
        const shopG = ctx.createRadialGradient(bx, WORLD.groundY - 35, 8, bx, WORLD.groundY - 35, 95);
        shopG.addColorStop(0, 'rgba(251, 146, 60, 0.58)');
        shopG.addColorStop(1, 'rgba(251, 146, 60, 0)');
        ctx.fillStyle = shopG;
        ctx.fillRect(bx - 95, WORLD.groundY - 105, 190, 105);

        // Striped awning canopy
        for (let st = 0; st < 8; st++) {
          ctx.fillStyle = st % 2 === 0 ? '#be123c' : '#fde047';
          ctx.beginPath();
          ctx.moveTo(bx - 96 + st * 24, WORLD.groundY - 106);
          ctx.lineTo(bx - 72 + st * 24, WORLD.groundY - 106);
          ctx.lineTo(bx - 68 + st * 24, WORLD.groundY - 82);
          ctx.lineTo(bx - 100 + st * 24, WORLD.groundY - 82);
          ctx.closePath();
          ctx.fill();
        }
        // Hanging marigold (genda) garlands along shopfront
        for (let g = 0; g < 6; g++) {
          const gx = bx - 80 + g * 32;
          ctx.fillStyle = g % 2 === 0 ? '#fb923c' : '#facc15';
          ctx.beginPath();
          ctx.arc(gx, WORLD.groundY - 76, 4.2, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // Hanging Bazaar Fairy-Light Strings (Catenary festoon lights)
      for (let lx = -1400; lx < 1400; lx += 360) {
        ctx.strokeStyle = 'rgba(253, 224, 71, 0.35)';
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        ctx.moveTo(lx, WORLD.groundY - 245);
        ctx.quadraticCurveTo(lx + 180, WORLD.groundY - 195, lx + 360, WORLD.groundY - 245);
        ctx.stroke();
        for (let b = 1; b <= 9; b++) {
          const t = b / 10;
          const px = lx + 360 * t;
          const py = (1 - t) * (1 - t) * (WORLD.groundY - 245) + 2 * (1 - t) * t * (WORLD.groundY - 195) + t * t * (WORLD.groundY - 245);
          ctx.fillStyle = b % 3 === 0 ? '#fb7185' : b % 3 === 1 ? '#fde047' : '#38bdf8';
          ctx.beginPath();
          ctx.arc(px, py + 2, 3.2, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // Drifting Paper Lanterns & Colourful Patangs
      for (const ln of this.lanterns) {
        const ly = ln.y + Math.sin(nowSec * 1.4 + ln.phase) * 12;
        const lx = ln.x + Math.sin(nowSec * 0.7 + ln.phase) * 10;
        const lg = ctx.createRadialGradient(lx, ly, 2, lx, ly, 20);
        lg.addColorStop(0, '#fffbeb');
        lg.addColorStop(0.4, ln.col);
        lg.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = lg;
        ctx.beginPath();
        ctx.arc(lx, ly, 20, 0, Math.PI * 2);
        ctx.fill();
      }
      for (const kt of this.kites) {
        ctx.save();
        ctx.translate(kt.x + Math.sin(nowSec * 2 + kt.sway) * 18, kt.y);
        ctx.rotate(Math.sin(nowSec * 1.5 + kt.sway) * 0.25);
        ctx.fillStyle = kt.col;
        ctx.strokeStyle = '#090712';
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.moveTo(0, -15);
        ctx.lineTo(13, 0);
        ctx.lineTo(0, 15);
        ctx.lineTo(-13, 0);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        ctx.restore();
      }
      ctx.strokeStyle = '#e2e8f0';
      ctx.lineWidth = 2;
      for (const pObj of this.pigeons) {
        const wing = Math.sin(nowSec * 9 + pObj.flap) * 6;
        ctx.beginPath();
        ctx.moveTo(pObj.x - 8, pObj.y + wing);
        ctx.quadraticCurveTo(pObj.x - 3, pObj.y - 4, pObj.x, pObj.y);
        ctx.quadraticCurveTo(pObj.x + 3, pObj.y - 4, pObj.x + 8, pObj.y + wing);
        ctx.stroke();
      }
    } else if (this.arenaId === 'howrah') {
      // Realistic Cantilever Steel Lattice Truss Towers & Suspension Cables
      ctx.strokeStyle = '#0c1b33';
      ctx.fillStyle = '#0a1629';
      for (const tx of [-520, 520]) {
        // Tapered twin A-frame cantilever towers
        ctx.beginPath();
        ctx.moveTo(tx - 44, WORLD.groundY);
        ctx.lineTo(tx - 16, WORLD.groundY - 350);
        ctx.lineTo(tx + 16, WORLD.groundY - 350);
        ctx.lineTo(tx + 44, WORLD.groundY);
        ctx.lineTo(tx + 26, WORLD.groundY);
        ctx.lineTo(tx + 8, WORLD.groundY - 325);
        ctx.lineTo(tx - 8, WORLD.groundY - 325);
        ctx.lineTo(tx - 26, WORLD.groundY);
        ctx.closePath();
        ctx.fill();

        // Steel X-brace trusses
        ctx.lineWidth = 3.2;
        for (let lv = 0; lv < 4; lv++) {
          const y1 = WORLD.groundY - 70 - lv * 70;
          const y2 = y1 - 70;
          const w1 = 36 - lv * 5;
          const w2 = 30 - lv * 5;
          ctx.beginPath();
          ctx.moveTo(tx - w1, y1);
          ctx.lineTo(tx + w2, y2);
          ctx.moveTo(tx + w1, y1);
          ctx.lineTo(tx - w2, y2);
          ctx.moveTo(tx - w1, y1);
          ctx.lineTo(tx + w1, y1);
          ctx.stroke();
        }
        // Aviation beacon light atop tower
        ctx.fillStyle = '#f43f5e';
        ctx.beginPath();
        ctx.arc(tx, WORLD.groundY - 356, 4.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#0a1629';
      }

      // Bridge Deck Girder + Vertical Suspension Hanger Cables + Moving Traffic Lights
      ctx.fillStyle = '#07101f';
      ctx.fillRect(-1500, WORLD.groundY - 125, 3000, 16);
      ctx.strokeStyle = '#122947';
      ctx.lineWidth = 3.6;
      ctx.beginPath();
      ctx.moveTo(-1400, WORLD.groundY - 170);
      ctx.quadraticCurveTo(-520, WORLD.groundY - 350, 0, WORLD.groundY - 210);
      ctx.quadraticCurveTo(520, WORLD.groundY - 350, 1400, WORLD.groundY - 170);
      ctx.stroke();

      // Vertical suspension hanger cables along bridge deck
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.16)';
      ctx.lineWidth = 1.4;
      for (let hx = -1100; hx <= 1100; hx += 65) {
        const arc = Math.abs(Math.abs(hx) - 520) / 520;
        const cableTop = WORLD.groundY - 305 + Math.min(1, arc * arc) * 115;
        ctx.beginPath();
        ctx.moveTo(hx, cableTop);
        ctx.lineTo(hx, WORLD.groundY - 125);
        ctx.stroke();
      }

      // Distant moving Kolkata traffic headlights/taillights across bridge deck
      for (let c = 0; c < 6; c++) {
        const dir = c % 2 === 0 ? 1 : -1;
        const cx = ((c * 430 + nowSec * 95 * dir + 2800) % 2800) - 1400;
        ctx.fillStyle = dir > 0 ? 'rgba(254, 240, 138, 0.85)' : 'rgba(244, 63, 94, 0.82)';
        ctx.fillRect(cx, WORLD.groundY - 130, 12, 4);
      }

      for (let lx = -1200; lx <= 1200; lx += 160) {
        const lg = ctx.createRadialGradient(lx, WORLD.groundY - 134, 2, lx, WORLD.groundY - 134, 34);
        lg.addColorStop(0, 'rgba(253, 224, 71, 0.85)');
        lg.addColorStop(1, 'rgba(253, 224, 71, 0)');
        ctx.fillStyle = lg;
        ctx.beginPath();
        ctx.arc(lx, WORLD.groundY - 134, 34, 0, Math.PI * 2);
        ctx.fill();
      }
      // Hooghly River Horizon Band behind promenade
      const riverG = ctx.createLinearGradient(0, WORLD.groundY - 82, 0, WORLD.groundY);
      riverG.addColorStop(0, '#09182c');
      riverG.addColorStop(1, '#102744');
      ctx.fillStyle = riverG;
      ctx.fillRect(-1600, WORLD.groundY - 82, 3200, 82);
      // Shimmering water moon ripples
      ctx.strokeStyle = 'rgba(224, 242, 254, 0.24)';
      ctx.lineWidth = 1.6;
      for (let r = 0; r < 14; r++) {
        const ry = WORLD.groundY - 72 + r * 5;
        const rw = 22 + Math.sin(nowSec * 3 + r) * 14;
        ctx.beginPath();
        ctx.moveTo(this.camX * 0.5 - rw, ry);
        ctx.lineTo(this.camX * 0.5 + rw, ry);
        ctx.stroke();
      }
    } else if (this.arenaId === 'banaras') {
      // Sacred Dashashwamedh Ghat: Tiered Temple Shikharas, Hanging Bells & Warm Oil Lamps
      for (let sx = -1260; sx <= 1260; sx += 420) {
        const stoneG = ctx.createLinearGradient(sx - 90, WORLD.groundY - 310, sx + 90, WORLD.groundY);
        stoneG.addColorStop(0, '#2e111f');
        stoneG.addColorStop(1, '#170812');
        ctx.fillStyle = stoneG;

        // Carved sandstone temple base & stepped Shikhara spire
        ctx.fillRect(sx - 82, WORLD.groundY - 165, 164, 165);
        ctx.beginPath();
        ctx.moveTo(sx - 72, WORLD.groundY - 165);
        ctx.quadraticCurveTo(sx - 40, WORLD.groundY - 265, sx, WORLD.groundY - 320);
        ctx.quadraticCurveTo(sx + 40, WORLD.groundY - 265, sx + 72, WORLD.groundY - 165);
        ctx.closePath();
        ctx.fill();

        // Amalaka & Golden Kalash finial
        ctx.fillStyle = '#eab308';
        ctx.beginPath();
        ctx.ellipse(sx, WORLD.groundY - 322, 14, 5, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.moveTo(sx - 4, WORLD.groundY - 326);
        ctx.lineTo(sx, WORLD.groundY - 344);
        ctx.lineTo(sx + 4, WORLD.groundY - 326);
        ctx.closePath();
        ctx.fill();

        // Torana Temple Archway & Glowing Inner Sanctum Diya Light
        const sanctumG = ctx.createRadialGradient(sx, WORLD.groundY - 62, 6, sx, WORLD.groundY - 62, 68);
        sanctumG.addColorStop(0, 'rgba(253, 224, 71, 0.78)');
        sanctumG.addColorStop(0.5, 'rgba(249, 115, 22, 0.35)');
        sanctumG.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = sanctumG;
        ctx.beginPath();
        ctx.roundRect(sx - 34, WORLD.groundY - 118, 68, 118, [34, 34, 0, 0]);
        ctx.fill();

        // Hanging brass temple bell
        ctx.strokeStyle = '#facc15';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(sx, WORLD.groundY - 118);
        ctx.lineTo(sx, WORLD.groundY - 96);
        ctx.stroke();
        ctx.fillStyle = '#ca8a04';
        ctx.beginPath();
        ctx.moveTo(sx - 8, WORLD.groundY - 82);
        ctx.lineTo(sx - 4, WORLD.groundY - 96);
        ctx.lineTo(sx + 4, WORLD.groundY - 96);
        ctx.lineTo(sx + 8, WORLD.groundY - 82);
        ctx.closePath();
        ctx.fill();
      }

      // Ganga Ghat Tiered Stone Steps along water edge
      for (let step = 0; step < 5; step++) {
        ctx.fillStyle = step % 2 === 0 ? '#26111c' : '#1d0c15';
        ctx.fillRect(-1600, WORLD.groundY - 40 + step * 8, 3200, 8);
      }

      // Ornate Brass Mashals (Flaming Ceremonial Torches)
      for (let c = 0; c < 2; c++) {
        const cx = c === 0 ? -WORLD.arenaHalfWidth + 24 : WORLD.arenaHalfWidth - 24;
        ctx.fillStyle = '#78350f';
        ctx.strokeStyle = '#facc15';
        ctx.lineWidth = 1.6;
        ctx.beginPath();
        ctx.moveTo(cx - 12, WORLD.groundY);
        ctx.lineTo(cx - 7, WORLD.groundY - 44);
        ctx.lineTo(cx + 7, WORLD.groundY - 44);
        ctx.lineTo(cx + 12, WORLD.groundY);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        // Volumetric flickering fire glow
        const flameR = 28 + Math.sin(nowSec * 14 + c) * 6;
        const fg = ctx.createRadialGradient(cx, WORLD.groundY - 52, 4, cx, WORLD.groundY - 52, flameR * 1.8);
        fg.addColorStop(0, '#fffbeb');
        fg.addColorStop(0.35, 'rgba(251, 146, 60, 0.85)');
        fg.addColorStop(1, 'rgba(249, 115, 22, 0)');
        ctx.fillStyle = fg;
        ctx.beginPath();
        ctx.arc(cx, WORLD.groundY - 52, flameR * 1.8, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    ctx.restore();

    // 4b. Volumetric Atmospheric Moonlight & Lamp God-Ray Beams
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    for (let gr = -2; gr <= 2; gr++) {
      const gx = this.camX * 0.55 + gr * 260;
      const beamG = ctx.createLinearGradient(gx - 60, -40, gx + 140, WORLD.groundY);
      beamG.addColorStop(0, hexToRgba(ar.moonCol, 0.055));
      beamG.addColorStop(0.65, hexToRgba(ar.rim, 0.028));
      beamG.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = beamG;
      ctx.beginPath();
      ctx.moveTo(gx - 35, -40);
      ctx.lineTo(gx + 55, -40);
      ctx.lineTo(gx + 225, WORLD.groundY);
      ctx.lineTo(gx + 45, WORLD.groundY);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();

    // Soft atmospheric ground-fog separating background & fighting stage
    const mistG = ctx.createLinearGradient(0, WORLD.groundY - 90, 0, WORLD.groundY);
    mistG.addColorStop(0, 'rgba(0,0,0,0)');
    mistG.addColorStop(1, hexToRgba(ar.skyMid, 0.56));
    ctx.fillStyle = mistG;
    ctx.fillRect(-span, WORLD.groundY - 90, span * 2, 90);

    // 5. Realistic 2.5D Textured Ground (Arena-Specific Cobblestone / Wet Asphalt / Carved Sandstone)
    this.renderArenaGround(ctx, span, nowSec);

    if (this.arenaId === 'chandni') {
      // Drifting golden bazaar dust motes & fireflies
      for (let mf = 0; mf < 24; mf++) {
        const mx = ((mf * 173 + Math.sin(nowSec * 0.9 + mf) * 45) % 1600) - 800;
        const my = WORLD.groundY - 25 - ((mf * 43 + nowSec * 14) % 210);
        const alpha = 0.25 + 0.45 * Math.abs(Math.sin(nowSec * 3.1 + mf));
        ctx.fillStyle = `rgba(253, 224, 71, ${alpha})`;
        ctx.beginPath();
        ctx.arc(mx, my, 1.8, 0, Math.PI * 2);
        ctx.fill();
      }
    } else if (this.arenaId === 'banaras') {
      for (const dy of this.diyas) {
        const flicker = 0.65 + 0.35 * Math.sin(nowSec * 6 + dy.phase);
        ctx.fillStyle = `rgba(253, 224, 71, ${flicker * 0.35})`;
        ctx.beginPath();
        ctx.ellipse(dy.x, dy.y + 3, 9, 3, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#fef08a';
        ctx.beginPath();
        ctx.arc(dy.x, dy.y, 2.4 + flicker * 0.9, 0, Math.PI * 2);
        ctx.fill();
      }
      // Rising glowing Agni embers across Banaras night sky
      for (let em = 0; em < 28; em++) {
        const ex = -680 + ((em * 97 + Math.sin(nowSec * 1.4 + em) * 28) % 1360);
        const ey = WORLD.groundY - ((em * 37 + nowSec * 48) % 340);
        const alpha = Math.max(0.15, 0.8 - (WORLD.groundY - ey) / 380);
        ctx.fillStyle = em % 2 === 0 ? `rgba(251, 146, 60, ${alpha})` : `rgba(253, 224, 71, ${alpha})`;
        ctx.beginPath();
        ctx.arc(ex, ey, 1.6 + (em % 2), 0, Math.PI * 2);
        ctx.fill();
      }
    } else if (this.arenaId === 'howrah') {
      // Wet rain puddles & lit river ferries
      for (const fObj of this.ferries) {
        ctx.fillStyle = '#0b1528';
        ctx.beginPath();
        ctx.moveTo(fObj.x - 42, WORLD.groundY - 12);
        ctx.lineTo(fObj.x + 42, WORLD.groundY - 12);
        ctx.lineTo(fObj.x + 32, WORLD.groundY - 2);
        ctx.lineTo(fObj.x - 32, WORLD.groundY - 2);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = '#fde047';
        ctx.fillRect(fObj.x - 24, WORLD.groundY - 10, 8, 4);
        ctx.fillRect(fObj.x - 4, WORLD.groundY - 10, 8, 4);
        ctx.fillRect(fObj.x + 16, WORLD.groundY - 10, 8, 4);
      }
      // Monsoon rain streaks & animated ground splash ripples
      ctx.strokeStyle = 'rgba(186, 230, 253, 0.24)';
      ctx.lineWidth = 1.25;
      for (let r = 0; r < 68; r++) {
        const rx = ((r * 137 + nowSec * 230) % 2400) - 1200;
        const ry = (r * 89 + nowSec * 700) % WORLD.groundY;
        ctx.beginPath();
        ctx.moveTo(rx, ry);
        ctx.lineTo(rx - 9, ry + 20);
        ctx.stroke();
      }
      for (let sp = 0; sp < 14; sp++) {
        const phase = (nowSec * 2.2 + sp * 0.37) % 1;
        const sx = -620 + sp * 95;
        const sy = WORLD.groundY + 10 + (sp % 3) * 14;
        ctx.strokeStyle = `rgba(125, 211, 252, ${(1 - phase) * 0.42})`;
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.ellipse(sx, sy, 4 + phase * 14, 1.5 + phase * 4, 0, 0, Math.PI * 2);
        ctx.stroke();
      }
      if (this.lightningTimer > 0) {
        ctx.fillStyle = `rgba(224, 242, 254, ${this.lightningTimer * 0.42})`;
        ctx.fillRect(-span, -200, span * 2, WORLD.height + 300);
      }
    }

    // 6. Animated Realistic 2.5D Akhara Spectators (Human silhouettes with cheering arms!)
    for (let ci = 0; ci < this.crowd.length; ci++) {
      const cd = this.crowd[ci];
      const cdx = cd.side < 0 ? -WORLD.arenaHalfWidth - 34 - (ci % 8) * 20 : WORLD.arenaHalfWidth + 34 + (ci % 8) * 20;
      const cheerRate = 5.2 + this.crowdExcitement * 7.5;
      const cheerAmp = 5 + this.crowdExcitement * 11;
      const cdy = WORLD.groundY - 14 - Math.abs(Math.sin(nowSec * cheerRate + cd.bob)) * cheerAmp;
      const armWave = Math.sin(nowSec * cheerRate * 1.3 + cd.bob);
      ctx.save();
      ctx.globalAlpha = 0.55 + this.crowdExcitement * 0.25;
      // Kurta torso
      ctx.fillStyle = '#0c0a18';
      ctx.strokeStyle = cd.col;
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.roundRect(cdx - 8, cdy - 18, 16, 24, 4);
      ctx.fill();
      ctx.stroke();
      // Cheering raised arms
      ctx.lineWidth = 3;
      ctx.strokeStyle = cd.col;
      ctx.beginPath();
      ctx.moveTo(cdx - 7, cdy - 14);
      ctx.lineTo(cdx - 13, cdy - 24 - armWave * 6 * (0.4 + this.crowdExcitement));
      ctx.moveTo(cdx + 7, cdy - 14);
      ctx.lineTo(cdx + 13, cdy - 24 + armWave * 6 * (0.4 + this.crowdExcitement));
      ctx.stroke();
      // Head
      ctx.fillStyle = '#18142c';
      ctx.beginPath();
      ctx.arc(cdx, cdy - 25, 6.2, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }

    // Sculpted Stone Corner Pillars with Grounded Bases & Arena Lanterns
    for (const wx of [-WORLD.arenaHalfWidth, WORLD.arenaHalfWidth]) {
      // Contact shadow at pillar base on stone curb
      ctx.fillStyle = 'rgba(0, 0, 0, 0.52)';
      ctx.beginPath();
      ctx.ellipse(wx, WORLD.groundY + 3, 22, 6, 0, 0, Math.PI * 2);
      ctx.fill();

      const pilG = ctx.createLinearGradient(wx - 12, 0, wx + 12, 0);
      pilG.addColorStop(0, '#0c0a16');
      pilG.addColorStop(0.5, this.arenaId === 'banaras' ? '#3d1c1e' : this.arenaId === 'howrah' ? '#1c2b42' : '#291f3d');
      pilG.addColorStop(1, '#0c0a16');
      ctx.fillStyle = pilG;
      ctx.strokeStyle = hexToRgba(ar.rim, 0.52);
      ctx.lineWidth = 1.4;
      // Stepped stone pedestal base
      ctx.fillRect(wx - 15, WORLD.groundY - 12, 30, 12);
      ctx.fillRect(wx - 11, WORLD.groundY - 102, 22, 90);
      ctx.strokeRect(wx - 11, WORLD.groundY - 102, 22, 90);
      // Pillar capital & lamp lantern glow
      ctx.fillRect(wx - 15, WORLD.groundY - 108, 30, 8);
      const lampG = ctx.createRadialGradient(wx, WORLD.groundY - 116, 2, wx, WORLD.groundY - 116, 30);
      lampG.addColorStop(0, '#fffbeb');
      lampG.addColorStop(0.4, ar.rim);
      lampG.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = lampG;
      ctx.beginPath();
      ctx.arc(wx, WORLD.groundY - 116, 30, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  private renderArenaGround(ctx: CanvasRenderingContext2D, span: number, nowSec: number): void {
    const gy = WORLD.groundY;
    const floorDepth = 420;
    const perspX = (worldX: number, y: number) => {
      const t = Math.max(0, (y - gy) / 220);
      return worldX + (worldX - this.camX) * t * 0.48;
    };
    const hash = (a: number, b: number) => {
      const v = Math.sin(a * 127.1 + b * 311.7) * 43758.5453;
      return v - Math.floor(v);
    };

    if (this.arenaId === 'chandni') {
      // 1. Old Delhi Night Bazaar: Staggered Sandstone Cobblestones & Warm Lantern Sheen
      const baseG = ctx.createLinearGradient(0, gy, 0, WORLD.height + 120);
      baseG.addColorStop(0, '#2a1d35');
      baseG.addColorStop(0.22, '#1c1326');
      baseG.addColorStop(0.6, '#100a17');
      baseG.addColorStop(1, '#050309');
      ctx.fillStyle = baseG;
      ctx.fillRect(-span, gy, span * 2, floorDepth);

      // Perspective staggered cobblestone courses (no rigid wireframe grid)
      const rowYs = [gy + 5, gy + 15, gy + 29, gy + 48, gy + 74, gy + 109, gy + 156, gy + 220];
      const cobbleW = 86;
      for (let r = 0; r < rowYs.length - 1; r++) {
        const y0 = rowYs[r];
        const y1 = rowYs[r + 1];
        const stagger = r % 2 === 0 ? 0 : cobbleW * 0.5;
        for (let c = -18; c <= 18; c++) {
          const wx0 = c * cobbleW + stagger;
          const wx1 = wx0 + cobbleW;
          const x00 = perspX(wx0, y0);
          const x10 = perspX(wx1, y0);
          const x01 = perspX(wx0, y1);
          const x11 = perspX(wx1, y1);
          const h = hash(r, c);
          const shade = Math.round(h * 16);

          ctx.fillStyle =
            h > 0.66
              ? `rgba(${58 + shade}, ${40 + shade}, ${66 + shade}, 0.58)`
              : h > 0.33
                ? `rgba(${44 + shade}, ${31 + shade}, ${54 + shade}, 0.56)`
                : `rgba(${34 + shade}, ${24 + shade}, ${44 + shade}, 0.56)`;

          ctx.beginPath();
          ctx.moveTo(x00 + 1.5, y0 + 1);
          ctx.lineTo(x10 - 1.5, y0 + 1);
          ctx.lineTo(x11 - 2.2, y1 - 1.2);
          ctx.lineTo(x01 + 2.2, y1 - 1.2);
          ctx.closePath();
          ctx.fill();

          // Subtle top bevel catchlight on stone face
          ctx.strokeStyle = `rgba(251, 191, 36, ${0.045 + h * 0.055})`;
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(x00 + 3, y0 + 1.6);
          ctx.lineTo(x10 - 3, y0 + 1.6);
          ctx.stroke();

          // Recessed dark mortar seam
          ctx.strokeStyle = 'rgba(7, 4, 13, 0.72)';
          ctx.lineWidth = 1.6;
          ctx.beginPath();
          ctx.moveTo(x00, y0);
          ctx.lineTo(x01, y1);
          ctx.moveTo(x00, y1);
          ctx.lineTo(x11, y1);
          ctx.stroke();
        }
      }

      // Warm bazaar shopfront amber reflection pools on wet night cobbles
      for (let bx = -1320; bx <= 1320; bx += 440) {
        const px = bx + this.camX * 0.14;
        const glowG = ctx.createRadialGradient(px, gy + 26, 6, px, gy + 36, 150);
        glowG.addColorStop(0, 'rgba(251, 146, 60, 0.22)');
        glowG.addColorStop(0.55, 'rgba(244, 63, 94, 0.08)');
        glowG.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = glowG;
        ctx.beginPath();
        ctx.ellipse(px, gy + 32, 165, 42, 0, 0, Math.PI * 2);
        ctx.fill();
      }

      // Sculpted sandstone bazaar curb along rear edge
      const curbG = ctx.createLinearGradient(0, gy - 3, 0, gy + 7);
      curbG.addColorStop(0, '#5a3d52');
      curbG.addColorStop(0.45, '#3b263c');
      curbG.addColorStop(1, '#180f20');
      ctx.fillStyle = curbG;
      ctx.fillRect(-span, gy - 2, span * 2, 8);
      ctx.fillStyle = 'rgba(253, 224, 71, 0.16)';
      ctx.fillRect(-span, gy - 2, span * 2, 1.3);

      // Scattered marigold petals & festive street specks
      for (let pt = 0; pt < 42; pt++) {
        const px = -780 + hash(pt, 9) * 1560;
        const py = gy + 10 + hash(pt, 17) * 95;
        const sx = perspX(px, py);
        ctx.fillStyle = pt % 3 === 0 ? 'rgba(251, 146, 60, 0.72)' : pt % 3 === 1 ? 'rgba(250, 204, 21, 0.7)' : 'rgba(244, 63, 94, 0.55)';
        ctx.beginPath();
        ctx.ellipse(sx, py, 2.8, 1.3, hash(pt, 3) * Math.PI, 0, Math.PI * 2);
        ctx.fill();
      }
    } else if (this.arenaId === 'howrah') {
      // 2. Howrah Bridge: Rain-Slicked Asphalt Roadway, Granite Curb & Steel Expansion Plates
      const asphG = ctx.createLinearGradient(0, gy, 0, WORLD.height + 120);
      asphG.addColorStop(0, '#172334');
      asphG.addColorStop(0.24, '#0f1826');
      asphG.addColorStop(0.62, '#080e17');
      asphG.addColorStop(1, '#03060c');
      ctx.fillStyle = asphG;
      ctx.fillRect(-span, gy, span * 2, floorDepth);

      // Granular wet tarmac aggregate texture & hairline cracks
      for (let sp = 0; sp < 140; sp++) {
        const wx = -900 + hash(sp, 11) * 1800;
        const wy = gy + 8 + hash(sp, 23) * 175;
        const sx = perspX(wx, wy);
        ctx.fillStyle = sp % 2 === 0 ? 'rgba(148, 163, 184, 0.08)' : 'rgba(2, 6, 23, 0.45)';
        ctx.fillRect(sx, wy, 2.5 + (sp % 3), 1.4);
      }

      // Glossy monsoon rain puddles reflecting moonlight & sodium bridge lamps
      const puddles = [
        { x: -340, y: gy + 28, rx: 118, ry: 16, col: 'rgba(125, 211, 252, 0.16)' },
        { x: -20, y: gy + 44, rx: 155, ry: 21, col: 'rgba(186, 230, 253, 0.19)' },
        { x: 295, y: gy + 24, rx: 110, ry: 15, col: 'rgba(253, 224, 71, 0.14)' },
        { x: -510, y: gy + 64, rx: 95, ry: 14, col: 'rgba(253, 224, 71, 0.11)' },
        { x: 470, y: gy + 62, rx: 105, ry: 15, col: 'rgba(125, 211, 252, 0.13)' },
      ];
      for (let i = 0; i < puddles.length; i++) {
        const pd = puddles[i];
        const px = perspX(pd.x, pd.y);
        const shimmer = 0.85 + 0.15 * Math.sin(nowSec * 2.6 + i);
        const pg = ctx.createRadialGradient(px, pd.y, 8, px, pd.y, pd.rx);
        pg.addColorStop(0, pd.col);
        pg.addColorStop(0.7, 'rgba(15, 23, 42, 0.52)');
        pg.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.save();
        ctx.globalAlpha = shimmer;
        ctx.fillStyle = pg;
        ctx.beginPath();
        ctx.ellipse(px, pd.y, pd.rx, pd.ry, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      // Riveted steel bridge expansion-joint plates receding cleanly in 2.5D perspective
      for (const ex of [-440, 0, 440]) {
        const topX = perspX(ex, gy + 6);
        const botX = perspX(ex, gy + 210);
        ctx.strokeStyle = 'rgba(100, 116, 139, 0.34)';
        ctx.lineWidth = 7;
        ctx.beginPath();
        ctx.moveTo(topX, gy + 6);
        ctx.lineTo(botX, gy + 210);
        ctx.stroke();

        ctx.strokeStyle = 'rgba(2, 6, 16, 0.85)';
        ctx.lineWidth = 2.2;
        ctx.beginPath();
        ctx.moveTo(topX, gy + 6);
        ctx.lineTo(botX, gy + 210);
        ctx.stroke();
      }

      // Faint weathered yellow bridge lane markings
      for (let lx = -840; lx <= 840; lx += 140) {
        const p1x = perspX(lx, gy + 86);
        const p2x = perspX(lx + 72, gy + 86);
        ctx.strokeStyle = 'rgba(250, 204, 21, 0.22)';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(p1x, gy + 86);
        ctx.lineTo(p2x, gy + 86);
        ctx.stroke();
      }

      // Raised concrete & granite bridge sidewalk curb at horizon
      const curbG = ctx.createLinearGradient(0, gy - 4, 0, gy + 9);
      curbG.addColorStop(0, '#334155');
      curbG.addColorStop(0.4, '#1e293b');
      curbG.addColorStop(1, '#09101a');
      ctx.fillStyle = curbG;
      ctx.fillRect(-span, gy - 3, span * 2, 11);
      ctx.fillStyle = 'rgba(186, 230, 253, 0.2)';
      ctx.fillRect(-span, gy - 3, span * 2, 1.4);
      ctx.strokeStyle = 'rgba(2, 6, 23, 0.72)';
      ctx.lineWidth = 1.4;
      for (let jx = -1200; jx <= 1200; jx += 96) {
        ctx.beginPath();
        ctx.moveTo(jx, gy - 3);
        ctx.lineTo(jx, gy + 8);
        ctx.stroke();
      }
    } else {
      // 3. Banaras Ghat: Carved Chunar Sandstone Slabs, Mashal Torch Glow & Offerings
      const sandG = ctx.createLinearGradient(0, gy, 0, WORLD.height + 120);
      sandG.addColorStop(0, '#381c1d');
      sandG.addColorStop(0.24, '#241013');
      sandG.addColorStop(0.64, '#13070a');
      sandG.addColorStop(1, '#060204');
      ctx.fillStyle = sandG;
      ctx.fillRect(-span, gy, span * 2, floorDepth);

      // Wide monumental carved sandstone ashlar slabs (running-bond perspective)
      const rowYs = [gy + 6, gy + 20, gy + 41, gy + 70, gy + 112, gy + 170, gy + 245];
      const slabW = 164;
      for (let r = 0; r < rowYs.length - 1; r++) {
        const y0 = rowYs[r];
        const y1 = rowYs[r + 1];
        const stagger = r % 2 === 0 ? 0 : slabW * 0.5;
        for (let c = -10; c <= 10; c++) {
          const wx0 = c * slabW + stagger;
          const wx1 = wx0 + slabW;
          const x00 = perspX(wx0, y0);
          const x10 = perspX(wx1, y0);
          const x01 = perspX(wx0, y1);
          const x11 = perspX(wx1, y1);
          const h = hash(r + 7, c);
          const warm = Math.round(h * 18);

          ctx.fillStyle =
            h > 0.65
              ? `rgba(${96 + warm}, ${48 + Math.round(warm * 0.5)}, ${38 + Math.round(warm * 0.3)}, 0.48)`
              : h > 0.32
                ? `rgba(${78 + warm}, ${38 + Math.round(warm * 0.5)}, ${32 + Math.round(warm * 0.3)}, 0.46)`
                : `rgba(${62 + warm}, ${30 + Math.round(warm * 0.4)}, ${26 + Math.round(warm * 0.3)}, 0.48)`;

          ctx.beginPath();
          ctx.moveTo(x00 + 2, y0 + 1);
          ctx.lineTo(x10 - 2, y0 + 1);
          ctx.lineTo(x11 - 3, y1 - 1.5);
          ctx.lineTo(x01 + 3, y1 - 1.5);
          ctx.closePath();
          ctx.fill();

          // Warm sandstone edge bevel & weathered chisel joints
          ctx.strokeStyle = `rgba(251, 191, 36, ${0.05 + h * 0.05})`;
          ctx.lineWidth = 1.1;
          ctx.beginPath();
          ctx.moveTo(x00 + 4, y0 + 1.8);
          ctx.lineTo(x10 - 4, y0 + 1.8);
          ctx.stroke();

          ctx.strokeStyle = 'rgba(12, 4, 6, 0.78)';
          ctx.lineWidth = 1.8;
          ctx.beginPath();
          ctx.moveTo(x00, y0);
          ctx.lineTo(x01, y1);
          ctx.moveTo(x00, y1);
          ctx.lineTo(x11, y1);
          ctx.stroke();
        }
      }

      // Animated flickering Mashal firelight pools across ghat stone terrace
      for (let c = 0; c < 2; c++) {
        const cx = c === 0 ? -WORLD.arenaHalfWidth + 24 : WORLD.arenaHalfWidth - 24;
        const pulse = 0.85 + 0.15 * Math.sin(nowSec * 12 + c * 2);
        const fg = ctx.createRadialGradient(cx, gy + 24, 10, cx, gy + 36, 220 * pulse);
        fg.addColorStop(0, 'rgba(251, 146, 60, 0.28)');
        fg.addColorStop(0.5, 'rgba(234, 88, 12, 0.11)');
        fg.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = fg;
        ctx.beginPath();
        ctx.ellipse(cx, gy + 32, 220 * pulse, 54, 0, 0, Math.PI * 2);
        ctx.fill();
      }

      // Ornate carved Chunar sandstone ghat step lip along horizon
      const stepG = ctx.createLinearGradient(0, gy - 4, 0, gy + 9);
      stepG.addColorStop(0, '#7c3f34');
      stepG.addColorStop(0.45, '#4b221e');
      stepG.addColorStop(1, '#1a0a0c');
      ctx.fillStyle = stepG;
      ctx.fillRect(-span, gy - 3, span * 2, 11);
      ctx.fillStyle = 'rgba(253, 224, 71, 0.22)';
      ctx.fillRect(-span, gy - 3, span * 2, 1.4);

      // Scattered genda petals & ceremonial haldi/kumkum specks on ghat steps
      for (let pt = 0; pt < 48; pt++) {
        const px = -760 + hash(pt, 5) * 1520;
        const py = gy + 9 + hash(pt, 13) * 85;
        const sx = perspX(px, py);
        ctx.fillStyle =
          pt % 4 === 0
            ? 'rgba(239, 68, 68, 0.55)'
            : pt % 2 === 0
              ? 'rgba(251, 146, 60, 0.72)'
              : 'rgba(250, 204, 21, 0.68)';
        ctx.beginPath();
        ctx.ellipse(sx, py, 3.1, 1.4, hash(pt, 21) * Math.PI, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // Shared 2.5D ambient occlusion along rear horizon curb (anchors characters & props)
    const aoG = ctx.createLinearGradient(0, gy, 0, gy + 24);
    aoG.addColorStop(0, 'rgba(0, 0, 0, 0.42)');
    aoG.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = aoG;
    ctx.fillRect(-span, gy, span * 2, 24);

    // Subtle foreground camera vignette at bottom of stage
    const fgVig = ctx.createLinearGradient(0, gy + 115, 0, WORLD.height + 120);
    fgVig.addColorStop(0, 'rgba(0, 0, 0, 0)');
    fgVig.addColorStop(1, 'rgba(2, 2, 6, 0.85)');
    ctx.fillStyle = fgVig;
    ctx.fillRect(-span, gy + 115, span * 2, 260);
  }

  private renderVictoriaMemorialLobby(nowSec: number): void {
    const ctx = this.ctx;
    const span = 2200;
    const gy = WORLD.groundY;
    const monumentX = 48;
    const theme = this.lobbyTheme;
    const isDiwali = theme === 'diwali_diya';
    const isBlood = theme === 'blood_moon';
    const isHoli = theme === 'holi_rang';

    // 1. Regal Kolkata Dusk-to-Seasonal Event Sky
    const sky = ctx.createLinearGradient(0, -900, 0, gy);
    if (isDiwali) {
      sky.addColorStop(0, '#0c0704');
      sky.addColorStop(0.45, '#2b1208');
      sky.addColorStop(0.76, '#61230c');
      sky.addColorStop(0.92, '#b45309');
      sky.addColorStop(1, '#f59e0b');
    } else if (isBlood) {
      sky.addColorStop(0, '#070106');
      sky.addColorStop(0.45, '#1f040f');
      sky.addColorStop(0.76, '#4c0519');
      sky.addColorStop(0.92, '#881337');
      sky.addColorStop(1, '#be123c');
    } else if (isHoli) {
      sky.addColorStop(0, '#0d061f');
      sky.addColorStop(0.45, '#290d4a');
      sky.addColorStop(0.76, '#581c87');
      sky.addColorStop(0.92, '#be185d');
      sky.addColorStop(1, '#0284c7');
    } else {
      sky.addColorStop(0, '#050816');
      sky.addColorStop(0.45, '#131333');
      sky.addColorStop(0.76, '#321b42');
      sky.addColorStop(0.92, '#693232');
      sky.addColorStop(1, '#9a4a2b');
    }
    ctx.fillStyle = sky;
    ctx.fillRect(-span, -1400, span * 2, gy + 1450);

    // Monument horizon bloom centered behind Victoria Memorial
    const breath = 0.92 + 0.08 * Math.sin(nowSec * 1.1);
    const horizonGlow = ctx.createRadialGradient(monumentX, gy - 110, 28, monumentX, gy - 95, (isDiwali ? 680 : 560) * breath);
    if (isDiwali) {
      horizonGlow.addColorStop(0, 'rgba(254, 240, 138, 0.58)');
      horizonGlow.addColorStop(0.38, 'rgba(251, 146, 60, 0.32)');
      horizonGlow.addColorStop(0.72, 'rgba(245, 158, 11, 0.14)');
      horizonGlow.addColorStop(1, 'rgba(0, 0, 0, 0)');
    } else if (isBlood) {
      horizonGlow.addColorStop(0, 'rgba(251, 113, 133, 0.45)');
      horizonGlow.addColorStop(0.38, 'rgba(225, 29, 72, 0.25)');
      horizonGlow.addColorStop(0.72, 'rgba(136, 19, 55, 0.12)');
      horizonGlow.addColorStop(1, 'rgba(0, 0, 0, 0)');
    } else if (isHoli) {
      horizonGlow.addColorStop(0, 'rgba(244, 114, 182, 0.42)');
      horizonGlow.addColorStop(0.38, 'rgba(56, 189, 248, 0.22)');
      horizonGlow.addColorStop(0.72, 'rgba(250, 204, 21, 0.12)');
      horizonGlow.addColorStop(1, 'rgba(0, 0, 0, 0)');
    } else {
      horizonGlow.addColorStop(0, 'rgba(253, 224, 71, 0.42)');
      horizonGlow.addColorStop(0.38, 'rgba(245, 158, 11, 0.2)');
      horizonGlow.addColorStop(0.72, 'rgba(244, 63, 94, 0.08)');
      horizonGlow.addColorStop(1, 'rgba(0, 0, 0, 0)');
    }
    ctx.fillStyle = horizonGlow;
    ctx.fillRect(-span, -240, span * 2, gy + 260);

    // Soft evening twinkling stars
    for (const st of this.stars) {
      ctx.globalAlpha = (isBlood ? 0.28 : 0.2) + 0.6 * Math.abs(Math.sin(nowSec * 1.9 + st.tw));
      ctx.fillStyle = isBlood ? '#fda4af' : isHoli ? '#f9a8d4' : '#fef3c7';
      ctx.beginPath();
      ctx.arc(st.x, st.y * 0.7, st.r * 0.95, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;

    // Moon / Blood Moon Eclipse in upper-left dusk sky
    const moonX = isBlood ? -390 : -430;
    const moonY = isBlood ? gy - 315 : gy - 335;
    if (isBlood) {
      const moonHalo = ctx.createRadialGradient(moonX, moonY, 16, moonX, moonY, 130);
      moonHalo.addColorStop(0, 'rgba(244, 63, 94, 0.62)');
      moonHalo.addColorStop(0.45, 'rgba(190, 18, 60, 0.28)');
      moonHalo.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = moonHalo;
      ctx.beginPath();
      ctx.arc(moonX, moonY, 130, 0, Math.PI * 2);
      ctx.fill();

      const bloodDisc = ctx.createRadialGradient(moonX - 10, moonY - 10, 4, moonX, moonY, 42);
      bloodDisc.addColorStop(0, '#fda4af');
      bloodDisc.addColorStop(0.45, '#e11d48');
      bloodDisc.addColorStop(1, '#4c0519');
      ctx.fillStyle = bloodDisc;
      ctx.beginPath();
      ctx.arc(moonX, moonY, 42, 0, Math.PI * 2);
      ctx.fill();
    } else {
      const moonHalo = ctx.createRadialGradient(moonX, moonY, 6, moonX, moonY, isDiwali ? 90 : 72);
      moonHalo.addColorStop(0, isDiwali ? 'rgba(254, 240, 138, 0.65)' : 'rgba(254, 243, 199, 0.45)');
      moonHalo.addColorStop(0.5, isHoli ? 'rgba(244, 114, 182, 0.16)' : 'rgba(251, 191, 36, 0.12)');
      moonHalo.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = moonHalo;
      ctx.beginPath();
      ctx.arc(moonX, moonY, isDiwali ? 90 : 72, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = isDiwali ? '#fef08a' : '#fef3c7';
      ctx.beginPath();
      ctx.arc(moonX, moonY, isDiwali ? 19 : 16, 0, Math.PI * 2);
      ctx.fill();
      if (!isDiwali) {
        ctx.fillStyle = isHoli ? '#1e0b38' : '#0d0f27';
        ctx.beginPath();
        ctx.arc(moonX + 6, moonY - 3, 13.5, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // Slowly drifting twilight dusk clouds behind the monument
    for (let c = 0; c < 5; c++) {
      const cx = -720 + ((nowSec * (7 + c * 1.8) + c * 310) % 1560);
      const cy = gy - 285 - (c % 3) * 44;
      const cw = 180 + (c % 3) * 55;
      const cg = ctx.createLinearGradient(cx - cw, cy, cx + cw, cy + 28);
      const cloudCol = isBlood ? 'rgba(244, 63, 94, 0.12)' : isHoli ? 'rgba(232, 121, 249, 0.12)' : 'rgba(251, 191, 36, 0.09)';
      cg.addColorStop(0, 'rgba(0, 0, 0, 0)');
      cg.addColorStop(0.5, cloudCol);
      cg.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = cg;
      ctx.beginPath();
      ctx.ellipse(cx, cy, cw, 16 + (c % 2) * 6, 0, 0, Math.PI * 2);
      ctx.fill();
    }

    // Floating Sky Lanterns / Diwali Fuljhadi Sparks / Blood Moon Embers / Holi Gulal Motes
    const lanternCount = isDiwali ? 16 : isBlood ? 14 : isHoli ? 18 : 11;
    for (let l = 0; l < lanternCount; l++) {
      const laneX = -600 + l * (1200 / lanternCount) + Math.sin(nowSec * 0.65 + l * 1.7) * 26;
      const riseProgress = ((nowSec * (11 + (l % 4) * 3.2) + l * 49) % 360) / 360;
      const ly = gy - 75 - riseProgress * 340;
      const lScale = 0.55 + (1 - riseProgress) * 0.45;
      const lAlpha = Math.sin(riseProgress * Math.PI) * 0.85;
      ctx.save();
      ctx.translate(laneX, ly);
      ctx.scale(lScale, lScale);
      ctx.globalAlpha = Math.max(0, lAlpha);

      if (isBlood) {
        const eg = ctx.createRadialGradient(0, 0, 1, 0, 0, 14);
        eg.addColorStop(0, 'rgba(253, 164, 175, 0.95)');
        eg.addColorStop(0.45, 'rgba(225, 29, 72, 0.45)');
        eg.addColorStop(1, 'rgba(225, 29, 72, 0)');
        ctx.fillStyle = eg;
        ctx.beginPath();
        ctx.arc(0, 0, 14, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#fb7185';
        ctx.beginPath();
        ctx.arc(0, 0, 2.5, 0, Math.PI * 2);
        ctx.fill();
      } else if (isHoli) {
        const holiCols = ['#ec4899', '#22d3ee', '#fde047', '#a855f7'];
        const col = holiCols[l % holiCols.length];
        ctx.fillStyle = hexToRgba(col, 0.55);
        ctx.beginPath();
        ctx.arc(0, 0, 9 + (l % 3) * 3, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = col;
        ctx.beginPath();
        ctx.arc(0, 0, 3.2, 0, Math.PI * 2);
        ctx.fill();
      } else {
        const lg = ctx.createRadialGradient(0, 0, 2, 0, 0, isDiwali ? 28 : 22);
        lg.addColorStop(0, 'rgba(254, 240, 138, 0.95)');
        lg.addColorStop(0.45, isDiwali ? 'rgba(245, 158, 11, 0.52)' : 'rgba(251, 146, 60, 0.38)');
        lg.addColorStop(1, 'rgba(251, 146, 60, 0)');
        ctx.fillStyle = lg;
        ctx.beginPath();
        ctx.arc(0, 0, isDiwali ? 28 : 22, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = isDiwali ? '#f59e0b' : '#fb923c';
        ctx.beginPath();
        ctx.moveTo(-6, -8);
        ctx.quadraticCurveTo(0, -11, 6, -8);
        ctx.lineTo(4.5, 5);
        ctx.lineTo(-4.5, 5);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = '#fef08a';
        ctx.beginPath();
        ctx.arc(0, 2.5, 2.4, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }
    ctx.globalAlpha = 1;

    // 2. Swaying Victoria Memorial Royal Garden Palms & Manicured Cypress
    for (let idx = 0; idx < 8; idx++) {
      const treeXs = [-560, -475, -390, -315, 365, 440, 520, 600];
      const tx = treeXs[idx];
      const sway = Math.sin(nowSec * 1.35 + idx * 0.9) * 5;
      const isPalm = idx % 2 === 0;
      if (isPalm) {
        ctx.strokeStyle = isBlood ? '#17040a' : '#091518';
        ctx.lineWidth = 6.5;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(tx, gy - 20);
        ctx.quadraticCurveTo(tx + sway * 0.4, gy - 82, tx + sway, gy - 135);
        ctx.stroke();

        const topX = tx + sway;
        const topY = gy - 135;
        ctx.fillStyle = isBlood ? '#1e060e' : '#0b1e21';
        for (let f = -2; f <= 2; f++) {
          ctx.beginPath();
          ctx.moveTo(topX, topY);
          const ang = f * 0.55 + Math.sin(nowSec * 1.9 + f + idx) * 0.06;
          const fx = topX + Math.sin(ang) * 34;
          const fy = topY - Math.cos(ang) * 14 + Math.abs(f) * 8;
          ctx.quadraticCurveTo(topX + Math.sin(ang) * 18, topY - 18, fx, fy);
          ctx.quadraticCurveTo(topX + Math.sin(ang) * 16, topY - 8, topX, topY);
          ctx.fill();
        }
      } else {
        const h = 86 + (Math.abs(tx) % 34);
        ctx.fillStyle = isBlood ? '#17040a' : '#09171a';
        ctx.beginPath();
        ctx.moveTo(tx - 21, gy - 18);
        ctx.quadraticCurveTo(tx + sway * 0.4, gy - 18 - h, tx + 21, gy - 18);
        ctx.closePath();
        ctx.fill();
      }
    }

    // Manicured garden hedge line & warm perimeter uplight wash
    ctx.fillStyle = isBlood ? '#1c050d' : '#0b1c1f';
    ctx.fillRect(-span, gy - 42, span * 2, 26);

    // 3. GRAND ILLUMINATED VICTORIA MEMORIAL PALACE (Makrana White Marble)
    ctx.save();
    ctx.translate(monumentX, gy - 26);

    // Animated rotating royal halo behind the Angel of Victory apex
    ctx.save();
    ctx.translate(0, -323);
    ctx.rotate(nowSec * 0.14);
    for (let r = 0; r < 12; r++) {
      ctx.rotate((Math.PI * 2) / 12);
      const rayG = ctx.createLinearGradient(0, 0, 0, -95);
      rayG.addColorStop(
        0,
        isBlood ? 'rgba(244, 63, 94, 0.34)' : isDiwali ? 'rgba(254, 240, 138, 0.38)' : isHoli ? 'rgba(232, 121, 249, 0.3)' : 'rgba(253, 224, 71, 0.24)',
      );
      rayG.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = rayG;
      ctx.beginPath();
      ctx.moveTo(-3, 0);
      ctx.lineTo(-10, -95);
      ctx.lineTo(10, -95);
      ctx.lineTo(3, 0);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();

    // Sweeping architectural heritage uplight cones across palace wings & dome
    const holiConePalette = ['rgba(236, 72, 153, ', 'rgba(34, 211, 238, ', 'rgba(250, 204, 21, ', 'rgba(168, 85, 247, ', 'rgba(236, 72, 153, '];
    [-210, -105, 0, 105, 210].forEach((ux, coneIdx) => {
      const pulse = (isDiwali ? 0.14 : 0.08) + 0.03 * Math.sin(nowSec * 1.4 + ux * 0.02);
      const uCone = ctx.createLinearGradient(ux, -12, ux, -245);
      const rgbPrefix = isBlood
        ? 'rgba(244, 63, 94, '
        : isHoli
          ? holiConePalette[coneIdx % holiConePalette.length]
          : 'rgba(251, 191, 36, ';
      uCone.addColorStop(0, `${rgbPrefix}${pulse * 1.7})`);
      uCone.addColorStop(1, `${rgbPrefix}0)`);
      ctx.fillStyle = uCone;
      ctx.beginPath();
      ctx.moveTo(ux - 22, -12);
      ctx.lineTo(ux + 22, -12);
      ctx.lineTo(ux + 68, -245);
      ctx.lineTo(ux - 68, -245);
      ctx.closePath();
      ctx.fill();
    });

    // Main wide marble facade & wings
    const marbleGrad = ctx.createLinearGradient(0, -240, 0, 0);
    if (isBlood) {
      marbleGrad.addColorStop(0, '#ffe4e6');
      marbleGrad.addColorStop(0.55, '#fda4af');
      marbleGrad.addColorStop(1, '#9f1239');
    } else if (isDiwali) {
      marbleGrad.addColorStop(0, '#fffbeb');
      marbleGrad.addColorStop(0.55, '#fef3c7');
      marbleGrad.addColorStop(1, '#d97706');
    } else {
      marbleGrad.addColorStop(0, '#ffffff');
      marbleGrad.addColorStop(0.55, '#e2e8f0');
      marbleGrad.addColorStop(1, '#cbd5e1');
    }

    // Left & right classical colonnade wings
    ctx.fillStyle = isBlood ? '#be123c' : isDiwali ? '#fde68a' : '#cbd5e1';
    ctx.fillRect(-295, -92, 590, 74);
    ctx.fillStyle = marbleGrad;
    ctx.fillRect(-285, -98, 570, 78);

    // Wing arches (interior glow)
    for (let ax = -255; ax <= 255; ax += 34) {
      if (Math.abs(ax) < 88) continue;
      ctx.fillStyle = '#1e1b2e';
      ctx.beginPath();
      ctx.roundRect(ax - 8, -72, 16, 40, [8, 8, 0, 0]);
      ctx.fill();
      const archFlicker = (isDiwali ? 0.65 : 0.42) + 0.1 * Math.sin(nowSec * 3.1 + ax);
      ctx.fillStyle = isBlood
        ? `rgba(244, 63, 94, ${archFlicker})`
        : isHoli
          ? `rgba(232, 121, 249, ${archFlicker})`
          : `rgba(251, 191, 36, ${archFlicker})`;
      ctx.beginPath();
      ctx.roundRect(ax - 5, -67, 10, 35, [5, 5, 0, 0]);
      ctx.fill();
    }

    // Diwali Special: Rooftop Golden Fairy-Light Diya String across palace colonnade
    if (isDiwali) {
      for (let lx = -280; lx <= 280; lx += 16) {
        const spark = 0.65 + 0.35 * Math.sin(nowSec * 7 + lx * 0.25);
        ctx.fillStyle = lx % 32 === 0 ? `rgba(254, 240, 138, ${spark})` : `rgba(251, 146, 60, ${spark})`;
        ctx.beginPath();
        ctx.arc(lx, -97 + Math.sin(lx * 0.08) * 2.5, 2.2, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // 4 Flanking Chhatri Corner Pavilions
    for (const cx of [-255, -135, 135, 255]) {
      const isInner = Math.abs(cx) < 180;
      const cw = isInner ? 36 : 28;
      const topY = isInner ? -155 : -132;
      ctx.fillStyle = isBlood ? '#fda4af' : isDiwali ? '#fef3c7' : '#e2e8f0';
      ctx.fillRect(cx - cw * 0.5, topY, cw, -topY - 76);
      ctx.fillStyle = isBlood ? '#ffe4e6' : '#f8fafc';
      ctx.beginPath();
      ctx.arc(cx, topY, cw * 0.56, Math.PI, 0);
      ctx.fill();
      ctx.fillStyle = isBlood ? '#fb7185' : '#fbbf24';
      ctx.fillRect(cx - 1.2, topY - cw * 0.56 - 14, 2.4, 15);
    }

    // Central Grand Portico & Drum
    ctx.fillStyle = marbleGrad;
    ctx.fillRect(-98, -145, 196, 126);
    ctx.fillStyle = '#1a1529';
    ctx.beginPath();
    ctx.roundRect(-30, -108, 60, 88, [30, 30, 0, 0]);
    ctx.fill();
    const archGlow = ctx.createRadialGradient(0, -68, 4, 0, -68, 62);
    if (isBlood) {
      archGlow.addColorStop(0, 'rgba(251, 113, 133, 0.85)');
      archGlow.addColorStop(1, 'rgba(190, 18, 60, 0)');
    } else if (isHoli) {
      archGlow.addColorStop(0, 'rgba(56, 189, 248, 0.8)');
      archGlow.addColorStop(1, 'rgba(236, 72, 153, 0)');
    } else {
      archGlow.addColorStop(0, 'rgba(254, 240, 138, 0.85)');
      archGlow.addColorStop(1, 'rgba(251, 146, 60, 0)');
    }
    ctx.fillStyle = archGlow;
    ctx.beginPath();
    ctx.roundRect(-25, -103, 50, 83, [25, 25, 0, 0]);
    ctx.fill();

    // Central Colonnade Drum beneath main dome
    ctx.fillStyle = isBlood ? '#fecdd3' : isDiwali ? '#fef9c3' : '#f1f5f9';
    ctx.fillRect(-66, -206, 132, 62);
    ctx.fillStyle = isBlood ? '#be123c' : '#94a3b8';
    for (let px = -56; px <= 56; px += 14) {
      ctx.fillRect(px - 2, -196, 4, 44);
    }

    // Iconic Soaring Makrana Marble Central Dome
    const domeG = ctx.createRadialGradient(-18, -245, 8, 0, -225, 82);
    if (isBlood) {
      domeG.addColorStop(0, '#ffe4e6');
      domeG.addColorStop(0.62, '#fda4af');
      domeG.addColorStop(1, '#9f1239');
    } else if (isDiwali) {
      domeG.addColorStop(0, '#ffffff');
      domeG.addColorStop(0.62, '#fef08a');
      domeG.addColorStop(1, '#d97706');
    } else {
      domeG.addColorStop(0, '#ffffff');
      domeG.addColorStop(0.62, '#e2e8f0');
      domeG.addColorStop(1, '#94a3b8');
    }
    ctx.fillStyle = domeG;
    ctx.beginPath();
    ctx.arc(0, -206, 66, Math.PI, 0);
    ctx.fill();
    ctx.strokeStyle = isBlood ? 'rgba(251, 113, 133, 0.65)' : 'rgba(254, 240, 138, 0.48)';
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.arc(0, -206, 66, Math.PI * 1.15, Math.PI * 1.85);
    ctx.stroke();

    // Lotus cupola & lantern spire
    ctx.fillStyle = '#f8fafc';
    ctx.fillRect(-10, -284, 20, 16);
    ctx.fillStyle = isBlood ? '#f43f5e' : '#fbbf24';
    ctx.beginPath();
    ctx.moveTo(0, -318);
    ctx.lineTo(-4, -284);
    ctx.lineTo(4, -284);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = isBlood ? '#fda4af' : '#fde047';
    ctx.beginPath();
    ctx.arc(0, -323, 3.6, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(0, -320);
    ctx.lineTo(-9, -313);
    ctx.lineTo(-2, -312);
    ctx.lineTo(8, -326);
    ctx.closePath();
    ctx.fill();

    // Marble Plinth & Royal Staircase
    ctx.fillStyle = isBlood ? '#9f1239' : isDiwali ? '#fde68a' : '#cbd5e1';
    ctx.fillRect(-315, -20, 630, 20);
    ctx.fillStyle = isBlood ? '#fecdd3' : '#e2e8f0';
    ctx.fillRect(-75, -18, 150, 18);
    ctx.fillStyle = '#94a3b8';
    ctx.fillRect(-315, -2, 630, 3);

    // Row of glowing Royal Diya Oil Lamps flickering along the palace marble plinth
    const diyaStep = isDiwali ? 22 : 36;
    for (let dx = -290; dx <= 290; dx += diyaStep) {
      const flicker = 0.8 + 0.2 * Math.sin(nowSec * 9.2 + dx);
      const radius = (isDiwali ? 14 : 10) * flicker;
      const dg = ctx.createRadialGradient(dx, -23, 1, dx, -23, radius);
      dg.addColorStop(0, isBlood ? 'rgba(253, 164, 175, 0.95)' : 'rgba(254, 240, 138, 0.98)');
      dg.addColorStop(0.5, isBlood ? 'rgba(225, 29, 72, 0.45)' : 'rgba(251, 146, 60, 0.45)');
      dg.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = dg;
      ctx.beginPath();
      ctx.arc(dx, -23, radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = isBlood ? '#fb7185' : '#fef08a';
      ctx.beginPath();
      ctx.arc(dx, -22.5, isDiwali ? 2.2 : 1.8, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();

    // 4. Illuminated Reflecting Pool & Animated Royal Garden Fountains
    const poolTop = gy - 26;
    const poolH = 26;
    const poolGrad = ctx.createLinearGradient(0, poolTop, 0, gy);
    if (isBlood) {
      poolGrad.addColorStop(0, '#1f050e');
      poolGrad.addColorStop(1, '#3b0718');
    } else if (isDiwali) {
      poolGrad.addColorStop(0, '#1a1106');
      poolGrad.addColorStop(1, '#362109');
    } else {
      poolGrad.addColorStop(0, '#0c1829');
      poolGrad.addColorStop(1, '#1a2a42');
    }
    ctx.fillStyle = poolGrad;
    ctx.fillRect(-span, poolTop, span * 2, poolH);

    // Rippling water reflection of illuminated Victoria Memorial facade & dome
    ctx.fillStyle = isBlood
      ? 'rgba(244, 63, 94, 0.28)'
      : isHoli
        ? 'rgba(232, 121, 249, 0.24)'
        : isDiwali
          ? 'rgba(253, 224, 71, 0.34)'
          : 'rgba(253, 224, 71, 0.22)';
    for (let r = 0; r < 7; r++) {
      const rw = 190 - r * 20 + Math.sin(nowSec * 2.4 + r) * 18;
      ctx.fillRect(monumentX - rw * 0.5 + Math.cos(nowSec * 1.9 + r) * 5, poolTop + 3 + r * 3.2, rw, 1.5);
    }
    ctx.fillStyle = 'rgba(248, 250, 252, 0.16)';
    ctx.fillRect(monumentX - 210, poolTop + 2, 420, 3.5);

    // Two Symmetrical Animated Royal Fountains arcing sparkling water jets
    for (const fx of [monumentX - 185, monumentX + 185]) {
      for (let rr = 0; rr < 3; rr++) {
        const rp = ((nowSec * 0.65 + rr * 0.33) % 1);
        ctx.strokeStyle = isBlood
          ? `rgba(253, 164, 175, ${(1 - rp) * 0.36})`
          : `rgba(186, 230, 253, ${(1 - rp) * 0.36})`;
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.ellipse(fx, gy - 11, 10 + rp * 42, 3 + rp * 7, 0, 0, Math.PI * 2);
        ctx.stroke();
      }
      for (let s = 0; s < 14; s++) {
        const side = s % 2 === 0 ? -1 : 1;
        const speedBand = (s % 3) * 0.22 + 0.55;
        const tp = ((nowSec * 1.15 + s * 0.17) % 1);
        const dx = side * (6 + (s % 4) * 7) * tp;
        const dy = -48 * speedBand * (4 * tp * (1 - tp));
        ctx.fillStyle = isBlood
          ? 'rgba(253, 164, 175, 0.72)'
          : s % 3 === 0
            ? 'rgba(254, 240, 138, 0.65)'
            : 'rgba(224, 242, 254, 0.72)';
        ctx.beginPath();
        ctx.arc(fx + dx, gy - 12 + dy, 1.4, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // Swaying Festive Marigold & Mango-Leaf Toran Garlands draped along the heritage terrace rail
    ctx.strokeStyle = isBlood ? 'rgba(244, 63, 94, 0.35)' : 'rgba(251, 191, 36, 0.28)';
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(-span, gy - 32);
    ctx.lineTo(span, gy - 32);
    ctx.stroke();
    for (let gx = -560; gx < 560; gx += 70) {
      const swayY = Math.sin(nowSec * 1.6 + gx * 0.03) * 1.5;
      for (let b = 0; b <= 6; b++) {
        const t = b / 6;
        const bx = gx + t * 70;
        const by = gy - 32 + Math.sin(t * Math.PI) * (10 + swayY);
        ctx.fillStyle = isBlood
          ? b % 2 === 0
            ? '#e11d48'
            : '#881337'
          : isHoli
            ? b % 3 === 0
              ? '#ec4899'
              : b % 3 === 1
                ? '#22d3ee'
                : '#facc15'
            : b % 2 === 0
              ? '#f59e0b'
              : '#f97316';
        ctx.beginPath();
        ctx.arc(bx, by, 2.3, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // 5. Foreground Heritage Marble Promenade Floor
    const floorGrad = ctx.createLinearGradient(0, gy, 0, WORLD.height + 120);
    if (isBlood) {
      floorGrad.addColorStop(0, '#2b131c');
      floorGrad.addColorStop(0.25, '#190a11');
      floorGrad.addColorStop(1, '#090306');
    } else if (isDiwali) {
      floorGrad.addColorStop(0, '#332418');
      floorGrad.addColorStop(0.25, '#1f150d');
      floorGrad.addColorStop(1, '#0a0704');
    } else {
      floorGrad.addColorStop(0, '#2a2638');
      floorGrad.addColorStop(0.25, '#191726');
      floorGrad.addColorStop(1, '#090810');
    }
    ctx.fillStyle = floorGrad;
    ctx.fillRect(-span, gy, span * 2, WORLD.height - gy + 140);

    // Ornate Victorian Cast-Iron Kolkata Street Lamps along the promenade
    for (const lx of [-465, -335, 315, 445]) {
      const lampPulse = 0.92 + 0.08 * Math.sin(nowSec * 4.5 + lx);
      const poolL = ctx.createRadialGradient(lx, gy + 8, 4, lx, gy + 8, 65);
      poolL.addColorStop(0, isBlood ? 'rgba(244, 63, 94, 0.22)' : isDiwali ? 'rgba(251, 191, 36, 0.26)' : 'rgba(251, 191, 36, 0.16)');
      poolL.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = poolL;
      ctx.beginPath();
      ctx.ellipse(lx, gy + 8, 65, 16, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#181825';
      ctx.fillRect(lx - 2.5, gy - 95, 5, 95);
      ctx.fillRect(lx - 6, gy - 12, 12, 12);
      ctx.fillRect(lx - 8, gy - 98, 16, 4);

      const globeGlow = ctx.createRadialGradient(lx, gy - 106, 2, lx, gy - 106, (isDiwali ? 44 : 36) * lampPulse);
      globeGlow.addColorStop(0, isBlood ? 'rgba(253, 164, 175, 0.95)' : 'rgba(254, 240, 138, 0.95)');
      globeGlow.addColorStop(0.35, isBlood ? 'rgba(225, 29, 72, 0.45)' : 'rgba(251, 146, 60, 0.42)');
      globeGlow.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = globeGlow;
      ctx.beginPath();
      ctx.arc(lx, gy - 106, (isDiwali ? 44 : 36) * lampPulse, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = isBlood ? '#fda4af' : '#fef3c7';
      ctx.beginPath();
      ctx.arc(lx, gy - 106, 5.2, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#0f0e1a';
      ctx.beginPath();
      ctx.moveTo(lx - 7, gy - 112);
      ctx.lineTo(lx, gy - 120);
      ctx.lineTo(lx + 7, gy - 112);
      ctx.closePath();
      ctx.fill();
    }

    // Perspective stone tile lines & warm brass curb inlay
    ctx.fillStyle = 'rgba(251, 191, 36, 0.45)';
    ctx.fillRect(-span, gy, span * 2, 2.2);
    ctx.strokeStyle = 'rgba(226, 232, 240, 0.08)';
    ctx.lineWidth = 1.2;
    for (let px = -1000; px <= 1000; px += 140) {
      ctx.beginPath();
      ctx.moveTo(px, gy + 2);
      ctx.lineTo(px * 1.45, WORLD.height + 120);
      ctx.stroke();
    }

    // 6. Royal Makrana Marble Hero Pedestal & Volumetric Stage Spotlight under lobby warrior (x = -190)
    const heroX = -190;
    const heroVis = this.f1 ? getFighterVisualPalette(this.f1.cfg, this.f1.skinId, this.f1.auraId) : null;
    const heroAura = heroVis?.auraCol || '#f59e0b';
    const heroGlow = heroVis?.glowCol || '#fde047';

    // Volumetric warm overhead stage beam illuminating the warrior
    const beamG = ctx.createLinearGradient(heroX, gy - 320, heroX, gy + 12);
    beamG.addColorStop(0, 'rgba(253, 224, 71, 0)');
    beamG.addColorStop(0.45, hexToRgba(heroGlow, 0.09));
    beamG.addColorStop(1, hexToRgba(heroAura, 0.18));
    ctx.fillStyle = beamG;
    ctx.beginPath();
    ctx.moveTo(heroX - 42, gy - 315);
    ctx.lineTo(heroX + 42, gy - 315);
    ctx.lineTo(heroX + 150, gy + 14);
    ctx.lineTo(heroX - 150, gy + 14);
    ctx.closePath();
    ctx.fill();

    // Soft backlit hero rim halo behind warrior torso/head
    const haloG = ctx.createRadialGradient(heroX, gy - 112, 12, heroX, gy - 112, 160);
    haloG.addColorStop(0, hexToRgba(heroGlow, 0.26));
    haloG.addColorStop(0.55, hexToRgba(heroAura, 0.11));
    haloG.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = haloG;
    ctx.beginPath();
    ctx.arc(heroX, gy - 112, 160, 0, Math.PI * 2);
    ctx.fill();

    // Engraved brass & marble floor medallion with rotating 12-spoke Mandala geometry beneath warrior feet
    const spotG = ctx.createRadialGradient(heroX, gy + 6, 12, heroX, gy + 6, 200);
    spotG.addColorStop(0, hexToRgba(heroGlow, 0.34));
    spotG.addColorStop(0.55, hexToRgba(heroAura, 0.14));
    spotG.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = spotG;
    ctx.beginPath();
    ctx.ellipse(heroX, gy + 6, 200, 44, 0, 0, Math.PI * 2);
    ctx.fill();

    // Slowly rotating etched Mandala spokes projected in perspective ellipse
    ctx.save();
    ctx.translate(heroX, gy + 5);
    ctx.scale(1, 0.185);
    ctx.rotate(nowSec * 0.22);
    ctx.strokeStyle = hexToRgba(heroGlow, 0.34);
    ctx.lineWidth = 2.2;
    for (let sp = 0; sp < 12; sp++) {
      const a = (sp * Math.PI * 2) / 12;
      ctx.beginPath();
      ctx.moveTo(Math.cos(a) * 58, Math.sin(a) * 58);
      ctx.lineTo(Math.cos(a) * 116, Math.sin(a) * 116);
      ctx.stroke();
    }
    ctx.restore();

    ctx.strokeStyle = 'rgba(251, 191, 36, 0.48)';
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.ellipse(heroX, gy + 5, 118, 22, 0, 0, Math.PI * 2);
    ctx.stroke();

    ctx.strokeStyle = hexToRgba(heroGlow, 0.58);
    ctx.lineWidth = 1.2;
    ctx.setLineDash([10, 6]);
    ctx.beginPath();
    ctx.ellipse(heroX, gy + 5, 92, 16, 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);

    // Gentle rising golden showcase motes & garden fireflies around the pedestal
    for (let m = 0; m < 14; m++) {
      const mx = heroX + Math.sin(nowSec * 1.15 + m * 1.9) * 125;
      const my = gy + 4 - ((nowSec * (22 + (m % 3) * 9) + m * 31) % 220);
      const ma = Math.max(0, 0.68 - (gy - my) / 230);
      ctx.fillStyle = m % 2 === 0 ? hexToRgba('#fde047', ma) : hexToRgba(heroGlow, ma * 0.85);
      ctx.beginPath();
      ctx.arc(mx, my, 1.8 + (m % 2) * 0.8, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  private renderScene(nowSec: number): void {
    const ctx = this.ctx;
    const cw = this.canvas.width;
    const ch = this.canvas.height;
    ctx.save();
    ctx.clearRect(0, 0, cw, ch);

    const sep = this.phase === 'MENU' ? 380 : this.f1 && this.f2 ? Math.abs(this.f1.x - this.f2.x) : 420;
    const minWorldWidth = Math.max(920, Math.min(1220, sep + 300));

    // Landscape framing across mobile (16:9 / 20:9), tablet (4:3), and PC/Mac monitors
    const fitHeight = ch / WORLD.height;
    const fitMinWidth = cw / minWorldWidth;
    let baseScale = Math.min(fitHeight, fitMinWidth);
    // Keep ultrawide monitors from cropping vertical arena ceiling/ground
    baseScale = Math.max(baseScale, cw / 1680);
    const centerWorldY = WORLD.height * 0.52;

    const sx = this.shake > 0 ? (Math.random() - 0.5) * this.shake : 0;
    const sy = this.shake > 0 ? (Math.random() - 0.5) * this.shake : 0;

    ctx.translate(cw * 0.5 + sx, ch * 0.5 + sy);
    ctx.scale(baseScale * this.camZoom, baseScale * this.camZoom);
    ctx.translate(-this.camX, -centerWorldY);

    if (this.phase === 'MENU') {
      this.renderVictoriaMemorialLobby(nowSec);
      if (this.f1) {
        // 1.48x foreground hero showcase scale anchored cleanly at the warrior's feet
        const lobbyHeroScale = 1.48;
        ctx.save();
        ctx.translate(this.f1.x, this.f1.y);
        ctx.scale(lobbyHeroScale, lobbyHeroScale);
        ctx.translate(-this.f1.x, -this.f1.y);
        this.renderFighter(this.f1);
        ctx.restore();
      }
    } else {
      this.renderArenaBackground(nowSec);
      if (this.f1 && this.f2) {
        this.renderFighter(this.f1);
        this.renderFighter(this.f2);
      }
    }

    for (const pr of this.projectiles) {
      ctx.save();
      ctx.translate(pr.x, pr.y);
      ctx.fillStyle = pr.col;
      ctx.strokeStyle = pr.glow;
      ctx.lineWidth = 2.2;

      // Soft energy motion wake behind projectile
      const wakeG = ctx.createLinearGradient(-pr.dir * 38, 0, pr.dir * 12, 0);
      wakeG.addColorStop(0, 'rgba(0,0,0,0)');
      wakeG.addColorStop(1, hexToRgba(pr.glow, 0.36));
      ctx.fillStyle = wakeG;
      ctx.beginPath();
      ctx.ellipse(-pr.dir * 12, 0, 26, 8, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = pr.col;
      if (pr.kind === 'munna_bhaiya') {
        ctx.fillStyle = '#fde047';
        ctx.strokeStyle = '#f43f5e';
        ctx.beginPath();
        ctx.ellipse(0, 0, 19, 5.5, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      } else if (pr.kind === 'chappal_chacha') {
        ctx.rotate(pr.rot);
        ctx.fillStyle = '#ec4899';
        ctx.strokeStyle = '#22d3ee';
        ctx.beginPath();
        ctx.ellipse(0, 0, 22, 9, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      } else if (pr.kind === 'lota_lal') {
        ctx.rotate(pr.rot * 0.7);
        ctx.fillStyle = '#ca8a04';
        ctx.strokeStyle = '#84cc16';
        ctx.beginPath();
        ctx.arc(0, 0, 14, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      } else if (pr.kind === 'belan_bhabhi') {
        ctx.rotate(pr.rot * 1.3);
        ctx.fillStyle = '#d97706';
        ctx.strokeStyle = '#fde047';
        ctx.beginPath();
        ctx.roundRect(-24, -5, 48, 10, 4);
        ctx.fill();
        ctx.stroke();
      } else if (pr.kind === 'sharmaji_beta') {
        ctx.fillStyle = '#e0f2fe';
        ctx.strokeStyle = '#38bdf8';
        ctx.fillRect(-26, -4, 52, 8);
        ctx.strokeRect(-26, -4, 52, 8);
      } else if (pr.kind === 'babaji_boom') {
        ctx.rotate(pr.rot * 1.1);
        ctx.strokeStyle = '#fde047';
        ctx.fillStyle = '#a855f7';
        ctx.beginPath();
        ctx.arc(0, 0, 15, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(0, 0, 21, 0, Math.PI * 1.3);
        ctx.stroke();
      } else if (pr.kind === 'raju_rickshaw') {
        ctx.fillStyle = '#eab308';
        ctx.strokeStyle = '#4ade80';
        ctx.beginPath();
        ctx.arc(0, 0, 15, -0.9, 0.9);
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(-pr.dir * 8, 0, 20, -0.7, 0.7);
        ctx.stroke();
      } else if (pr.kind === 'pados_aunty') {
        ctx.rotate(pr.rot);
        ctx.fillStyle = '#be123c';
        ctx.strokeStyle = '#fbcfe8';
        ctx.beginPath();
        ctx.roundRect(-14, -10, 28, 20, 4);
        ctx.fill();
        ctx.stroke();
      } else if (pr.kind === 'traffic_mama') {
        ctx.fillStyle = '#ef4444';
        ctx.strokeStyle = '#38bdf8';
        ctx.beginPath();
        ctx.roundRect(-24, -5, 48, 10, 5);
        ctx.fill();
        ctx.stroke();
      } else if (pr.kind === 'gym_bunty') {
        ctx.rotate(pr.rot * 1.2);
        ctx.fillStyle = '#334155';
        ctx.strokeStyle = '#fb923c';
        ctx.fillRect(-16, -2.5, 32, 5);
        ctx.fillRect(-20, -10, 8, 20);
        ctx.strokeRect(-20, -10, 8, 20);
        ctx.fillRect(12, -10, 8, 20);
        ctx.strokeRect(12, -10, 8, 20);
      } else {
        ctx.rotate(pr.rot);
        ctx.beginPath();
        ctx.ellipse(0, 0, 20, 10, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      }
      ctx.restore();
    }

    for (const ef of this.vfxEffects) {
      const prog = 1 - ef.life / ef.maxLife;
      ctx.save();
      ctx.globalAlpha = Math.max(0, ef.life / ef.maxLife);
      ctx.translate(ef.x, ef.y);
      if (ef.kind === 'hit_spark') {
        ctx.strokeStyle = ef.glow;
        ctx.lineWidth = 3.2;
        for (let s = 0; s < 8; s++) {
          const a = (s / 8) * Math.PI * 2;
          ctx.beginPath();
          ctx.moveTo(Math.cos(a) * 8, Math.sin(a) * 8);
          ctx.lineTo(Math.cos(a) * (26 + prog * 22), Math.sin(a) * (26 + prog * 22));
          ctx.stroke();
        }
      } else if (ef.kind === 'impact_ring') {
        ctx.strokeStyle = ef.col;
        ctx.lineWidth = 4.5 * (1 - prog * 0.6);
        ctx.beginPath();
        ctx.ellipse(0, 0, 18 + prog * 56, 12 + prog * 38, 0, 0, Math.PI * 2);
        ctx.stroke();
      } else if (ef.kind === 'block_ring') {
        ctx.strokeStyle = '#7dd3fc';
        ctx.lineWidth = 4 * (1 - prog * 0.5);
        ctx.beginPath();
        ctx.arc(0, 0, 20 + prog * 40, -1.1, 1.1);
        ctx.stroke();
      } else if (ef.kind === 'telegraph_flash') {
        ctx.strokeStyle = '#fde047';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(0, 0, 28 + prog * 68, 0, Math.PI * 2);
        ctx.stroke();
      } else {
        ctx.strokeStyle = ef.glow;
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(0, -60, 28 + prog * 70, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.restore();
    }

    for (const par of this.particles) {
      ctx.globalAlpha = Math.max(0, par.life / par.maxLife);
      ctx.fillStyle = par.col;
      ctx.beginPath();
      ctx.arc(par.x, par.y, par.size, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;

    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    for (const pop of this.popups) {
      let alpha = Math.min(1, pop.life * 2.4);
      if (pop.life < 0.25) alpha = pop.life / 0.25;
      ctx.save();
      ctx.translate(pop.x, pop.y);
      ctx.rotate((pop.rot || 0) * 0.85);
      ctx.scale(pop.scale, pop.scale);
      ctx.globalAlpha = alpha;

      const isHuge = pop.style === 'ko' || pop.style === 'big';
      const isCounter = pop.style === 'counter';
      const isInfo = pop.style === 'info';
      const baseSize = isHuge ? 25 : isCounter ? 20 : isInfo ? 14 : 18;
      ctx.font = `900 ${baseSize}px "Bangers", "Yatra One", Impact, sans-serif`;

      const textW = Math.max(48, ctx.measureText(pop.text).width);
      // Colourful comic starburst behind high-impact, counter, or combo hits
      if (isHuge || isCounter || pop.text.includes('x')) {
        const spikes = isHuge ? 14 : 10;
        const rx = textW * 0.72 + (isHuge ? 18 : 12);
        const ry = baseSize * 0.95 + (isHuge ? 11 : 7);
        const burstGrad = ctx.createLinearGradient(-rx, -ry, rx, ry);
        if (isCounter) {
          burstGrad.addColorStop(0, '#ec4899');
          burstGrad.addColorStop(0.5, '#8b5cf6');
          burstGrad.addColorStop(1, '#38bdf8');
        } else {
          burstGrad.addColorStop(0, '#fde047');
          burstGrad.addColorStop(0.5, '#fb923c');
          burstGrad.addColorStop(1, '#f43f5e');
        }
        ctx.save();
        ctx.beginPath();
        for (let s = 0; s < spikes * 2; s++) {
          const ang = (s * Math.PI) / spikes;
          const mult = s % 2 === 0 ? 1.0 : 0.68;
          const px = Math.cos(ang) * rx * mult;
          const py = Math.sin(ang) * ry * mult;
          if (s === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        }
        ctx.closePath();
        ctx.fillStyle = burstGrad;
        ctx.fill();
        ctx.lineWidth = 2.6;
        ctx.strokeStyle = '#090514';
        ctx.lineJoin = 'round';
        ctx.stroke();
        ctx.restore();
      }

      // Dynamic comic-book italic slant
      ctx.transform(1, 0, -0.16, 1, 0, 0);

      // Hard 3D ink extrusion shadow
      ctx.lineJoin = 'round';
      ctx.fillStyle = '#090514';
      ctx.fillText(pop.text, 3.2, 3.8);
      ctx.fillText(pop.text, 1.8, 2.1);

      // Thick comic black outer outline
      ctx.lineWidth = isHuge ? 6.5 : 5.2;
      ctx.strokeStyle = '#090514';
      ctx.strokeText(pop.text, 0, 0);

      // Crisp inner white pop rim
      ctx.lineWidth = isHuge ? 2.4 : 1.8;
      ctx.strokeStyle = '#fffbeb';
      ctx.strokeText(pop.text, 0, 0);

      // Vibrant multi-stop comic gradient fill
      const txtGrad = ctx.createLinearGradient(0, -baseSize * 0.6, 0, baseSize * 0.6);
      if (isCounter) {
        txtGrad.addColorStop(0, '#ffffff');
        txtGrad.addColorStop(0.35, '#67e8f9');
        txtGrad.addColorStop(1, '#f472b6');
      } else if (isInfo) {
        txtGrad.addColorStop(0, '#ffffff');
        txtGrad.addColorStop(0.45, pop.col || '#7dd3fc');
        txtGrad.addColorStop(1, '#38bdf8');
      } else if (isHuge) {
        txtGrad.addColorStop(0, '#ffffff');
        txtGrad.addColorStop(0.28, '#fde047');
        txtGrad.addColorStop(0.68, '#fb923c');
        txtGrad.addColorStop(1, '#f43f5e');
      } else {
        txtGrad.addColorStop(0, '#fffbeb');
        txtGrad.addColorStop(0.38, '#fde047');
        txtGrad.addColorStop(1, pop.col || '#fb923c');
      }
      ctx.fillStyle = txtGrad;
      ctx.fillText(pop.text, 0, 0);
      ctx.restore();
    }

    // In-match Desi Sticker Emote Bubbles above fighter heads
    for (const st of this.activeStickers) {
      const target = st.slot === 1 ? this.f1 : this.f2;
      if (!target) continue;
      const emoteDef = STICKER_EMOTES.find((e) => e.id === st.emoteId) || STICKER_EMOTES[0];
      const age = st.maxLife - st.life;
      const popIn = Math.min(1, age / 0.16);
      const fadeOut = st.life < 0.35 ? st.life / 0.35 : 1;
      const spring = 0.72 + Math.sin(popIn * Math.PI * 0.72) * 0.44;
      const bobY = Math.sin(nowSec * 6.5) * 4;
      const bx = target.x;
      const by = target.y - 182 + bobY;

      ctx.save();
      ctx.translate(bx, by);
      ctx.scale(spring, spring);
      ctx.globalAlpha = Math.max(0, fadeOut);

      // Comic sticker speech bubble
      ctx.fillStyle = '#0b0816';
      ctx.strokeStyle = emoteDef.accent;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.roundRect(-64, -30, 128, 48, 16);
      ctx.fill();
      ctx.stroke();

      // Speech tail
      ctx.fillStyle = '#0b0816';
      ctx.beginPath();
      ctx.moveTo(-9, 17);
      ctx.lineTo(0, 29);
      ctx.lineTo(9, 17);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = emoteDef.accent;
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      ctx.moveTo(-9, 17);
      ctx.lineTo(0, 29);
      ctx.lineTo(9, 17);
      ctx.stroke();

      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.font = '24px "Apple Color Emoji", "Segoe UI Emoji", sans-serif';
      ctx.fillText(emoteDef.emoji, -36, -6);

      ctx.font = '900 13px "Bangers", "Yatra One", Impact, sans-serif';
      ctx.fillStyle = emoteDef.accent;
      ctx.fillText(emoteDef.label, 18, -5);
      ctx.restore();
    }

    ctx.restore();
  }
}

export interface VictoryPoseMeta {
  poseName: string;
  vibe: string;
}

export const VICTORY_POSE_META: Record<string, VictoryPoseMeta> = {
  munna_bhaiya: { poseName: 'Gaddi Salute', vibe: 'Skyward Katta & King Swagger' },
  chappal_chacha: { poseName: 'Flying Chappal Crane', vibe: 'One-Legged Samurai Balance' },
  lota_lal: { poseName: 'Lota Victory Flex', vibe: 'Wide Sumo Champion Stance' },
  belan_bhabhi: { poseName: 'Tawa Queen Triumph', vibe: 'Overhead Belan Crown Hold' },
  babaji_boom: { poseName: 'Brahmastra Levitation', vibe: 'Twin-Arm Cosmic Blessing' },
  raju_rickshaw: { poseName: 'Meter Down Horn Raise', vibe: 'Street Racer Finish' },
  sharmaji_beta: { poseName: 'Topper V-Sign', vibe: '99.9% Scholar Perfection' },
  pados_aunty: { poseName: 'Society Queen Pose', vibe: 'Purse-High Gossip Crown' },
  traffic_mama: { poseName: 'Red Light Command', vibe: 'Whistle Halt Stance' },
  gym_bunty: { poseName: 'Most Muscular Bro', vibe: 'Double Bicep Protein Flex' },
};

function drawStandaloneMuscle(
  ctx: CanvasRenderingContext2D,
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  rStart: number,
  rMid: number,
  rEnd: number,
  bulgeShift: number,
  rimColor: string,
  glowColor: string,
  depthDim: boolean,
  baseColor: string,
  darkColor: string,
  cuffColor?: string
): void {
  drawRealisticLimbSegment(
    ctx,
    x1,
    y1,
    x2,
    y2,
    rStart,
    rMid,
    rEnd,
    bulgeShift,
    rimColor,
    glowColor,
    depthDim,
    baseColor,
    darkColor,
    cuffColor
  );
}

export function drawFighterPosePreview(
  canvas: HTMLCanvasElement,
  fighterId: string,
  poseMode: 'victory' | 'defeat',
  nowSec: number,
  skinId?: string | null,
  auraId?: string | null,
  poseId?: string | null,
): void {
  const cfg = getCfgById(fighterId);
  const look = getCharacterLook(cfg.id, skinId);
  const vis = getFighterVisualPalette(cfg, skinId, auraId);
  const resolvedPoseId = poseId || getSelectedVictoryPoseId(cfg.id);
  const activePose: VictoryPoseDef = getVictoryPoseById(cfg.id, resolvedPoseId);
  const w = canvas.width || 280;
  const h = canvas.height || 240;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  ctx.clearRect(0, 0, w, h);

  // Arena spotlight backdrop
  const bg = ctx.createRadialGradient(w * 0.5, h * 0.45, 12, w * 0.5, h * 0.52, Math.max(w, h) * 0.56);
  if (poseMode === 'victory') {
    bg.addColorStop(0, hexToRgba(vis.glowCol, 0.34));
    bg.addColorStop(0.55, hexToRgba(vis.auraCol, 0.16));
    bg.addColorStop(1, 'rgba(9, 7, 18, 0)');
  } else {
    bg.addColorStop(0, 'rgba(244, 63, 94, 0.18)');
    bg.addColorStop(0.6, 'rgba(30, 27, 46, 0.25)');
    bg.addColorStop(1, 'rgba(9, 7, 18, 0)');
  }
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, w, h);

  // Rotating halo mandala & rising celebration marigold petals / golden embers on Victory
  const stageScale = Math.min(w * 0.85, h) / 182;
  if (poseMode === 'victory') {
    ctx.save();
    ctx.translate(w * 0.5, h * 0.47);
    ctx.rotate(nowSec * 0.5);
    ctx.strokeStyle = hexToRgba(vis.glowCol, 0.45);
    ctx.lineWidth = Math.max(0.8, 1.8 * stageScale);
    ctx.setLineDash([Math.max(3, 12 * stageScale), Math.max(2, 8 * stageScale)]);
    ctx.beginPath();
    ctx.arc(0, 0, Math.min(w, h) * 0.34, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();

    for (let i = 0; i < 10; i++) {
      const px = w * 0.5 + Math.sin(nowSec * 1.4 + i * 1.7) * (w * 0.36);
      const py = h - ((nowSec * (32 + (i % 3) * 14) + i * 27) % (h * 0.92));
      ctx.fillStyle = i % 2 === 0 ? hexToRgba('#fbbf24', 0.65) : hexToRgba(vis.glowCol, 0.55);
      ctx.beginPath();
      ctx.ellipse(
        px,
        py,
        Math.max(1.2, 3.0 * stageScale),
        Math.max(0.7, 1.6 * stageScale),
        nowSec * 2 + i,
        0,
        Math.PI * 2,
      );
      ctx.fill();
    }
  }

  // Stage ground ellipse & Full-Body Fit Framing
  const groundY = h * 0.89;
  const scale = stageScale;
  ctx.fillStyle = 'rgba(0, 0, 0, 0.58)';
  ctx.beginPath();
  ctx.ellipse(w * 0.5, groundY, w * 0.24, Math.max(2.5, 9 * scale), 0, 0, Math.PI * 2);
  ctx.fill();

  drawCosmeticAuraStage(ctx, w * 0.5, groundY - 2 * scale, nowSec, scale, vis.auraDef);

  const b = Math.sin(nowSec * 3.1);
  const b2 = Math.cos(nowSec * 2.2);
  let hipY = -63 + b * 1.5;
  let lean = -0.08;
  let fThigh = 0.36;
  let fShin = 0.22;
  let bThigh = -0.34;
  let bShin = 0.2;
  let fSh = 2.45 + b * 0.05;
  let fEl = 0.3;
  let bSh = 0.32;
  let bEl = 1.42;
  let propRot = -0.25;
  let frontHandStyle: 'fist' | 'peace' | 'open' = 'fist';
  let backHandStyle: 'fist' | 'peace' | 'open' = 'fist';

  if (poseMode === 'defeat') {
    hipY = -43 + b * 0.9;
    lean = 0.38;
    fThigh = 1.12;
    fShin = 1.48;
    bThigh = -0.72;
    bShin = 1.38;
    fSh = 0.25;
    fEl = 0.28;
    bSh = -0.24;
    bEl = 0.95;
    propRot = 0.6;
  } else {
    switch (activePose.kinematicKey) {
      case 'crane_kick':
        hipY = -66 + b * 1.8;
        lean = -0.14;
        fThigh = 1.24 + b * 0.03;
        fShin = 1.44;
        bThigh = -0.08;
        bShin = 0.1;
        fSh = 2.34 + b * 0.05;
        fEl = 0.36;
        bSh = -0.52;
        bEl = 1.35;
        propRot = -0.38;
        backHandStyle = 'open';
        break;
      case 'levitate_blessing':
        hipY = -72 + b * 4.2;
        lean = -0.04;
        fThigh = 0.48;
        fShin = 0.95;
        bThigh = -0.48;
        bShin = 0.95;
        fSh = 2.38 + b2 * 0.04;
        fEl = 0.3;
        bSh = 2.28 - b2 * 0.04;
        bEl = 0.36;
        backHandStyle = 'open';
        break;
      case 'lotus_float':
        hipY = -74 + Math.sin(nowSec * 2.4) * 5.0;
        lean = 0;
        fThigh = 1.15;
        fShin = 2.25;
        bThigh = -1.15;
        bShin = -2.25;
        fSh = 0.58;
        fEl = 1.18;
        bSh = -0.58;
        bEl = 1.18;
        propRot = 0.35;
        backHandStyle = 'open';
        break;
      case 'tandav_nataraja':
        hipY = -66 + b * 2.2;
        lean = -0.18;
        fThigh = 1.35;
        fShin = 1.55;
        bThigh = -0.18;
        bShin = 0.28;
        fSh = 2.65 + b * 0.04;
        fEl = 0.12;
        bSh = -1.15;
        bEl = 0.45;
        propRot = -0.4;
        backHandStyle = 'open';
        break;
      case 'double_bicep':
        hipY = -58 + b * 1.4;
        lean = -0.1;
        fThigh = 0.56;
        fShin = 0.44;
        bThigh = -0.56;
        bShin = 0.44;
        fSh = 1.86 + b * 0.04;
        fEl = 1.56;
        bSh = 1.74 + b * 0.04;
        bEl = 1.56;
        break;
      case 'bodybuilder_knee':
        hipY = -49 + b * 1.1;
        lean = 0.12;
        fThigh = 1.16;
        fShin = 1.46;
        bThigh = -0.78;
        bShin = 1.35;
        fSh = 1.72;
        fEl = 1.62;
        bSh = -0.75;
        bEl = 1.25;
        break;
      case 'katta_swagger':
        lean = -0.16;
        fSh = 2.58 + b * 0.05;
        fEl = 0.18;
        bSh = -0.36;
        bEl = 1.52;
        fThigh = 0.44;
        fShin = 0.24;
        bThigh = -0.42;
        bShin = 0.22;
        break;
      case 'throne_aim':
        hipY = -60 + b * 1.2;
        lean = 0.08;
        fThigh = 0.52;
        fShin = 0.42;
        bThigh = -0.46;
        bShin = 0.24;
        fSh = 1.52 + b * 0.03;
        fEl = 0.08;
        bSh = -0.45;
        bEl = 1.65;
        propRot = -0.05;
        break;
      case 'guard_salute':
        lean = -0.06;
        fSh = 2.46 + b * 0.04;
        fEl = 0.22;
        bSh = 0.85;
        bEl = 1.48;
        backHandStyle = 'peace';
        break;
      case 'glasses_push':
        lean = -0.05;
        fThigh = 0.25;
        fShin = 0.16;
        bThigh = -0.25;
        bShin = 0.16;
        fSh = 1.05;
        fEl = 1.98 + b * 0.05;
        bSh = -0.35;
        bEl = 0.65;
        backHandStyle = 'peace';
        break;
      case 'hip_pop_crown':
        hipY = -62 + b * 1.5;
        lean = -0.14;
        fThigh = 0.22;
        fShin = 0.14;
        bThigh = -0.42;
        bShin = 0.36;
        fSh = 2.38 + b * 0.05;
        fEl = 0.32;
        bSh = -0.42;
        bEl = 1.72;
        backHandStyle = 'open';
        break;
      case 'akhara_horse':
        hipY = -54 + b * 1.2;
        lean = 0.04;
        fThigh = 0.78;
        fShin = 0.78;
        bThigh = -0.78;
        bShin = -0.78;
        fSh = 1.75 + b * 0.04;
        fEl = 0.75;
        bSh = -1.25;
        bEl = 1.35;
        break;
      case 'wheelie_lean':
        hipY = -62 + b * 1.8;
        lean = -0.26;
        fThigh = 0.86;
        fShin = 0.92;
        bThigh = -0.36;
        bShin = 0.24;
        fSh = 2.18 + b * 0.06;
        fEl = 0.55;
        bSh = 1.48;
        bEl = 0.72;
        backHandStyle = 'peace';
        break;
      case 'baton_halt':
        lean = -0.04;
        fThigh = 0.32;
        fShin = 0.18;
        bThigh = -0.34;
        bShin = 0.2;
        fSh = 2.52 + b * 0.04;
        fEl = 0.18;
        bSh = 1.48;
        bEl = 0.15;
        backHandStyle = 'open';
        break;
      case 'hero_raise':
      default:
        lean = -0.12;
        fSh = 2.48 + b * 0.06;
        fEl = 0.24;
        bSh = 1.98;
        bEl = 0.52;
        backHandStyle = 'open';
        break;
    }
  }

  const isHeavy = cfg.prop === 'lota' || cfg.prop === 'dumbbell';
  const isSlimFem = cfg.prop === 'belan' || cfg.prop === 'purse';
  const bulk = isHeavy ? 1.15 : isSlimFem ? 0.94 : 1.02;
  const upperArmCol = look.bareArms ? look.skin : look.tunic;
  const upperArmDark = look.bareArms ? look.skinDark : look.tunicDark;
  const bootCol = vis.bootOverride || (cfg.prop === 'chappal' ? '#7c2d12' : '#1e1b2e');
  const auraCol = vis.auraCol;
  const glowCol = vis.glowCol;

  ctx.save();
  ctx.translate(w * 0.5, groundY + hipY * scale);
  ctx.scale(scale, scale);

  // Flowing animated dupatta / gamcha / sash trail behind shoulder
  const nx = Math.sin(lean) * 42;
  const ny = -Math.cos(lean) * 42;
  ctx.save();
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  const clothPts = Array.from({ length: 5 }, (_, ci) => ({
    x: nx - 5 - ci * 8.5 + Math.sin(nowSec * 3.4 - ci * 0.7) * (2.2 + ci * 0.9),
    y: ny + 6 + ci * 10.5 + Math.cos(nowSec * 2.8 - ci * 0.6) * 2.0,
  }));
  ctx.strokeStyle = look.tunicDark;
  ctx.lineWidth = isSlimFem || cfg.prop === 'katta' ? 12 : 8.5;
  ctx.beginPath();
  ctx.moveTo(clothPts[0].x, clothPts[0].y);
  for (let i = 1; i < clothPts.length; i++) ctx.lineTo(clothPts[i].x, clothPts[i].y);
  ctx.stroke();
  ctx.strokeStyle = hexToRgba(look.trim, 0.85);
  ctx.lineWidth = isSlimFem || cfg.prop === 'katta' ? 6 : 3.8;
  ctx.stroke();
  ctx.restore();

  // Back Leg + Realistic Boot/Jutti
  const thighLen = 31;
  const shinLen = 30;
  const bKx = -2 + Math.sin(bThigh) * thighLen;
  const bKy = Math.cos(bThigh) * thighLen;
  const bLegAng = bThigh - bShin;
  const bFx = bKx + Math.sin(bLegAng) * shinLen;
  const bFy = bKy + Math.cos(bLegAng) * shinLen;
  drawStandaloneMuscle(ctx, -2, 0, bKx, bKy, 8.4 * bulk, 8 * bulk, 5.5 * bulk, 1.4, auraCol, glowCol, true, look.pants, look.pantsDark);
  drawStandaloneMuscle(ctx, bKx, bKy, bFx, bFy, 5.4 * bulk, 6.2 * bulk, 3.7 * bulk, -1.2, auraCol, glowCol, true, look.pants, look.pantsDark, look.trim);
  drawRealisticFoot(ctx, bFx, bFy, bLegAng, bulk, auraCol, glowCol, true, bootCol, cfg.prop);

  // Back Arm + Sculpted Hand
  const bShX = nx - Math.cos(lean) * 4;
  const bShY = ny + Math.sin(lean) * 4 + 5;
  const bEx = bShX + Math.sin(bSh) * 22;
  const bEy = bShY + Math.cos(bSh) * 22;
  const bArmAng = bSh + bEl;
  const bHx = bEx + Math.sin(bArmAng) * 20;
  const bHy = bEy + Math.cos(bArmAng) * 20;
  drawStandaloneMuscle(ctx, bShX, bShY, bEx, bEy, 5.9 * bulk, 5.7 * bulk, 4.4 * bulk, 1, auraCol, glowCol, true, upperArmCol, upperArmDark, look.bareArms ? undefined : look.trim);
  drawStandaloneMuscle(ctx, bEx, bEy, bHx, bHy, 4.4 * bulk, 4.8 * bulk, 3.4 * bulk, 0.8, auraCol, glowCol, true, look.skin, look.skinDark);
  drawRealisticHand(ctx, bHx, bHy, bArmAng, bulk * 0.94, auraCol, glowCol, true, look.skin, look.skinDark, backHandStyle);

  // Sculpted Realistic Torso & Neck
  ctx.save();
  ctx.rotate(lean);
  drawRealisticTorso(ctx, look, cfg.prop, auraCol, glowCol, isHeavy, isSlimFem, bulk, poseMode === 'victory', nowSec);
  ctx.restore();

  // Sculpted Realistic Human Head + Expression + Detailed Eyes + Hair/Headgear
  const headX = nx + Math.sin(lean) * 14;
  const headY = ny - Math.cos(lean) * 14;
  ctx.save();
  ctx.translate(headX, headY);
  ctx.rotate(lean * 0.45);
  drawRealisticHead(ctx, look, vis.eyeCol, auraCol, glowCol, poseMode === 'victory', poseMode === 'victory' ? 'victory' : 'defeat');
  ctx.restore();

  // Front Leg + Realistic Boot/Jutti
  const fKx = 2 + Math.sin(fThigh) * thighLen;
  const fKy = Math.cos(fThigh) * thighLen;
  const fLegAng = fThigh - fShin;
  const fFx = fKx + Math.sin(fLegAng) * shinLen;
  const fFy = fKy + Math.cos(fLegAng) * shinLen;
  drawStandaloneMuscle(ctx, 2, 0, fKx, fKy, 8.8 * bulk, 8.4 * bulk, 5.8 * bulk, 1.6, auraCol, glowCol, false, look.pants, look.pantsDark);
  drawStandaloneMuscle(ctx, fKx, fKy, fFx, fFy, 5.7 * bulk, 6.7 * bulk, 3.9 * bulk, -1.4, auraCol, glowCol, false, look.pants, look.pantsDark, look.trim);
  drawRealisticFoot(ctx, fFx, fFy, fLegAng, bulk, auraCol, glowCol, false, bootCol, cfg.prop);

  // Front Arm + Sculpted Hand + Signature Detailed Weapon
  const fShX = nx + Math.cos(lean) * 3;
  const fShY = ny + Math.sin(lean) * 3 + 5;
  const fEx = fShX + Math.sin(fSh) * 22;
  const fEy = fShY + Math.cos(fSh) * 22;
  const fArmAng = fSh + fEl;
  const fHx = fEx + Math.sin(fArmAng) * 20;
  const fHy = fEy + Math.cos(fArmAng) * 20;
  drawStandaloneMuscle(ctx, fShX, fShY, fEx, fEy, 6.5 * bulk, 6.2 * bulk, 4.7 * bulk, 1.3, auraCol, glowCol, false, upperArmCol, upperArmDark, look.bareArms ? undefined : look.trim);
  drawStandaloneMuscle(ctx, fEx, fEy, fHx, fHy, 4.7 * bulk, 5.1 * bulk, 3.7 * bulk, 1, auraCol, glowCol, false, look.skin, look.skinDark);
  drawRealisticHand(ctx, fHx, fHy, fArmAng, bulk, auraCol, glowCol, false, look.skin, look.skinDark, frontHandStyle);

  ctx.save();
  ctx.translate(fHx, fHy);
  ctx.rotate(Math.PI * 0.5 - fArmAng + propRot);
  drawDetailedWeapon(ctx, cfg.prop, glowCol, look.trim);
  ctx.restore();
  ctx.restore();
}

export function drawCosmeticThumbnail(
  canvas: HTMLCanvasElement,
  fighterId: string,
  skinId: string | null | undefined,
  auraId: string | null | undefined,
  isAuraCard: boolean,
  nowSec = 0.85,
): void {
  const cssSize = 52;
  const dpr = typeof window !== 'undefined' ? Math.min(3, Math.max(2, window.devicePixelRatio || 2)) : 2;
  const targetPx = Math.round(cssSize * dpr);
  if (canvas.width !== targetPx || canvas.height !== targetPx) {
    canvas.width = targetPx;
    canvas.height = targetPx;
  }

  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const cfg = getCfgById(fighterId);
  const look = getCharacterLook(cfg.id, skinId);
  const vis = getFighterVisualPalette(cfg, skinId, auraId);

  ctx.save();
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, cssSize, cssSize);

  // Dark rich thumbnail backdrop + glowing radial spotlight
  ctx.fillStyle = '#090714';
  ctx.fillRect(0, 0, cssSize, cssSize);

  const bg = ctx.createRadialGradient(cssSize * 0.5, cssSize * 0.44, 3, cssSize * 0.5, cssSize * 0.48, cssSize * 0.62);
  if (isAuraCard) {
    bg.addColorStop(0, hexToRgba(vis.auraDef.sparkColor, 0.42));
    bg.addColorStop(0.55, hexToRgba(vis.auraDef.ringColor, 0.24));
    bg.addColorStop(1, 'rgba(9, 7, 20, 0)');
  } else {
    bg.addColorStop(0, hexToRgba(vis.glowCol, 0.36));
    bg.addColorStop(0.58, hexToRgba(vis.auraCol, 0.2));
    bg.addColorStop(1, 'rgba(9, 7, 20, 0)');
  }
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, cssSize, cssSize);

  const groundY = cssSize * 0.89;
  const scale = cssSize / 154; // ~0.338 — frames full fighter crisply inside 52x52

  // Subtle floor shadow
  ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
  ctx.beginPath();
  ctx.ellipse(cssSize * 0.5, groundY, cssSize * 0.26, 2.8, 0, 0, Math.PI * 2);
  ctx.fill();

  if (isAuraCard) {
    // Boost aura visibility slightly for miniature card recognition
    drawCosmeticAuraStage(ctx, cssSize * 0.5, groundY - 1, nowSec, scale * 1.18, vis.auraDef);
    if (vis.auraDef.style === 'none') {
      ctx.strokeStyle = hexToRgba(vis.auraDef.ringColor, 0.65);
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.ellipse(cssSize * 0.5, groundY, cssSize * 0.32, 4.2, 0, 0, Math.PI * 2);
      ctx.stroke();
    }
  } else {
    // Subtle outfit halo ring behind skin fighter
    ctx.save();
    ctx.translate(cssSize * 0.5, cssSize * 0.46);
    ctx.strokeStyle = hexToRgba(look.trim, 0.38);
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(0, 0, cssSize * 0.36, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }

  // Confident miniature showcase pose
  const b = Math.sin(nowSec * 2.8);
  const hipY = -62 + b * 1.2;
  const lean = -0.1;
  const fThigh = 0.36;
  const fShin = 0.22;
  const bThigh = -0.34;
  const bShin = 0.2;
  const fSh = 2.38 + b * 0.04;
  const fEl = 0.26;
  const bSh = 0.36;
  const bEl = 1.38;
  const propRot = -0.25;

  const isHeavy = cfg.prop === 'lota' || cfg.prop === 'dumbbell';
  const isSlimFem = cfg.prop === 'belan' || cfg.prop === 'purse';
  const bulk = isHeavy ? 1.15 : isSlimFem ? 0.94 : 1.02;
  const upperArmCol = look.bareArms ? look.skin : look.tunic;
  const upperArmDark = look.bareArms ? look.skinDark : look.tunicDark;
  const bootCol = vis.bootOverride || (cfg.prop === 'chappal' ? '#7c2d12' : '#1e1b2e');
  const auraCol = vis.auraCol;
  const glowCol = vis.glowCol;

  ctx.save();
  ctx.translate(cssSize * 0.5, groundY + hipY * scale);
  ctx.scale(scale, scale);

  const nx = Math.sin(lean) * 42;
  const ny = -Math.cos(lean) * 42;
  const thighLen = 31;
  const shinLen = 30;

  // Back leg
  const bKx = -2 + Math.sin(bThigh) * thighLen;
  const bKy = Math.cos(bThigh) * thighLen;
  const bLegAng = bThigh - bShin;
  const bFx = bKx + Math.sin(bLegAng) * shinLen;
  const bFy = bKy + Math.cos(bLegAng) * shinLen;
  drawStandaloneMuscle(ctx, -2, 0, bKx, bKy, 8.4 * bulk, 8 * bulk, 5.5 * bulk, 1.4, auraCol, glowCol, true, look.pants, look.pantsDark);
  drawStandaloneMuscle(ctx, bKx, bKy, bFx, bFy, 5.4 * bulk, 6.2 * bulk, 3.7 * bulk, -1.2, auraCol, glowCol, true, look.pants, look.pantsDark, look.trim);
  drawRealisticFoot(ctx, bFx, bFy, bLegAng, bulk, auraCol, glowCol, true, bootCol, cfg.prop);

  // Back arm
  const bShX = nx - Math.cos(lean) * 4;
  const bShY = ny + Math.sin(lean) * 4 + 5;
  const bEx = bShX + Math.sin(bSh) * 22;
  const bEy = bShY + Math.cos(bSh) * 22;
  const bArmAng = bSh + bEl;
  const bHx = bEx + Math.sin(bArmAng) * 20;
  const bHy = bEy + Math.cos(bArmAng) * 20;
  drawStandaloneMuscle(ctx, bShX, bShY, bEx, bEy, 5.9 * bulk, 5.7 * bulk, 4.4 * bulk, 1, auraCol, glowCol, true, upperArmCol, upperArmDark, look.bareArms ? undefined : look.trim);
  drawStandaloneMuscle(ctx, bEx, bEy, bHx, bHy, 4.4 * bulk, 4.8 * bulk, 3.4 * bulk, 0.8, auraCol, glowCol, true, look.skin, look.skinDark);
  drawRealisticHand(ctx, bHx, bHy, bArmAng, bulk * 0.94, auraCol, glowCol, true, look.skin, look.skinDark, 'open');

  // Torso
  ctx.save();
  ctx.rotate(lean);
  drawRealisticTorso(ctx, look, cfg.prop, auraCol, glowCol, isHeavy, isSlimFem, bulk, true, nowSec);
  ctx.restore();

  // Head
  const headX = nx + Math.sin(lean) * 14;
  const headY = ny - Math.cos(lean) * 14;
  ctx.save();
  ctx.translate(headX, headY);
  ctx.rotate(lean * 0.45);
  drawRealisticHead(ctx, look, vis.eyeCol, auraCol, glowCol, true, 'victory');
  ctx.restore();

  // Front leg
  const fKx = 2 + Math.sin(fThigh) * thighLen;
  const fKy = Math.cos(fThigh) * thighLen;
  const fLegAng = fThigh - fShin;
  const fFx = fKx + Math.sin(fLegAng) * shinLen;
  const fFy = fKy + Math.cos(fLegAng) * shinLen;
  drawStandaloneMuscle(ctx, 2, 0, fKx, fKy, 8.8 * bulk, 8.4 * bulk, 5.8 * bulk, 1.6, auraCol, glowCol, false, look.pants, look.pantsDark);
  drawStandaloneMuscle(ctx, fKx, fKy, fFx, fFy, 5.7 * bulk, 6.7 * bulk, 3.9 * bulk, -1.4, auraCol, glowCol, false, look.pants, look.pantsDark, look.trim);
  drawRealisticFoot(ctx, fFx, fFy, fLegAng, bulk, auraCol, glowCol, false, bootCol, cfg.prop);

  // Front arm & weapon
  const fShX = nx + Math.cos(lean) * 3;
  const fShY = ny + Math.sin(lean) * 3 + 5;
  const fEx = fShX + Math.sin(fSh) * 22;
  const fEy = fShY + Math.cos(fSh) * 22;
  const fArmAng = fSh + fEl;
  const fHx = fEx + Math.sin(fArmAng) * 20;
  const fHy = fEy + Math.cos(fArmAng) * 20;
  drawStandaloneMuscle(ctx, fShX, fShY, fEx, fEy, 6.5 * bulk, 6.2 * bulk, 4.7 * bulk, 1.3, auraCol, glowCol, false, upperArmCol, upperArmDark, look.bareArms ? undefined : look.trim);
  drawStandaloneMuscle(ctx, fEx, fEy, fHx, fHy, 4.7 * bulk, 5.1 * bulk, 3.7 * bulk, 1, auraCol, glowCol, false, look.skin, look.skinDark);
  drawRealisticHand(ctx, fHx, fHy, fArmAng, bulk, auraCol, glowCol, false, look.skin, look.skinDark, 'fist');

  ctx.save();
  ctx.translate(fHx, fHy);
  ctx.rotate(Math.PI * 0.5 - fArmAng + propRot);
  drawDetailedWeapon(ctx, cfg.prop, glowCol, look.trim);
  ctx.restore();

  ctx.restore();
  ctx.restore();
}
