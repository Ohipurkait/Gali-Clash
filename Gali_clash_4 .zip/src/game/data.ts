import { ArenaId, ArenaTheme, CombatButtonKind, FighterConfig, MoveDef, StickerEmoteDef } from './types';

export const STICKER_EMOTES: StickerEmoteDef[] = [
  { id: 'namaste', emoji: '🙏', label: 'NAMASTE', accent: '#fde047', keyHint: '1' },
  { id: 'chappal', emoji: '🩴', label: 'CHAPPAL!', accent: '#f472b6', keyHint: '2' },
  { id: 'chai', emoji: '☕', label: 'CHAI BREAK', accent: '#fb923c', keyHint: '3' },
  { id: 'fire', emoji: '🔥', label: 'AAG LAGA DI!', accent: '#f43f5e', keyHint: '4' },
  { id: 'op', emoji: '👑', label: 'SHABAASH!', accent: '#38bdf8', keyHint: '5' },
  { id: 'cry', emoji: '😭', label: 'BACHAO!', accent: '#a78bfa', keyHint: '6' },
];

export const COOLDOWNS = {
  SP1: 3.6,
  SP2: 4.8,
  DASH: 0.9,
} as const;

export const DEFAULT_KEY_BINDS: Record<CombatButtonKind, string> = {
  basic: 'j',
  sp1: 'u',
  sp2: 'i',
  dash: ' ',
  shield: 'k',
  rage: 'o',
};

export const WORLD = {
  width: 1280,
  height: 720,
  groundY: 520,
  gravity: 1850,
  arenaHalfWidth: 560,
  charScale: 1.0,
};

export const ARENAS: Record<ArenaId, ArenaTheme> = {
  chandni: {
    id: 'chandni',
    name: 'Chandni Chowk',
    skyTop: '#1a1035',
    skyMid: '#2d1b4e',
    skyBot: '#0f0a1f',
    floorTop: '#1c1530',
    floorBot: '#0a0814',
    rim: '#f43f5e',
    moonCol: '#fde68a',
  },
  howrah: {
    id: 'howrah',
    name: 'Howrah Bridge',
    skyTop: '#0c1929',
    skyMid: '#132f4c',
    skyBot: '#081018',
    floorTop: '#0e1c2e',
    floorBot: '#050a12',
    rim: '#38bdf8',
    moonCol: '#e0f2fe',
  },
  banaras: {
    id: 'banaras',
    name: 'Banaras Ghat',
    skyTop: '#2a0f1a',
    skyMid: '#3d1528',
    skyBot: '#140810',
    floorTop: '#1f1218',
    floorBot: '#0a0508',
    rim: '#facc15',
    moonCol: '#fde047',
  },
};

export const MOVES: Record<string, MoveDef> = {
  // Neutral 3-Hit Martial Arts Combo Chain (Step 1 Fast Jab -> Step 2 Spinning Backfist/Slash -> Step 3 Akhara Roundhouse Kick)
  BASIC_1:    { key: 'BASIC_1',    startup: 5,  active: 3,  recovery: 8,  dmg: 40, knockX: 115, knockY: -40,  range: 96,  special: false },
  BASIC_2:    { key: 'BASIC_2',    startup: 6,  active: 3,  recovery: 10, dmg: 46, knockX: 150, knockY: -60,  range: 110, special: false },
  BASIC_3:    { key: 'BASIC_3',    startup: 8,  active: 4,  recovery: 16, dmg: 58, knockX: 265, knockY: -135, range: 124, special: false },

  // Directional Martial Arts Normals via Joystick/WASD + Basic
  BASIC_FWD:  { key: 'BASIC_FWD',  startup: 7,  active: 4,  recovery: 16, dmg: 54, knockX: 220, knockY: -80,  range: 120, special: false, dashSpeed: 310 },
  BASIC_LOW:  { key: 'BASIC_LOW',  startup: 6,  active: 4,  recovery: 12, dmg: 44, knockX: 190, knockY: -45,  range: 114, special: false, low: true },
  BASIC_UP:   { key: 'BASIC_UP',   startup: 6,  active: 4,  recovery: 13, dmg: 52, knockX: 145, knockY: -265, range: 108, special: false, antiAir: true },
  BASIC_BACK: { key: 'BASIC_BACK', startup: 6,  active: 3,  recovery: 11, dmg: 46, knockX: 205, knockY: -90,  range: 102, special: false },
  BASIC_AIR:  { key: 'BASIC_AIR',  startup: 5,  active: 5,  recovery: 11, dmg: 50, knockX: 225, knockY: -95,  range: 118, special: false },

  // Skill 1 = Long Range Projectile | Skill 2 = Close Range Strike Burst | Ultimate = High-Impact Chakra Finisher
  SP1:        { key: 'SP1',        startup: 9,  active: 4,  recovery: 20, dmg: 88,  knockX: 270, knockY: -140, range: 440, special: 'SP1', projectile: true },
  SP2:        { key: 'SP2',        startup: 10, active: 6,  recovery: 20, dmg: 110, knockX: 335, knockY: -175, range: 165, special: 'SP2', dashSpeed: 300 },
  RAGE:       { key: 'RAGE',       startup: 13, active: 16, recovery: 26, dmg: 75,  knockX: 390, knockY: -290, range: 265, special: 'RAGE', waveDmg: 75 },
};

export const CHAR_MOVES: Record<string, Partial<Record<'SP1' | 'SP2' | 'RAGE', Partial<MoveDef>>>> = {
  // Strictly balanced competitive kits: Skill 1 = Long Range (projectile), Skill 2 = Close Range burst, Ultimate = exact 225 total
  munna_bhaiya: {
    SP1: { dmg: 88, range: 450, projectile: true, knockX: 285, knockY: -140, startup: 8, recovery: 19 },
    SP2: { dmg: 110, range: 166, projectile: false, dashSpeed: 315, knockX: 345, knockY: -180, startup: 9, recovery: 19 },
    RAGE: { waveDmg: 75, range: 265, knockX: 390, knockY: -290 },
  },
  chappal_chacha: {
    SP1: { dmg: 88, range: 430, projectile: true, knockX: 265, knockY: -140, startup: 8, recovery: 19 },
    SP2: { dmg: 108, range: 170, projectile: false, dashSpeed: 335, knockX: 340, knockY: -170, startup: 9, recovery: 19 },
    RAGE: { waveDmg: 75, range: 265, knockX: 390, knockY: -290 },
  },
  lota_lal: {
    SP1: { dmg: 80, range: 420, projectile: true, knockX: 245, knockY: -125, startup: 9, recovery: 20 },
    SP2: { dmg: 102, range: 162, projectile: false, dashSpeed: 295, knockX: 325, knockY: -165, startup: 10, recovery: 20 },
    RAGE: { waveDmg: 75, range: 265, knockX: 390, knockY: -290 },
  },
  belan_bhabhi: {
    SP1: { dmg: 94, range: 420, projectile: true, knockX: 315, knockY: -165, startup: 10, recovery: 20 },
    SP2: { dmg: 116, range: 164, projectile: false, dashSpeed: 275, knockX: 375, knockY: -200, startup: 11, recovery: 21 },
    RAGE: { waveDmg: 75, range: 265, knockX: 390, knockY: -290 },
  },
  babaji_boom: {
    SP1: { dmg: 92, range: 435, projectile: true, knockX: 280, knockY: -180, startup: 10, recovery: 20 },
    SP2: { dmg: 112, range: 172, projectile: false, dashSpeed: 285, knockX: 330, knockY: -210, startup: 10, recovery: 20 },
    RAGE: { waveDmg: 75, range: 265, knockX: 390, knockY: -290 },
  },
  raju_rickshaw: {
    SP1: { dmg: 86, range: 425, projectile: true, knockX: 255, knockY: -125, startup: 8, recovery: 19 },
    SP2: { dmg: 108, range: 172, projectile: false, dashSpeed: 340, knockX: 365, knockY: -155, startup: 9, recovery: 19 },
    RAGE: { waveDmg: 75, range: 265, knockX: 390, knockY: -290 },
  },
  sharmaji_beta: {
    SP1: { dmg: 90, range: 465, projectile: true, knockX: 250, knockY: -115, startup: 9, recovery: 19 },
    SP2: { dmg: 112, range: 168, projectile: false, dashSpeed: 290, knockX: 320, knockY: -195, startup: 10, recovery: 19 },
    RAGE: { waveDmg: 75, range: 265, knockX: 390, knockY: -290 },
  },
  pados_aunty: {
    SP1: { dmg: 84, range: 435, projectile: true, knockX: 245, knockY: -130, startup: 9, recovery: 19 },
    SP2: { dmg: 104, range: 164, projectile: false, dashSpeed: 290, knockX: 320, knockY: -175, startup: 10, recovery: 20 },
    RAGE: { waveDmg: 75, range: 265, knockX: 390, knockY: -290 },
  },
  traffic_mama: {
    SP1: { dmg: 84, range: 445, projectile: true, knockX: 235, knockY: -115, startup: 9, recovery: 19 },
    SP2: { dmg: 104, range: 164, projectile: false, dashSpeed: 290, knockX: 310, knockY: -180, startup: 10, recovery: 20 },
    RAGE: { waveDmg: 75, range: 265, knockX: 390, knockY: -290 },
  },
  gym_bunty: {
    SP1: { dmg: 94, range: 410, projectile: true, knockX: 325, knockY: -170, startup: 10, recovery: 21 },
    SP2: { dmg: 116, range: 165, projectile: false, dashSpeed: 310, knockX: 375, knockY: -200, startup: 11, recovery: 20 },
    RAGE: { waveDmg: 75, range: 265, knockX: 390, knockY: -290 },
  },
};

export const FIGHTERS: FighterConfig[] = [
  {
    id: 'munna_bhaiya', name: 'MUNNA BHAIYA', title: 'King of Purvanchal',
    prop: 'katta', eye: '#fde047', aura: '#f43f5e', glow: '#fde047', speed: 310,
    sp1Name: 'Katta Dhamaka', sp2Name: 'Purvanchal Rush', rageName: 'Gaddi Ki Power',
    sp1Sfx: 'katta', sp2Sfx: 'heavy_hit',
    quote: 'Hum hain Purvanchal ke raja—gaddi hamari hai!',
  },
  {
    id: 'chappal_chacha', name: 'CHAPPAL CHACHA', title: 'Slipper Samurai',
    prop: 'chappal', eye: '#22d3ee', aura: '#ec4899', glow: '#22d3ee', speed: 310,
    sp1Name: 'Chappal Chakram', sp2Name: 'Slipper Tornado', rageName: 'Chappal Storm',
    sp1Sfx: 'chappal', sp2Sfx: 'whoosh',
    quote: 'Chappal se hi nikalta hai asli dard!',
  },
  {
    id: 'lota_lal', name: 'LOTA LAL', title: 'The Stink Lord',
    prop: 'lota', eye: '#84cc16', aura: '#84cc16', glow: '#facc15', speed: 310,
    sp1Name: 'Pet Kharab Bomb', sp2Name: 'Fart Jet', rageName: 'Gas Chamber',
    sp1Sfx: 'fart', sp2Sfx: 'fart',
    quote: 'Jo smell karega, wahi haar karega!',
  },
  {
    id: 'belan_bhabhi', name: 'BELAN BHABHI', title: 'Kitchen Queen',
    prop: 'belan', eye: '#f97316', aura: '#f97316', glow: '#fde047', speed: 310,
    sp1Name: 'Belan Bazooka', sp2Name: 'Tawa Slam', rageName: 'Kitchen Fury',
    sp1Sfx: 'tawa', sp2Sfx: 'heavy_hit',
    quote: 'Ghar ka belan ab battlefield pe!',
  },
  {
    id: 'babaji_boom', name: 'BABAJI BOOM', title: 'Divine Destroyer',
    prop: 'kamandalu', eye: '#c084fc', aura: '#a855f7', glow: '#fde047', speed: 310,
    sp1Name: 'Mantra Missile', sp2Name: 'Om Wave', rageName: 'Brahmastra',
    sp1Sfx: 'mantra', sp2Sfx: 'gong',
    quote: 'Om namah... BOOM!',
  },
  {
    id: 'raju_rickshaw', name: 'RAJU RICKSHAW', title: 'Auto King',
    prop: 'horn', eye: '#eab308', aura: '#eab308', glow: '#4ade80', speed: 310,
    sp1Name: 'Horn Blast', sp2Name: 'Rickshaw Ram', rageName: 'Meter Down',
    sp1Sfx: 'horn', sp2Sfx: 'whoosh',
    quote: 'Meter on hai bhai, dhamaka free!',
  },
  {
    id: 'sharmaji_beta', name: 'SHARMAJI BETA', title: '99.9% Marks',
    prop: 'glasses', eye: '#38bdf8', aura: '#38bdf8', glow: '#e0f2fe', speed: 310,
    sp1Name: '99.9% Laser', sp2Name: 'E=mc² Beam', rageName: 'Board Result',
    sp1Sfx: 'laser', sp2Sfx: 'laser',
    quote: 'Beta, marks se power aati hai!',
  },
  {
    id: 'pados_aunty', name: 'PADOS AUNTY', title: 'Gossip Sniper',
    prop: 'purse', eye: '#fb7185', aura: '#f43f5e', glow: '#fbcfe8', speed: 310,
    sp1Name: 'Taana Shot', sp2Name: 'Rumor Wave', rageName: 'Society Scandal',
    sp1Sfx: 'whoosh', sp2Sfx: 'heavy_hit',
    quote: 'Main toh bas dekh rahi thi... lekin ab maarungi!',
  },
  {
    id: 'traffic_mama', name: 'TRAFFIC MAMA', title: 'Signal Commander',
    prop: 'whistle', eye: '#fef08a', aura: '#facc15', glow: '#38bdf8', speed: 310,
    sp1Name: 'Whistle Laser', sp2Name: 'Red Light Freeze', rageName: 'Challan Storm',
    sp1Sfx: 'horn', sp2Sfx: 'block',
    quote: 'Ruk jao! Signal red hai!',
  },
  {
    id: 'gym_bunty', name: 'GYM BUNTY', title: 'Protein Punch',
    prop: 'dumbbell', eye: '#fb923c', aura: '#fb923c', glow: '#fed7aa', speed: 310,
    sp1Name: 'Dumbbell Dash', sp2Name: 'Protein Pump', rageName: 'Bro Mode',
    sp1Sfx: 'heavy_hit', sp2Sfx: 'whoosh',
    quote: 'Bro, protein se power aati hai!',
  },
];

export function getCfgById(id: string): FighterConfig {
  return FIGHTERS.find((f) => f.id === id) || FIGHTERS[0];
}
