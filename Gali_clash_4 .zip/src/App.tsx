import React, { useCallback, useEffect, useRef, useState } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import {
  Backpack,
  Check,
  ChevronLeft,
  ChevronRight,
  Code2,
  Coins,
  Copy,
  Crown,
  Edit3,
  History,
  Keyboard,
  LogIn,
  LogOut,
  Mail,
  Maximize2,
  MessageSquare,
  Minimize2,
  RefreshCw,
  RotateCcw,
  ScrollText,
  Send,
  Settings,
  Shield,
  ShoppingBag,
  Shuffle,
  Sliders,
  Sparkles,
  Swords,
  Trophy,
  UserCheck,
  Users,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { ArmoryModal } from './components/ArmoryModal';
import { CombatHud } from './components/CombatHud';
import { DailyQuestsModal } from './components/DailyQuestsModal';
import { DevCmsModal } from './components/DevCmsModal';
import { FriendsPanel } from './components/FriendsPanel';
import { MailboxModal } from './components/MailboxModal';
import { MatchHistoryModal } from './components/MatchHistoryModal';
import { SocialHubModal, SocialHubTab } from './components/SocialHubModal';
import { VictoryPoseGalleryModal } from './components/VictoryPoseGalleryModal';
import { auth } from './firebase';
import { sound, UiSfxKind } from './game/audio';
import {
  CosmeticCurrency,
  CosmeticItem,
  DEFAULT_AURA_ID,
  getSkinById,
  isDevUnreleasedCosmeticId,
  setDevUnreleasedCosmetics,
} from './game/cosmetics';
import {
  ACTION_LABELS,
  cloneDefaultConfig,
  formatKeyLabel,
  loadControlConfig,
  saveControlConfig,
} from './game/controlsStorage';
import { ARENAS, FIGHTERS, getCfgById, STICKER_EMOTES } from './game/data';
import { drawCharFace, drawFighterPosePreview, GameEngine } from './game/engine';
import {
  getSelectedVictoryPoseId,
  getVictoryPoseById,
  getVictoryPosesForFighter,
  isVictoryPoseUnlocked,
  saveSelectedVictoryPoseId,
} from './game/victoryPoses';
import {
  claimDailyQuestReward,
  DailyQuestItem,
  loadDailyQuests,
  recordDailyQuestCombatMetric,
  recordDailyQuestMatchComplete,
} from './services/dailyQuests';
import {
  createDefaultLiveCmsConfig,
  DevUnreleasedSessionState,
  equipDevUnreleasedInSession,
  fetchLiveCmsConfig,
  LiveCmsConfig,
  loadDevUnreleasedCosmetics,
  loadDevUnreleasedSession,
  loadLocalLiveCmsConfig,
  publishLiveCmsConfig,
  saveDevUnreleasedCosmetics,
  saveDevUnreleasedSession,
  saveLocalLiveCmsConfig,
} from './services/devCms';
import {
  acceptFriendRequest,
  declineFriendRequest,
  deleteDirectMatchInvite,
  DirectMatchInvite,
  enrichFriendsPresence,
  FriendEntry,
  FriendRequestItem,
  removeFriend,
  respondToDirectMatchInvite,
  sendDirectMatchInvite,
  sendFriendRequest,
  subscribeFriendsList,
  subscribeIncomingFriendRequests,
  subscribeIncomingInvites,
  subscribeSentInviteStatus,
  syncPlayerDirectoryPresence,
} from './services/friends';
import {
  claimPlayerGiftMail,
  DevGiftMail,
  fetchPlayerMailbox,
  getOrCreatePlayerId,
  MailGiftType,
  sendDeveloperGiftMail,
} from './services/mailbox';
import {
  appendMatchHistoryEntry,
  clearMatchHistory,
  loadMatchHistory,
  MatchHistoryEntry,
} from './services/matchHistory';
import {
  computeMatchFutiKodiEarned,
  deactivateDeveloperMode,
  ensurePlayerAccountDocuments,
  equipCosmeticItem,
  equipCosmeticLocal,
  getEquippedSkinIdForFighter,
  getSavedLocalDevMode,
  loadLocalLoadout,
  logoutAccount,
  PlayerProfile,
  purchaseBundleCloud,
  purchaseBundleLocal,
  readCachedPlayerProfile,
  readGuestWallet,
  recordGuestMatchResult,
  recordPlayerMatchResult,
  saveLocalLoadout,
  setSavedLocalDevMode,
  signInWithGmail,
  subscribePlayerProfile,
  unequipAuraCosmetic,
  unequipAuraLocal,
  unequipSkinForFighter,
  unequipSkinForFighterLocal,
  unlockCosmeticItem,
  unlockCosmeticLocal,
  unlockDeveloperMode,
  unlockVictoryPose,
  unlockVictoryPoseLocal,
  updateAkharaName,
} from './services/playerAccount';
import {
  ArenaId,
  CombatButtonKind,
  ControlLayoutConfig,
  Difficulty,
  FighterConfig,
  GameMode,
  HudSnapshot,
  ScreenId,
  StickerEmoteId,
  VictoryInfo,
} from './game/types';

const INITIAL_HUD: HudSnapshot = {
  p1Name: 'MUNNA BHAIYA',
  p2Name: 'CHAPPAL CHACHA · BOT',
  p1Hp: 1000,
  p1MaxHp: 1000,
  p2Hp: 1000,
  p2MaxHp: 1000,
  p1Rage: 0,
  p2Rage: 0,
  p1Awakened: false,
  p2Awakened: false,
  p1Wins: 0,
  p2Wins: 0,
  round: 1,
  timer: 60,
  p1Sp1Cd: 0,
  p1Sp2Cd: 0,
  p1DashCd: 0,
  p2Sp1Cd: 0,
  p2Sp2Cd: 0,
  p2DashCd: 0,
  localSlot: 1,
  practice: false,
  comboCount: 0,
  comboDamage: 0,
  maxCombo: 0,
  mpPingMs: null,
};

function FighterFaceThumb({ cfg, skinId }: { cfg: FighterConfig; skinId?: string }) {
  const ref = useRef<HTMLCanvasElement | null>(null);
  useEffect(() => {
    if (ref.current) drawCharFace(ref.current, cfg, skinId);
  }, [cfg, skinId]);
  return <canvas ref={ref} className="w-10 h-10 sm:w-12 sm:h-12 rounded-full shrink-0" />;
}

function ResultPoseCanvas({
  fighterId,
  poseMode,
  skinId,
  auraId,
  poseId,
  width = 220,
  height = 165,
  className = '',
}: {
  fighterId: string;
  poseMode: 'victory' | 'defeat';
  skinId?: string;
  auraId?: string;
  poseId?: string;
  width?: number;
  height?: number;
  className?: string;
}) {
  const ref = useRef<HTMLCanvasElement | null>(null);
  useEffect(() => {
    let raf = 0;
    let last = 0;
    const render = (now: number) => {
      raf = window.requestAnimationFrame(render);
      if (now - last < 34) return;
      last = now;
      if (ref.current) {
        drawFighterPosePreview(ref.current, fighterId, poseMode, now * 0.001, skinId, auraId, poseId);
      }
    };
    raf = window.requestAnimationFrame(render);
    return () => window.cancelAnimationFrame(raf);
  }, [fighterId, poseMode, skinId, auraId, poseId]);

  return <canvas ref={ref} width={width} height={height} className={className} />;
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);

  const [screen, setScreen] = useState<ScreenId>('menu');
  const [mode, setMode] = useState<GameMode>('bot');
  const [practice, setPractice] = useState(false);
  const [difficulty, setDifficulty] = useState<Difficulty>('normal');
  const [arenaId, setArenaId] = useState<ArenaId>(() => loadLocalLoadout().arenaId);
  const [p1Id, setP1Id] = useState<string>(() => loadLocalLoadout().fighterId);
  const [p2Id, setP2Id] = useState<string>('chappal_chacha');
  const [selectSlot, setSelectSlot] = useState<1 | 2>(1);

  const [hud, setHud] = useState<HudSnapshot>(INITIAL_HUD);
  const [announcement, setAnnouncement] = useState<string | null>(null);
  const [victory, setVictory] = useState<VictoryInfo | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const toastTimerRef = useRef<number | null>(null);

  // Settings & Audio states
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [customizing, setCustomizing] = useState(false);
  const [keybindsOpen, setKeybindsOpen] = useState(false);
  const [listeningAction, setListeningAction] = useState<CombatButtonKind | null>(null);
  const [controlConfig, setControlConfig] = useState<ControlLayoutConfig>(() => loadControlConfig());
  const [bgmOn, setBgmOn] = useState(sound.bgmOn);
  const [sfxOn, setSfxOn] = useState(sound.sfxOn);
  const [bgmVol, setBgmVol] = useState(sound.bgmVolume);
  const [sfxVol, setSfxVol] = useState(sound.sfxVolume);
  const [voiceOn, setVoiceOn] = useState(sound.voiceOn);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isPortrait, setIsPortrait] = useState(() => {
    if (typeof window === 'undefined') return false;
    const vw = window.visualViewport?.width || window.innerWidth;
    const vh = window.visualViewport?.height || window.innerHeight;
    return vh > vw;
  });

  const [authReady, setAuthReady] = useState(false);
  const [authUser, setAuthUser] = useState<User | null>(null);
  const [playerProfile, setPlayerProfile] = useState<PlayerProfile | null>(null);
  const [accountModalOpen, setAccountModalOpen] = useState(false);
  const [poseGalleryOpen, setPoseGalleryOpen] = useState(false);
  const [poseGalleryFighterId, setPoseGalleryFighterId] = useState<string>('munna_bhaiya');
  const [winnerPoseOverride, setWinnerPoseOverride] = useState<string | null>(null);
  const [armoryOpen, setArmoryOpen] = useState(false);
  const [armoryInitialTab, setArmoryInitialTab] = useState<'store' | 'inventory'>('store');
  const [armoryInitialStoreFilter, setArmoryInitialStoreFilter] = useState<
    'fighter' | 'all_skins' | 'aura' | 'bundles' | 'gota_packs'
  >('fighter');
  const openArmory = (
    tab: 'store' | 'inventory',
    storeFilter: 'fighter' | 'all_skins' | 'aura' | 'bundles' | 'gota_packs' = 'fighter',
  ) => {
    setArmoryInitialTab(tab);
    setArmoryInitialStoreFilter(storeFilter);
    setArmoryOpen(true);
  };
  const [lastFutiKodiEarned, setLastFutiKodiEarned] = useState<number>(0);
  const [socialHubOpen, setSocialHubOpen] = useState(false);
  const [socialHubTab, setSocialHubTab] = useState<SocialHubTab>('leaderboard');
  const [questsOpen, setQuestsOpen] = useState(false);
  const [dailyQuests, setDailyQuests] = useState<DailyQuestItem[]>(() => loadDailyQuests());
  const [authBusy, setAuthBusy] = useState(false);
  const [editingName, setEditingName] = useState(false);
  const [nameDraft, setNameDraft] = useState('');
  const [localDevMode, setLocalDevMode] = useState<boolean>(() => getSavedLocalDevMode());
  const [devCodeInput, setDevCodeInput] = useState('');
  const [devUnlockBusy, setDevUnlockBusy] = useState(false);
  const [devUnlockError, setDevUnlockError] = useState<string | null>(null);
  const isDeveloperActive = authUser ? Boolean(playerProfile?.isDeveloper) : localDevMode;

  const [cmsOpen, setCmsOpen] = useState(false);
  const [liveCmsConfig, setLiveCmsConfig] = useState<LiveCmsConfig>(() => loadLocalLiveCmsConfig());
  const [devUnreleasedItems, setDevUnreleasedItems] = useState<CosmeticItem[]>([]);
  const [devUnreleasedSession, setDevUnreleasedSession] = useState<DevUnreleasedSessionState>({
    unlockedIds: [],
    equippedSkinIds: [],
    equippedAuraId: null,
  });

  const [playerId] = useState<string>(() => getOrCreatePlayerId());
  const [guestWallet, setGuestWallet] = useState<PlayerProfile>(() =>
    readGuestWallet(getSavedLocalDevMode()),
  );
  const baseProfile = authUser ? playerProfile : guestWallet;
  const effectiveProfile: PlayerProfile | null = (() => {
    if (!baseProfile) return null;
    if (!isDeveloperActive) return baseProfile;
    let nextSkins = [...baseProfile.equippedSkinIds];
    for (const devSid of devUnreleasedSession.equippedSkinIds) {
      const devSkin = getSkinById(devSid);
      if (!devSkin) continue;
      nextSkins = nextSkins.filter((sid) => getSkinById(sid)?.fighterId !== devSkin.fighterId);
      nextSkins.push(devSkin.id);
    }
    const nextAura = devUnreleasedSession.equippedAuraId || baseProfile.equippedAuraId;
    return {
      ...baseProfile,
      equippedSkinIds: nextSkins,
      equippedAuraId: nextAura,
    };
  })();

  const [mailboxOpen, setMailboxOpen] = useState(false);
  const [mailboxInitialTab, setMailboxInitialTab] = useState<'inbox' | 'send'>('inbox');
  const [mails, setMails] = useState<DevGiftMail[]>([]);
  const [mailsLoading, setMailsLoading] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [matchHistory, setMatchHistory] = useState<MatchHistoryEntry[]>(() => loadMatchHistory());

  // Friends & Direct 1v1 Invite states
  const [friends, setFriends] = useState<FriendEntry[]>([]);
  const [incomingFriendRequests, setIncomingFriendRequests] = useState<FriendRequestItem[]>([]);
  const [incomingInvites, setIncomingInvites] = useState<DirectMatchInvite[]>([]);
  const [outgoingInvite, setOutgoingInvite] = useState<{
    inviteId: string;
    friendName: string;
    friendPlayerId: string;
    roomCode: string;
  } | null>(null);

  // Multiplayer states
  const [mpRole, setMpRole] = useState<'host' | 'guest' | null>(null);
  const [mpCode, setMpCode] = useState('SHD-88K');
  const [joinCode, setJoinCode] = useState('');
  const [hostStatus, setHostStatus] = useState<{ text: string; color: string }>({
    text: 'Creating private room...',
    color: '#fde047',
  });
  const [guestStatus, setGuestStatus] = useState<{ text: string; color: string }>({
    text: '',
    color: '#94a3b8',
  });

  const screenRef = useRef<ScreenId>(screen);
  screenRef.current = screen;
  const settingsOpenRef = useRef<boolean>(settingsOpen);
  settingsOpenRef.current = settingsOpen;
  const accountModalOpenRef = useRef<boolean>(accountModalOpen);
  accountModalOpenRef.current = accountModalOpen;
  const poseGalleryOpenRef = useRef<boolean>(poseGalleryOpen);
  poseGalleryOpenRef.current = poseGalleryOpen;
  const armoryOpenRef = useRef<boolean>(armoryOpen);
  armoryOpenRef.current = armoryOpen;
  const socialHubOpenRef = useRef<boolean>(socialHubOpen);
  socialHubOpenRef.current = socialHubOpen;
  const questsOpenRef = useRef<boolean>(questsOpen);
  questsOpenRef.current = questsOpen;
  const mailboxOpenRef = useRef<boolean>(mailboxOpen);
  mailboxOpenRef.current = mailboxOpen;
  const historyOpenRef = useRef<boolean>(historyOpen);
  historyOpenRef.current = historyOpen;
  const cmsOpenRef = useRef<boolean>(cmsOpen);
  cmsOpenRef.current = cmsOpen;
  const customizingRef = useRef<boolean>(customizing);
  customizingRef.current = customizing;
  const keybindsOpenRef = useRef<boolean>(keybindsOpen);
  keybindsOpenRef.current = keybindsOpen;
  const listeningActionRef = useRef<CombatButtonKind | null>(listeningAction);
  listeningActionRef.current = listeningAction;
  const controlConfigRef = useRef<ControlLayoutConfig>(controlConfig);
  controlConfigRef.current = controlConfig;
  const authUserRef = useRef<User | null>(authUser);
  authUserRef.current = authUser;
  const p1IdRef = useRef<string>(p1Id);
  p1IdRef.current = p1Id;
  const p2IdRef = useRef<string>(p2Id);
  p2IdRef.current = p2Id;
  const arenaIdRef = useRef<ArenaId>(arenaId);
  arenaIdRef.current = arenaId;
  const practiceRef = useRef<boolean>(practice);
  practiceRef.current = practice;

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    if (toastTimerRef.current !== null) window.clearTimeout(toastTimerRef.current);
    toastTimerRef.current = window.setTimeout(() => setToast(null), 2600);
  }, []);

  const refreshMailbox = useCallback(async () => {
    setMailsLoading(true);
    try {
      const list = await fetchPlayerMailbox(playerId);
      setMails(list);
    } finally {
      setMailsLoading(false);
    }
  }, [playerId]);

  const handleCopyPlayerId = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(playerId);
      showToast(`Player ID ${playerId} copied!`);
    } catch {
      showToast(`Your Player ID: ${playerId}`);
    }
  }, [playerId, showToast]);

  const openMailboxModal = useCallback(
    (tab: 'inbox' | 'send' = 'inbox') => {
      setMailboxInitialTab(tab);
      setMailboxOpen(true);
      void refreshMailbox();
    },
    [refreshMailbox],
  );

  const updateControlConfig = useCallback((next: ControlLayoutConfig) => {
    setControlConfig(next);
    saveControlConfig(next);
  }, []);

  const resetControlConfig = useCallback(() => {
    const fresh = cloneDefaultConfig();
    setControlConfig(fresh);
    saveControlConfig(fresh);
    showToast('Controls reset to 6-button competitive layout!');
  }, [showToast]);

  // Check Mailbox & Live CMS Config once on initial lobby load (Spark-optimized: 1 read each, zero polling)
  useEffect(() => {
    void refreshMailbox();
    void fetchLiveCmsConfig().then((remote) => {
      if (remote) {
        setLiveCmsConfig(remote);
      }
    });
  }, [refreshMailbox]);

  // Isolate developer-only unreleased skins/auras strictly within active Developer Mode sessions
  useEffect(() => {
    if (isDeveloperActive) {
      const items = loadDevUnreleasedCosmetics();
      const sess = loadDevUnreleasedSession();
      setDevUnreleasedCosmetics(items);
      setDevUnreleasedItems(items);
      setDevUnreleasedSession(sess);
    } else {
      setDevUnreleasedCosmetics([]);
      setDevUnreleasedItems([]);
      setDevUnreleasedSession({ unlockedIds: [], equippedSkinIds: [], equippedAuraId: null });
      setCmsOpen(false);
    }
  }, [isDeveloperActive]);

  // Keep guest local wallet synced with localDevMode toggle
  useEffect(() => {
    if (!authUser) {
      setGuestWallet(readGuestWallet(localDevMode));
    }
  }, [authUser, localDevMode]);

  // Listen to Firebase Auth & sync persistent Gmail player profile with localStorage cache
  useEffect(() => {
    let unsubProfile: (() => void) | null = null;
    let cancelled = false;

    const unsubAuth = onAuthStateChanged(auth, async (user) => {
      if (unsubProfile) {
        unsubProfile();
        unsubProfile = null;
      }
      setAuthUser(user);
      setAuthReady(true);

      if (!user) {
        setPlayerProfile(null);
        setEditingName(false);
        const savedDev = getSavedLocalDevMode(null);
        setLocalDevMode(savedDev);
        setGuestWallet(readGuestWallet(savedDev));
        return;
      }

      const cached = readCachedPlayerProfile(user.uid);
      if (cached) {
        setPlayerProfile(cached);
        setSavedLocalDevMode(Boolean(cached.isDeveloper), user.uid);
        setLocalDevMode(Boolean(cached.isDeveloper));
        setNameDraft(cached.akharaName);
      }

      try {
        const ensured = await ensurePlayerAccountDocuments(user, p1IdRef.current, arenaIdRef.current);
        if (cancelled) return;
        setPlayerProfile(ensured);
        setSavedLocalDevMode(Boolean(ensured.isDeveloper), user.uid);
        setLocalDevMode(Boolean(ensured.isDeveloper));
        setNameDraft(ensured.akharaName);
        if (screenRef.current === 'menu') {
          if (FIGHTERS.some((f) => f.id === ensured.favoriteFighterId)) {
            setP1Id(ensured.favoriteFighterId);
          }
          if (ARENAS[ensured.favoriteArenaId]) {
            setArenaId(ensured.favoriteArenaId);
          }
          saveLocalLoadout(ensured.favoriteFighterId, ensured.favoriteArenaId);
        }
        unsubProfile = subscribePlayerProfile(user.uid, (live) => {
          if (!cancelled && live) {
            setPlayerProfile(live);
            setSavedLocalDevMode(Boolean(live.isDeveloper), user.uid);
            setLocalDevMode(Boolean(live.isDeveloper));
          }
        });
      } catch (err) {
        console.error('Failed to sync Gmail profile:', err);
        if (!cached) {
          showToast('Account sync error — check connection and retry.');
        }
      }
    });

    return () => {
      cancelled = true;
      unsubAuth();
      if (unsubProfile) unsubProfile();
    };
  }, [showToast]);

  // Initialize GameEngine once on mount
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const engine = new GameEngine(canvas, {
      onHudUpdate: (snap) => setHud(snap),
      onAnnounce: (txt) => setAnnouncement(txt),
      onToast: (msg) => showToast(msg),
      onVictory: (info) => {
        setWinnerPoseOverride(null);
        setVictory(info);
        const user = authUserRef.current;
        const didWin = info.winnerSlot === info.localSlot;
        const localFighterId = info.localSlot === 1 ? p1IdRef.current : p2IdRef.current;
        const opponentFighterId = info.localSlot === 1 ? p2IdRef.current : p1IdRef.current;
        const localScore = info.localSlot === 1 ? info.p1Wins : info.p2Wins;
        const rivalScore = info.localSlot === 1 ? info.p2Wins : info.p1Wins;
        if (!practiceRef.current) {
          setDailyQuests(
            recordDailyQuestMatchComplete({
              fighterId: localFighterId,
              arenaId: arenaIdRef.current,
              didWin,
            }),
          );
        }
        let fkEarnedForHistory = 0;
        if (user && !practiceRef.current) {
          const projected = computeMatchFutiKodiEarned(didWin, info.localMaxCombo);
          fkEarnedForHistory = projected;
          setLastFutiKodiEarned(projected);
          void recordPlayerMatchResult(
            user.uid,
            didWin,
            info.localMaxCombo,
            p1IdRef.current,
            arenaIdRef.current,
          ).catch((err) => {
            console.error('Failed to save match stats:', err);
          });
        } else if (!user && !practiceRef.current) {
          const { earned, wallet } = recordGuestMatchResult(
            didWin,
            info.localMaxCombo,
            p1IdRef.current,
            arenaIdRef.current,
            getSavedLocalDevMode(null),
          );
          fkEarnedForHistory = earned;
          setGuestWallet(wallet);
          setLastFutiKodiEarned(earned);
        } else {
          setLastFutiKodiEarned(0);
        }
        setMatchHistory(
          appendMatchHistoryEntry({
            mode: practiceRef.current ? 'Practice' : info.mode === 'mp' ? '1v1' : 'Bot',
            result: didWin ? 'WIN' : 'LOSS',
            playerFighterId: localFighterId,
            opponentFighterId,
            arenaId: info.arenaId || arenaIdRef.current,
            roundsScore: `${localScore}-${rivalScore}`,
            maxCombo: info.localMaxCombo,
            futiKodiEarned: fkEarnedForHistory,
          }),
        );
      },
      onQuestMetric: (metric) => {
        setDailyQuests(recordDailyQuestCombatMetric(metric));
      },
      onMpConnected: (role, nextP1, nextP2, nextArena) => {
        setOutgoingInvite(null);
        setMpRole(role);
        setP1Id(nextP1);
        setP2Id(nextP2);
        setArenaId(nextArena);
        setSelectSlot(role === 'host' ? 1 : 2);
        setScreen('select');
      },
      onMpSelectSync: (nextP1, nextP2, nextArena) => {
        setP1Id(nextP1);
        setP2Id(nextP2);
        setArenaId(nextArena);
      },
      onMpStartMatch: (nextP1, nextP2, nextArena) => {
        setP1Id(nextP1);
        setP2Id(nextP2);
        setArenaId(nextArena);
        setVictory(null);
        setSettingsOpen(false);
        setScreen('combat');
        engine.beginMatch();
      },
      onMpStatusText: (target, text, color) => {
        if (target === 'host') setHostStatus({ text, color });
        else setGuestStatus({ text, color });
      },
    });

    engineRef.current = engine;
    setMpCode(engine.mpCode);

    const onResize = () => {
      engine.resize();
      const vw = window.visualViewport?.width || window.innerWidth;
      const vh = window.visualViewport?.height || window.innerHeight;
      setIsPortrait(vh > vw);
    };
    onResize();
    window.addEventListener('resize', onResize);
    window.visualViewport?.addEventListener('resize', onResize);

    const onFsChange = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', onFsChange);

    return () => {
      window.removeEventListener('resize', onResize);
      window.visualViewport?.removeEventListener('resize', onResize);
      document.removeEventListener('fullscreenchange', onFsChange);
      if (toastTimerRef.current !== null) window.clearTimeout(toastTimerRef.current);
      engine.destroy();
      engineRef.current = null;
    };
  }, [showToast]);

  // Sync React settings, lobby theme & equipped cosmetics down to GameEngine
  useEffect(() => {
    const eng = engineRef.current;
    if (!eng) return;
    eng.setLobbyTheme(liveCmsConfig.lobbyTheme);
    eng.mode = mode;
    eng.practice = practice;
    eng.difficulty = difficulty;
    eng.arenaId = arenaId;
    eng.p1Id = p1Id;
    eng.p2Id = p2Id;
    const localSlot: 1 | 2 = mode === 'mp' && mpRole === 'guest' ? 2 : 1;
    const localFighterId = localSlot === 1 ? p1Id : p2Id;
    const skin = getEquippedSkinIdForFighter(effectiveProfile, localFighterId);
    const aura = effectiveProfile?.equippedAuraId || DEFAULT_AURA_ID;
    eng.setCosmetics(localSlot, skin, aura);
    if (localSlot === 1 && mode === 'bot') {
      eng.setCosmetics(2, '', DEFAULT_AURA_ID);
    }
    if (screen === 'menu') {
      eng.setLobbyShowcase(p1Id, getEquippedSkinIdForFighter(effectiveProfile, p1Id), aura);
    }
  }, [
    screen,
    mode,
    mpRole,
    practice,
    difficulty,
    arenaId,
    p1Id,
    p2Id,
    effectiveProfile,
    liveCmsConfig.lobbyTheme,
  ]);

  // Keep PlayerDirectory online presence & Friend/Invite subscriptions active when signed in
  useEffect(() => {
    if (!authUser) {
      setIncomingFriendRequests([]);
      setIncomingInvites([]);
      setFriends([]);
      return;
    }

    const displayName = playerProfile?.akharaName || authUser.displayName || 'Desi Yoddha';
    const activeFighter = playerProfile?.favoriteFighterId || p1Id;

    void syncPlayerDirectoryPresence({
      playerId,
      uid: authUser.uid,
      akharaName: displayName,
      favoriteFighterId: activeFighter,
      online: true,
    });

    const unsubReqs = subscribeIncomingFriendRequests(playerId, true, setIncomingFriendRequests);
    const unsubFriends = subscribeFriendsList(playerId, authUser.uid, setFriends);
    const unsubInvites = subscribeIncomingInvites(playerId, true, setIncomingInvites);

    const handleBeforeUnload = () => {
      void syncPlayerDirectoryPresence({
        playerId,
        uid: authUser.uid,
        akharaName: displayName,
        favoriteFighterId: activeFighter,
        online: false,
      });
    };
    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
      unsubReqs();
      unsubFriends();
      unsubInvites();
    };
  }, [authUser, playerId, playerProfile?.akharaName, playerProfile?.favoriteFighterId, p1Id]);

  // Monitor outgoing direct 1v1 invite acceptance/decline
  useEffect(() => {
    if (!outgoingInvite) return;
    const unsub = subscribeSentInviteStatus(outgoingInvite.inviteId, (status) => {
      if (status === 'declined') {
        showToast(`${outgoingInvite.friendName} declined your 1v1 challenge.`);
        void deleteDirectMatchInvite(outgoingInvite.inviteId);
        setOutgoingInvite(null);
      } else if (status === 'accepted') {
        showToast(`${outgoingInvite.friendName} accepted! Connecting arena...`);
      }
    });
    return () => unsub();
  }, [outgoingInvite, showToast]);

  // Keep engine.paused in sync when modals or Portrait rotate guard are active
  useEffect(() => {
    const eng = engineRef.current;
    if (!eng) return;
    eng.paused =
      (screen === 'combat' &&
        (settingsOpen ||
          customizing ||
          keybindsOpen ||
          accountModalOpen ||
          poseGalleryOpen ||
          armoryOpen ||
          socialHubOpen ||
          questsOpen ||
          mailboxOpen ||
          historyOpen ||
          cmsOpen)) ||
      isPortrait;
  }, [
    screen,
    settingsOpen,
    customizing,
    keybindsOpen,
    accountModalOpen,
    poseGalleryOpen,
    armoryOpen,
    socialHubOpen,
    questsOpen,
    mailboxOpen,
    historyOpen,
    cmsOpen,
    isPortrait,
  ]);

  // Global keyboard controls + dynamic keybind listener
  useEffect(() => {
    let lastLeftTap = 0;
    let lastRightTap = 0;

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      const k = e.key.toLowerCase();

      // Rebinding mode
      if (listeningActionRef.current) {
        e.preventDefault();
        if (k === 'escape') {
          setListeningAction(null);
          return;
        }
        if (['w', 'a', 's', 'd', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright'].includes(k)) {
          showToast('Movement keys (WASD / Arrows) stay reserved for movement!');
          return;
        }
        const act = listeningActionRef.current;
        const nextCfg: ControlLayoutConfig = {
          ...controlConfigRef.current,
          keyBinds: {
            ...controlConfigRef.current.keyBinds,
            [act]: k,
          },
        };
        updateControlConfig(nextCfg);
        setListeningAction(null);
        showToast(`${ACTION_LABELS[act].name} bound to [${formatKeyLabel(k)}]`);
        return;
      }

      const eng = engineRef.current;
      if (!eng) return;

      if (k === 'escape') {
        if (cmsOpenRef.current) {
          setCmsOpen(false);
          return;
        }
        if (historyOpenRef.current) {
          setHistoryOpen(false);
          return;
        }
        if (questsOpenRef.current) {
          setQuestsOpen(false);
          return;
        }
        if (mailboxOpenRef.current) {
          setMailboxOpen(false);
          return;
        }
        if (armoryOpenRef.current) {
          setArmoryOpen(false);
          return;
        }
        if (poseGalleryOpenRef.current) {
          setPoseGalleryOpen(false);
          return;
        }
        if (socialHubOpenRef.current) {
          setSocialHubOpen(false);
          return;
        }
        if (accountModalOpenRef.current) {
          setEditingName(false);
          setAccountModalOpen(false);
          return;
        }
        if (keybindsOpenRef.current) {
          setKeybindsOpen(false);
          return;
        }
        if (customizingRef.current) {
          setCustomizing(false);
          return;
        }
        if (screenRef.current === 'combat') {
          setSettingsOpen((prev) => !prev);
        } else if (settingsOpenRef.current) {
          setSettingsOpen(false);
        }
        return;
      }

      if (
        screenRef.current !== 'combat' ||
        settingsOpenRef.current ||
        customizingRef.current ||
        keybindsOpenRef.current ||
        accountModalOpenRef.current ||
        poseGalleryOpenRef.current ||
        armoryOpenRef.current ||
        socialHubOpenRef.current ||
        questsOpenRef.current ||
        mailboxOpenRef.current ||
        historyOpenRef.current ||
        cmsOpenRef.current
      ) {
        return;
      }

      if (['arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' '].includes(k)) {
        e.preventDefault();
      }

      const wasDown = !!eng.keys[k];
      eng.keys[k] = true;
      if (wasDown) return;

      sound.ensureAudio();

      // Double-tap left/right to dash
      if (k === 'a' || k === 'arrowleft') {
        const now = performance.now();
        const lf = eng.getLocalFighter();
        if (lf && eng.phase === 'FIGHT' && now - lastLeftTap < 240) eng.triggerDash(lf, -1);
        lastLeftTap = now;
      } else if (k === 'd' || k === 'arrowright') {
        const now = performance.now();
        const lf = eng.getLocalFighter();
        if (lf && eng.phase === 'FIGHT' && now - lastRightTap < 240) eng.triggerDash(lf, 1);
        lastRightTap = now;
      }

      // Quick Desi Sticker Emote hotkeys 1..6
      const emoteIdx = ['1', '2', '3', '4', '5', '6'].indexOf(k);
      if (emoteIdx !== -1 && STICKER_EMOTES[emoteIdx]) {
        eng.triggerEmote(STICKER_EMOTES[emoteIdx].id);
        return;
      }

      const binds = controlConfigRef.current.keyBinds;
      if (k === binds.basic || k === 'z') eng.triggerCombatAction('basic');
      else if (k === binds.sp1 || k === 'c') eng.triggerCombatAction('sp1');
      else if (k === binds.sp2 || k === 'v') eng.triggerCombatAction('sp2');
      else if (k === binds.dash || k === 'h') eng.triggerCombatAction('dash');
      else if (k === binds.shield || k === 'shift') eng.setShieldHeld(true);
      else if (k === binds.rage || k === 'b') eng.triggerCombatAction('rage');
    };

    const onKeyUp = (e: KeyboardEvent) => {
      const eng = engineRef.current;
      if (!eng) return;
      const k = e.key.toLowerCase();
      eng.keys[k] = false;
      const binds = controlConfigRef.current.keyBinds;
      if (k === binds.shield || k === 'shift') eng.setShieldHeld(false);
    };

    const clearAllKeys = () => {
      engineRef.current?.resetInputs();
    };

    const unlockAudio = () => {
      sound.ensureAudio();
    };

    const onGlobalUiClick = (e: MouseEvent) => {
      sound.ensureAudio();
      const rawTarget = e.target as HTMLElement | null;
      if (!rawTarget) return;
      if (rawTarget.closest('[data-ui-sfx="none"]')) return;
      const interactive = rawTarget.closest('button, [role="button"], summary, a') as HTMLElement | null;
      if (!interactive) return;
      if (interactive.hasAttribute('disabled') || interactive.getAttribute('aria-disabled') === 'true') return;
      const explicit = interactive.getAttribute('data-ui-sfx') as UiSfxKind | 'none' | null;
      if (explicit === 'none') return;
      if (
        explicit === 'tap' ||
        explicit === 'select' ||
        explicit === 'unlock' ||
        explicit === 'dev_on' ||
        explicit === 'dev_off' ||
        explicit === 'locked'
      ) {
        sound.playUiSfx(explicit);
        return;
      }
      sound.playUiSfx('tap');
    };

    const onGlobalUiChange = (e: Event) => {
      const rawTarget = e.target as HTMLElement | null;
      if (!rawTarget || rawTarget.tagName !== 'SELECT') return;
      const explicit = rawTarget.getAttribute('data-ui-sfx') as UiSfxKind | 'none' | null;
      if (explicit === 'none') return;
      sound.playUiSfx(explicit && explicit !== 'tap' ? explicit : 'select');
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('pointerdown', unlockAudio, { passive: true });
    window.addEventListener('touchstart', unlockAudio, { passive: true });
    document.addEventListener('click', onGlobalUiClick);
    document.addEventListener('change', onGlobalUiChange);
    window.addEventListener('blur', clearAllKeys);
    document.addEventListener('visibilitychange', clearAllKeys);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('pointerdown', unlockAudio);
      window.removeEventListener('touchstart', unlockAudio);
      document.removeEventListener('click', onGlobalUiClick);
      document.removeEventListener('change', onGlobalUiChange);
      window.removeEventListener('blur', clearAllKeys);
      document.removeEventListener('visibilitychange', clearAllKeys);
    };
  }, []);

  const tryLockLandscape = async () => {
    try {
      const ori = window.screen?.orientation as { lock?: (mode: string) => Promise<void> } | undefined;
      if (ori && typeof ori.lock === 'function') {
        await ori.lock('landscape');
      }
    } catch {
      // Orientation lock requires fullscreen/mobile PWA on some browsers
    }
  };

  const toggleFullscreen = async () => {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen();
        await tryLockLandscape();
      } else {
        await document.exitFullscreen();
      }
    } catch {
      showToast('Fullscreen unavailable in this preview frame');
    }
  };

  const handleOpenBotMode = (isPractice: boolean) => {
    sound.ensureAudio();
    engineRef.current?.cleanupPeerSession();
    setMode('bot');
    setPractice(isPractice);
    setMpRole(null);
    setSelectSlot(1);
    setScreen('select');
  };

  const handleOpenMpLobby = () => {
    sound.ensureAudio();
    const eng = engineRef.current;
    setMode('mp');
    setPractice(false);
    setMpRole('host');
    setScreen('mp');
    if (eng) {
      eng.initHostMultiplayerRoom();
      setMpCode(eng.mpCode);
    }
  };

  const handleCopyCode = async () => {
    try {
      await navigator.clipboard.writeText(mpCode);
      showToast(`Room code ${mpCode} copied!`);
    } catch {
      showToast(`Share code: ${mpCode}`);
    }
  };

  const handleRegenCode = () => {
    const eng = engineRef.current;
    if (!eng) return;
    eng.mpCode = eng.generateRoomCode();
    setMpCode(eng.mpCode);
    eng.initHostMultiplayerRoom();
  };

  const handleJoinRoom = (e: React.FormEvent) => {
    e.preventDefault();
    sound.ensureAudio();
    setMpRole('guest');
    engineRef.current?.joinGuestMultiplayerRoom(joinCode);
  };

  const handleSelectFighter = (id: string) => {
    sound.ensureAudio();
    if (mode === 'mp') {
      if (mpRole === 'guest') {
        if (id === p1Id) {
          showToast('Host already locked this warrior!');
          return;
        }
        setP2Id(id);
        engineRef.current?.sendNetMsg({ type: 'SELECT_SYNC', p1Id, p2Id: id, arenaId });
      } else {
        setP1Id(id);
        let nextP2 = p2Id;
        if (id === p2Id) {
          nextP2 = FIGHTERS.find((f) => f.id !== id)?.id || p2Id;
          setP2Id(nextP2);
        }
        engineRef.current?.sendNetMsg({ type: 'SELECT_SYNC', p1Id: id, p2Id: nextP2, arenaId });
      }
      return;
    }

    if (selectSlot === 1) {
      setP1Id(id);
      if (id === p2Id) {
        const alt = FIGHTERS.find((f) => f.id !== id);
        if (alt) setP2Id(alt.id);
      }
      saveLocalLoadout(id, arenaId);
    } else {
      if (id === p1Id) {
        showToast('Pick a different rival from your fighter!');
        return;
      }
      setP2Id(id);
    }
  };

  const handleRandomOpponent = () => {
    const pool = FIGHTERS.filter((f) => f.id !== p1Id);
    const pick = pool[Math.floor(Math.random() * pool.length)];
    if (pick) setP2Id(pick.id);
  };

  const handleSelectArena = (id: ArenaId) => {
    setArenaId(id);
    if (mode === 'mp') {
      engineRef.current?.sendNetMsg({ type: 'SELECT_SYNC', p1Id, p2Id, arenaId: id });
    } else {
      saveLocalLoadout(p1Id, id);
    }
  };

  const handleGmailLogin = async () => {
    if (authBusy) return;
    setAuthBusy(true);
    try {
      const user = await signInWithGmail();
      showToast(`Swagat hai, ${user.displayName || user.email || 'Yoddha'}!`);
    } catch (err: unknown) {
      const code = (err as { code?: string })?.code || '';
      if (code === 'auth/popup-closed-by-user' || code === 'auth/cancelled-popup-request') {
        showToast('Gmail login cancelled.');
      } else if (code === 'auth/popup-blocked') {
        showToast('Popup blocked — please allow popups to sign in with Gmail.');
      } else {
        console.error('Gmail login failed:', err);
        showToast('Gmail login failed. Please try again.');
      }
    } finally {
      setAuthBusy(false);
    }
  };

  const handleLogout = async () => {
    if (authBusy) return;
    setAuthBusy(true);
    try {
      await logoutAccount();
      setEditingName(false);
      showToast('Logged out! Dobara same Gmail se login karne par aapka account wapas milega.');
    } catch (err) {
      console.error('Logout error:', err);
      showToast('Logout failed.');
    } finally {
      setAuthBusy(false);
    }
  };

  const handleSaveAkharaName = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!authUser || authBusy) return;
    const trimmed = nameDraft.trim();
    if (trimmed.length < 2) {
      showToast('Akhara Name kam se kam 2 letters ka hona chahiye.');
      return;
    }
    setAuthBusy(true);
    try {
      const saved = await updateAkharaName(authUser.uid, trimmed, authUser.photoURL);
      setNameDraft(saved);
      setEditingName(false);
      showToast(`Akhara Name updated: ${saved}`);
    } catch (err) {
      console.error('Name update error:', err);
      showToast('Could not update Akhara Name.');
    } finally {
      setAuthBusy(false);
    }
  };

  const handleCycleLobbyFighter = (delta: 1 | -1) => {
    sound.ensureAudio();
    const curIdx = FIGHTERS.findIndex((f) => f.id === p1Id);
    const nextIdx = ((curIdx >= 0 ? curIdx : 0) + delta + FIGHTERS.length) % FIGHTERS.length;
    const nextId = FIGHTERS[nextIdx].id;
    setP1Id(nextId);
    saveLocalLoadout(nextId, arenaId);
  };

  const handleUnlockDeveloper = async (e: React.FormEvent) => {
    e.preventDefault();
    if (devUnlockBusy) return;
    const trimmed = devCodeInput.trim().toUpperCase();
    if (!trimmed) {
      sound.playUiSfx('locked');
      setDevUnlockError('Please enter Dev Code.');
      return;
    }
    if (trimmed !== 'OHIIT1310') {
      sound.playUiSfx('locked');
      setDevUnlockError('Invalid Developer Code.');
      return;
    }

    setDevUnlockError(null);
    if (!authUser) {
      setSavedLocalDevMode(true, null);
      setLocalDevMode(true);
      setDevCodeInput('');
      sound.playUiSfx('dev_on');
      showToast('Developer Mode Activated! DEV ∞ active.');
      return;
    }

    setDevUnlockBusy(true);
    try {
      await unlockDeveloperMode(authUser.uid, trimmed);
      setSavedLocalDevMode(true, authUser.uid);
      setLocalDevMode(true);
      setPlayerProfile((prev) =>
        prev ? { ...prev, isDeveloper: true, futiKodi: 9999999, gota: 9999999 } : prev,
      );
      setDevCodeInput('');
      sound.playUiSfx('dev_on');
      showToast('Developer Mode Activated! DEV ∞ badge & ∞ Store currencies active.');
    } catch (err) {
      sound.playUiSfx('locked');
      setDevUnlockError(err instanceof Error ? err.message : 'Invalid Developer Code.');
    } finally {
      setDevUnlockBusy(false);
    }
  };

  const handleDeactivateDeveloper = async () => {
    if (devUnlockBusy) return;
    setDevUnlockError(null);

    if (!authUser) {
      setSavedLocalDevMode(false, null);
      setLocalDevMode(false);
      sound.playUiSfx('dev_off');
      showToast('Developer Mode Deactivated.');
      return;
    }

    setDevUnlockBusy(true);
    try {
      const restored = await deactivateDeveloperMode(authUser.uid);
      setSavedLocalDevMode(false, authUser.uid);
      setLocalDevMode(false);
      setPlayerProfile((prev) =>
        prev
          ? { ...prev, isDeveloper: false, futiKodi: restored.futiKodi, gota: restored.gota }
          : prev,
      );
      sound.playUiSfx('dev_off');
      showToast(`Developer Mode Deactivated — Restored ${restored.futiKodi} FK & ${restored.gota} Gota.`);
    } catch (err) {
      sound.playUiSfx('locked');
      setDevUnlockError(err instanceof Error ? err.message : 'Could not deactivate Developer Mode.');
    } finally {
      setDevUnlockBusy(false);
    }
  };

  const handleStartFight = () => {
    sound.ensureAudio();
    void tryLockLandscape();
    const eng = engineRef.current;
    if (!eng) return;

    if (mode === 'mp' && eng.mpConnected) {
      eng.sendNetMsg({ type: 'START_MATCH', p1Id, p2Id, arenaId });
    }
    setVictory(null);
    setSettingsOpen(false);
    setScreen('combat');
    eng.beginMatch();
  };

  const handleExitToMenu = () => {
    const eng = engineRef.current;
    setVictory(null);
    setSettingsOpen(false);
    setAnnouncement(null);
    setScreen('menu');
    if (eng) {
      eng.paused = false;
      eng.cleanupPeerSession();
      eng.setupMenuDemoFighters();
    }
  };

  const handleJoystick = useCallback((nx: number, ny: number) => {
    engineRef.current?.setJoystick(nx, ny);
  }, []);

  const handleCombatAction = useCallback((kind: CombatButtonKind) => {
    engineRef.current?.triggerCombatAction(kind);
  }, []);

  const handleBlockChange = useCallback((held: boolean) => {
    engineRef.current?.setShieldHeld(held);
  }, []);

  const handleEmote = useCallback((emoteId: StickerEmoteId) => {
    engineRef.current?.triggerEmote(emoteId);
  }, []);

  const handleJoinCodeFromChat = useCallback((code: string) => {
    sound.ensureAudio();
    setSocialHubOpen(false);
    setMode('mp');
    setPractice(false);
    setMpRole('guest');
    setJoinCode(code);
    setScreen('mp');
    engineRef.current?.joinGuestMultiplayerRoom(code);
  }, []);

  const handleSendFriendRequest = useCallback(
    async (targetPlayerId: string) => {
      if (!authUser) {
        showToast('Sign in with Gmail first to send Friend Requests!');
        return;
      }
      try {
        await sendFriendRequest({
          myPlayerId: playerId,
          myUid: authUser.uid,
          myName: playerProfile?.akharaName || authUser.displayName || 'Desi Yoddha',
          myFighterId: p1Id,
          targetPlayerId,
        });
        showToast(`Friend Request sent to ${targetPlayerId.trim().toUpperCase()}!`);
      } catch (err) {
        showToast(err instanceof Error ? err.message : 'Could not send Friend Request.');
      }
    },
    [authUser, playerId, playerProfile?.akharaName, p1Id, showToast],
  );

  const handleAcceptFriendRequest = useCallback(
    async (req: FriendRequestItem) => {
      if (!authUser) return;
      try {
        await acceptFriendRequest({
          myPlayerId: playerId,
          myUid: authUser.uid,
          myName: playerProfile?.akharaName || authUser.displayName || 'Desi Yoddha',
          myFighterId: p1Id,
          req,
        });
        showToast(`${req.fromName} added to your Friends List!`);
      } catch (err) {
        showToast(err instanceof Error ? err.message : 'Could not accept request.');
      }
    },
    [authUser, playerId, playerProfile?.akharaName, p1Id, showToast],
  );

  const handleDeclineFriendRequest = useCallback(
    async (reqId: string) => {
      try {
        await declineFriendRequest(reqId);
        showToast('Friend Request declined.');
      } catch {
        showToast('Could not decline request.');
      }
    },
    [showToast],
  );

  const handleRemoveFriend = useCallback(
    async (friendPlayerId: string) => {
      try {
        await removeFriend({ myPlayerId: playerId, friendPlayerId });
        showToast('Friend removed.');
      } catch {
        showToast('Could not remove friend.');
      }
    },
    [playerId, showToast],
  );

  const handleRefreshFriends = useCallback(async () => {
    const updated = await enrichFriendsPresence(friends);
    setFriends(updated);
    showToast('Friend status refreshed!');
  }, [friends, showToast]);

  const handleChallengeFriend = useCallback(
    async (friend: FriendEntry) => {
      if (!authUser) {
        showToast('Sign in with Gmail first to send 1v1 invites!');
        return;
      }
      const eng = engineRef.current;
      if (!eng) return;
      sound.ensureAudio();

      setMode('mp');
      setPractice(false);
      setMpRole('host');
      eng.initHostMultiplayerRoom();
      const roomCode = eng.mpCode;
      setMpCode(roomCode);

      try {
        const inviteId = await sendDirectMatchInvite({
          fromPlayerId: playerId,
          fromUid: authUser.uid,
          fromName: playerProfile?.akharaName || authUser.displayName || 'Desi Yoddha',
          fromFighterId: p1Id,
          toPlayerId: friend.friendPlayerId,
          roomCode,
        });
        setOutgoingInvite({
          inviteId,
          friendName: friend.friendName,
          friendPlayerId: friend.friendPlayerId,
          roomCode,
        });
        setSocialHubOpen(false);
        showToast(`1v1 Challenge sent to ${friend.friendName}!`);
      } catch (err) {
        showToast(err instanceof Error ? err.message : 'Could not send 1v1 Invite.');
      }
    },
    [authUser, playerId, playerProfile?.akharaName, p1Id, showToast],
  );

  const handleAcceptIncomingInvite = useCallback(
    async (invite: DirectMatchInvite) => {
      if (!authUser) return;
      sound.ensureAudio();
      await respondToDirectMatchInvite(
        invite.id,
        'accepted',
        playerId,
        authUser.uid,
        playerProfile?.akharaName || authUser.displayName || 'Desi Yoddha',
        p1Id,
      );
      setIncomingInvites((prev) => prev.filter((item) => item.id !== invite.id));
      setSocialHubOpen(false);
      setMailboxOpen(false);
      setQuestsOpen(false);
      setArmoryOpen(false);
      setPoseGalleryOpen(false);
      setSettingsOpen(false);
      setVictory(null);

      setMode('mp');
      setPractice(false);
      setMpRole('guest');
      setJoinCode(invite.roomCode);
      setScreen('mp');
      engineRef.current?.joinGuestMultiplayerRoom(invite.roomCode);
      void deleteDirectMatchInvite(invite.id);
    },
    [authUser, playerId, playerProfile?.akharaName, p1Id],
  );

  const handleDeclineIncomingInvite = useCallback(
    async (invite: DirectMatchInvite) => {
      if (authUser) {
        await respondToDirectMatchInvite(
          invite.id,
          'declined',
          playerId,
          authUser.uid,
          playerProfile?.akharaName || authUser.displayName || 'Desi Yoddha',
          p1Id,
        );
      }
      setIncomingInvites((prev) => prev.filter((item) => item.id !== invite.id));
    },
    [authUser, playerId, playerProfile?.akharaName, p1Id],
  );

  const activeBioCfg = getCfgById(mode === 'mp' && mpRole === 'guest' ? p2Id : selectSlot === 1 ? p1Id : p2Id);
  const arenaList = Object.values(ARENAS);
  const friendsNotifyCount = incomingFriendRequests.length + incomingInvites.length;
  const readyQuestsCount = dailyQuests.filter((q) => q.progress >= q.targetCount && !q.claimed).length;

  return (
    <div className="relative w-dvw h-dvh overflow-hidden bg-[#07060d] text-amber-50 select-none">
      {/* FULL-SCREEN FIGHT CANVAS */}
      <canvas ref={canvasRef} className="fixed inset-0 w-full h-full block" />

      {/* ==================== 1. VICTORIA MEMORIAL CLEAN LOBBY ==================== */}
      {screen === 'menu' && (() => {
        const lobbyWarrior = getCfgById(p1Id);
        const lobbySkinId = getEquippedSkinIdForFighter(effectiveProfile, p1Id);
        const lobbySkin = lobbySkinId ? getSkinById(lobbySkinId) : undefined;
        return (
          <div
            id="screen-menu"
            className="fixed inset-0 z-10 flex flex-col justify-between p-2 sm:p-3.5 lg:p-5 bg-gradient-to-r from-[#060914]/38 via-transparent to-[#060914]/75"
          >
            {/* Clean Esports Top Header (100dvw zero-clipping fit) */}
            <div className="flex items-center justify-between gap-1 sm:gap-2 max-w-6xl w-full mx-auto shrink-0 bg-[#080a16]/68 backdrop-blur-xs border border-white/10 rounded-xl sm:rounded-2xl px-2 sm:px-2.5 py-1.5 overflow-hidden">
              <div className="min-w-0 flex items-baseline gap-2 shrink">
                <h1 className="font-display-in text-sm sm:text-xl lg:text-2xl tracking-wide text-transparent bg-clip-text bg-gradient-to-b from-yellow-200 via-amber-400 to-rose-500 leading-none whitespace-nowrap">
                  GALI CLASH
                </h1>
                <span className="hidden xl:inline text-[10px] font-semibold tracking-[0.2em] text-amber-200/75 uppercase whitespace-nowrap">
                  Victoria Memorial · Kolkata
                </span>
              </div>

              <div className="flex items-center gap-1 sm:gap-1.5 shrink-0 min-w-0">
                <button
                  type="button"
                  onClick={() => openArmory('store')}
                  className="h-7 sm:h-8 px-1.5 sm:px-2 rounded-lg sm:rounded-xl border border-amber-400/50 bg-amber-500/15 text-amber-200 text-[10px] sm:text-[11px] font-extrabold flex items-center gap-1 hover:border-amber-300 hover:bg-amber-500/25 cursor-pointer transition whitespace-nowrap shrink-0"
                >
                  <ShoppingBag className="w-3.5 h-3.5 text-amber-300 shrink-0" />
                  <span>Store</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setPoseGalleryFighterId(p1Id);
                    setPoseGalleryOpen(true);
                  }}
                  title="Victory Poses"
                  className="h-7 sm:h-8 px-1.5 sm:px-2 rounded-lg sm:rounded-xl border border-white/15 bg-black/40 text-amber-100 text-[10px] sm:text-[11px] font-bold flex items-center gap-1 hover:border-amber-300/60 cursor-pointer transition whitespace-nowrap shrink-0"
                >
                  <Crown className="w-3.5 h-3.5 text-amber-300 shrink-0" />
                  <span className="hidden sm:inline">Poses</span>
                </button>
                <button
                  type="button"
                  onClick={() => setQuestsOpen(true)}
                  title="Daily Quests (10–50 FK)"
                  className="relative h-7 sm:h-8 px-1.5 sm:px-2 rounded-lg sm:rounded-xl border border-amber-400/40 bg-black/45 text-amber-100 text-[10px] sm:text-[11px] font-bold flex items-center gap-1 hover:border-amber-300 cursor-pointer transition whitespace-nowrap shrink-0"
                >
                  <ScrollText className="w-3.5 h-3.5 text-amber-300 shrink-0" />
                  <span className="hidden md:inline">Quests</span>
                  {readyQuestsCount > 0 && (
                    <span className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.95)] animate-pulse" />
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSocialHubTab('friends');
                    setSocialHubOpen(true);
                  }}
                  title="Friends & 1v1 Invites"
                  className="relative h-7 sm:h-8 px-1.5 sm:px-2 rounded-lg sm:rounded-xl border border-emerald-400/35 bg-black/45 text-emerald-100 text-[10px] sm:text-[11px] font-bold flex items-center gap-1 hover:border-emerald-300 cursor-pointer transition whitespace-nowrap shrink-0"
                >
                  <Users className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
                  <span className="hidden lg:inline">Friends</span>
                  {friendsNotifyCount > 0 && (
                    <span className="w-2 h-2 rounded-full bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.95)] animate-pulse" />
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSocialHubTab('leaderboard');
                    setSocialHubOpen(true);
                  }}
                  title="Global Leaderboard"
                  className="h-7 sm:h-8 px-1.5 sm:px-2 rounded-lg sm:rounded-xl border border-white/15 bg-black/40 text-emerald-200 text-[10px] sm:text-[11px] font-bold flex items-center gap-1 hover:border-emerald-300/60 cursor-pointer transition whitespace-nowrap shrink-0"
                >
                  <Trophy className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
                  <span className="hidden lg:inline">Ranks</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSocialHubTab('chat');
                    setSocialHubOpen(true);
                  }}
                  title="Global Chat"
                  className="h-7 sm:h-8 px-1.5 sm:px-2 rounded-lg sm:rounded-xl border border-white/15 bg-black/40 text-cyan-200 text-[10px] sm:text-[11px] font-bold flex items-center gap-1 hover:border-cyan-300/60 cursor-pointer transition whitespace-nowrap shrink-0"
                >
                  <MessageSquare className="w-3.5 h-3.5 text-cyan-300 shrink-0" />
                  <span className="hidden lg:inline">Chat</span>
                </button>
                <button
                  type="button"
                  onClick={() => openMailboxModal('inbox')}
                  title="Gali Clash Dak Ghar (Mailbox)"
                  className="relative h-7 sm:h-8 px-1.5 sm:px-2 rounded-lg sm:rounded-xl border border-amber-400/40 bg-black/45 text-amber-100 text-[10px] sm:text-[11px] font-bold flex items-center gap-1 hover:border-amber-300 cursor-pointer transition whitespace-nowrap shrink-0"
                >
                  <Mail className="w-3.5 h-3.5 text-amber-300 shrink-0" />
                  <span className="hidden xl:inline">Mail</span>
                  {mails.length > 0 && (
                    <span className="px-1 min-w-[15px] h-[15px] rounded-full bg-gradient-to-r from-rose-500 to-amber-400 text-slate-950 font-num text-[9px] font-black flex items-center justify-center leading-none shadow-[0_0_8px_rgba(244,63,94,0.65)]">
                      {mails.length > 9 ? '9+' : mails.length}
                    </span>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => setHistoryOpen(true)}
                  title="Local Match History"
                  aria-label="Local Match History"
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg sm:rounded-xl border border-amber-400/35 bg-black/45 text-amber-200 flex items-center justify-center hover:border-amber-300 cursor-pointer transition shrink-0"
                >
                  <History className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-300" />
                </button>
                {isDeveloperActive && (
                  <button
                    type="button"
                    data-ui-sfx="select"
                    onClick={() => setCmsOpen(true)}
                    title="Developer Live Operations Panel (CMS)"
                    className="h-7 sm:h-8 px-1.5 sm:px-2 rounded-lg sm:rounded-xl border border-amber-300/75 bg-gradient-to-r from-amber-400/25 to-rose-500/25 text-amber-100 text-[10px] sm:text-[11px] font-black flex items-center gap-1 hover:border-amber-200 hover:brightness-110 cursor-pointer transition whitespace-nowrap shrink-0 shadow-[0_0_12px_rgba(251,191,36,0.28)]"
                  >
                    <Sliders className="w-3.5 h-3.5 text-amber-300 shrink-0" />
                    <span>LIVE CMS</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => setAccountModalOpen(true)}
                  className={`h-7 sm:h-8 px-1.5 sm:px-2 rounded-lg sm:rounded-xl border flex items-center gap-1 text-[10px] sm:text-[11px] font-bold transition cursor-pointer shrink-0 min-w-0 ${
                    authUser
                      ? 'border-emerald-400/45 bg-emerald-500/12 text-emerald-100 hover:border-emerald-300'
                      : 'border-amber-400/45 bg-[#120e20]/90 text-amber-200 hover:border-amber-300'
                  }`}
                >
                  {authUser ? (
                    <>
                      {playerProfile?.photoUrl || authUser.photoURL ? (
                        <img
                          src={playerProfile?.photoUrl || authUser.photoURL || ''}
                          alt=""
                          referrerPolicy="no-referrer"
                          className="w-4 h-4 sm:w-5 sm:h-5 rounded-full border border-emerald-300/60 object-cover shrink-0"
                        />
                      ) : (
                        <UserCheck className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
                      )}
                      <span className="max-w-[66px] sm:max-w-[82px] md:max-w-[110px] lg:max-w-[135px] truncate">
                        {playerProfile?.akharaName || authUser.displayName || 'Yoddha'}
                      </span>
                      {isDeveloperActive && (
                        <span className="inline-flex items-center px-1 py-[1px] rounded bg-gradient-to-r from-amber-400 to-yellow-300 text-slate-950 text-[8px] font-black uppercase shrink-0">
                          DEV
                        </span>
                      )}
                    </>
                  ) : (
                    <>
                      <LogIn className="w-3.5 h-3.5 text-amber-300 shrink-0" />
                      <span className="whitespace-nowrap">{authReady ? 'Login' : 'Account...'}</span>
                      {isDeveloperActive && (
                        <span className="inline-flex items-center px-1 py-[1px] rounded bg-gradient-to-r from-amber-400 to-yellow-300 text-slate-950 text-[8px] font-black uppercase shrink-0">
                          DEV
                        </span>
                      )}
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={toggleFullscreen}
                  title="Fullscreen"
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg sm:rounded-xl border border-white/15 bg-black/40 text-amber-200 flex items-center justify-center hover:border-amber-300 transition cursor-pointer shrink-0"
                >
                  {isFullscreen ? <Minimize2 className="w-3.5 h-3.5 sm:w-4 sm:h-4" /> : <Maximize2 className="w-3.5 h-3.5 sm:w-4 sm:h-4" />}
                </button>
                <button
                  type="button"
                  onClick={() => setSettingsOpen(true)}
                  title="Settings"
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg sm:rounded-xl border border-white/15 bg-black/40 text-amber-200 flex items-center justify-center hover:border-amber-300 transition cursor-pointer shrink-0"
                >
                  <Settings className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </button>
              </div>
            </div>

            {/* Center Open Showcase Stage (Left Social Icons + Bottom-Left Warrior Plate; Right Clean Play Stack) */}
            <div className="max-w-6xl w-full mx-auto flex-1 min-h-0 flex items-end sm:items-center justify-between gap-4 py-1.5 sm:py-2">
              {/* Left Column: Vertical Social Links (Discord & Instagram) + Bottom-Left Warrior Showcase Plate */}
              <div className="self-stretch flex flex-col justify-between items-start min-w-0">
                {/* Vertical Left-Side Social Media Icons Panel */}
                <div className="flex flex-col gap-2 mt-1 sm:mt-2">
                  <a
                    href="https://discord.gg/SgKrnEGss6"
                    target="_blank"
                    rel="noopener noreferrer"
                    data-ui-sfx="tap"
                    title="Join Official Gali Clash Discord"
                    aria-label="Join Official Discord Server"
                    className="group w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-[#080a16]/72 backdrop-blur-xs border border-white/15 text-indigo-300 flex items-center justify-center transition-all duration-200 hover:scale-105 active:scale-95 hover:text-indigo-200 hover:border-[#5865F2]/80 hover:bg-[#5865F2]/20 hover:shadow-[0_0_16px_rgba(88,101,242,0.55)] cursor-pointer"
                  >
                    <svg
                      viewBox="0 0 24 24"
                      aria-hidden="true"
                      className="w-[18px] h-[18px] sm:w-5 sm:h-5 fill-current transition-transform duration-200 group-hover:scale-110"
                    >
                      <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z" />
                    </svg>
                  </a>

                  <a
                    href="https://www.instagram.com/ohi_purkait13?mdxt=MTc4anMwdnFsajBkbA=="
                    target="_blank"
                    rel="noopener noreferrer"
                    data-ui-sfx="tap"
                    title="Follow @ohi_purkait13 on Instagram"
                    aria-label="Follow on Instagram"
                    className="group w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-[#080a16]/72 backdrop-blur-xs border border-white/15 text-pink-300 flex items-center justify-center transition-all duration-200 hover:scale-105 active:scale-95 hover:text-pink-200 hover:border-pink-400/80 hover:bg-gradient-to-br hover:from-pink-500/20 hover:to-amber-500/20 hover:shadow-[0_0_16px_rgba(236,72,153,0.55)] cursor-pointer"
                  >
                    <svg
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                      className="w-[18px] h-[18px] sm:w-5 sm:h-5 transition-transform duration-200 group-hover:scale-110"
                    >
                      <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
                      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                      <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
                    </svg>
                  </a>
                </div>

                {/* Bottom-Left Warrior Showcase Plate + Quick Skins Inventory Button */}
                <div className="flex items-center gap-2 px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-2xl border border-amber-300/30 bg-[#080a16]/72 backdrop-blur-xs shadow-lg">
                  <button
                    type="button"
                    data-ui-sfx="select"
                    onClick={() => handleCycleLobbyFighter(-1)}
                    aria-label="Previous Warrior"
                    className="w-7 h-7 rounded-lg border border-white/15 bg-white/5 text-amber-200 flex items-center justify-center hover:border-amber-300 cursor-pointer shrink-0"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <div className="min-w-[115px] sm:min-w-[155px]">
                    <div className="text-[9px] font-bold uppercase tracking-[0.18em] text-amber-300/80">
                      Active Yoddha · {lobbySkin?.name || 'Classic'}
                    </div>
                    <div className="font-display-in text-sm sm:text-lg text-amber-100 leading-tight whitespace-normal">
                      {lobbyWarrior.name}
                    </div>
                  </div>
                  <button
                    type="button"
                    data-ui-sfx="select"
                    onClick={() => handleCycleLobbyFighter(1)}
                    aria-label="Next Warrior"
                    className="w-7 h-7 rounded-lg border border-white/15 bg-white/5 text-amber-200 flex items-center justify-center hover:border-amber-300 cursor-pointer shrink-0"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => openArmory('inventory')}
                    title="Open Skins & Cosmetics Inventory"
                    className="h-7 sm:h-8 px-2 sm:px-2.5 rounded-lg border border-emerald-400/50 bg-emerald-500/15 text-emerald-200 text-[10px] sm:text-[11px] font-extrabold flex items-center gap-1 hover:border-emerald-300 hover:bg-emerald-500/25 cursor-pointer transition whitespace-nowrap shrink-0"
                  >
                    <Backpack className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
                    <span>Inventory</span>
                  </button>
                </div>
              </div>

              {/* Right-Side Clean Match Mode Panel */}
              <div className="w-full max-w-[235px] sm:max-w-[270px] flex flex-col gap-2.5 ml-auto bg-[#080a16]/72 backdrop-blur-xs border border-amber-400/25 rounded-2xl p-3 sm:p-4 shadow-2xl">
                <div className="text-[10px] font-bold tracking-[0.22em] text-amber-300/80 uppercase">
                  Select Battle Mode
                </div>
                <button
                  type="button"
                  onClick={() => handleOpenBotMode(false)}
                  className="w-full py-2.5 sm:py-3 px-4 rounded-xl bg-gradient-to-r from-amber-400 via-orange-500 to-rose-600 text-slate-950 font-extrabold tracking-wide text-xs sm:text-sm shadow-[0_8px_24px_rgba(245,158,11,0.35)] hover:brightness-110 active:scale-[0.98] transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Swords className="w-4 h-4" />
                  PLAYER VS BOT
                </button>

                <button
                  type="button"
                  onClick={handleOpenMpLobby}
                  className="w-full py-2.5 px-4 rounded-xl border border-amber-400/45 bg-[#130f22]/90 text-amber-100 font-bold tracking-wide text-xs sm:text-sm hover:border-amber-300 hover:bg-[#1c1632] active:scale-[0.98] transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Users className="w-4 h-4 text-amber-300" />
                  MULTIPLAYER
                </button>

                <button
                  type="button"
                  onClick={() => handleOpenBotMode(true)}
                  className="w-full py-2.5 px-4 rounded-xl border border-cyan-400/35 bg-[#0e1424]/85 text-cyan-100 font-bold tracking-wide text-xs sm:text-sm hover:border-cyan-300 hover:bg-[#131d33] active:scale-[0.98] transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Shield className="w-4 h-4 text-cyan-300" />
                  ABHYAS (PRACTICE)
                </button>
              </div>
            </div>

            {/* Subtle Footer Credit */}
            <div className="max-w-6xl w-full mx-auto flex items-center justify-between text-[10px] sm:text-xs text-amber-100/55 tracking-wider shrink-0">
              <span className="hidden sm:inline">10 Desi Warriors · 3 Indian Arenas</span>
              <span className="ml-auto">
                Developed by <span className="text-amber-300/85 font-semibold">Ohi Purkait</span> ·{' '}
                <span className="text-cyan-300/80">@ohi_purkait13</span>
              </span>
            </div>
          </div>
        );
      })()}

      {/* ==================== 2. SINGLE-SCREEN UNIFIED MULTIPLAYER LOBBY ==================== */}
      {screen === 'mp' && (
        <div className="fixed inset-0 z-10 h-dvh flex items-center justify-center p-2 sm:p-3 bg-[#07060d]/85 backdrop-blur-sm overflow-hidden">
          <div className="w-full max-w-5xl h-[min(510px,calc(100dvh-1rem))] flex flex-col overflow-hidden rounded-2xl border border-amber-400/35 bg-[#100d1d]/95 p-3 sm:p-4 shadow-2xl gap-2.5 sm:gap-3">
            {/* Compact Header */}
            <div className="shrink-0 flex items-center justify-between gap-2 border-b border-amber-400/15 pb-2">
              <div className="min-w-0">
                <h2 className="font-display-in text-lg sm:text-2xl text-amber-300 leading-none truncate">
                  MULTIPLAYER AKHARA
                </h2>
                <p className="text-[10px] sm:text-xs text-amber-100/65 mt-0.5 truncate">
                  Challenge Friends Directly (No Team Code) OR Host / Join via 6-Char Team Code
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  if (outgoingInvite) {
                    void deleteDirectMatchInvite(outgoingInvite.inviteId);
                    setOutgoingInvite(null);
                  }
                  engineRef.current?.cleanupPeerSession();
                  setScreen('menu');
                }}
                className="shrink-0 px-3 py-1.5 rounded-lg border border-amber-400/30 text-xs font-bold text-amber-200 hover:bg-amber-400/10 cursor-pointer"
              >
                Back
              </button>
            </div>

            {/* Side-by-Side Single-Screen Body (Fits 100dvh Landscape Without Outer Scroll) */}
            <div className="flex-1 min-h-0 grid grid-cols-[1.18fr_1fr] gap-2.5 sm:gap-3 overflow-hidden">
              {/* Left Column: Friends List, Add Friend (GC-XXXXXX) & Direct 1v1 Invite */}
              <div className="min-h-0 rounded-xl border border-emerald-400/30 bg-black/35 p-2.5 sm:p-3 flex flex-col overflow-hidden">
                <div className="shrink-0 text-[10px] font-bold tracking-widest uppercase text-emerald-300 mb-1.5">
                  Challenge Friends Directly
                </div>
                <div className="flex-1 min-h-0 overflow-hidden">
                  <FriendsPanel
                    compact
                    playerId={playerId}
                    authUser={authUser}
                    friends={friends}
                    incomingRequests={incomingFriendRequests}
                    authBusy={authBusy}
                    onGmailLogin={handleGmailLogin}
                    onCopyPlayerId={() => void handleCopyPlayerId()}
                    onSendFriendRequest={handleSendFriendRequest}
                    onAcceptRequest={handleAcceptFriendRequest}
                    onDeclineRequest={handleDeclineFriendRequest}
                    onRemoveFriend={handleRemoveFriend}
                    onChallengeFriend={handleChallengeFriend}
                    onRefreshFriends={handleRefreshFriends}
                  />
                </div>
              </div>

              {/* Right Column: Host Team Code & Join by Team Code */}
              <div className="min-h-0 flex flex-col justify-between gap-2 sm:gap-3 overflow-hidden">
                {/* Host Room Card */}
                <div className="flex-1 min-h-0 rounded-xl border border-amber-400/25 bg-black/35 p-2.5 sm:p-3 flex flex-col justify-between">
                  <div className="min-w-0">
                    <span className="text-[10px] font-bold tracking-widest uppercase text-amber-300 block leading-none">
                      Host Private Team Code
                    </span>
                    <div className="font-num text-xl sm:text-3xl font-extrabold tracking-widest text-amber-100 my-1 leading-tight">
                      {mpCode}
                    </div>
                    <p className="text-[10.5px] leading-snug line-clamp-2" style={{ color: hostStatus.color }}>
                      {hostStatus.text}
                    </p>
                  </div>
                  <div className="flex gap-1.5 sm:gap-2 mt-2 shrink-0">
                    <button
                      type="button"
                      onClick={handleCopyCode}
                      className="flex-1 py-1.5 sm:py-2 px-2.5 rounded-lg bg-amber-500/20 border border-amber-400/45 text-amber-200 text-[11px] sm:text-xs font-bold flex items-center justify-center gap-1.5 hover:bg-amber-500/30 cursor-pointer whitespace-nowrap"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      Copy Code
                    </button>
                    <button
                      type="button"
                      onClick={handleRegenCode}
                      title="New Room Code"
                      aria-label="New Room Code"
                      className="py-1.5 sm:py-2 px-2.5 rounded-lg border border-amber-400/25 text-amber-200/80 hover:text-amber-100 cursor-pointer shrink-0"
                    >
                      <RefreshCw className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setSocialHubTab('chat');
                        setSocialHubOpen(true);
                      }}
                      title="Share Code in Global Chat"
                      className="py-1.5 sm:py-2 px-2.5 rounded-lg border border-cyan-400/40 bg-cyan-500/15 text-cyan-200 text-[11px] sm:text-xs font-bold flex items-center gap-1 hover:bg-cyan-500/25 cursor-pointer shrink-0"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      Post
                    </button>
                  </div>
                </div>

                {/* Join Room Card */}
                <form
                  onSubmit={handleJoinRoom}
                  className="shrink-0 rounded-xl border border-cyan-400/25 bg-black/35 p-2.5 sm:p-3 flex flex-col justify-between"
                >
                  <div>
                    <span className="text-[10px] font-bold tracking-widest uppercase text-cyan-300 block leading-none">
                      Join by Team Code
                    </span>
                    <div className="flex gap-1.5 sm:gap-2 mt-1.5 sm:mt-2">
                      <input
                        type="text"
                        value={joinCode}
                        onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                        placeholder="SHD-88K"
                        maxLength={8}
                        className="flex-1 min-w-0 px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-lg bg-[#090712] border border-cyan-400/35 text-amber-100 font-num text-sm sm:text-base tracking-widest uppercase focus:outline-none focus:border-cyan-300"
                      />
                      <button
                        type="submit"
                        className="shrink-0 py-1.5 sm:py-2 px-3.5 sm:px-4 rounded-lg bg-gradient-to-r from-cyan-500 to-teal-500 text-slate-950 text-[11px] sm:text-xs font-extrabold tracking-wider uppercase hover:brightness-110 cursor-pointer"
                      >
                        Join
                      </button>
                    </div>
                    {guestStatus.text && (
                      <p className="text-[10.5px] mt-1.5 leading-snug line-clamp-2" style={{ color: guestStatus.color }}>
                        {guestStatus.text}
                      </p>
                    )}
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==================== 3. FIGHTER & ARENA SELECT (LANDSCAPE FIT, ZERO OVERFLOW) ==================== */}
      {screen === 'select' && (
        <div
          id="screen-select"
          className="fixed inset-0 z-10 h-dvh overflow-hidden flex flex-col p-2 sm:p-3.5 select-screen-shell bg-[#07060d]/88 backdrop-blur-sm"
        >
          <div className="max-w-6xl w-full mx-auto h-full flex flex-col min-h-0">
            {/* Compact Pinned Header */}
            <div className="shrink-0 flex items-center justify-between gap-2 border-b border-amber-400/15 pb-1.5 sm:pb-2 select-screen-header">
              <div className="min-w-0 flex items-baseline gap-2.5 flex-wrap">
                <h2 className="font-display-in text-base sm:text-xl lg:text-2xl text-amber-100 leading-none">
                  CHOOSE YOUR YODDHA &amp; AKHARA
                </h2>
                <span className="text-[9.5px] sm:text-[11px] font-bold tracking-[0.16em] uppercase text-amber-300/80">
                  {practice ? 'Abhyas Practice' : mode === 'mp' ? `Room ${mpCode} · ${mpRole === 'guest' ? 'P2' : 'P1'}` : 'Player vs Bot'}
                </span>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => openArmory('inventory')}
                  className="h-7 sm:h-8 px-2 sm:px-2.5 rounded-lg border border-emerald-400/45 bg-emerald-500/15 text-emerald-200 text-[10px] sm:text-[11px] font-bold flex items-center gap-1 cursor-pointer hover:border-emerald-300 whitespace-nowrap shrink-0"
                >
                  <Backpack className="w-3.5 h-3.5 text-emerald-300" />
                  <span>Inventory</span>
                </button>
                <button
                  type="button"
                  onClick={() => openArmory('store')}
                  className="h-7 sm:h-8 px-2 sm:px-2.5 rounded-lg border border-amber-400/45 bg-amber-500/15 text-amber-200 text-[10px] sm:text-[11px] font-bold flex items-center gap-1 cursor-pointer hover:border-amber-300 whitespace-nowrap shrink-0"
                >
                  <ShoppingBag className="w-3.5 h-3.5 text-amber-300" />
                  <span>Store</span>
                </button>
                <button
                  type="button"
                  onClick={() => setAccountModalOpen(true)}
                  className={`h-7 sm:h-8 px-2 sm:px-2.5 rounded-lg border text-[10px] sm:text-[11px] font-bold flex items-center gap-1 cursor-pointer ${
                    authUser
                      ? 'border-emerald-400/40 bg-emerald-500/12 text-emerald-100 hover:border-emerald-300'
                      : 'border-amber-400/30 bg-[#120e20] text-amber-200 hover:border-amber-300'
                  }`}
                >
                  {authUser ? <UserCheck className="w-3.5 h-3.5 text-emerald-300" /> : <LogIn className="w-3.5 h-3.5 text-amber-300" />}
                  <span className="max-w-[85px] truncate">
                    {authUser ? playerProfile?.akharaName || 'Account' : 'Gmail'}
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => setSettingsOpen(true)}
                  aria-label="Combat Settings"
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg border border-amber-400/30 bg-[#120e20] text-amber-200 flex items-center justify-center cursor-pointer hover:border-amber-300"
                >
                  <Settings className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </button>
                <button
                  type="button"
                  onClick={handleExitToMenu}
                  className="h-7 sm:h-8 px-2.5 sm:px-3 rounded-lg border border-amber-400/30 bg-[#120e20] text-[10px] sm:text-xs font-bold text-amber-200 hover:bg-amber-400/10 cursor-pointer flex items-center"
                >
                  Menu
                </button>
              </div>
            </div>

            {/* 2-Column Landscape Body: Scrollable Roster Left, Loadout + Pinned Start Right */}
            <div className="flex-1 min-h-0 grid grid-cols-[1.1fr_1fr] sm:grid-cols-[1.25fr_1fr] gap-2 sm:gap-3.5 pt-1.5 sm:pt-2.5 select-screen-body">
              {/* 10 Warriors Scrollable Pane */}
              <div className="min-h-0 overflow-y-auto roster-scroll pr-1">
                <div className="grid grid-cols-2 lg:grid-cols-3 gap-1.5 sm:gap-2 content-start pb-1">
                  {FIGHTERS.map((f) => {
                    const isP1 = f.id === p1Id;
                    const isP2 = f.id === p2Id;
                    return (
                      <button
                        key={f.id}
                        type="button"
                        data-ui-sfx="select"
                        onClick={() => handleSelectFighter(f.id)}
                        className={`relative text-left p-1.5 sm:p-2 rounded-xl border transition flex items-center gap-1.5 sm:gap-2 cursor-pointer ${
                          isP1
                            ? 'border-amber-400 bg-amber-500/15 shadow-[0_0_14px_rgba(251,191,36,0.2)]'
                            : isP2
                              ? 'border-cyan-400 bg-cyan-500/12 shadow-[0_0_12px_rgba(34,211,238,0.18)]'
                              : 'border-white/10 bg-[#110e1e]/85 hover:border-amber-300/45'
                        }`}
                      >
                        <FighterFaceThumb
                          cfg={f}
                          skinId={
                            (mode === 'mp' ? (mpRole === 'guest' ? isP2 : isP1) : isP1)
                              ? getEquippedSkinIdForFighter(effectiveProfile, f.id)
                              : undefined
                          }
                        />
                        <div className="min-w-0 flex-1">
                          <div
                            className={`font-display-in text-[11px] sm:text-[13px] leading-[1.12] text-amber-100 whitespace-normal break-words ${
                              isP1 || isP2 ? 'pr-6' : ''
                            }`}
                          >
                            {f.name}
                          </div>
                          <div className="text-[9px] sm:text-[10px] text-amber-200/65 leading-tight mt-0.5 truncate">
                            {f.title}
                          </div>
                        </div>
                        {(isP1 || isP2) && (
                          <span
                            className={`absolute top-1 right-1.5 text-[7.5px] font-extrabold tracking-widest uppercase ${
                              isP1 ? 'text-amber-300' : 'text-cyan-300'
                            }`}
                          >
                            {mode === 'mp'
                              ? isP1
                                ? 'HOST'
                                : 'RIVAL'
                              : isP1
                                ? 'YOU'
                                : practice
                                  ? 'DUMMY'
                                  : 'BOT'}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Right Configuration & Bio Panel with Pinned Start Yudh Button */}
              <div className="min-h-0 flex flex-col justify-between rounded-2xl border border-amber-400/25 bg-[#100d1d]/92 p-1.5 sm:p-2.5 gap-1 sm:gap-1.5 select-right-panel overflow-hidden">
                <div className="flex-1 min-h-0 overflow-y-auto roster-scroll space-y-1 sm:space-y-1.5 select-right-scroll pr-0.5">
                  {/* Slot Toggle (Bot / Practice only) */}
                  {mode === 'bot' && (
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => setSelectSlot(1)}
                        className={`flex-1 py-1 rounded-lg text-[9.5px] sm:text-[11px] font-bold leading-tight border transition cursor-pointer px-1.5 truncate select-chip-btn ${
                          selectSlot === 1
                            ? 'bg-amber-500/25 border-amber-400 text-amber-200'
                            : 'bg-black/30 border-white/10 text-slate-300'
                        }`}
                      >
                        YOU: {getCfgById(p1Id).name}
                      </button>
                      <button
                        type="button"
                        onClick={() => setSelectSlot(2)}
                        className={`flex-1 py-1 rounded-lg text-[9.5px] sm:text-[11px] font-bold leading-tight border transition cursor-pointer px-1.5 truncate select-chip-btn ${
                          selectSlot === 2
                            ? 'bg-cyan-500/25 border-cyan-400 text-cyan-200'
                            : 'bg-black/30 border-white/10 text-slate-300'
                        }`}
                      >
                        {practice ? 'DUMMY' : 'BOT'}: {getCfgById(p2Id).name}
                      </button>
                      <button
                        type="button"
                        data-ui-sfx="select"
                        onClick={handleRandomOpponent}
                        title="Random Rival"
                        className="p-1 rounded-lg border border-amber-400/30 bg-black/35 text-amber-200 hover:bg-amber-400/15 cursor-pointer shrink-0"
                      >
                        <Shuffle className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}

                  {/* Active Fighter Bio */}
                  <div className="border-t border-b border-white/10 py-1 select-bio-box shrink-0">
                    <div className="flex items-center justify-between gap-1.5">
                      <div className="flex items-baseline gap-1.5 min-w-0">
                        <h3 className="font-display-in text-[12.5px] sm:text-base leading-tight text-amber-300 whitespace-normal break-words">
                          {activeBioCfg.name}
                        </h3>
                        <span className="text-[9px] sm:text-[10px] text-cyan-300/85 font-semibold truncate">
                          {activeBioCfg.title}
                        </span>
                      </div>
                      <span className="shrink-0 px-1.5 py-[1px] rounded bg-emerald-500/15 border border-emerald-400/40 text-[7.5px] font-extrabold tracking-wider uppercase text-emerald-300">
                        Fair Power
                      </span>
                    </div>
                    <p className="hidden lg:block text-[10px] italic text-amber-100/70 mt-0.5 line-clamp-1 select-bio-quote">
                      “{activeBioCfg.quote}”
                    </p>
                    <div className="grid grid-cols-3 gap-1 mt-1 text-[9px] sm:text-[9.5px] select-skill-grid">
                      <div className="bg-black/35 rounded-md px-1.5 py-0.5 sm:py-1 border border-white/5 select-skill-card">
                        <div className="text-amber-300/75 font-bold uppercase text-[7px] sm:text-[7.5px] leading-none">
                          S1 · Long
                        </div>
                        <div className="text-amber-50 font-semibold leading-tight mt-0.5 truncate">{activeBioCfg.sp1Name}</div>
                      </div>
                      <div className="bg-black/35 rounded-md px-1.5 py-0.5 sm:py-1 border border-white/5 select-skill-card">
                        <div className="text-orange-300/75 font-bold uppercase text-[7px] sm:text-[7.5px] leading-none">
                          S2 · Close
                        </div>
                        <div className="text-amber-50 font-semibold leading-tight mt-0.5 truncate">{activeBioCfg.sp2Name}</div>
                      </div>
                      <div className="bg-black/35 rounded-md px-1.5 py-0.5 sm:py-1 border border-white/5 select-skill-card">
                        <div className="text-cyan-300/75 font-bold uppercase text-[7px] sm:text-[7.5px] leading-none">
                          Ult · 100%
                        </div>
                        <div className="text-amber-50 font-semibold leading-tight mt-0.5 truncate">{activeBioCfg.rageName}</div>
                      </div>
                    </div>
                  </div>

                  {/* Bot Difficulty (hidden cleanly in Practice Mode and MP) */}
                  {mode === 'bot' && !practice && (
                    <div className="shrink-0">
                      <div className="text-[9px] sm:text-[10px] font-bold tracking-wider uppercase text-amber-200/70 mb-0.5 sm:mb-1 leading-none">
                        Bot Difficulty
                      </div>
                      <div className="grid grid-cols-3 gap-1.5">
                        {(['easy', 'normal', 'hard'] as Difficulty[]).map((d) => (
                          <button
                            key={d}
                            type="button"
                            onClick={() => setDifficulty(d)}
                            className={`py-1 sm:py-1.5 rounded-lg text-[10px] sm:text-xs font-bold uppercase border transition cursor-pointer select-chip-btn ${
                              difficulty === d
                                ? 'bg-amber-500/25 border-amber-400 text-amber-200'
                                : 'bg-black/30 border-white/10 text-slate-400 hover:text-amber-100'
                            }`}
                          >
                            {d}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Arena Picker */}
                  <div className="shrink-0">
                    <div className="text-[9px] sm:text-[10px] font-bold tracking-wider uppercase text-amber-200/70 mb-0.5 sm:mb-1 leading-none">
                      Desi Battleground
                    </div>
                    <div className="grid grid-cols-3 gap-1.5">
                      {arenaList.map((ar) => {
                        const desc =
                          ar.id === 'chandni'
                            ? 'Old Delhi Night'
                            : ar.id === 'howrah'
                              ? 'Monsoon Steel'
                              : 'Agni Corner';
                        return (
                          <button
                            key={ar.id}
                            type="button"
                            onClick={() => handleSelectArena(ar.id)}
                            className={`p-1 sm:p-1.5 rounded-lg border text-left transition cursor-pointer select-arena-card ${
                              arenaId === ar.id
                                ? 'bg-amber-500/20 border-amber-400 text-amber-100'
                                : 'bg-black/30 border-white/10 text-slate-300 hover:border-amber-400/40'
                            }`}
                          >
                            <div className="text-[10px] sm:text-[11px] font-bold leading-tight truncate">{ar.name}</div>
                            <div className="text-[8.5px] sm:text-[9px] text-amber-300/75 leading-tight truncate">{desc}</div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* Pinned Start Yudh Footer (always inside viewport) */}
                <div className="shrink-0 pt-1 border-t border-white/10 select-start-footer">
                  {mode === 'mp' && mpRole === 'guest' ? (
                    <div className="py-1.5 sm:py-2 px-3 rounded-xl border border-cyan-400/35 bg-cyan-500/10 text-center text-xs font-bold text-cyan-200">
                      Waiting for Host to press Start Yudh...
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={handleStartFight}
                      className="w-full py-2 sm:py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 via-orange-500 to-rose-600 text-slate-950 font-extrabold tracking-wider text-sm sm:text-base shadow-[0_6px_22px_rgba(245,158,11,0.35)] hover:brightness-110 active:scale-[0.98] transition cursor-pointer select-start-btn"
                    >
                      START YUDH!
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==================== 4. INDIAN-STYLE GAMEPLAY HUD & CONTROLS ==================== */}
      {screen === 'combat' && (
        <CombatHud
          hud={hud}
          announcement={announcement}
          controlConfig={controlConfig}
          customizing={customizing}
          onUpdateControlConfig={updateControlConfig}
          onResetControls={resetControlConfig}
          onToggleCustomizing={(active) => setCustomizing(active)}
          onOpenKeybinds={() => setKeybindsOpen(true)}
          onJoystick={handleJoystick}
          onAction={handleCombatAction}
          onBlockChange={handleBlockChange}
          onEmote={handleEmote}
          onPause={() => setSettingsOpen(true)}
        />
      )}

      {/* ==================== COMBAT SETTINGS / PAUSE COMMAND CENTER ==================== */}
      {settingsOpen && (
        <div className="fixed inset-0 z-40 flex items-center justify-center p-2.5 sm:p-4 bg-black/80 backdrop-blur-xs">
          <div className="w-full max-w-2xl max-h-[calc(100dvh-1rem)] flex flex-col overflow-hidden rounded-2xl border-2 border-amber-400/55 bg-[#0d0a18]/98 shadow-[0_0_50px_rgba(245,158,11,0.25)]">
            {/* Fixed Top Tactical Header */}
            <div className="shrink-0 flex items-center justify-between px-4 py-2.5 border-b border-amber-400/20 bg-gradient-to-r from-amber-500/15 via-transparent to-rose-500/15">
              <div className="flex items-center gap-2.5">
                <Swords className="w-4 h-4 text-amber-400" />
                <h3 className="font-display-in text-lg sm:text-xl tracking-wider text-amber-300">
                  {screen === 'combat' ? 'YUDH PAUSED · COMBAT OPTIONS' : 'AKHARA COMBAT SETTINGS'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSettingsOpen(false)}
                aria-label="Close Settings"
                className="w-8 h-8 rounded-lg border border-amber-400/30 bg-black/40 flex items-center justify-center text-amber-200 hover:bg-amber-400/15 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Scrollable 2-Column Combat Body (2 columns across all landscape widths) */}
            <div className="flex-1 overflow-y-auto roster-scroll px-3.5 sm:px-4 py-2.5 sm:py-3 grid grid-cols-2 gap-2.5 sm:gap-3 text-xs">
              {/* LEFT COLUMN: AUDIO, DISPLAY & DIFFICULTY */}
              <div className="space-y-2">
                <div className="text-[10px] font-extrabold tracking-[0.2em] uppercase text-amber-300/80">
                  Audio &amp; Arena Display
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      const next = !bgmOn;
                      setBgmOn(next);
                      sound.setBgm(next);
                    }}
                    className={`px-2.5 py-2 rounded-xl border text-left transition cursor-pointer ${
                      bgmOn
                        ? 'bg-amber-500/15 border-amber-400/60 text-amber-100'
                        : 'bg-black/40 border-white/10 text-slate-400'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold flex items-center gap-1">
                        {bgmOn ? <Volume2 className="w-3.5 h-3.5 text-amber-300" /> : <VolumeX className="w-3.5 h-3.5" />}
                        Indian BGM
                      </span>
                      <span className={`font-num text-[10px] font-black ${bgmOn ? 'text-amber-300' : 'text-slate-500'}`}>
                        {bgmOn ? 'ON' : 'OFF'}
                      </span>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const next = !sfxOn;
                      setSfxOn(next);
                      sound.setSfx(next);
                    }}
                    className={`px-2.5 py-2 rounded-xl border text-left transition cursor-pointer ${
                      sfxOn
                        ? 'bg-amber-500/15 border-amber-400/60 text-amber-100'
                        : 'bg-black/40 border-white/10 text-slate-400'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold">Combat SFX</span>
                      <span className={`font-num text-[10px] font-black ${sfxOn ? 'text-amber-300' : 'text-slate-500'}`}>
                        {sfxOn ? 'ON' : 'OFF'}
                      </span>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const next = !voiceOn;
                      setVoiceOn(next);
                      sound.setVoice(next);
                    }}
                    className={`px-2.5 py-2 rounded-xl border text-left transition cursor-pointer ${
                      voiceOn
                        ? 'bg-amber-500/15 border-amber-400/60 text-amber-100'
                        : 'bg-black/40 border-white/10 text-slate-400'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold">Win Stinger</span>
                      <span className={`font-num text-[10px] font-black ${voiceOn ? 'text-amber-300' : 'text-slate-500'}`}>
                        {voiceOn ? 'ON' : 'OFF'}
                      </span>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={toggleFullscreen}
                    className="px-2.5 py-2 rounded-xl border border-cyan-400/40 bg-cyan-500/10 text-cyan-100 text-left hover:bg-cyan-500/20 transition cursor-pointer"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold">Fullscreen</span>
                      <span className="font-num text-[10px] font-black text-cyan-300">
                        {isFullscreen ? 'EXIT' : 'ENTER'}
                      </span>
                    </div>
                  </button>
                </div>

                {/* BGM & SFX Volume Sliders */}
                <div className="p-2 rounded-xl bg-black/40 border border-white/10 space-y-1.5">
                  <label className="flex flex-col gap-0.5">
                    <span className="text-amber-200/90 text-[11px] font-semibold flex justify-between">
                      <span>BGM Volume</span>
                      <span className="font-num text-amber-300">{Math.round(bgmVol * 100)}%</span>
                    </span>
                    <input
                      type="range"
                      min={0}
                      max={100}
                      step={5}
                      value={Math.round(bgmVol * 100)}
                      onChange={(e) => {
                        const pct = parseInt(e.target.value, 10);
                        const v = Math.max(0, Math.min(1, pct / 100));
                        setBgmVol(v);
                        if (v > 0 && !bgmOn) {
                          setBgmOn(true);
                          sound.setBgm(true);
                        }
                        sound.setBgmVolume(v);
                      }}
                      className="accent-amber-400 cursor-pointer h-3"
                    />
                  </label>
                  <label className="flex flex-col gap-0.5">
                    <span className="text-amber-200/90 text-[11px] font-semibold flex justify-between">
                      <span>SFX Volume</span>
                      <span className="font-num text-cyan-300">{Math.round(sfxVol * 100)}%</span>
                    </span>
                    <input
                      type="range"
                      min={0}
                      max={100}
                      step={5}
                      value={Math.round(sfxVol * 100)}
                      onChange={(e) => {
                        const pct = parseInt(e.target.value, 10);
                        const v = Math.max(0, Math.min(1, pct / 100));
                        setSfxVol(v);
                        if (v > 0 && !sfxOn) {
                          setSfxOn(true);
                          sound.setSfx(true);
                        }
                        sound.setSfxVolume(v);
                      }}
                      className="accent-cyan-400 cursor-pointer h-3"
                    />
                  </label>
                </div>

                {/* Live Bot Difficulty Selector right in Combat Settings */}
                {mode === 'bot' && !practice && (
                  <div className="pt-1">
                    <div className="text-[10px] font-extrabold tracking-[0.2em] uppercase text-amber-300/80 mb-1.5">
                      AI Opponent Difficulty
                    </div>
                    <div className="grid grid-cols-3 gap-1.5">
                      {(['easy', 'normal', 'hard'] as Difficulty[]).map((d) => (
                        <button
                          key={d}
                          type="button"
                          onClick={() => {
                            setDifficulty(d);
                            showToast(`Bot Difficulty: ${d.toUpperCase()}`);
                          }}
                          className={`py-1.5 rounded-lg text-[10px] font-extrabold uppercase border transition cursor-pointer ${
                            difficulty === d
                              ? 'bg-amber-500/25 border-amber-400 text-amber-200'
                              : 'bg-black/40 border-white/10 text-slate-400 hover:text-amber-100'
                          }`}
                        >
                          {d}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                {/* Developer Mode Activate / Deactivate Card */}
                <div className="pt-1 border-t border-white/10">
                  <div
                    className={`p-2 rounded-xl border space-y-1.5 ${
                      isDeveloperActive
                        ? 'border-emerald-400/45 bg-emerald-500/8'
                        : 'border-white/10 bg-black/35'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="flex items-center gap-1.5 text-[11px] font-bold text-amber-200/90">
                        <Code2 className="w-3.5 h-3.5 text-amber-300 shrink-0" />
                        Developer
                      </span>
                      {isDeveloperActive ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-gradient-to-r from-emerald-400 to-amber-300 text-slate-950 text-[9.5px] font-black uppercase tracking-wider">
                          ACTIVE · DEV ∞
                        </span>
                      ) : (
                        <span className="text-[9.5px] font-extrabold uppercase tracking-wider text-slate-400">
                          Secret Code
                        </span>
                      )}
                    </div>

                    {isDeveloperActive ? (
                      <div className="space-y-1.5 pt-0.5">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-[10px] text-emerald-300 font-semibold leading-tight">
                            Unlimited currencies &amp; DEV badge enabled.
                          </span>
                          <button
                            type="button"
                            data-ui-sfx="none"
                            disabled={devUnlockBusy}
                            onClick={() => void handleDeactivateDeveloper()}
                            className="px-2.5 py-1 rounded-md border border-rose-400/75 bg-rose-500/22 text-rose-200 hover:bg-rose-500 hover:text-white font-extrabold text-[10px] uppercase tracking-wider transition disabled:opacity-50 cursor-pointer shrink-0"
                          >
                            {devUnlockBusy ? '...' : 'DEACTIVATE'}
                          </button>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            setSettingsOpen(false);
                            openMailboxModal('send');
                          }}
                          className="w-full py-1.5 px-2.5 rounded-lg border border-cyan-400/45 bg-cyan-500/15 text-cyan-100 hover:bg-cyan-500/25 font-extrabold text-[10.5px] flex items-center justify-center gap-1.5 cursor-pointer transition"
                        >
                          <Send className="w-3 h-3 text-cyan-300" />
                          📤 Send Gift Mail (DEV)
                        </button>
                      </div>
                    ) : (
                      <form onSubmit={handleUnlockDeveloper} className="space-y-1">
                        <div className="flex items-center gap-1.5">
                          <input
                            type="password"
                            value={devCodeInput}
                            onChange={(e) => {
                              setDevCodeInput(e.target.value);
                              if (devUnlockError) setDevUnlockError(null);
                            }}
                            placeholder="Enter Dev Code..."
                            className="flex-1 min-w-0 px-2 py-1 rounded-md bg-black/60 border border-amber-400/35 text-[11px] text-amber-100 focus:outline-none focus:border-amber-300"
                          />
                          <button
                            type="submit"
                            data-ui-sfx="none"
                            disabled={devUnlockBusy}
                            className="px-2.5 py-1 rounded-md bg-amber-400 text-slate-950 font-extrabold text-[10px] uppercase tracking-wider hover:brightness-110 disabled:opacity-50 cursor-pointer shrink-0"
                          >
                            {devUnlockBusy ? '...' : 'ACTIVATE'}
                          </button>
                        </div>
                        {devUnlockError && <div className="text-[10px] text-rose-300 font-semibold">{devUnlockError}</div>}
                      </form>
                    )}
                  </div>
                </div>
              </div>

              {/* RIGHT COLUMN: COMBAT CONTROLS CUSTOMIZER */}
              <div className="space-y-2">
                <div className="text-[10px] font-extrabold tracking-[0.2em] uppercase text-cyan-300/85">
                  Combat Controls &amp; Layout
                </div>

                <div className="p-2.5 rounded-xl bg-black/40 border border-white/10 space-y-2">
                  <label className="flex flex-col gap-1">
                    <span className="text-amber-200/90 font-semibold flex justify-between">
                      <span>Control Button Size</span>
                      <span className="font-num text-amber-300">{Math.round(controlConfig.scale * 100)}%</span>
                    </span>
                    <input
                      type="range"
                      min={0.75}
                      max={1.35}
                      step={0.05}
                      value={controlConfig.scale}
                      onChange={(e) =>
                        updateControlConfig({ ...controlConfig, scale: parseFloat(e.target.value) })
                      }
                      className="accent-amber-400 cursor-pointer h-3"
                    />
                  </label>

                  <div className="grid grid-cols-2 gap-2 pt-0.5">
                    {screen === 'combat' ? (
                      <button
                        type="button"
                        onClick={() => {
                          setSettingsOpen(false);
                          setCustomizing(true);
                        }}
                        className="py-2 px-2.5 rounded-lg bg-amber-500/20 border border-amber-400/50 text-amber-200 font-bold flex items-center justify-center gap-1.5 hover:bg-amber-500/30 cursor-pointer"
                      >
                        <Sliders className="w-3.5 h-3.5" />
                        Drag Layout
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={resetControlConfig}
                        className="py-2 px-2.5 rounded-lg border border-rose-400/40 text-rose-200 font-bold flex items-center justify-center gap-1.5 hover:bg-rose-500/15 cursor-pointer"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        Reset HUD
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => setKeybindsOpen(true)}
                      className="py-2 px-2.5 rounded-lg bg-cyan-500/15 border border-cyan-400/45 text-cyan-100 font-bold flex items-center justify-center gap-1.5 hover:bg-cyan-500/25 cursor-pointer"
                    >
                      <Keyboard className="w-3.5 h-3.5" />
                      Keybinds
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Fixed Combat Action Footer (Single horizontal row, always visible inside screen!) */}
            {screen === 'combat' ? (
              <div className="shrink-0 px-3.5 sm:px-4 py-2 border-t border-white/10 bg-black/50 flex items-center gap-1.5 sm:gap-2">
                <button
                  type="button"
                  onClick={() => setSettingsOpen(false)}
                  className="flex-1 py-2 px-3 rounded-xl bg-gradient-to-r from-amber-500 via-orange-500 to-rose-600 text-slate-950 font-extrabold text-[11px] sm:text-sm tracking-wide whitespace-nowrap cursor-pointer"
                >
                  RESUME YUDH
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSettingsOpen(false);
                    engineRef.current?.beginMatch();
                  }}
                  className="py-2 px-2.5 sm:px-3 rounded-xl border border-amber-400/40 text-amber-200 text-[11px] sm:text-xs font-bold hover:bg-amber-400/15 whitespace-nowrap cursor-pointer"
                >
                  Restart
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSettingsOpen(false);
                    setScreen('select');
                  }}
                  className="py-2 px-2.5 sm:px-3 rounded-xl border border-cyan-400/35 text-cyan-200 text-[11px] sm:text-xs font-bold hover:bg-cyan-400/15 whitespace-nowrap cursor-pointer"
                >
                  Fighters
                </button>
                <button
                  type="button"
                  onClick={handleExitToMenu}
                  className="py-2 px-2.5 sm:px-3 rounded-xl border border-rose-400/40 text-rose-200 text-[11px] sm:text-xs font-bold hover:bg-rose-400/15 whitespace-nowrap cursor-pointer"
                >
                  Menu
                </button>
              </div>
            ) : (
              <div className="shrink-0 px-3.5 sm:px-4 py-2 border-t border-white/10 bg-black/50 flex justify-end">
                <button
                  type="button"
                  onClick={() => setSettingsOpen(false)}
                  className="px-6 py-2 rounded-xl bg-gradient-to-r from-amber-500 via-orange-500 to-rose-600 text-slate-950 font-extrabold text-xs tracking-wide cursor-pointer"
                >
                  SAVE &amp; CLOSE
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ==================== KEYBOARD & CONTROL CUSTOMIZER MODAL ==================== */}
      {keybindsOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-black/80 backdrop-blur-xs">
          <div className="w-full max-w-2xl max-h-[calc(100dvh-1rem)] flex flex-col overflow-hidden rounded-2xl border-2 border-cyan-400/45 bg-[#100d1d] shadow-2xl">
            {/* Fixed Header */}
            <div className="shrink-0 flex items-center justify-between px-4 py-2.5 border-b border-white/10">
              <div>
                <h3 className="font-display-in text-lg sm:text-xl text-cyan-300">CUSTOMIZE KEYS &amp; SIZE</h3>
                <p className="text-[10px] sm:text-[11px] text-amber-100/65">Click any key to rebind for PC/Mac</p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setListeningAction(null);
                  setKeybindsOpen(false);
                }}
                className="w-8 h-8 rounded-lg border border-white/15 flex items-center justify-center text-slate-300 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Scrollable Body */}
            <div className="flex-1 overflow-y-auto roster-scroll px-4 py-3 space-y-3">
              <div className="grid grid-cols-3 gap-2.5 p-2.5 rounded-xl bg-black/35 border border-white/10 text-xs">
                <label className="flex flex-col gap-1">
                  <span className="text-amber-200/85 font-semibold flex justify-between">
                    <span>All Size</span>
                    <span className="font-num text-amber-300">{Math.round(controlConfig.scale * 100)}%</span>
                  </span>
                  <input
                    type="range"
                    min={0.75}
                    max={1.35}
                    step={0.05}
                    value={controlConfig.scale}
                    onChange={(e) =>
                      updateControlConfig({ ...controlConfig, scale: parseFloat(e.target.value) })
                    }
                    className="accent-amber-400 cursor-pointer h-3"
                  />
                </label>
                <label className="flex flex-col gap-1">
                  <span className="text-cyan-200/90 font-semibold flex justify-between">
                    <span>Joystick</span>
                    <span className="font-num text-cyan-300">{Math.round((controlConfig.dpadScale || 1) * 100)}%</span>
                  </span>
                  <input
                    type="range"
                    min={0.75}
                    max={1.45}
                    step={0.05}
                    value={controlConfig.dpadScale || 1}
                    onChange={(e) =>
                      updateControlConfig({ ...controlConfig, dpadScale: parseFloat(e.target.value) })
                    }
                    className="accent-cyan-400 cursor-pointer h-3"
                  />
                </label>
                <label className="flex flex-col gap-1">
                  <span className="text-amber-200/85 font-semibold flex justify-between">
                    <span>Opacity</span>
                    <span className="font-num text-amber-300">{Math.round(controlConfig.opacity * 100)}%</span>
                  </span>
                  <input
                    type="range"
                    min={0.35}
                    max={1.0}
                    step={0.05}
                    value={controlConfig.opacity}
                    onChange={(e) =>
                      updateControlConfig({ ...controlConfig, opacity: parseFloat(e.target.value) })
                    }
                    className="accent-amber-400 cursor-pointer h-3"
                  />
                </label>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                {(Object.keys(ACTION_LABELS) as CombatButtonKind[]).map((kind) => {
                  const isListening = listeningAction === kind;
                  return (
                    <div
                      key={kind}
                      className="flex items-center justify-between gap-2 px-3 py-1.5 rounded-xl bg-black/35 border border-white/10"
                    >
                      <div className="min-w-0">
                        <div className="font-bold text-amber-100">{ACTION_LABELS[kind].name}</div>
                        <div className="text-[10px] text-slate-400 truncate">{ACTION_LABELS[kind].desc}</div>
                      </div>
                      <button
                        type="button"
                        onClick={() => setListeningAction(isListening ? null : kind)}
                        className={`min-w-[62px] px-2 py-1 rounded-lg border font-num text-xs font-extrabold cursor-pointer transition ${
                          isListening
                            ? 'bg-amber-400 text-slate-950 border-yellow-200 animate-pulse'
                            : 'bg-[#090712] border-cyan-400/45 text-cyan-200 hover:border-cyan-300'
                        }`}
                      >
                        {isListening ? 'PRESS...' : formatKeyLabel(controlConfig.keyBinds[kind])}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Fixed Footer */}
            <div className="shrink-0 px-4 py-2.5 border-t border-white/10 bg-black/40 flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={resetControlConfig}
                className="px-3 py-1.5 rounded-xl border border-rose-400/40 text-rose-200 text-xs font-bold flex items-center gap-1.5 hover:bg-rose-500/15 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Reset All
              </button>
              <button
                type="button"
                onClick={() => {
                  setListeningAction(null);
                  setKeybindsOpen(false);
                }}
                className="px-5 py-1.5 rounded-xl bg-gradient-to-r from-cyan-400 to-teal-400 text-slate-950 text-xs font-extrabold cursor-pointer"
              >
                Save Keys
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================== DISTINCT WINNER vs LOSER MATCH RESULT POPUPS ==================== */}
      {victory && (() => {
        const isLocalWinner = victory.winnerSlot === victory.localSlot;
        const allWinnerPoses = getVictoryPosesForFighter(victory.winnerId);
        const winnerPoses = allWinnerPoses.filter((p) =>
          isVictoryPoseUnlocked(victory.winnerId, p.id, effectiveProfile?.unlockedPoses),
        );
        const candidatePoseId = winnerPoseOverride || getSelectedVictoryPoseId(victory.winnerId);
        const safePoseId = winnerPoses.some((p) => p.id === candidatePoseId)
          ? candidatePoseId
          : allWinnerPoses[0].id;
        const winMeta = getVictoryPoseById(victory.winnerId, safePoseId);
        const cycleWinnerPose = (delta: number) => {
          if (winnerPoses.length <= 1) return;
          const curIdx = Math.max(0, winnerPoses.findIndex((p) => p.id === winMeta.id));
          const next = winnerPoses[(curIdx + delta + winnerPoses.length) % winnerPoses.length];
          saveSelectedVictoryPoseId(victory.winnerId, next.id);
          setWinnerPoseOverride(next.id);
          sound.ensureAudio();
        };
        const localScore = victory.localSlot === 1 ? victory.p1Wins : victory.p2Wins;
        const rivalScore = victory.localSlot === 1 ? victory.p2Wins : victory.p1Wins;

        return isLocalWinner ? (
          /* WINNER CELEBRATION POPUP */
          <div className="fixed inset-0 z-40 flex items-center justify-center p-2.5 sm:p-4 bg-black/78 backdrop-blur-xs">
            <div className="w-full max-w-xl max-h-[calc(100dvh-1rem)] overflow-y-auto roster-scroll rounded-2xl border-2 border-amber-400/75 bg-gradient-to-b from-[#1a122e] via-[#120d21] to-[#0c0916] p-4 sm:p-5 shadow-[0_0_65px_rgba(245,158,11,0.4)]">
              <div className="grid grid-cols-[0.95fr_1.15fr] gap-3 sm:gap-5 items-center">
                <div className="rounded-xl border border-amber-400/35 bg-[#080611] p-2 flex flex-col items-center">
                  <ResultPoseCanvas
                    fighterId={victory.winnerId}
                    poseMode="victory"
                    skinId={victory.winnerSlot === 1 ? victory.p1SkinId : victory.p2SkinId}
                    auraId={victory.winnerSlot === 1 ? victory.p1AuraId : victory.p2AuraId}
                    poseId={winMeta.id}
                    width={240}
                    height={185}
                    className="w-full h-[155px] sm:h-[185px] object-contain"
                  />
                  <div className="mt-1 flex items-center justify-center gap-1 w-full">
                    <button
                      type="button"
                      data-ui-sfx="select"
                      onClick={() => cycleWinnerPose(-1)}
                      aria-label="Previous Victory Pose"
                      className="px-1.5 py-0.5 rounded bg-black/60 border border-amber-400/35 text-[9.5px] font-extrabold text-amber-200 hover:bg-amber-400/20 cursor-pointer"
                    >
                      ◀
                    </button>
                    <span className="px-2 py-0.5 rounded bg-amber-400/15 border border-amber-300/45 text-[9.5px] font-extrabold uppercase tracking-wider text-amber-200 truncate">
                      {winMeta.poseName}
                    </span>
                    <button
                      type="button"
                      data-ui-sfx="select"
                      onClick={() => cycleWinnerPose(1)}
                      aria-label="Next Victory Pose"
                      className="px-1.5 py-0.5 rounded bg-black/60 border border-amber-400/35 text-[9.5px] font-extrabold text-amber-200 hover:bg-amber-400/20 cursor-pointer"
                    >
                      ▶
                    </button>
                  </div>
                </div>

                <div className="text-left space-y-2">
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-400/20 border border-amber-300/60 text-[10px] font-black tracking-[0.2em] uppercase text-amber-200">
                    <Crown className="w-3.5 h-3.5 text-yellow-300" />
                    Aap Jeet Gaye · Vijeta!
                  </div>
                  <h2 className="font-display-in text-2xl sm:text-4xl text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-amber-400 to-emerald-300 leading-none">
                    {victory.winnerName}
                  </h2>
                  <div className="text-xs font-semibold text-cyan-300">{victory.winnerTitle}</div>
                  <p className="text-xs italic text-amber-100/80">“{victory.quote}”</p>

                  <div className="grid grid-cols-2 gap-1.5 text-center pt-1 font-num">
                    <div className="p-1.5 rounded-lg bg-black/45 border border-emerald-400/30">
                      <div className="text-[9px] text-emerald-300/80 uppercase">Rounds</div>
                      <div className="text-sm font-black text-emerald-300">
                        {localScore} - {rivalScore}
                      </div>
                    </div>
                    <div className="p-1.5 rounded-lg bg-black/45 border border-cyan-400/30">
                      <div className="text-[9px] text-cyan-300/80 uppercase">Max Combo</div>
                      <div className="text-sm font-black text-cyan-300">{victory.localMaxCombo}x</div>
                    </div>
                  </div>

                  {authUser && playerProfile && !practice ? (
                    <div className="px-2.5 py-1 rounded-lg border border-emerald-400/35 bg-emerald-500/12 text-[10.5px] text-emerald-200 flex items-center justify-between gap-1.5">
                      <span className="inline-flex items-center gap-1.5 truncate">
                        <Trophy className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
                        +100 Rank · {playerProfile.wins}W / {playerProfile.losses}L
                      </span>
                      <span className="inline-flex items-center gap-1 text-cyan-300 font-extrabold shrink-0 tabular-nums">
                        <Coins className="w-3 h-3" />+{lastFutiKodiEarned || 80} Futi Kodi
                      </span>
                    </div>
                  ) : !authUser && !practice ? (
                    <button
                      type="button"
                      onClick={handleGmailLogin}
                      disabled={authBusy}
                      className="w-full py-1.5 px-2.5 rounded-lg border border-amber-400/35 bg-amber-500/10 text-amber-200 text-[10.5px] font-bold hover:bg-amber-500/20 cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <LogIn className="w-3.5 h-3.5" />
                      {authBusy ? 'Connecting...' : 'Gmail Login to save Futi Kodi & Rank'}
                    </button>
                  ) : null}

                  <div className="grid gap-1.5 pt-1">
                    <button
                      type="button"
                      onClick={() => {
                        setVictory(null);
                        if (mode === 'mp') engineRef.current?.sendNetMsg({ type: 'REMATCH_SYNC' });
                        engineRef.current?.beginMatch();
                      }}
                      className="w-full py-2 rounded-xl bg-gradient-to-r from-amber-500 via-orange-500 to-emerald-400 text-slate-950 font-extrabold text-xs sm:text-sm tracking-wide cursor-pointer"
                    >
                      JEET KA REMATCH!
                    </button>
                    <div className="grid grid-cols-3 gap-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          setPoseGalleryFighterId(victory.winnerId);
                          setPoseGalleryOpen(true);
                        }}
                        className="py-1.5 rounded-lg border border-amber-400/40 text-amber-200 text-[10.5px] font-bold hover:bg-amber-400/10 cursor-pointer flex items-center justify-center gap-1"
                      >
                        <Sparkles className="w-3 h-3" />
                        Poses
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setVictory(null);
                          setScreen('select');
                        }}
                        className="py-1.5 rounded-lg border border-cyan-400/35 text-cyan-200 text-[10.5px] font-bold hover:bg-cyan-400/10 cursor-pointer"
                      >
                        Yoddha
                      </button>
                      <button
                        type="button"
                        onClick={handleExitToMenu}
                        className="py-1.5 rounded-lg border border-white/15 text-slate-300 text-[10.5px] font-bold hover:bg-white/10 cursor-pointer"
                      >
                        Menu
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* LOSER / DEFEAT COMEBACK POPUP (Distinct screen for defeated player) */
          <div className="fixed inset-0 z-40 flex items-center justify-center p-2.5 sm:p-4 bg-black/82 backdrop-blur-xs">
            <div className="w-full max-w-xl max-h-[calc(100dvh-1rem)] overflow-y-auto roster-scroll rounded-2xl border-2 border-rose-500/65 bg-gradient-to-b from-[#240d19] via-[#130914] to-[#09060d] p-4 sm:p-5 shadow-[0_0_65px_rgba(244,63,94,0.35)]">
              <div className="grid grid-cols-[0.95fr_1.15fr] gap-3 sm:gap-5 items-center">
                <div className="rounded-xl border border-rose-500/35 bg-[#0a050b] p-2 flex flex-col items-center">
                  <ResultPoseCanvas
                    fighterId={victory.loserId}
                    poseMode="defeat"
                    skinId={victory.winnerSlot === 1 ? victory.p2SkinId : victory.p1SkinId}
                    auraId={victory.winnerSlot === 1 ? victory.p2AuraId : victory.p1AuraId}
                    width={240}
                    height={185}
                    className="w-full h-[155px] sm:h-[185px] object-contain"
                  />
                  <span className="mt-1 px-2 py-0.5 rounded bg-rose-500/15 border border-rose-400/40 text-[9.5px] font-extrabold uppercase tracking-wider text-rose-200">
                    Knockout · Haar Gaye
                  </span>
                </div>

                <div className="text-left space-y-2">
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-rose-500/20 border border-rose-400/60 text-[10px] font-black tracking-[0.2em] uppercase text-rose-200">
                    <Swords className="w-3.5 h-3.5 text-rose-300" />
                    Parajay · Comeback Karo!
                  </div>
                  <h2 className="font-display-in text-2xl sm:text-3xl text-rose-200 leading-none">
                    {victory.loserName} DEFEATED
                  </h2>
                  <div className="text-xs font-semibold text-amber-300/90">
                    Winner: {victory.winnerName} ({localScore} - {rivalScore})
                  </div>
                  <p className="text-xs text-rose-100/75 leading-snug">
                    “{victory.quote}” — Dhal (Shield) aur Counter combos practice karke badla lo!
                  </p>

                  <div className="grid grid-cols-2 gap-1.5 text-center pt-1 font-num">
                    <div className="p-1.5 rounded-lg bg-black/45 border border-rose-400/30">
                      <div className="text-[9px] text-rose-300/80 uppercase">Score</div>
                      <div className="text-sm font-black text-rose-300">
                        {localScore} - {rivalScore}
                      </div>
                    </div>
                    <div className="p-1.5 rounded-lg bg-black/45 border border-cyan-400/30">
                      <div className="text-[9px] text-cyan-300/80 uppercase">Your Combo</div>
                      <div className="text-sm font-black text-cyan-300">{victory.localMaxCombo}x</div>
                    </div>
                  </div>
                  {authUser && !practice && (
                    <div className="px-2.5 py-1 rounded-lg border border-cyan-400/30 bg-cyan-500/10 text-[10.5px] text-cyan-200 flex items-center justify-between">
                      <span>Match Effort Reward</span>
                      <span className="font-num font-extrabold text-cyan-300">+{lastFutiKodiEarned || 35} Futi Kodi</span>
                    </div>
                  )}

                  <div className="grid gap-1.5 pt-1">
                    <button
                      type="button"
                      onClick={() => {
                        setVictory(null);
                        if (mode === 'mp') engineRef.current?.sendNetMsg({ type: 'REMATCH_SYNC' });
                        engineRef.current?.beginMatch();
                      }}
                      className="w-full py-2 rounded-xl bg-gradient-to-r from-rose-500 via-orange-500 to-amber-500 text-slate-950 font-extrabold text-xs sm:text-sm tracking-wide cursor-pointer"
                    >
                      BADLA LO (REMATCH!)
                    </button>
                    <div className="grid grid-cols-3 gap-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          setVictory(null);
                          handleOpenBotMode(true);
                        }}
                        className="py-1.5 rounded-lg border border-cyan-400/40 text-cyan-200 text-[10.5px] font-bold hover:bg-cyan-400/10 cursor-pointer"
                      >
                        Abhyas
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setVictory(null);
                          setScreen('select');
                        }}
                        className="py-1.5 rounded-lg border border-amber-400/35 text-amber-200 text-[10.5px] font-bold hover:bg-amber-400/10 cursor-pointer"
                      >
                        Yoddha
                      </button>
                      <button
                        type="button"
                        onClick={handleExitToMenu}
                        className="py-1.5 rounded-lg border border-white/15 text-slate-300 text-[10.5px] font-bold hover:bg-white/10 cursor-pointer"
                      >
                        Menu
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {/* ==================== GMAIL ACCOUNT & PROFILE MODAL ==================== */}
      {accountModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-black/80 backdrop-blur-xs">
          <div className="w-full max-w-lg max-h-[calc(100dvh-1rem)] flex flex-col overflow-hidden rounded-2xl border-2 border-amber-400/55 bg-[#0e0b1a] shadow-[0_0_50px_rgba(245,158,11,0.25)]">
            <div className="shrink-0 flex items-center justify-between px-4 py-2.5 border-b border-amber-400/20 bg-gradient-to-r from-amber-500/15 via-transparent to-emerald-500/10">
              <div className="flex items-center gap-2">
                <Trophy className="w-4 h-4 text-amber-300" />
                <h3 className="font-display-in text-lg sm:text-xl tracking-wider text-amber-200">
                  AKHARA GMAIL ACCOUNT
                </h3>
              </div>
              <button
                type="button"
                onClick={() => {
                  setEditingName(false);
                  setAccountModalOpen(false);
                }}
                aria-label="Close Account Modal"
                className="w-8 h-8 rounded-lg border border-amber-400/30 bg-black/40 flex items-center justify-center text-amber-200 hover:bg-amber-400/15 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto roster-scroll p-4 space-y-3 text-xs">
              {/* Permanent Player ID Card with One-Tap Copy ID */}
              <div className="flex items-center justify-between gap-2 p-2.5 rounded-xl border border-cyan-400/40 bg-gradient-to-r from-cyan-500/12 via-black/45 to-amber-500/10">
                <div className="min-w-0">
                  <div className="text-[9.5px] font-extrabold uppercase tracking-[0.18em] text-cyan-300/85">
                    Unique Player ID · Share for Gifts
                  </div>
                  <div className="font-num text-base sm:text-lg font-black tracking-widest text-cyan-100 mt-0.5">
                    {playerId}
                  </div>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    data-ui-sfx="select"
                    onClick={() => void handleCopyPlayerId()}
                    className="px-2.5 py-1.5 rounded-lg bg-cyan-400/20 hover:bg-cyan-400/35 border border-cyan-300/50 text-cyan-100 text-[11px] font-extrabold flex items-center gap-1 cursor-pointer shrink-0 transition"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy ID</span>
                  </button>
                  <button
                    type="button"
                    data-ui-sfx="select"
                    onClick={() => {
                      setAccountModalOpen(false);
                      setHistoryOpen(true);
                    }}
                    className="px-2.5 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/35 border border-amber-400/55 text-amber-100 text-[11px] font-extrabold flex items-center gap-1 cursor-pointer shrink-0 transition"
                  >
                    <span>📜 History</span>
                  </button>
                </div>
              </div>

              {!authUser ? (
                <div className="space-y-3 text-center py-2">
                  <div className="w-12 h-12 rounded-2xl border border-amber-400/45 bg-amber-500/15 flex items-center justify-center mx-auto">
                    <LogIn className="w-6 h-6 text-amber-300" />
                  </div>
                  <div>
                    <div className="font-display-in text-xl text-amber-100">FREE GMAIL ACCOUNT</div>
                    <p className="text-xs text-amber-100/75 mt-1 leading-relaxed max-w-sm mx-auto">
                      Apne Gmail se bilkul free account banayein. Jab aap logout karenge aur baad mein dobara usi Gmail se login karenge, aapka same Akhara Name, Wins, Best Combo aur favorite Yoddha wapas mil jayega.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleGmailLogin}
                    disabled={authBusy}
                    className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 via-orange-500 to-rose-600 text-slate-950 font-extrabold text-sm tracking-wide shadow-[0_6px_22px_rgba(245,158,11,0.35)] hover:brightness-110 active:scale-[0.98] transition cursor-pointer flex items-center justify-center gap-2 disabled:opacity-60"
                  >
                    <LogIn className="w-4 h-4" />
                    {authBusy ? 'Opening Google Sign-In...' : 'Continue with Gmail (Free)'}
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center gap-3 p-3 rounded-xl bg-black/40 border border-emerald-400/30">
                    {playerProfile?.photoUrl || authUser.photoURL ? (
                      <img
                        src={playerProfile?.photoUrl || authUser.photoURL || ''}
                        alt=""
                        referrerPolicy="no-referrer"
                        className="w-12 h-12 rounded-full border-2 border-emerald-400/60 object-cover shrink-0"
                      />
                    ) : (
                      <div className="w-12 h-12 rounded-full border-2 border-emerald-400/60 bg-emerald-500/15 flex items-center justify-center shrink-0">
                        <UserCheck className="w-6 h-6 text-emerald-300" />
                      </div>
                    )}
                    <div className="min-w-0 flex-1">
                      {editingName ? (
                        <form onSubmit={handleSaveAkharaName} className="flex items-center gap-1.5">
                          <input
                            type="text"
                            value={nameDraft}
                            onChange={(e) => setNameDraft(e.target.value)}
                            maxLength={32}
                            autoFocus
                            className="flex-1 min-w-0 px-2.5 py-1 rounded-lg bg-[#090712] border border-amber-400/50 text-amber-100 font-bold text-xs focus:outline-none"
                          />
                          <button
                            type="submit"
                            disabled={authBusy}
                            className="px-2.5 py-1 rounded-lg bg-emerald-500 text-slate-950 font-extrabold text-[11px] flex items-center gap-1 cursor-pointer"
                          >
                            <Check className="w-3.5 h-3.5" />
                            Save
                          </button>
                        </form>
                      ) : (
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="font-display-in text-lg text-amber-200 truncate">
                            {playerProfile?.akharaName || authUser.displayName || 'Desi Yoddha'}
                          </span>
                          {playerProfile?.isDeveloper && (
                            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-gradient-to-r from-amber-400 to-yellow-300 text-slate-950 text-[9px] font-black uppercase tracking-wider shadow-[0_0_12px_rgba(251,191,36,0.45)]">
                              <Code2 className="w-2.5 h-2.5" />
                              DEV
                            </span>
                          )}
                          <button
                            type="button"
                            onClick={() => {
                              setNameDraft(playerProfile?.akharaName || authUser.displayName || 'Desi Yoddha');
                              setEditingName(true);
                            }}
                            title="Edit Akhara Name"
                            className="p-1 rounded border border-white/10 text-amber-300/80 hover:text-amber-200 cursor-pointer"
                          >
                            <Edit3 className="w-3 h-3" />
                          </button>
                        </div>
                      )}
                      <div className="text-[11px] text-emerald-300/90 truncate">{authUser.email}</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-4 gap-2 text-center">
                    <div className="p-2 rounded-xl bg-black/40 border border-white/10">
                      <div className="text-[9px] font-bold uppercase text-slate-400">Matches</div>
                      <div className="font-num text-base font-extrabold text-amber-100">
                        {playerProfile?.matchesPlayed ?? 0}
                      </div>
                    </div>
                    <div className="p-2 rounded-xl bg-black/40 border border-emerald-400/25">
                      <div className="text-[9px] font-bold uppercase text-emerald-300/80">Wins</div>
                      <div className="font-num text-base font-extrabold text-emerald-300">
                        {playerProfile?.wins ?? 0}
                      </div>
                    </div>
                    <div className="p-2 rounded-xl bg-black/40 border border-rose-400/25">
                      <div className="text-[9px] font-bold uppercase text-rose-300/80">Losses</div>
                      <div className="font-num text-base font-extrabold text-rose-300">
                        {playerProfile?.losses ?? 0}
                      </div>
                    </div>
                    <div className="p-2 rounded-xl bg-black/40 border border-cyan-400/25">
                      <div className="text-[9px] font-bold uppercase text-cyan-300/80">Best Combo</div>
                      <div className="font-num text-base font-extrabold text-cyan-300">
                        {playerProfile?.bestCombo ?? 0}x
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div className="p-2.5 rounded-xl bg-black/35 border border-white/10">
                      <div className="text-[9px] uppercase font-bold text-amber-300/75">Saved Yoddha</div>
                      <div className="font-bold text-amber-100 truncate mt-0.5">
                        {getCfgById(playerProfile?.favoriteFighterId || p1Id).name}
                      </div>
                    </div>
                    <div className="p-2.5 rounded-xl bg-black/35 border border-white/10">
                      <div className="text-[9px] uppercase font-bold text-cyan-300/75">Saved Akhara</div>
                      <div className="font-bold text-cyan-100 truncate mt-0.5">
                        {ARENAS[playerProfile?.favoriteArenaId || arenaId]?.name || 'Chandni Chowk'}
                      </div>
                    </div>
                  </div>

                  <p className="text-[11px] text-amber-100/65 leading-snug">
                    Aapka stats aur profile cloud par Gmail ID se saved hai. Logout ke baad dobara usi Gmail se login karne par yahi account restore hoga.
                  </p>

                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <button
                      type="button"
                      onClick={handleGmailLogin}
                      disabled={authBusy}
                      className="py-2 px-3 rounded-xl border border-cyan-400/40 bg-cyan-500/10 text-cyan-100 font-bold hover:bg-cyan-500/20 cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      Switch Gmail
                    </button>
                    <button
                      type="button"
                      onClick={handleLogout}
                      disabled={authBusy}
                      className="py-2 px-3 rounded-xl border border-rose-400/45 bg-rose-500/12 text-rose-200 font-bold hover:bg-rose-500/25 cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      Logout
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ==================== VICTORY POSE GALLERY, ARMORY, MAILBOX, LIVE CMS & SOCIAL HUB MODALS ==================== */}
      <VictoryPoseGalleryModal
        open={poseGalleryOpen}
        authUser={authUser}
        profile={effectiveProfile}
        isDeveloperMode={isDeveloperActive}
        cmsConfig={liveCmsConfig}
        initialFighterId={poseGalleryFighterId}
        favoriteFighterId={effectiveProfile?.favoriteFighterId || p1Id}
        equippedSkinIds={effectiveProfile?.equippedSkinIds}
        auraId={effectiveProfile?.equippedAuraId}
        onSelectFighter={(fid) => {
          setP1Id(fid);
          saveLocalLoadout(fid, arenaId);
          showToast(`${getCfgById(fid).name} equipped!`);
        }}
        onUnlockPose={async (fighterId, poseId, payCurrency) => {
          if (authUser) {
            await unlockVictoryPose(authUser.uid, fighterId, poseId, payCurrency, liveCmsConfig);
          } else {
            const nextWallet = unlockVictoryPoseLocal(fighterId, poseId, payCurrency, localDevMode, liveCmsConfig);
            setGuestWallet(nextWallet);
          }
          showToast('Victory Pose Unlocked!');
        }}
        onRequireLogin={() => {
          setPoseGalleryOpen(false);
          setAccountModalOpen(true);
        }}
        onOpenBuyGota={() => {
          setPoseGalleryOpen(false);
          openArmory('store', 'gota_packs');
        }}
        onClose={() => setPoseGalleryOpen(false)}
      />

      <ArmoryModal
        open={armoryOpen}
        onClose={() => setArmoryOpen(false)}
        authUser={authUser}
        profile={effectiveProfile}
        isDeveloperMode={isDeveloperActive}
        cmsConfig={liveCmsConfig}
        unreleasedCosmetics={isDeveloperActive ? devUnreleasedItems : []}
        devSessionUnlockedIds={isDeveloperActive ? devUnreleasedSession.unlockedIds : []}
        initialFighterId={p1Id}
        initialTab={armoryInitialTab}
        initialStoreFilter={armoryInitialStoreFilter}
        onRequireLogin={() => {
          setArmoryOpen(false);
          setAccountModalOpen(true);
        }}
        onUnlockCosmetic={async (item: CosmeticItem, payCurrency: CosmeticCurrency) => {
          if (isDevUnreleasedCosmeticId(item.id)) {
            if (!isDeveloperActive) throw new Error('Developer Mode required.');
            setDevUnreleasedSession((prev) => equipDevUnreleasedInSession(prev, item.category, item.id));
            showToast(`Unlocked & Equipped Dev Prototype: ${item.name}`);
            return;
          }
          if (authUser) {
            await unlockCosmeticItem(authUser.uid, item, payCurrency, liveCmsConfig);
          } else {
            const nextWallet = unlockCosmeticLocal(item, payCurrency, localDevMode, liveCmsConfig);
            setGuestWallet(nextWallet);
          }
          // Clear any conflicting dev prototype overlay when equipping a standard unlocked cosmetic
          if (item.category === 'aura' && devUnreleasedSession.equippedAuraId) {
            setDevUnreleasedSession((prev) => saveDevUnreleasedSession({ ...prev, equippedAuraId: null }));
          } else if (item.category === 'skin') {
            setDevUnreleasedSession((prev) =>
              saveDevUnreleasedSession({
                ...prev,
                equippedSkinIds: prev.equippedSkinIds.filter((sid) => getSkinById(sid)?.fighterId !== item.fighterId),
              }),
            );
          }
          showToast(`Unlocked & Equipped: ${item.name}`);
        }}
        onPurchaseBundle={async (bundle) => {
          if (authUser) {
            await purchaseBundleCloud(authUser.uid, bundle);
          } else {
            const nextWallet = purchaseBundleLocal(bundle, localDevMode);
            setGuestWallet(nextWallet);
          }
          showToast(`Bundle Unlocked: ${bundle.title}!`);
        }}
        onEquipCosmetic={async (category, id) => {
          if (isDevUnreleasedCosmeticId(id)) {
            if (!isDeveloperActive) throw new Error('Developer Mode required.');
            setDevUnreleasedSession((prev) => equipDevUnreleasedInSession(prev, category, id));
            showToast('Dev Prototype Cosmetic equipped!');
            return;
          }
          if (category === 'aura' && devUnreleasedSession.equippedAuraId) {
            setDevUnreleasedSession((prev) => saveDevUnreleasedSession({ ...prev, equippedAuraId: null }));
          } else if (category === 'skin') {
            const targetFighter = getSkinById(id)?.fighterId;
            if (targetFighter) {
              setDevUnreleasedSession((prev) =>
                saveDevUnreleasedSession({
                  ...prev,
                  equippedSkinIds: prev.equippedSkinIds.filter((sid) => getSkinById(sid)?.fighterId !== targetFighter),
                }),
              );
            }
          }
          if (authUser) {
            await equipCosmeticItem(authUser.uid, category, id);
          } else {
            const nextWallet = equipCosmeticLocal(category, id, localDevMode);
            setGuestWallet(nextWallet);
          }
          showToast('Cosmetic equipped!');
        }}
        onUnequipFighterSkin={async (fighterId) => {
          const hadDevSkin = devUnreleasedSession.equippedSkinIds.some(
            (sid) => getSkinById(sid)?.fighterId === fighterId,
          );
          if (hadDevSkin) {
            setDevUnreleasedSession((prev) =>
              saveDevUnreleasedSession({
                ...prev,
                equippedSkinIds: prev.equippedSkinIds.filter((sid) => getSkinById(sid)?.fighterId !== fighterId),
              }),
            );
          }
          const hasProdSkin = baseProfile?.equippedSkinIds.some(
            (sid) => getSkinById(sid)?.fighterId === fighterId,
          );
          if (hasProdSkin) {
            if (authUser) {
              await unequipSkinForFighter(authUser.uid, fighterId);
            } else {
              const nextWallet = unequipSkinForFighterLocal(fighterId, localDevMode);
              setGuestWallet(nextWallet);
            }
          }
          showToast('Skin unequipped — Classic look restored!');
        }}
        onUnequipAura={async () => {
          if (devUnreleasedSession.equippedAuraId) {
            setDevUnreleasedSession((prev) => saveDevUnreleasedSession({ ...prev, equippedAuraId: null }));
          }
          if (baseProfile && baseProfile.equippedAuraId !== DEFAULT_AURA_ID) {
            if (authUser) {
              await unequipAuraCosmetic(authUser.uid);
            } else {
              const nextWallet = unequipAuraLocal(localDevMode);
              setGuestWallet(nextWallet);
            }
          }
          showToast('Aura unequipped — Classic aura restored!');
        }}
      />

      <MailboxModal
        open={mailboxOpen}
        initialTab={mailboxInitialTab}
        playerId={playerId}
        isDeveloperMode={isDeveloperActive}
        isSignedIn={Boolean(authUser)}
        mails={mails}
        loading={mailsLoading}
        onRefresh={refreshMailbox}
        onClaimMail={async (mail) => {
          const { updatedProfile, badgeText } = await claimPlayerGiftMail({
            playerId,
            mail,
            authUser,
            currentProfile: effectiveProfile,
            isLocalDevMode: localDevMode,
          });
          if (updatedProfile) {
            if (authUser) {
              setPlayerProfile(updatedProfile);
            } else {
              setGuestWallet(updatedProfile);
            }
          }
          setMails((prev) => prev.filter((m) => m.id !== mail.id));
          showToast(`Claimed ${badgeText}!`);
        }}
        onSendGiftMail={async (payload) => {
          const res = await sendDeveloperGiftMail({
            authUser,
            isFirestoreDeveloper: Boolean(playerProfile?.isDeveloper),
            targetPlayerId: payload.targetPlayerId,
            title: payload.title,
            message: payload.message,
            giftType: payload.giftType,
            giftAmount: payload.giftAmount,
            giftItemId: payload.giftItemId,
          });
          showToast(`Gift Mail sent to ${res.mail.targetPlayerId}!`);
          return { syncedCloud: res.syncedCloud };
        }}
        onCopyPlayerId={() => void handleCopyPlayerId()}
        onClose={() => setMailboxOpen(false)}
      />

      <DailyQuestsModal
        open={questsOpen}
        quests={dailyQuests}
        onClaimQuest={async (quest) => {
          const { quests: nextQuests, updatedProfile } = await claimDailyQuestReward({
            quest,
            authUser,
            isLocalDevMode: localDevMode,
          });
          setDailyQuests(nextQuests);
          if (updatedProfile) {
            if (authUser) {
              setPlayerProfile(updatedProfile);
            } else {
              setGuestWallet(updatedProfile);
            }
          }
          showToast(`Claimed +${quest.rewardFk} Futi Kodi!`);
        }}
        onClose={() => setQuestsOpen(false)}
        onToast={showToast}
      />

      <SocialHubModal
        open={socialHubOpen}
        initialTab={socialHubTab}
        authUser={authUser}
        playerProfile={playerProfile}
        playerId={playerId}
        friends={friends}
        incomingRequests={incomingFriendRequests}
        activeMpCode={mode === 'mp' && mpRole === 'host' ? mpCode : undefined}
        onGmailLogin={handleGmailLogin}
        authBusy={authBusy}
        onJoinCodeFromChat={handleJoinCodeFromChat}
        onCopyPlayerId={() => void handleCopyPlayerId()}
        onSendFriendRequest={handleSendFriendRequest}
        onAcceptRequest={handleAcceptFriendRequest}
        onDeclineRequest={handleDeclineFriendRequest}
        onRemoveFriend={handleRemoveFriend}
        onChallengeFriend={handleChallengeFriend}
        onRefreshFriends={handleRefreshFriends}
        onClose={() => setSocialHubOpen(false)}
        onToast={showToast}
      />

      <MatchHistoryModal
        open={historyOpen}
        entries={matchHistory}
        onClearHistory={() => {
          setMatchHistory(clearMatchHistory());
          showToast('Local Match History cleared.');
        }}
        onClose={() => setHistoryOpen(false)}
      />

      {isDeveloperActive && (
        <DevCmsModal
          open={cmsOpen}
          onClose={() => setCmsOpen(false)}
          cmsConfig={liveCmsConfig}
          isFirestoreDeveloper={Boolean(authUser && playerProfile?.isDeveloper)}
          unreleasedCosmetics={devUnreleasedItems}
          devSession={devUnreleasedSession}
          onUpdateCmsConfig={(next) => {
            const saved = saveLocalLiveCmsConfig(next);
            setLiveCmsConfig(saved);
          }}
          onSaveAndPushLive={async (cfg) => {
            const res = await publishLiveCmsConfig(cfg, {
              syncCloud: Boolean(authUser),
              isFirestoreDeveloper: Boolean(authUser && playerProfile?.isDeveloper),
            });
            setLiveCmsConfig(res.config);
            return { syncedCloud: res.syncedCloud };
          }}
          onResetCmsConfig={async () => {
            const fresh = createDefaultLiveCmsConfig();
            const res = await publishLiveCmsConfig(fresh, {
              syncCloud: Boolean(authUser),
              isFirestoreDeveloper: Boolean(authUser && playerProfile?.isDeveloper),
            });
            setLiveCmsConfig(res.config);
            showToast('Live CMS config reset to factory defaults.');
          }}
          onInjectCosmetic={(item) => {
            const nextList = saveDevUnreleasedCosmetics([item, ...devUnreleasedItems]);
            setDevUnreleasedCosmetics(nextList);
            setDevUnreleasedItems(nextList);
            setDevUnreleasedSession((prev) => equipDevUnreleasedInSession(prev, item.category, item.id));
          }}
          onDeleteInjectedCosmetic={(id) => {
            const nextList = saveDevUnreleasedCosmetics(devUnreleasedItems.filter((c) => c.id !== id));
            setDevUnreleasedCosmetics(nextList);
            setDevUnreleasedItems(nextList);
            setDevUnreleasedSession((prev) =>
              saveDevUnreleasedSession({
                unlockedIds: prev.unlockedIds.filter((uid) => uid !== id),
                equippedSkinIds: prev.equippedSkinIds.filter((sid) => sid !== id),
                equippedAuraId: prev.equippedAuraId === id ? null : prev.equippedAuraId,
              }),
            );
            showToast('Deleted dev prototype cosmetic.');
          }}
          onEquipInjectedCosmetic={(item) => {
            setDevUnreleasedSession((prev) => equipDevUnreleasedInSession(prev, item.category, item.id));
            if (item.category === 'skin') {
              setP1Id(item.fighterId);
              saveLocalLoadout(item.fighterId, arenaId);
            }
            showToast(`Equipped Dev Prototype: ${item.name}`);
          }}
          onToast={showToast}
        />
      )}

      {/* ==================== OUTGOING & INCOMING DIRECT 1V1 CHALLENGE BANNERS ==================== */}
      {outgoingInvite && screen !== 'select' && screen !== 'combat' && (
        <div className="fixed top-3 left-1/2 -translate-x-1/2 z-[65] w-[min(92vw,420px)] px-3.5 py-2.5 rounded-2xl border-2 border-amber-400/75 bg-[#120d22]/96 shadow-[0_0_30px_rgba(245,158,11,0.4)] flex items-center justify-between gap-2.5">
          <div className="flex items-center gap-2 min-w-0">
            <Swords className="w-4 h-4 text-amber-300 animate-pulse shrink-0" />
            <div className="min-w-0">
              <div className="text-xs font-extrabold text-amber-100 truncate">
                Waiting for {outgoingInvite.friendName} to accept...
              </div>
              <div className="text-[10px] text-amber-200/75 font-num truncate">
                Direct 1v1 Invite · Room {outgoingInvite.roomCode}
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={() => {
              void deleteDirectMatchInvite(outgoingInvite.inviteId);
              setOutgoingInvite(null);
              engineRef.current?.cleanupPeerSession();
              showToast('1v1 Invite cancelled.');
            }}
            className="shrink-0 px-2.5 py-1 rounded-lg border border-rose-400/50 bg-rose-500/15 text-rose-200 text-[10.5px] font-extrabold hover:bg-rose-500/25 cursor-pointer"
          >
            Cancel
          </button>
        </div>
      )}

      {incomingInvites.length > 0 && screen !== 'combat' && (
        <div className="fixed top-14 left-1/2 -translate-x-1/2 z-[70] w-[min(94vw,440px)] p-3 rounded-2xl border-2 border-emerald-400 bg-gradient-to-r from-[#0d1f1c]/98 via-[#121024]/98 to-[#1f1224]/98 shadow-[0_0_40px_rgba(52,211,153,0.45)]">
          <div className="flex items-center justify-between gap-2.5">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-xl border border-emerald-400/55 bg-emerald-500/20 flex items-center justify-center shrink-0">
                <Swords className="w-4 h-4 text-emerald-300 animate-bounce" />
              </div>
              <div className="min-w-0">
                <div className="text-[10px] font-black uppercase tracking-wider text-emerald-300">
                  Direct 1v1 Akhara Challenge!
                </div>
                <div className="text-xs font-extrabold text-amber-100 truncate">
                  {incomingInvites[0].fromName} ({incomingInvites[0].fromPlayerId})
                </div>
              </div>
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                type="button"
                onClick={() => void handleAcceptIncomingInvite(incomingInvites[0])}
                className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-400 to-cyan-400 text-slate-950 text-[11px] font-black flex items-center gap-1 hover:brightness-110 cursor-pointer"
              >
                <Swords className="w-3.5 h-3.5" />
                ACCEPT
              </button>
              <button
                type="button"
                onClick={() => void handleDeclineIncomingInvite(incomingInvites[0])}
                className="px-2.5 py-1.5 rounded-xl border border-rose-400/50 bg-rose-500/15 text-rose-200 text-[11px] font-extrabold hover:bg-rose-500/25 cursor-pointer"
              >
                ✕ DECLINE
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================== LANDSCAPE-ONLY ROTATE GUARD ==================== */}
      {isPortrait && (
        <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center p-6 text-center bg-[#07060d]/95 backdrop-blur-md">
          <div className="w-20 h-20 rounded-2xl border-2 border-amber-400/60 bg-amber-500/10 flex items-center justify-center mb-5 shadow-[0_0_32px_rgba(245,158,11,0.3)]">
            <svg viewBox="0 0 48 48" className="w-11 h-11 text-amber-300 animate-pulse fill-none stroke-current stroke-[2.2]">
              <rect x="8" y="15" width="32" height="18" rx="3" />
              <circle cx="36" cy="24" r="1.5" className="fill-current" />
              <path d="M18 9a12 12 0 0114 3l-2-4m2 4l-4 1" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
          <div className="text-[11px] font-bold tracking-[0.26em] uppercase text-amber-300/85">
            Landscape Mode Only
          </div>
          <h2 className="font-display-in text-3xl text-amber-100 mt-1">
            ROTATE YOUR DEVICE
          </h2>
          <p className="text-sm text-amber-100/70 max-w-xs mt-2 leading-relaxed">
            Gali Clash sirf <span className="text-amber-300 font-semibold">Landscape Mode</span> mein khela jaata hai. Behtar Akhara view ke liye phone ko ghumaayein.
          </p>
          <button
            type="button"
            onClick={async () => {
              try {
                if (!document.fullscreenElement) await document.documentElement.requestFullscreen();
                await tryLockLandscape();
              } catch {
                showToast('Please enable Auto-Rotate and turn your phone sideways!');
              }
            }}
            className="mt-6 px-5 py-3 rounded-xl bg-gradient-to-r from-amber-500 via-orange-500 to-rose-600 text-slate-950 font-extrabold text-xs tracking-wider uppercase shadow-lg cursor-pointer"
          >
            Fullscreen &amp; Lock Landscape
          </button>
        </div>
      )}

      {/* ==================== TOAST ==================== */}
      {toast && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[110] px-4 py-2 rounded-xl border border-amber-400/50 bg-[#120e20]/95 text-amber-100 text-xs font-bold shadow-xl pointer-events-none">
          {toast}
        </div>
      )}
    </div>
  );
}
