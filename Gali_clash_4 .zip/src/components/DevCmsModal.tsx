import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Check,
  Cloud,
  CloudUpload,
  Code2,
  Coins,
  Crown,
  Edit3,
  Flame,
  FlaskConical,
  Gem,
  HardDrive,
  PackagePlus,
  Palette,
  Pause,
  Play,
  RotateCcw,
  Save,
  Search,
  Sparkles,
  Tag,
  Trash2,
  Wand2,
  X,
} from 'lucide-react';
import {
  AURAS,
  AuraDef,
  CosmeticItem,
  DEFAULT_AURA_ID,
  setDevStagePreviewCosmetic,
  SKINS,
  SkinDef,
} from '../game/cosmetics';
import { FIGHTERS, getCfgById } from '../game/data';
import { drawCosmeticThumbnail, drawFighterPosePreview } from '../game/engine';
import { FIGHTER_VICTORY_POSES, getVictoryPosePrice } from '../game/victoryPoses';
import {
  buildDevTestAuraDef,
  buildDevTestSkinDef,
  CmsBundleDef,
  CmsPriceOverride,
  computeBundleRegularGotaValue,
  decodeBundleToken,
  DevUnreleasedSessionState,
  encodePoseBundleToken,
  getEffectiveCosmeticPricing,
  getEffectivePosePricing,
  LiveCmsConfig,
  LOBBY_THEMES,
  LobbyThemeId,
} from '../services/devCms';

type CmsTab = 'pricing' | 'bundles' | 'injector' | 'themes';
type PricingFilter = 'all' | 'skin' | 'aura' | 'pose';
type BundlePickerFilter = 'skin' | 'aura' | 'pose';

interface DevCmsModalProps {
  open: boolean;
  onClose: () => void;
  cmsConfig: LiveCmsConfig;
  isFirestoreDeveloper: boolean;
  unreleasedCosmetics: CosmeticItem[];
  devSession: DevUnreleasedSessionState;
  onUpdateCmsConfig: (next: LiveCmsConfig) => void;
  onSaveAndPushLive: (cfg: LiveCmsConfig) => Promise<{ syncedCloud: boolean }>;
  onResetCmsConfig: () => Promise<void>;
  onInjectCosmetic: (item: CosmeticItem) => void;
  onDeleteInjectedCosmetic: (id: string) => void;
  onEquipInjectedCosmetic: (item: CosmeticItem) => void;
  onToast: (msg: string) => void;
}

const MiniThumb: React.FC<{
  fighterId: string;
  skinId?: string;
  auraId?: string;
  isAuraCard: boolean;
}> = ({ fighterId, skinId, auraId, isAuraCard }) => {
  const ref = useRef<HTMLCanvasElement | null>(null);
  useEffect(() => {
    if (ref.current) {
      drawCosmeticThumbnail(ref.current, fighterId, skinId, auraId, isAuraCard, 0.9);
    }
  }, [fighterId, skinId, auraId, isAuraCard]);
  return <canvas ref={ref} className="w-10 h-10 rounded-lg border border-white/15 bg-[#090714] shrink-0 block" />;
};

const MOTIF_OPTIONS: NonNullable<SkinDef['palette']['motif']>[] = [
  'zari',
  'bandhani',
  'bhangra',
  'vibhuti',
  'neon',
  'royal',
];

const AURA_STYLES: Exclude<AuraDef['style'], 'none'>[] = [
  'gulal',
  'diya',
  'chakra',
  'morpankh',
  'lotus_vip',
  'trishul_vip',
];

export const DevCmsModal: React.FC<DevCmsModalProps> = ({
  open,
  onClose,
  cmsConfig,
  isFirestoreDeveloper,
  unreleasedCosmetics,
  devSession,
  onUpdateCmsConfig,
  onSaveAndPushLive,
  onResetCmsConfig,
  onInjectCosmetic,
  onDeleteInjectedCosmetic,
  onEquipInjectedCosmetic,
  onToast,
}) => {
  const [activeTab, setActiveTab] = useState<CmsTab>('pricing');
  const [pushing, setPushing] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);

  // Tab 1: Flash Offers & Pricing
  const [priceSearch, setPriceSearch] = useState('');
  const [priceFilter, setPriceFilter] = useState<PricingFilter>('all');

  // Tab 2: Bundle Creator
  const [bundleFilter, setBundleFilter] = useState<BundlePickerFilter>('skin');
  const [bundleSearch, setBundleSearch] = useState('');
  const [editingBundleId, setEditingBundleId] = useState<string | null>(null);
  const [bundleTitle, setBundleTitle] = useState('Maharaja Diwali Pack');
  const [bundleSubtitle, setBundleSubtitle] = useState('Curated festive skin, aura & celebration bundle');
  const [bundleBadge, setBundleBadge] = useState('LIMITED FLASH');
  const [bundleGotaPrice, setBundleGotaPrice] = useState<number>(35);
  const [bundleItemIds, setBundleItemIds] = useState<string[]>([
    'skin_munna_velvet',
    'aura_diya',
  ]);

  // Tab 3: Unreleased Skins Injector
  const [injectMode, setInjectMode] = useState<'skin' | 'aura'>('skin');
  const [skinFighterId, setSkinFighterId] = useState(FIGHTERS[0].id);
  const [skinName, setSkinName] = useState('Kala Bhairav Prototype');
  const [skinSubtitle, setSkinSubtitle] = useState('Unreleased dark crimson & gold prototype');
  const [tunicColor, setTunicColor] = useState('#4c0519');
  const [tunicDarkColor, setTunicDarkColor] = useState('#1f030c');
  const [pantsColor, setPantsColor] = useState('#111827');
  const [pantsDarkColor, setPantsDarkColor] = useState('#030712');
  const [trimColor, setTrimColor] = useState('#fbbf24');
  const [auraColor, setAuraColor] = useState('#f43f5e');
  const [glowColor, setGlowColor] = useState('#fde047');
  const [eyeColor, setEyeColor] = useState('#fef08a');
  const [skinMotif, setSkinMotif] = useState<NonNullable<SkinDef['palette']['motif']>>('royal');
  const [skinShiny, setSkinShiny] = useState(true);
  const [auraName, setAuraName] = useState('Nava Graha Halo');
  const [auraSubtitle, setAuraSubtitle] = useState('Experimental prismatic orbital halo');
  const [auraRingColor, setAuraRingColor] = useState('#a855f7');
  const [auraSparkColor, setAuraSparkColor] = useState('#fde047');
  const [auraSecondaryColor, setAuraSecondaryColor] = useState('#22d3ee');
  const [auraStyle, setAuraStyle] = useState<Exclude<AuraDef['style'], 'none'>>('chakra');
  const [testFkPrice, setTestFkPrice] = useState<string>('550');
  const [testGotaPrice, setTestGotaPrice] = useState<number>(20);
  const injectorCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Build pose pricing catalog rows
  const allPoseEntries = useMemo(() => {
    const rows: {
      fighterId: string;
      fighterName: string;
      poseId: string;
      poseName: string;
      index: 2 | 3;
      baseFk: number;
      baseGota: number;
    }[] = [];
    for (const f of FIGHTERS) {
      const poses = FIGHTER_VICTORY_POSES[f.id] || [];
      poses.forEach((p, idx) => {
        if (idx === 0) return; // Pose 1 is always free default
        const base = getVictoryPosePrice(f.id, p.id);
        rows.push({
          fighterId: f.id,
          fighterName: f.name,
          poseId: p.id,
          poseName: p.poseName,
          index: (idx + 1) as 2 | 3,
          baseFk: base.fkPrice,
          baseGota: base.gotaPrice,
        });
      });
    }
    return rows;
  }, []);

  // Sync live draft cosmetic colors into isolated stage preview slot ONLY while Injector tab is open
  useEffect(() => {
    if (!open || activeTab !== 'injector') {
      setDevStagePreviewCosmetic(null, null);
      return;
    }
    if (injectMode === 'skin') {
      const draftSkin: SkinDef = {
        id: '__dev_stage_preview_skin__',
        category: 'skin',
        fighterId: skinFighterId,
        name: skinName || 'Prototype',
        subtitle: skinSubtitle || '',
        currency: 'futi_kodi',
        price: 550,
        fkPrice: 550,
        gotaPrice: testGotaPrice,
        isDevUnreleased: true,
        palette: {
          tunic: tunicColor,
          tunicDark: tunicDarkColor,
          pants: pantsColor,
          pantsDark: pantsDarkColor,
          trim: trimColor,
          aura: auraColor,
          glow: glowColor,
          eye: eyeColor,
          shiny: skinShiny,
          motif: skinMotif,
        },
      };
      setDevStagePreviewCosmetic(draftSkin, null);
    } else {
      const draftAura: AuraDef = {
        id: '__dev_stage_preview_aura__',
        category: 'aura',
        name: auraName || 'Prototype Aura',
        subtitle: auraSubtitle || '',
        currency: 'futi_kodi',
        price: 550,
        fkPrice: 550,
        gotaPrice: testGotaPrice,
        ringColor: auraRingColor,
        sparkColor: auraSparkColor,
        secondaryColor: auraSecondaryColor,
        style: auraStyle,
        isDevUnreleased: true,
      };
      setDevStagePreviewCosmetic(null, draftAura);
    }
    return () => {
      setDevStagePreviewCosmetic(null, null);
    };
  }, [
    open,
    activeTab,
    injectMode,
    skinFighterId,
    skinName,
    skinSubtitle,
    tunicColor,
    tunicDarkColor,
    pantsColor,
    pantsDarkColor,
    trimColor,
    auraColor,
    glowColor,
    eyeColor,
    skinShiny,
    skinMotif,
    auraName,
    auraSubtitle,
    auraRingColor,
    auraSparkColor,
    auraSecondaryColor,
    auraStyle,
    testGotaPrice,
  ]);

  // Animate Injector live stage preview canvas
  useEffect(() => {
    if (!open || activeTab !== 'injector') return;
    let raf = 0;
    let last = 0;
    const loop = (now: number) => {
      raf = window.requestAnimationFrame(loop);
      if (now - last < 36) return;
      last = now;
      if (injectorCanvasRef.current) {
        drawFighterPosePreview(
          injectorCanvasRef.current,
          skinFighterId,
          'victory',
          now * 0.001,
          injectMode === 'skin' ? '__dev_stage_preview_skin__' : '',
          injectMode === 'aura' ? '__dev_stage_preview_aura__' : DEFAULT_AURA_ID,
        );
      }
    };
    raf = window.requestAnimationFrame(loop);
    return () => window.cancelAnimationFrame(raf);
  }, [open, activeTab, injectMode, skinFighterId]);

  if (!open) return null;

  const overrideCount = Object.keys(cmsConfig.priceOverrides).length;
  const activeBundleCount = cmsConfig.bundles.filter((b) => b.active).length;

  const handleSetPriceOverride = (
    itemId: string,
    patch: Partial<CmsPriceOverride>,
    baseFk: number | null,
    baseGota: number,
  ) => {
    const existing = cmsConfig.priceOverrides[itemId] || {};
    const merged: CmsPriceOverride = {
      ...existing,
      ...patch,
    };

    const fkSame =
      merged.fkPrice === undefined || merged.fkPrice === baseFk;
    const gotaSame =
      merged.gotaPrice === undefined || merged.gotaPrice === baseGota;
    const labelEmpty = !merged.flashLabel || !merged.flashLabel.trim();

    const nextOverrides = { ...cmsConfig.priceOverrides };
    if (fkSame && gotaSame && labelEmpty) {
      delete nextOverrides[itemId];
    } else {
      nextOverrides[itemId] = {
        ...(merged.fkPrice !== undefined ? { fkPrice: merged.fkPrice } : {}),
        ...(merged.gotaPrice !== undefined ? { gotaPrice: Math.max(1, merged.gotaPrice) } : {}),
        ...(merged.flashLabel?.trim() ? { flashLabel: merged.flashLabel.trim().slice(0, 24) } : {}),
      };
    }
    onUpdateCmsConfig({ ...cmsConfig, priceOverrides: nextOverrides });
  };

  const handleClearSingleOverride = (itemId: string) => {
    if (!cmsConfig.priceOverrides[itemId]) return;
    const nextOverrides = { ...cmsConfig.priceOverrides };
    delete nextOverrides[itemId];
    onUpdateCmsConfig({ ...cmsConfig, priceOverrides: nextOverrides });
  };

  const handleSavePush = async (cfgToPush = cmsConfig) => {
    if (pushing) return;
    setPushing(true);
    try {
      const res = await onSaveAndPushLive(cfgToPush);
      onToast(
        res.syncedCloud
          ? 'Live CMS published globally (Firestore + Local Cache)!'
          : 'Live CMS saved to local Developer Session!',
      );
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Failed to push Live CMS.');
    } finally {
      setPushing(false);
    }
  };

  const handleSelectTheme = async (themeId: LobbyThemeId) => {
    const next: LiveCmsConfig = { ...cmsConfig, lobbyTheme: themeId };
    onUpdateCmsConfig(next);
    setPushing(true);
    try {
      const res = await onSaveAndPushLive(next);
      const meta = LOBBY_THEMES.find((t) => t.id === themeId);
      onToast(
        `${meta?.name || themeId} applied${res.syncedCloud ? ' & synced globally!' : ' to lobby!'}`,
      );
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Theme applied locally.');
    } finally {
      setPushing(false);
    }
  };

  const toggleBundleToken = (token: string) => {
    setBundleItemIds((prev) => {
      if (prev.includes(token)) return prev.filter((t) => t !== token);
      if (prev.length >= 12) {
        onToast('Max 12 items per promotional bundle.');
        return prev;
      }
      return [...prev, token];
    });
  };

  const draftRegularGota = computeBundleRegularGotaValue({
    id: 'draft',
    title: bundleTitle,
    subtitle: bundleSubtitle,
    itemIds: bundleItemIds,
    gotaPrice: bundleGotaPrice,
    active: true,
    createdAtMs: 0,
  });
  const draftDiscountPct =
    draftRegularGota > 0
      ? Math.max(0, Math.round(((draftRegularGota - bundleGotaPrice) / draftRegularGota) * 100))
      : 0;

  const handlePushBundle = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanTitle = bundleTitle.trim();
    if (cleanTitle.length < 2) {
      onToast('Enter a Bundle Title (2+ characters).');
      return;
    }
    if (bundleItemIds.length === 0) {
      onToast('Select at least 1 skin, aura, or pose for the bundle.');
      return;
    }
    const cleanGota = Math.max(1, Math.round(bundleGotaPrice || 1));
    const newBundle: CmsBundleDef = {
      id: editingBundleId || `bundle_${Date.now().toString(36)}`,
      title: cleanTitle.slice(0, 48),
      subtitle: bundleSubtitle.trim().slice(0, 80) || `${bundleItemIds.length} curated Akhara rewards`,
      itemIds: [...bundleItemIds],
      gotaPrice: cleanGota,
      badgeText: bundleBadge.trim().slice(0, 20) || (draftDiscountPct > 0 ? `SAVE ${draftDiscountPct}%` : 'BUNDLE'),
      active: true,
      createdAtMs: Date.now(),
    };

    const nextBundles = editingBundleId
      ? cmsConfig.bundles.map((b) => (b.id === editingBundleId ? newBundle : b))
      : [newBundle, ...cmsConfig.bundles].slice(0, 20);

    const nextCfg: LiveCmsConfig = { ...cmsConfig, bundles: nextBundles };
    onUpdateCmsConfig(nextCfg);
    setEditingBundleId(null);
    await handleSavePush(nextCfg);
  };

  const handleToggleBundleActive = (bundleId: string) => {
    const nextBundles = cmsConfig.bundles.map((b) =>
      b.id === bundleId ? { ...b, active: !b.active } : b,
    );
    onUpdateCmsConfig({ ...cmsConfig, bundles: nextBundles });
  };

  const handleDeleteBundle = (bundleId: string) => {
    const nextBundles = cmsConfig.bundles.filter((b) => b.id !== bundleId);
    onUpdateCmsConfig({ ...cmsConfig, bundles: nextBundles });
    if (editingBundleId === bundleId) setEditingBundleId(null);
  };

  const handleInjectSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedFk = testFkPrice.trim() === '' ? null : Math.max(1, Math.round(Number(testFkPrice) || 500));
    const parsedGota = Math.max(1, Math.round(testGotaPrice || 20));
    if (injectMode === 'skin') {
      const def = buildDevTestSkinDef({
        fighterId: skinFighterId,
        name: skinName,
        subtitle: skinSubtitle,
        tunic: tunicColor,
        tunicDark: tunicDarkColor,
        pants: pantsColor,
        pantsDark: pantsDarkColor,
        trim: trimColor,
        aura: auraColor,
        glow: glowColor,
        eye: eyeColor,
        motif: skinMotif,
        shiny: skinShiny,
        fkPrice: parsedFk,
        gotaPrice: parsedGota,
      });
      onInjectCosmetic(def);
      onToast(`Injected Dev Test Skin "${def.name}" (Dev Session Only)`);
    } else {
      const def = buildDevTestAuraDef({
        name: auraName,
        subtitle: auraSubtitle,
        ringColor: auraRingColor,
        sparkColor: auraSparkColor,
        secondaryColor: auraSecondaryColor,
        style: auraStyle,
        fkPrice: parsedFk,
        gotaPrice: parsedGota,
      });
      onInjectCosmetic(def);
      onToast(`Injected Dev Test Aura "${def.name}" (Dev Session Only)`);
    }
  };

  const q = priceSearch.trim().toLowerCase();
  const filteredCosmetics = [
    ...(priceFilter === 'all' || priceFilter === 'skin' ? SKINS : []),
    ...(priceFilter === 'all' || priceFilter === 'aura' ? AURAS.filter((a) => a.id !== DEFAULT_AURA_ID) : []),
  ].filter((c) => {
    if (!q) return true;
    const fName = c.category === 'skin' ? getCfgById(c.fighterId).name.toLowerCase() : 'all warriors';
    return c.name.toLowerCase().includes(q) || fName.includes(q) || c.id.toLowerCase().includes(q);
  });

  const filteredPoses =
    priceFilter === 'all' || priceFilter === 'pose'
      ? allPoseEntries.filter(
          (p) =>
            !q ||
            p.poseName.toLowerCase().includes(q) ||
            p.fighterName.toLowerCase().includes(q) ||
            p.poseId.toLowerCase().includes(q),
        )
      : [];

  const bq = bundleSearch.trim().toLowerCase();
  const pickerSkins = SKINS.filter(
    (s) => !bq || s.name.toLowerCase().includes(bq) || getCfgById(s.fighterId).name.toLowerCase().includes(bq),
  );
  const pickerAuras = AURAS.filter(
    (a) => a.id !== DEFAULT_AURA_ID && (!bq || a.name.toLowerCase().includes(bq)),
  );
  const pickerPoses = allPoseEntries.filter(
    (p) => !bq || p.poseName.toLowerCase().includes(bq) || p.fighterName.toLowerCase().includes(bq),
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-1.5 sm:p-3 bg-[#05040b]/88 backdrop-blur-md">
      <div className="w-full max-w-5xl h-[min(585px,calc(100dvh-0.75rem))] flex flex-col rounded-2xl border-2 border-amber-400/55 bg-[#0d0a19]/98 shadow-[0_0_55px_rgba(245,158,11,0.28)] overflow-hidden">
        {/* Top LiveOps Bar */}
        <div className="shrink-0 flex items-center justify-between gap-2 px-3 sm:px-4 py-2 border-b border-amber-400/20 bg-gradient-to-r from-amber-500/16 via-[#120d22] to-cyan-500/12">
          <div className="min-w-0 flex items-center gap-2">
            <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-gradient-to-br from-amber-400 to-rose-500 text-slate-950 flex items-center justify-center shrink-0 shadow">
              <Code2 className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <h2 className="font-display-in text-sm sm:text-lg tracking-wider text-amber-200 leading-none truncate">
                  GALI CLASH · LIVE OPERATIONS PANEL
                </h2>
                <span className="px-1.5 py-0.5 rounded bg-amber-400 text-slate-950 text-[8.5px] font-black uppercase tracking-wider shrink-0">
                  DEV CMS
                </span>
              </div>
              <div className="flex items-center gap-2 text-[9.5px] text-amber-100/70 mt-0.5 truncate">
                <span className="inline-flex items-center gap-1 font-semibold text-emerald-300">
                  {isFirestoreDeveloper ? <Cloud className="w-3 h-3" /> : <HardDrive className="w-3 h-3 text-cyan-300" />}
                  {isFirestoreDeveloper ? 'Cloud Synced (1-Read Boot)' : 'Local Dev Session'}
                </span>
                <span>·</span>
                <span className="tabular-nums">{overrideCount} Price Overrides</span>
                <span>·</span>
                <span className="tabular-nums">{activeBundleCount} Active Bundles</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {confirmReset ? (
              <div className="flex items-center gap-1 bg-rose-500/15 border border-rose-400/50 rounded-lg px-1.5 py-0.5">
                <span className="text-[9.5px] font-bold text-rose-200">Reset all?</span>
                <button
                  type="button"
                  onClick={() => {
                    setConfirmReset(false);
                    void onResetCmsConfig();
                  }}
                  className="px-1.5 py-0.5 rounded bg-rose-500 text-white text-[9.5px] font-black cursor-pointer"
                >
                  Yes
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmReset(false)}
                  className="px-1.5 py-0.5 rounded bg-white/10 text-slate-200 text-[9.5px] font-bold cursor-pointer"
                >
                  No
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmReset(true)}
                title="Reset all CMS overrides, bundles & lobby theme"
                className="h-7 sm:h-8 px-2 rounded-lg border border-rose-400/35 bg-rose-500/10 text-rose-200 text-[10px] font-bold flex items-center gap-1 hover:bg-rose-500/20 cursor-pointer whitespace-nowrap"
              >
                <RotateCcw className="w-3 h-3" />
                <span className="hidden sm:inline">Reset</span>
              </button>
            )}

            <button
              type="button"
              data-ui-sfx="unlock"
              disabled={pushing}
              onClick={() => void handleSavePush()}
              className="h-7 sm:h-8 px-2.5 sm:px-3 rounded-lg bg-gradient-to-r from-emerald-400 to-cyan-400 text-slate-950 text-[10.5px] font-black flex items-center gap-1.5 hover:brightness-110 cursor-pointer whitespace-nowrap disabled:opacity-60"
            >
              {isFirestoreDeveloper ? <CloudUpload className="w-3.5 h-3.5" /> : <Save className="w-3.5 h-3.5" />}
              <span>{pushing ? 'Pushing...' : 'Save & Push Live'}</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              aria-label="Close Live Operations Panel"
              className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg border border-white/15 bg-white/5 text-amber-200 flex items-center justify-center hover:border-amber-300 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 4 Module Navigation Tabs */}
        <div className="shrink-0 flex items-center gap-1.5 px-3 sm:px-4 py-1.5 border-b border-white/10 bg-black/35 overflow-x-auto">
          {(
            [
              { id: 'pricing', label: 'Flash Offers & Pricing', icon: Tag, badge: overrideCount || null },
              { id: 'bundles', label: 'Bundle Creator', icon: PackagePlus, badge: cmsConfig.bundles.length || null },
              {
                id: 'injector',
                label: 'Unreleased Skins Injector',
                icon: Wand2,
                badge: unreleasedCosmetics.length || null,
              },
              { id: 'themes', label: 'Theme Event Switcher', icon: Palette, badge: null },
            ] as const
          ).map((t) => {
            const Icon = t.icon;
            const active = activeTab === t.id;
            return (
              <button
                key={t.id}
                type="button"
                data-ui-sfx="select"
                onClick={() => setActiveTab(t.id)}
                className={`px-2.5 sm:px-3 py-1.5 rounded-lg text-[10.5px] sm:text-xs font-extrabold flex items-center gap-1.5 transition cursor-pointer whitespace-nowrap shrink-0 ${
                  active
                    ? 'bg-amber-500 text-slate-950 shadow'
                    : 'bg-white/5 text-amber-100/80 border border-white/10 hover:border-amber-300/45'
                }`}
              >
                <Icon className="w-3.5 h-3.5 shrink-0" />
                <span>{t.label}</span>
                {t.badge !== null && (
                  <span
                    className={`px-1.5 py-0.2 rounded-full text-[9px] font-black tabular-nums ${
                      active ? 'bg-slate-950 text-amber-300' : 'bg-amber-400/20 text-amber-300'
                    }`}
                  >
                    {t.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Tab Workspace */}
        <div className="flex-1 min-h-0 overflow-hidden p-2.5 sm:p-3.5 flex flex-col">
          {/* ==================== TAB 1: FLASH OFFERS & PRICING ==================== */}
          {activeTab === 'pricing' && (
            <div className="flex-1 min-h-0 flex flex-col gap-2">
              <div className="shrink-0 flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-1 p-0.5 rounded-xl bg-black/45 border border-white/10">
                  {(
                    [
                      { id: 'all', label: 'All Items' },
                      { id: 'skin', label: `Skins (${SKINS.length})` },
                      { id: 'aura', label: `Auras (${AURAS.length - 1})` },
                      { id: 'pose', label: `Poses (${allPoseEntries.length})` },
                    ] as const
                  ).map((f) => (
                    <button
                      key={f.id}
                      type="button"
                      onClick={() => setPriceFilter(f.id)}
                      className={`px-2.5 py-1 rounded-lg text-[10.5px] font-bold cursor-pointer whitespace-nowrap ${
                        priceFilter === f.id
                          ? 'bg-amber-400 text-slate-950'
                          : 'text-amber-100/75 hover:text-amber-100'
                      }`}
                    >
                      {f.label}
                    </button>
                  ))}
                </div>

                <div className="relative flex-1 min-w-[170px] max-w-xs">
                  <Search className="w-3.5 h-3.5 text-amber-300/70 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    value={priceSearch}
                    onChange={(e) => setPriceSearch(e.target.value)}
                    placeholder="Search skin, warrior, aura, pose..."
                    className="w-full pl-8 pr-2.5 py-1 rounded-lg bg-[#080612] border border-white/15 text-xs text-amber-100 focus:outline-none focus:border-amber-300"
                  />
                </div>
              </div>

              <div className="flex-1 min-h-0 overflow-y-auto roster-scroll pr-1 space-y-1.5">
                {filteredCosmetics.map((item) => {
                  const eff = getEffectiveCosmeticPricing(item, cmsConfig);
                  const thumbFighter = item.category === 'skin' ? item.fighterId : FIGHTERS[0].id;
                  const ownerLabel = item.category === 'skin' ? getCfgById(item.fighterId).name : 'All Warriors';
                  return (
                    <div
                      key={item.id}
                      className={`rounded-xl border px-2.5 py-1.5 flex items-center justify-between gap-2 ${
                        eff.hasOverride
                          ? 'border-amber-400/65 bg-amber-500/10'
                          : 'border-white/10 bg-[#130f22]/90'
                      }`}
                    >
                      <div className="flex items-center gap-2 min-w-0 flex-1">
                        <MiniThumb
                          fighterId={thumbFighter}
                          skinId={item.category === 'skin' ? item.id : undefined}
                          auraId={item.category === 'aura' ? item.id : DEFAULT_AURA_ID}
                          isAuraCard={item.category === 'aura'}
                        />
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs font-extrabold text-amber-100 truncate">{item.name}</span>
                            {eff.flashLabel && (
                              <span className="px-1.5 py-0.2 rounded bg-rose-500 text-white text-[8.5px] font-black uppercase">
                                {eff.flashLabel}
                              </span>
                            )}
                          </div>
                          <div className="text-[9.5px] text-amber-200/70 truncate">
                            {ownerLabel} · Base:{' '}
                            {item.fkPrice !== null ? `${item.fkPrice} FK / ` : 'Crown · '}
                            {item.gotaPrice} Gota
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        {item.fkPrice !== null ? (
                          <label className="flex items-center gap-1 px-1.5 py-1 rounded-lg bg-[#080612] border border-cyan-400/35">
                            <Coins className="w-3 h-3 text-cyan-300 shrink-0" />
                            <input
                              type="number"
                              min={1}
                              max={99999}
                              value={eff.fkPrice ?? ''}
                              onChange={(e) => {
                                const val = Math.max(1, Math.round(Number(e.target.value) || 1));
                                handleSetPriceOverride(item.id, { fkPrice: val }, item.fkPrice, item.gotaPrice);
                              }}
                              aria-label={`${item.name} FK Price`}
                              className="w-14 bg-transparent text-xs font-num font-bold text-cyan-100 focus:outline-none tabular-nums"
                            />
                          </label>
                        ) : (
                          <span className="px-2 py-1 rounded-lg border border-amber-400/25 bg-black/40 text-[9.5px] font-bold text-amber-300/80 whitespace-nowrap">
                            Crown Only
                          </span>
                        )}

                        <label className="flex items-center gap-1 px-1.5 py-1 rounded-lg bg-[#080612] border border-amber-400/40">
                          <Gem className="w-3 h-3 text-amber-300 shrink-0" />
                          <input
                            type="number"
                            min={1}
                            max={9999}
                            value={eff.gotaPrice}
                            onChange={(e) => {
                              const val = Math.max(1, Math.round(Number(e.target.value) || 1));
                              handleSetPriceOverride(item.id, { gotaPrice: val }, item.fkPrice, item.gotaPrice);
                            }}
                            aria-label={`${item.name} Gota Price`}
                            className="w-12 bg-transparent text-xs font-num font-bold text-amber-100 focus:outline-none tabular-nums"
                          />
                        </label>

                        <input
                          type="text"
                          value={cmsConfig.priceOverrides[item.id]?.flashLabel || ''}
                          onChange={(e) =>
                            handleSetPriceOverride(
                              item.id,
                              { flashLabel: e.target.value },
                              item.fkPrice,
                              item.gotaPrice,
                            )
                          }
                          maxLength={18}
                          placeholder="Flash tag"
                          className="hidden md:block w-24 px-2 py-1 rounded-lg bg-[#080612] border border-white/15 text-[10.5px] font-bold text-rose-200 placeholder:text-slate-500 focus:outline-none focus:border-rose-400"
                        />

                        <button
                          type="button"
                          disabled={!eff.hasOverride}
                          onClick={() => handleClearSingleOverride(item.id)}
                          title="Restore default price"
                          className="px-2 py-1 rounded-lg border border-white/15 bg-white/5 text-[10px] font-bold text-slate-300 hover:text-white disabled:opacity-30 cursor-pointer"
                        >
                          Reset
                        </button>
                      </div>
                    </div>
                  );
                })}

                {filteredPoses.map((pose) => {
                  const eff = getEffectivePosePricing(pose.fighterId, pose.poseId, cmsConfig);
                  return (
                    <div
                      key={pose.poseId}
                      className={`rounded-xl border px-2.5 py-1.5 flex items-center justify-between gap-2 ${
                        eff.hasOverride
                          ? 'border-amber-400/65 bg-amber-500/10'
                          : 'border-white/10 bg-[#130f22]/90'
                      }`}
                    >
                      <div className="flex items-center gap-2 min-w-0 flex-1">
                        <div className="w-10 h-10 rounded-lg border border-amber-400/35 bg-[#090714] flex flex-col items-center justify-center shrink-0">
                          <Crown className="w-4 h-4 text-amber-300" />
                          <span className="text-[8px] font-black text-amber-200">POSE {pose.index}</span>
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs font-extrabold text-amber-100 truncate">{pose.poseName}</span>
                            {eff.flashLabel && (
                              <span className="px-1.5 py-0.2 rounded bg-rose-500 text-white text-[8.5px] font-black uppercase">
                                {eff.flashLabel}
                              </span>
                            )}
                          </div>
                          <div className="text-[9.5px] text-amber-200/70 truncate">
                            {pose.fighterName} · Base: {pose.baseFk} FK / {pose.baseGota} Gota
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <label className="flex items-center gap-1 px-1.5 py-1 rounded-lg bg-[#080612] border border-cyan-400/35">
                          <Coins className="w-3 h-3 text-cyan-300 shrink-0" />
                          <input
                            type="number"
                            min={1}
                            max={99999}
                            value={eff.fkPrice}
                            onChange={(e) => {
                              const val = Math.max(1, Math.round(Number(e.target.value) || 1));
                              handleSetPriceOverride(pose.poseId, { fkPrice: val }, pose.baseFk, pose.baseGota);
                            }}
                            aria-label={`${pose.poseName} FK Price`}
                            className="w-14 bg-transparent text-xs font-num font-bold text-cyan-100 focus:outline-none tabular-nums"
                          />
                        </label>

                        <label className="flex items-center gap-1 px-1.5 py-1 rounded-lg bg-[#080612] border border-amber-400/40">
                          <Gem className="w-3 h-3 text-amber-300 shrink-0" />
                          <input
                            type="number"
                            min={1}
                            max={9999}
                            value={eff.gotaPrice}
                            onChange={(e) => {
                              const val = Math.max(1, Math.round(Number(e.target.value) || 1));
                              handleSetPriceOverride(pose.poseId, { gotaPrice: val }, pose.baseFk, pose.baseGota);
                            }}
                            aria-label={`${pose.poseName} Gota Price`}
                            className="w-12 bg-transparent text-xs font-num font-bold text-amber-100 focus:outline-none tabular-nums"
                          />
                        </label>

                        <input
                          type="text"
                          value={cmsConfig.priceOverrides[pose.poseId]?.flashLabel || ''}
                          onChange={(e) =>
                            handleSetPriceOverride(
                              pose.poseId,
                              { flashLabel: e.target.value },
                              pose.baseFk,
                              pose.baseGota,
                            )
                          }
                          maxLength={18}
                          placeholder="Flash tag"
                          className="hidden md:block w-24 px-2 py-1 rounded-lg bg-[#080612] border border-white/15 text-[10.5px] font-bold text-rose-200 placeholder:text-slate-500 focus:outline-none focus:border-rose-400"
                        />

                        <button
                          type="button"
                          disabled={!eff.hasOverride}
                          onClick={() => handleClearSingleOverride(pose.poseId)}
                          className="px-2 py-1 rounded-lg border border-white/15 bg-white/5 text-[10px] font-bold text-slate-300 hover:text-white disabled:opacity-30 cursor-pointer"
                        >
                          Reset
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ==================== TAB 2: BUNDLE CREATOR ==================== */}
          {activeTab === 'bundles' && (
            <div className="flex-1 min-h-0 grid grid-cols-[1.05fr_1fr] gap-3 overflow-hidden">
              {/* Left: Multi-Select Item Picker */}
              <div className="min-h-0 flex flex-col rounded-xl border border-white/12 bg-black/35 p-2.5 gap-2 overflow-hidden">
                <div className="shrink-0 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1 p-0.5 rounded-lg bg-[#090714] border border-white/10">
                    {(
                      [
                        { id: 'skin', label: 'Skins' },
                        { id: 'aura', label: 'Auras' },
                        { id: 'pose', label: 'Poses' },
                      ] as const
                    ).map((f) => (
                      <button
                        key={f.id}
                        type="button"
                        onClick={() => setBundleFilter(f.id)}
                        className={`px-2 py-0.5 rounded text-[10.5px] font-bold cursor-pointer ${
                          bundleFilter === f.id ? 'bg-amber-400 text-slate-950' : 'text-amber-100/75'
                        }`}
                      >
                        {f.label}
                      </button>
                    ))}
                  </div>
                  <input
                    type="text"
                    value={bundleSearch}
                    onChange={(e) => setBundleSearch(e.target.value)}
                    placeholder="Filter items..."
                    className="flex-1 min-w-0 px-2 py-1 rounded-lg bg-[#080612] border border-white/15 text-[11px] text-amber-100 focus:outline-none focus:border-amber-300"
                  />
                </div>

                <div className="flex-1 min-h-0 overflow-y-auto roster-scroll pr-1 grid grid-cols-1 sm:grid-cols-2 gap-1.5 content-start">
                  {bundleFilter === 'skin' &&
                    pickerSkins.map((s) => {
                      const selected = bundleItemIds.includes(s.id);
                      return (
                        <button
                          key={s.id}
                          type="button"
                          onClick={() => toggleBundleToken(s.id)}
                          className={`text-left p-1.5 rounded-lg border flex items-center gap-2 cursor-pointer transition ${
                            selected
                              ? 'border-emerald-400 bg-emerald-500/18'
                              : 'border-white/10 bg-[#120e21] hover:border-amber-300/45'
                          }`}
                        >
                          <MiniThumb fighterId={s.fighterId} skinId={s.id} isAuraCard={false} />
                          <div className="min-w-0 flex-1">
                            <div className="text-[11px] font-extrabold text-amber-100 truncate">{s.name}</div>
                            <div className="text-[9.5px] text-amber-200/70 truncate">
                              {getCfgById(s.fighterId).name} · {s.gotaPrice} Gota
                            </div>
                          </div>
                          {selected && <Check className="w-3.5 h-3.5 text-emerald-300 shrink-0" />}
                        </button>
                      );
                    })}

                  {bundleFilter === 'aura' &&
                    pickerAuras.map((a) => {
                      const selected = bundleItemIds.includes(a.id);
                      return (
                        <button
                          key={a.id}
                          type="button"
                          onClick={() => toggleBundleToken(a.id)}
                          className={`text-left p-1.5 rounded-lg border flex items-center gap-2 cursor-pointer transition ${
                            selected
                              ? 'border-emerald-400 bg-emerald-500/18'
                              : 'border-white/10 bg-[#120e21] hover:border-amber-300/45'
                          }`}
                        >
                          <MiniThumb fighterId={FIGHTERS[0].id} auraId={a.id} isAuraCard />
                          <div className="min-w-0 flex-1">
                            <div className="text-[11px] font-extrabold text-amber-100 truncate">{a.name}</div>
                            <div className="text-[9.5px] text-cyan-200/75 truncate">Aura · {a.gotaPrice} Gota</div>
                          </div>
                          {selected && <Check className="w-3.5 h-3.5 text-emerald-300 shrink-0" />}
                        </button>
                      );
                    })}

                  {bundleFilter === 'pose' &&
                    pickerPoses.map((p) => {
                      const token = encodePoseBundleToken(p.fighterId, p.poseId);
                      const selected = bundleItemIds.includes(token);
                      return (
                        <button
                          key={token}
                          type="button"
                          onClick={() => toggleBundleToken(token)}
                          className={`text-left p-1.5 rounded-lg border flex items-center gap-2 cursor-pointer transition ${
                            selected
                              ? 'border-emerald-400 bg-emerald-500/18'
                              : 'border-white/10 bg-[#120e21] hover:border-amber-300/45'
                          }`}
                        >
                          <div className="w-10 h-10 rounded-lg border border-amber-400/35 bg-[#090714] flex flex-col items-center justify-center shrink-0">
                            <Crown className="w-4 h-4 text-amber-300" />
                            <span className="text-[8px] font-black text-amber-200">P{p.index}</span>
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="text-[11px] font-extrabold text-amber-100 truncate">{p.poseName}</div>
                            <div className="text-[9.5px] text-amber-200/70 truncate">
                              {p.fighterName} · {p.baseGota} Gota
                            </div>
                          </div>
                          {selected && <Check className="w-3.5 h-3.5 text-emerald-300 shrink-0" />}
                        </button>
                      );
                    })}
                </div>
              </div>

              {/* Right: Bundle Form + Existing Bundles */}
              <div className="min-h-0 flex flex-col gap-2 overflow-y-auto roster-scroll pr-1">
                <form
                  onSubmit={handlePushBundle}
                  className="shrink-0 rounded-xl border border-amber-400/35 bg-[#140f25] p-2.5 space-y-2"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[10.5px] font-black uppercase tracking-wider text-amber-300">
                      {editingBundleId ? 'Edit Promotional Bundle' : 'Create Promotional Bundle'}
                    </span>
                    {editingBundleId && (
                      <button
                        type="button"
                        onClick={() => setEditingBundleId(null)}
                        className="text-[10px] text-rose-300 underline cursor-pointer"
                      >
                        Cancel Edit
                      </button>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      value={bundleTitle}
                      onChange={(e) => setBundleTitle(e.target.value)}
                      maxLength={48}
                      placeholder="Bundle Title"
                      className="px-2.5 py-1.5 rounded-lg bg-[#080612] border border-white/15 text-xs font-bold text-amber-100 focus:outline-none focus:border-amber-300"
                    />
                    <input
                      type="text"
                      value={bundleBadge}
                      onChange={(e) => setBundleBadge(e.target.value)}
                      maxLength={20}
                      placeholder="Badge (e.g. SAVE 40%)"
                      className="px-2.5 py-1.5 rounded-lg bg-[#080612] border border-white/15 text-xs font-bold text-rose-200 focus:outline-none focus:border-rose-300"
                    />
                  </div>

                  <input
                    type="text"
                    value={bundleSubtitle}
                    onChange={(e) => setBundleSubtitle(e.target.value)}
                    maxLength={80}
                    placeholder="Short promotional tagline..."
                    className="w-full px-2.5 py-1.5 rounded-lg bg-[#080612] border border-white/15 text-[11px] text-amber-100/90 focus:outline-none focus:border-amber-300"
                  />

                  <div className="flex flex-wrap gap-1 min-h-[26px]">
                    {bundleItemIds.length === 0 ? (
                      <span className="text-[10px] text-slate-400">Pick items from the left catalog...</span>
                    ) : (
                      bundleItemIds.map((tok) => {
                        const dec = decodeBundleToken(tok);
                        const label =
                          dec?.kind === 'cosmetic'
                            ? dec.cosmetic.name
                            : dec?.kind === 'pose'
                              ? `${dec.pose.poseName} (Pose)`
                              : tok;
                        return (
                          <button
                            key={tok}
                            type="button"
                            onClick={() => toggleBundleToken(tok)}
                            className="px-1.5 py-0.5 rounded bg-amber-500/18 border border-amber-400/40 text-[9.5px] font-bold text-amber-200 flex items-center gap-1 cursor-pointer hover:bg-rose-500/20"
                          >
                            <span className="truncate max-w-[120px]">{label}</span>
                            <X className="w-2.5 h-2.5" />
                          </button>
                        );
                      })
                    )}
                  </div>

                  <div className="flex items-center justify-between gap-2 pt-1 border-t border-white/10">
                    <div className="flex items-center gap-2">
                      <label className="flex items-center gap-1 px-2 py-1 rounded-lg bg-[#080612] border border-amber-400/45">
                        <Gem className="w-3.5 h-3.5 text-amber-300" />
                        <input
                          type="number"
                          min={1}
                          max={9999}
                          value={bundleGotaPrice}
                          onChange={(e) => setBundleGotaPrice(Math.max(1, Math.round(Number(e.target.value) || 1)))}
                          className="w-12 bg-transparent text-xs font-num font-black text-amber-100 focus:outline-none tabular-nums"
                        />
                        <span className="text-[10px] font-bold text-amber-200">Gota</span>
                      </label>
                      <div className="text-[10px] text-emerald-300 font-bold tabular-nums">
                        Reg: {draftRegularGota} Gota · {draftDiscountPct > 0 ? `${draftDiscountPct}% OFF` : 'Custom'}
                      </div>
                    </div>

                    <button
                      type="submit"
                      data-ui-sfx="unlock"
                      className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-400 to-rose-500 text-slate-950 text-[11px] font-black flex items-center gap-1 cursor-pointer hover:brightness-110 shrink-0"
                    >
                      <PackagePlus className="w-3.5 h-3.5" />
                      {editingBundleId ? 'Update Bundle' : 'Push Bundle to Store'}
                    </button>
                  </div>
                </form>

                {/* Active & Paused Bundles List */}
                <div className="space-y-1.5">
                  <div className="text-[10px] font-black uppercase tracking-wider text-amber-200/75">
                    Published Store Bundles ({cmsConfig.bundles.length})
                  </div>
                  {cmsConfig.bundles.length === 0 ? (
                    <div className="p-3 rounded-xl border border-white/10 bg-black/25 text-[11px] text-slate-400 text-center">
                      No promotional bundles created yet. Select items on the left and click Push Bundle to Store.
                    </div>
                  ) : (
                    cmsConfig.bundles.map((b) => (
                      <div
                        key={b.id}
                        className={`rounded-xl border p-2 flex items-center justify-between gap-2 ${
                          b.active ? 'border-emerald-400/45 bg-emerald-500/8' : 'border-white/10 bg-black/30 opacity-70'
                        }`}
                      >
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs font-extrabold text-amber-100 truncate">{b.title}</span>
                            {b.badgeText && (
                              <span className="px-1.5 py-0.2 rounded bg-amber-400 text-slate-950 text-[8.5px] font-black uppercase">
                                {b.badgeText}
                              </span>
                            )}
                          </div>
                          <div className="text-[10px] text-amber-200/75 tabular-nums">
                            {b.itemIds.length} items · {b.gotaPrice} Gota · {b.active ? 'LIVE IN STORE' : 'PAUSED'}
                          </div>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            onClick={() => handleToggleBundleActive(b.id)}
                            title={b.active ? 'Pause bundle' : 'Activate bundle'}
                            className="p-1.5 rounded-lg border border-white/15 bg-white/5 text-amber-200 hover:border-amber-300 cursor-pointer"
                          >
                            {b.active ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setEditingBundleId(b.id);
                              setBundleTitle(b.title);
                              setBundleSubtitle(b.subtitle);
                              setBundleBadge(b.badgeText || '');
                              setBundleGotaPrice(b.gotaPrice);
                              setBundleItemIds(b.itemIds);
                            }}
                            title="Edit bundle"
                            className="p-1.5 rounded-lg border border-cyan-400/35 bg-cyan-500/10 text-cyan-200 hover:bg-cyan-500/20 cursor-pointer"
                          >
                            <Edit3 className="w-3 h-3" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteBundle(b.id)}
                            title="Delete bundle"
                            className="p-1.5 rounded-lg border border-rose-400/35 bg-rose-500/10 text-rose-200 hover:bg-rose-500/20 cursor-pointer"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ==================== TAB 3: UNRELEASED SKINS INJECTOR ==================== */}
          {activeTab === 'injector' && (
            <div className="flex-1 min-h-0 flex flex-col gap-2 overflow-hidden">
              <div className="shrink-0 px-3 py-1.5 rounded-xl border border-cyan-400/35 bg-cyan-500/10 text-[10.5px] text-cyan-100 flex items-center justify-between gap-2">
                <span className="flex items-center gap-1.5 truncate">
                  <FlaskConical className="w-3.5 h-3.5 text-cyan-300 shrink-0" />
                  <span>
                    <strong>Dev-Session Isolated:</strong> Prototype skins &amp; auras stay inside{' '}
                    <code className="text-amber-300">gc_dev_unreleased_cosmetics_v1</code> — zero bloat for regular players.
                  </span>
                </span>
                <span className="text-[9.5px] font-extrabold text-amber-300 shrink-0 tabular-nums">
                  {unreleasedCosmetics.length} Injected
                </span>
              </div>

              <div className="flex-1 min-h-0 grid grid-cols-[1.15fr_1fr] gap-3 overflow-hidden">
                {/* Left: Builder Form */}
                <form
                  onSubmit={handleInjectSubmit}
                  className="min-h-0 overflow-y-auto roster-scroll pr-1 rounded-xl border border-white/12 bg-black/35 p-2.5 space-y-2"
                >
                  <div className="flex items-center gap-1 p-0.5 rounded-lg bg-[#090714] border border-white/10">
                    <button
                      type="button"
                      onClick={() => setInjectMode('skin')}
                      className={`flex-1 py-1 rounded text-[11px] font-extrabold cursor-pointer ${
                        injectMode === 'skin' ? 'bg-amber-400 text-slate-950' : 'text-amber-100/75'
                      }`}
                    >
                      Custom Fighter Skin
                    </button>
                    <button
                      type="button"
                      onClick={() => setInjectMode('aura')}
                      className={`flex-1 py-1 rounded text-[11px] font-extrabold cursor-pointer ${
                        injectMode === 'aura' ? 'bg-cyan-400 text-slate-950' : 'text-amber-100/75'
                      }`}
                    >
                      Custom Aura FX
                    </button>
                  </div>

                  {injectMode === 'skin' ? (
                    <>
                      <div className="grid grid-cols-2 gap-2">
                        <select
                          value={skinFighterId}
                          onChange={(e) => setSkinFighterId(e.target.value)}
                          className="px-2 py-1.5 rounded-lg bg-[#080612] border border-amber-400/35 text-xs font-bold text-amber-100 focus:outline-none"
                        >
                          {FIGHTERS.map((f) => (
                            <option key={f.id} value={f.id}>
                              {f.name}
                            </option>
                          ))}
                        </select>
                        <select
                          value={skinMotif}
                          onChange={(e) => setSkinMotif(e.target.value as NonNullable<SkinDef['palette']['motif']>)}
                          className="px-2 py-1.5 rounded-lg bg-[#080612] border border-white/15 text-xs font-bold text-amber-100 focus:outline-none"
                        >
                          {MOTIF_OPTIONS.map((m) => (
                            <option key={m} value={m}>
                              Motif: {m.toUpperCase()}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <input
                          type="text"
                          value={skinName}
                          onChange={(e) => setSkinName(e.target.value)}
                          maxLength={36}
                          placeholder="Prototype Skin Name"
                          className="px-2.5 py-1.5 rounded-lg bg-[#080612] border border-white/15 text-xs font-bold text-amber-100 focus:outline-none"
                        />
                        <input
                          type="text"
                          value={skinSubtitle}
                          onChange={(e) => setSkinSubtitle(e.target.value)}
                          maxLength={64}
                          placeholder="Subtitle"
                          className="px-2.5 py-1.5 rounded-lg bg-[#080612] border border-white/15 text-[11px] text-amber-100 focus:outline-none"
                        />
                      </div>

                      <div className="grid grid-cols-4 gap-1.5 text-[9.5px] font-bold text-amber-100/80">
                        {(
                          [
                            ['Tunic', tunicColor, setTunicColor],
                            ['Tunic Dark', tunicDarkColor, setTunicDarkColor],
                            ['Pants', pantsColor, setPantsColor],
                            ['Pants Dark', pantsDarkColor, setPantsDarkColor],
                            ['Zari Trim', trimColor, setTrimColor],
                            ['Aura Glow', auraColor, setAuraColor],
                            ['Highlight', glowColor, setGlowColor],
                            ['Eyes', eyeColor, setEyeColor],
                          ] as const
                        ).map(([label, val, setter]) => (
                          <label
                            key={label}
                            className="flex items-center justify-between gap-1 px-1.5 py-1 rounded-lg bg-[#080612] border border-white/10 cursor-pointer"
                          >
                            <span className="truncate">{label}</span>
                            <input
                              type="color"
                              value={val}
                              onChange={(e) => setter(e.target.value)}
                              className="w-5 h-4 bg-transparent border-0 cursor-pointer shrink-0"
                            />
                          </label>
                        ))}
                      </div>

                      <label className="flex items-center gap-2 text-[11px] text-amber-200 font-bold cursor-pointer">
                        <input
                          type="checkbox"
                          checked={skinShiny}
                          onChange={(e) => setSkinShiny(e.target.checked)}
                          className="accent-amber-400"
                        />
                        Enable metallic / silk shimmer highlight
                      </label>
                    </>
                  ) : (
                    <>
                      <div className="grid grid-cols-2 gap-2">
                        <input
                          type="text"
                          value={auraName}
                          onChange={(e) => setAuraName(e.target.value)}
                          maxLength={36}
                          placeholder="Prototype Aura Name"
                          className="px-2.5 py-1.5 rounded-lg bg-[#080612] border border-white/15 text-xs font-bold text-amber-100 focus:outline-none"
                        />
                        <select
                          value={auraStyle}
                          onChange={(e) => setAuraStyle(e.target.value as Exclude<AuraDef['style'], 'none'>)}
                          className="px-2 py-1.5 rounded-lg bg-[#080612] border border-cyan-400/35 text-xs font-bold text-cyan-100 focus:outline-none"
                        >
                          {AURA_STYLES.map((st) => (
                            <option key={st} value={st}>
                              FX Style: {st.toUpperCase()}
                            </option>
                          ))}
                        </select>
                      </div>

                      <input
                        type="text"
                        value={auraSubtitle}
                        onChange={(e) => setAuraSubtitle(e.target.value)}
                        maxLength={64}
                        placeholder="Aura description..."
                        className="w-full px-2.5 py-1.5 rounded-lg bg-[#080612] border border-white/15 text-[11px] text-amber-100 focus:outline-none"
                      />

                      <div className="grid grid-cols-3 gap-2 text-[10px] font-bold text-amber-100/80">
                        {(
                          [
                            ['Ring Color', auraRingColor, setAuraRingColor],
                            ['Spark Color', auraSparkColor, setAuraSparkColor],
                            ['Secondary', auraSecondaryColor, setAuraSecondaryColor],
                          ] as const
                        ).map(([label, val, setter]) => (
                          <label
                            key={label}
                            className="flex items-center justify-between gap-1 px-2 py-1.5 rounded-lg bg-[#080612] border border-white/10 cursor-pointer"
                          >
                            <span>{label}</span>
                            <input
                              type="color"
                              value={val}
                              onChange={(e) => setter(e.target.value)}
                              className="w-6 h-5 bg-transparent border-0 cursor-pointer"
                            />
                          </label>
                        ))}
                      </div>
                    </>
                  )}

                  <div className="grid grid-cols-2 gap-2 pt-1 border-t border-white/10">
                    <label className="flex items-center justify-between px-2 py-1 rounded-lg bg-[#080612] border border-cyan-400/30 text-[10px] text-cyan-200 font-bold">
                      <span>Test FK (empty = Crown)</span>
                      <input
                        type="number"
                        min={1}
                        max={99999}
                        value={testFkPrice}
                        onChange={(e) => setTestFkPrice(e.target.value)}
                        placeholder="Crown"
                        className="w-16 text-right bg-transparent text-xs font-num text-cyan-100 focus:outline-none"
                      />
                    </label>
                    <label className="flex items-center justify-between px-2 py-1 rounded-lg bg-[#080612] border border-amber-400/35 text-[10px] text-amber-200 font-bold">
                      <span>Test Gota</span>
                      <input
                        type="number"
                        min={1}
                        max={9999}
                        value={testGotaPrice}
                        onChange={(e) => setTestGotaPrice(Math.max(1, Math.round(Number(e.target.value) || 1)))}
                        className="w-14 text-right bg-transparent text-xs font-num text-amber-100 focus:outline-none"
                      />
                    </label>
                  </div>

                  <button
                    type="submit"
                    data-ui-sfx="unlock"
                    className="w-full py-2 rounded-xl bg-gradient-to-r from-cyan-400 to-emerald-400 text-slate-950 text-xs font-black flex items-center justify-center gap-1.5 hover:brightness-110 cursor-pointer"
                  >
                    <Wand2 className="w-3.5 h-3.5" />
                    Inject Test {injectMode === 'skin' ? 'Skin' : 'Aura'} into Dev Session
                  </button>
                </form>

                {/* Right: Live Preview Stage + Injected Prototypes */}
                <div className="min-h-0 flex flex-col gap-2 overflow-hidden">
                  <div className="shrink-0 relative h-[165px] rounded-xl border border-amber-400/30 bg-[#080612] overflow-hidden flex items-center justify-center">
                    <canvas ref={injectorCanvasRef} width={300} height={180} className="w-full h-full object-contain" />
                    <span className="absolute top-1.5 left-2 px-2 py-0.5 rounded bg-black/70 border border-cyan-400/40 text-[9px] font-black uppercase text-cyan-200">
                      Live Prototype Preview
                    </span>
                  </div>

                  <div className="flex-1 min-h-0 overflow-y-auto roster-scroll pr-1 space-y-1.5">
                    {unreleasedCosmetics.length === 0 ? (
                      <div className="p-3 rounded-xl border border-white/10 bg-black/25 text-[11px] text-slate-400 text-center">
                        No test cosmetics injected yet. Tweak colors on the left and click Inject!
                      </div>
                    ) : (
                      unreleasedCosmetics.map((item) => {
                        const isEq =
                          item.category === 'skin'
                            ? devSession.equippedSkinIds.includes(item.id)
                            : devSession.equippedAuraId === item.id;
                        return (
                          <div
                            key={item.id}
                            className={`rounded-xl border p-2 flex items-center justify-between gap-2 ${
                              isEq ? 'border-emerald-400 bg-emerald-500/12' : 'border-white/10 bg-[#120e21]'
                            }`}
                          >
                            <div className="flex items-center gap-2 min-w-0">
                              <MiniThumb
                                fighterId={item.category === 'skin' ? item.fighterId : skinFighterId}
                                skinId={item.category === 'skin' ? item.id : undefined}
                                auraId={item.category === 'aura' ? item.id : DEFAULT_AURA_ID}
                                isAuraCard={item.category === 'aura'}
                              />
                              <div className="min-w-0">
                                <div className="flex items-center gap-1">
                                  <span className="text-xs font-extrabold text-amber-100 truncate">{item.name}</span>
                                  <span className="px-1 py-0.2 rounded bg-cyan-400 text-slate-950 text-[8px] font-black uppercase shrink-0">
                                    DEV TEST
                                  </span>
                                </div>
                                <div className="text-[9.5px] text-amber-200/70 truncate">
                                  {item.category === 'skin' ? getCfgById(item.fighterId).name : 'All Warriors'} ·{' '}
                                  {item.fkPrice ? `${item.fkPrice} FK / ` : ''}
                                  {item.gotaPrice} Gota
                                </div>
                              </div>
                            </div>

                            <div className="flex items-center gap-1 shrink-0">
                              <button
                                type="button"
                                data-ui-sfx="unlock"
                                onClick={() => onEquipInjectedCosmetic(item)}
                                className={`px-2 py-1 rounded-lg text-[10px] font-black cursor-pointer ${
                                  isEq
                                    ? 'bg-emerald-400 text-slate-950'
                                    : 'bg-amber-500 text-slate-950 hover:brightness-110'
                                }`}
                              >
                                {isEq ? 'Equipped' : 'Equip Now'}
                              </button>
                              <button
                                type="button"
                                onClick={() => onDeleteInjectedCosmetic(item.id)}
                                title="Remove injected test cosmetic"
                                className="p-1.5 rounded-lg border border-rose-400/35 bg-rose-500/10 text-rose-200 hover:bg-rose-500/20 cursor-pointer"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ==================== TAB 4: THEME EVENT SWITCHER ==================== */}
          {activeTab === 'themes' && (
            <div className="flex-1 min-h-0 flex flex-col gap-3 overflow-y-auto roster-scroll">
              <div className="px-3 py-2 rounded-xl border border-amber-400/30 bg-amber-500/10 text-[11px] text-amber-100 flex items-center justify-between gap-2">
                <span>
                  <strong className="text-amber-300">Victoria Memorial Live Event Switcher:</strong> Changes sky palette, celestial body, palace lighting, water reflection, and festive atmospheric particles in real time.
                </span>
                <Sparkles className="w-4 h-4 text-amber-300 shrink-0" />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 flex-1">
                {LOBBY_THEMES.map((theme) => {
                  const active = cmsConfig.lobbyTheme === theme.id;
                  return (
                    <button
                      key={theme.id}
                      type="button"
                      data-ui-sfx="select"
                      onClick={() => void handleSelectTheme(theme.id)}
                      className={`text-left rounded-2xl border-2 p-3 flex flex-col justify-between gap-2.5 transition cursor-pointer ${
                        active
                          ? 'border-emerald-400 bg-emerald-500/12 shadow-[0_0_24px_rgba(52,211,153,0.22)]'
                          : 'border-white/12 bg-[#130f22]/90 hover:border-amber-300/60'
                      }`}
                    >
                      <div
                        className="h-20 w-full rounded-xl border border-white/15 relative overflow-hidden flex items-end p-2"
                        style={{ background: theme.previewGradient }}
                      >
                        <div className="flex items-center justify-between w-full">
                          <span className="px-2 py-0.5 rounded-md bg-black/65 text-[10px] font-black uppercase tracking-wider text-white flex items-center gap-1">
                            {theme.id === 'blood_moon' ? (
                              <Flame className="w-3 h-3 text-rose-400" />
                            ) : (
                              <Sparkles className="w-3 h-3" style={{ color: theme.accentColor }} />
                            )}
                            {theme.name}
                          </span>
                          {active && (
                            <span className="px-2 py-0.5 rounded-md bg-emerald-400 text-slate-950 text-[9.5px] font-black uppercase flex items-center gap-1">
                              <Check className="w-3 h-3" />
                              ACTIVE
                            </span>
                          )}
                        </div>
                      </div>
                      <div>
                        <div className="font-display-in text-base text-amber-100">{theme.name}</div>
                        <p className="text-[11px] text-amber-100/75 leading-snug mt-0.5">{theme.tagline}</p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
