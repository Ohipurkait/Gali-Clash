import React, { useEffect, useState } from 'react';
import {
  Check,
  Code2,
  Coins,
  Copy,
  Crown,
  Gem,
  Gift,
  Inbox,
  Mail,
  RefreshCw,
  Send,
  Sparkles,
  Trophy,
  X,
} from 'lucide-react';
import { sound } from '../game/audio';
import { AURAS, SKINS } from '../game/cosmetics';
import { getCfgById } from '../game/data';
import {
  DevGiftMail,
  formatGiftBadgeText,
  getAllUnlockablePoseOptions,
  MailGiftType,
} from '../services/mailbox';

interface MailboxModalProps {
  open: boolean;
  initialTab?: 'inbox' | 'send';
  playerId: string;
  isDeveloperMode: boolean;
  isSignedIn: boolean;
  mails: DevGiftMail[];
  loading: boolean;
  onRefresh: () => Promise<void>;
  onClaimMail: (mail: DevGiftMail) => Promise<void>;
  onSendGiftMail: (payload: {
    targetPlayerId: string;
    title: string;
    message: string;
    giftType: MailGiftType;
    giftAmount: number;
    giftItemId: string;
  }) => Promise<{ syncedCloud: boolean }>;
  onCopyPlayerId: () => void;
  onClose: () => void;
}

const UNLOCKABLE_AURAS = AURAS.filter((a) => a.id !== 'aura_classic');
const UNLOCKABLE_POSES = getAllUnlockablePoseOptions();

export const MailboxModal: React.FC<MailboxModalProps> = ({
  open,
  initialTab = 'inbox',
  playerId,
  isDeveloperMode,
  isSignedIn,
  mails,
  loading,
  onRefresh,
  onClaimMail,
  onSendGiftMail,
  onCopyPlayerId,
  onClose,
}) => {
  const [tab, setTab] = useState<'inbox' | 'send'>(initialTab);
  const [claimingId, setClaimingId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState(false);

  // Dev Sender state
  const [targetId, setTargetId] = useState('ALL');
  const [title, setTitle] = useState('Akhara Special Gift!');
  const [message, setMessage] = useState('Shabaash Yoddha! Enjoy this special reward from DEV TEAM.');
  const [giftType, setGiftType] = useState<MailGiftType>('futi_kodi');
  const [giftAmount, setGiftAmount] = useState<number>(200);
  const [giftSkinId, setGiftSkinId] = useState<string>(SKINS[0]?.id || '');
  const [giftAuraId, setGiftAuraId] = useState<string>(UNLOCKABLE_AURAS[0]?.id || '');
  const [giftPoseId, setGiftPoseId] = useState<string>(UNLOCKABLE_POSES[0]?.id || '');
  const [sending, setSending] = useState(false);
  const [sendFeedback, setSendFeedback] = useState<{ ok: boolean; text: string } | null>(null);

  useEffect(() => {
    if (!open) return;
    setTab(isDeveloperMode && initialTab === 'send' ? 'send' : 'inbox');
    setSendFeedback(null);
  }, [open, initialTab, isDeveloperMode]);

  useEffect(() => {
    if (!isDeveloperMode && tab === 'send') {
      setTab('inbox');
    }
  }, [isDeveloperMode, tab]);

  if (!open) return null;

  const handleCopy = () => {
    onCopyPlayerId();
    setCopiedId(true);
    window.setTimeout(() => setCopiedId(false), 1800);
  };

  const handleClaim = async (mail: DevGiftMail) => {
    if (claimingId) return;
    setClaimingId(mail.id);
    try {
      await onClaimMail(mail);
      sound.playUiSfx('unlock');
    } catch {
      sound.playUiSfx('locked');
    } finally {
      setClaimingId(null);
    }
  };

  const handleSendSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (sending) return;
    setSendFeedback(null);
    setSending(true);
    try {
      const selectedItemId =
        giftType === 'skin'
          ? giftSkinId
          : giftType === 'aura'
            ? giftAuraId
            : giftType === 'pose'
              ? giftPoseId
              : '';
      const res = await onSendGiftMail({
        targetPlayerId: targetId,
        title,
        message,
        giftType,
        giftAmount: giftType === 'futi_kodi' || giftType === 'gota' ? giftAmount : 0,
        giftItemId: selectedItemId,
      });
      sound.playUiSfx('unlock');
      setSendFeedback({
        ok: true,
        text: res.syncedCloud
          ? `Gift Mail sent to ${targetId.trim().toUpperCase()} via Firebase!`
          : `Gift Mail queued locally for ${targetId.trim().toUpperCase()} (Sign in as Cloud Dev to broadcast globally).`,
      });
      await onRefresh();
    } catch (err) {
      sound.playUiSfx('locked');
      setSendFeedback({
        ok: false,
        text: err instanceof Error ? err.message : 'Failed to send gift mail.',
      });
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/82 backdrop-blur-xs">
      <div className="w-full max-w-3xl h-[min(540px,calc(100dvh-1rem))] flex flex-col overflow-hidden rounded-2xl border-2 border-amber-400/55 bg-[#0e0a1a]/98 shadow-[0_0_55px_rgba(245,158,11,0.3)]">
        {/* Header with Permanent GC-XXXXXX Player ID & One-Tap Copy */}
        <div className="shrink-0 flex flex-wrap items-center justify-between gap-2 px-3 sm:px-4 py-2 border-b border-amber-400/20 bg-gradient-to-r from-amber-500/18 via-transparent to-rose-500/15">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-8 h-8 rounded-xl border border-amber-400/50 bg-amber-500/18 flex items-center justify-center shrink-0">
              <Mail className="w-4 h-4 text-amber-300" />
            </div>
            <div className="min-w-0">
              <h3 className="font-display-in text-base sm:text-xl tracking-wider text-amber-200 leading-none truncate">
                GALI CLASH · DAK GHAR
              </h3>
              <p className="text-[10px] text-amber-100/65 mt-0.5 truncate">
                Developer Mailbox &amp; Gift Rewards
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <div className="flex items-center gap-1.5 px-2 py-1 rounded-lg border border-cyan-400/40 bg-cyan-500/10">
              <span className="text-[9.5px] font-bold uppercase tracking-wider text-cyan-200/80 hidden sm:inline">
                ID
              </span>
              <span className="font-num text-[11px] font-black tracking-wider text-cyan-100">
                {playerId}
              </span>
              <button
                type="button"
                data-ui-sfx="select"
                onClick={handleCopy}
                className="px-1.5 py-0.5 rounded bg-cyan-400/20 hover:bg-cyan-400/35 border border-cyan-300/45 text-[9.5px] font-extrabold text-cyan-100 flex items-center gap-1 cursor-pointer"
              >
                {copiedId ? <Check className="w-3 h-3 text-emerald-300" /> : <Copy className="w-3 h-3" />}
                <span>{copiedId ? 'Copied' : 'Copy ID'}</span>
              </button>
            </div>

            <button
              type="button"
              onClick={() => void onRefresh()}
              disabled={loading}
              title="Refresh Mailbox"
              className="w-8 h-8 rounded-lg border border-white/15 bg-black/45 text-amber-200 flex items-center justify-center hover:border-amber-300 cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close Mailbox"
              className="w-8 h-8 rounded-lg border border-amber-400/35 bg-black/45 flex items-center justify-center text-amber-200 hover:bg-amber-400/15 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Mode Switcher Bar */}
        <div className="shrink-0 flex items-center justify-between gap-2 px-3 sm:px-4 py-1.5 border-b border-white/10 bg-black/35">
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setTab('inbox')}
              className={`px-3 py-1 rounded-lg text-[11px] font-extrabold flex items-center gap-1.5 transition cursor-pointer ${
                tab === 'inbox'
                  ? 'bg-amber-400 text-slate-950 shadow-sm'
                  : 'bg-white/5 text-amber-100/75 hover:text-amber-100 border border-white/10'
              }`}
            >
              <Inbox className="w-3.5 h-3.5" />
              <span>Inbox</span>
              <span
                className={`px-1.5 py-[1px] rounded font-num text-[10px] font-black ${
                  tab === 'inbox' ? 'bg-slate-950/20 text-slate-950' : 'bg-rose-500/80 text-white'
                }`}
              >
                {mails.length}
              </span>
            </button>

            {isDeveloperMode && (
              <button
                type="button"
                onClick={() => setTab('send')}
                className={`px-3 py-1 rounded-lg text-[11px] font-extrabold flex items-center gap-1.5 transition cursor-pointer ${
                  tab === 'send'
                    ? 'bg-gradient-to-r from-emerald-400 to-cyan-400 text-slate-950 shadow-sm'
                    : 'bg-emerald-500/12 text-emerald-200 border border-emerald-400/35 hover:bg-emerald-500/20'
                }`}
              >
                <Send className="w-3.5 h-3.5" />
                <span>📤 Send Gift Mail (DEV)</span>
              </button>
            )}
          </div>

          <span className="text-[10px] text-amber-100/55 hidden sm:inline">
            Claimed mails auto-archive to save cloud space
          </span>
        </div>

        {/* Tab Body */}
        <div className="flex-1 min-h-0 overflow-y-auto roster-scroll p-3 sm:p-4">
          {tab === 'inbox' ? (
            loading && mails.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-8 text-xs text-amber-200/75">
                <RefreshCw className="w-6 h-6 animate-spin text-amber-300 mb-2" />
                Checking Dak Ghar for new gifts...
              </div>
            ) : mails.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-8 px-4">
                <div className="w-12 h-12 rounded-2xl border border-amber-400/35 bg-amber-500/10 flex items-center justify-center mb-3">
                  <Gift className="w-6 h-6 text-amber-300/80" />
                </div>
                <div className="font-display-in text-lg text-amber-100">NO PENDING GIFTS IN DAK GHAR</div>
                <p className="text-xs text-amber-100/65 mt-1 max-w-sm">
                  Share your Player ID (<span className="text-cyan-300 font-num font-bold">{playerId}</span>) with friends or the Developer Team to receive Futi Kodi, Gota, Skins, Auras, or Victory Poses!
                </p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {mails.map((mail) => {
                  const isClaiming = claimingId === mail.id;
                  const badge = formatGiftBadgeText(mail);
                  return (
                    <div
                      key={mail.id}
                      className="rounded-xl border border-amber-400/35 bg-gradient-to-r from-[#171128] via-[#120e21] to-[#191224] p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md"
                    >
                      <div className="min-w-0 space-y-1 flex-1">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-amber-400/20 border border-amber-300/45 text-[9.5px] font-black uppercase tracking-wider text-amber-200">
                            <Code2 className="w-3 h-3" />
                            {mail.senderName}
                          </span>
                          <span className="px-1.5 py-0.5 rounded bg-white/5 border border-white/10 font-num text-[9.5px] font-bold text-cyan-200">
                            {mail.targetPlayerId === 'ALL' ? 'GLOBAL GIFT' : `TO: ${mail.targetPlayerId}`}
                          </span>
                        </div>

                        <div className="font-display-in text-base sm:text-lg text-amber-100 leading-tight">
                          {mail.title}
                        </div>
                        <p className="text-[11px] sm:text-xs text-amber-100/75 leading-snug">
                          {mail.message}
                        </p>

                        <div className="pt-0.5">
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border border-yellow-300/50 bg-gradient-to-r from-amber-500/25 to-rose-500/20 text-yellow-200 text-[11px] font-extrabold">
                            {badge}
                          </span>
                        </div>
                      </div>

                      <div className="shrink-0 flex sm:flex-col items-stretch sm:items-end justify-end gap-1.5">
                        <button
                          type="button"
                          data-ui-sfx="none"
                          disabled={isClaiming}
                          onClick={() => void handleClaim(mail)}
                          className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-400 via-yellow-400 to-emerald-400 text-slate-950 font-extrabold text-xs tracking-wide shadow-[0_4px_18px_rgba(251,191,36,0.35)] hover:brightness-110 active:scale-[0.98] transition disabled:opacity-50 cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap"
                        >
                          <Gift className="w-3.5 h-3.5" />
                          <span>{isClaiming ? 'CLAIMING...' : 'CLAIM GIFT'}</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )
          ) : (
            /* DEV GIFT SENDER PANEL */
            <form onSubmit={handleSendSubmit} className="space-y-3 text-xs">
              <div className="p-2.5 rounded-xl border border-emerald-400/35 bg-emerald-500/10 flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2 text-emerald-200 font-bold">
                  <Code2 className="w-4 h-4 text-emerald-300 shrink-0" />
                  <span>Developer Dak Ghar Dispatch · OHIIT1310</span>
                </div>
                {!isSignedIn && (
                  <span className="text-[10px] text-amber-300 font-semibold">
                    Local Dev Preview Mode (Sign in with Gmail to push globally)
                  </span>
                )}
              </div>

              <div className="grid sm:grid-cols-2 gap-2.5">
                <div className="space-y-1">
                  <label className="text-[10px] font-extrabold uppercase tracking-wider text-amber-200/85 flex items-center justify-between">
                    <span>1. Target Player ID (or ALL)</span>
                    <span className="flex gap-1">
                      <button
                        type="button"
                        onClick={() => setTargetId('ALL')}
                        className="px-1.5 py-0.5 rounded bg-white/10 hover:bg-amber-400/25 text-[9.5px] text-amber-200 cursor-pointer"
                      >
                        ALL
                      </button>
                      <button
                        type="button"
                        onClick={() => setTargetId(playerId)}
                        className="px-1.5 py-0.5 rounded bg-cyan-500/20 hover:bg-cyan-500/35 text-[9.5px] text-cyan-200 cursor-pointer"
                      >
                        My ID
                      </button>
                    </span>
                  </label>
                  <input
                    type="text"
                    value={targetId}
                    onChange={(e) => setTargetId(e.target.value.toUpperCase())}
                    placeholder="GC-7X9K2M or ALL"
                    maxLength={12}
                    className="w-full px-3 py-1.5 rounded-lg bg-[#090712] border border-cyan-400/40 text-cyan-100 font-num text-xs tracking-wider uppercase focus:outline-none focus:border-cyan-300"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-extrabold uppercase tracking-wider text-amber-200/85 block">
                    2. Mail Subject
                  </label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    maxLength={80}
                    placeholder="Festival Akhara Gift!"
                    className="w-full px-3 py-1.5 rounded-lg bg-[#090712] border border-amber-400/35 text-amber-100 text-xs focus:outline-none focus:border-amber-300"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-extrabold uppercase tracking-wider text-amber-200/85 block">
                  Short Message
                </label>
                <input
                  type="text"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  maxLength={240}
                  placeholder="Write a note to the player..."
                  className="w-full px-3 py-1.5 rounded-lg bg-[#090712] border border-amber-400/35 text-amber-100 text-xs focus:outline-none focus:border-amber-300"
                />
              </div>

              {/* 3. Gift Type Selector */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-extrabold uppercase tracking-wider text-amber-200/85 block">
                  3. Select Gift Type &amp; Item
                </label>
                <div className="grid grid-cols-5 gap-1.5">
                  {(
                    [
                      { id: 'futi_kodi', label: 'Futi Kodi', icon: <Coins className="w-3.5 h-3.5" /> },
                      { id: 'gota', label: 'Gota', icon: <Gem className="w-3.5 h-3.5" /> },
                      { id: 'skin', label: 'Skin', icon: <Crown className="w-3.5 h-3.5" /> },
                      { id: 'aura', label: 'Aura', icon: <Sparkles className="w-3.5 h-3.5" /> },
                      { id: 'pose', label: 'Pose', icon: <Trophy className="w-3.5 h-3.5" /> },
                    ] as const
                  ).map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      data-ui-sfx="select"
                      onClick={() => {
                        setGiftType(opt.id);
                        if (opt.id === 'futi_kodi' && giftAmount < 50) setGiftAmount(200);
                        if (opt.id === 'gota' && giftAmount > 500) setGiftAmount(50);
                      }}
                      className={`py-1.5 px-1 rounded-lg border font-bold text-[10px] sm:text-[11px] flex items-center justify-center gap-1 transition cursor-pointer ${
                        giftType === opt.id
                          ? 'bg-amber-400 text-slate-950 border-yellow-200'
                          : 'bg-black/45 border-white/12 text-amber-100/80 hover:border-amber-400/45'
                      }`}
                    >
                      {opt.icon}
                      <span className="truncate">{opt.label}</span>
                    </button>
                  ))}
                </div>

                {(giftType === 'futi_kodi' || giftType === 'gota') && (
                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    <input
                      type="number"
                      min={1}
                      max={1000000}
                      value={giftAmount}
                      onChange={(e) => setGiftAmount(Math.max(1, parseInt(e.target.value || '1', 10)))}
                      className="w-32 px-3 py-1.5 rounded-lg bg-[#090712] border border-amber-400/40 text-amber-100 font-num font-bold text-xs focus:outline-none"
                    />
                    {(giftType === 'futi_kodi' ? [200, 500, 1500, 5000] : [25, 50, 100, 250]).map((amt) => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => setGiftAmount(amt)}
                        className="px-2.5 py-1 rounded-lg border border-white/15 bg-white/5 hover:border-amber-300/60 text-[11px] font-num font-bold text-amber-200 cursor-pointer"
                      >
                        +{amt}
                      </button>
                    ))}
                  </div>
                )}

                {giftType === 'skin' && (
                  <select
                    value={giftSkinId}
                    onChange={(e) => setGiftSkinId(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-[#090712] border border-amber-400/40 text-amber-100 text-xs font-semibold focus:outline-none"
                  >
                    {SKINS.map((s) => (
                      <option key={s.id} value={s.id}>
                        {getCfgById(s.fighterId).name} — {s.name} ({s.fkPrice === null ? '👑 Crown' : `${s.fkPrice} FK`})
                      </option>
                    ))}
                  </select>
                )}

                {giftType === 'aura' && (
                  <select
                    value={giftAuraId}
                    onChange={(e) => setGiftAuraId(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-[#090712] border border-amber-400/40 text-amber-100 text-xs font-semibold focus:outline-none"
                  >
                    {UNLOCKABLE_AURAS.map((a) => (
                      <option key={a.id} value={a.id}>
                        {a.name} ({a.fkPrice === null ? '👑 Crown' : `${a.fkPrice} FK`})
                      </option>
                    ))}
                  </select>
                )}

                {giftType === 'pose' && (
                  <select
                    value={giftPoseId}
                    onChange={(e) => setGiftPoseId(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-[#090712] border border-amber-400/40 text-amber-100 text-xs font-semibold focus:outline-none"
                  >
                    {UNLOCKABLE_POSES.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.fighterName} — {p.poseName} ({p.tierLabel})
                      </option>
                    ))}
                  </select>
                )}
              </div>

              {sendFeedback && (
                <div
                  className={`px-3 py-1.5 rounded-lg border text-[11px] font-bold ${
                    sendFeedback.ok
                      ? 'border-emerald-400/50 bg-emerald-500/15 text-emerald-200'
                      : 'border-rose-400/50 bg-rose-500/15 text-rose-200'
                  }`}
                >
                  {sendFeedback.text}
                </div>
              )}

              <button
                type="submit"
                data-ui-sfx="none"
                disabled={sending}
                className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-400 via-orange-500 to-rose-500 text-slate-950 font-extrabold text-xs sm:text-sm tracking-wide shadow-[0_6px_22px_rgba(245,158,11,0.3)] hover:brightness-110 active:scale-[0.99] transition disabled:opacity-50 cursor-pointer flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                <span>{sending ? 'DISPATCHING MAIL...' : '🚀 SEND GIFT MAIL'}</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
