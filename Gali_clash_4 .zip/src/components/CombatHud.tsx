import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  Check,
  ChevronDown,
  ChevronUp,
  Grid,
  Keyboard,
  Move,
  Pause,
  RotateCcw,
  Sliders,
  Smile,
  Tag,
} from 'lucide-react';
import { COOLDOWNS, STICKER_EMOTES } from '../game/data';
import { ACTION_LABELS, formatKeyLabel } from '../game/controlsStorage';
import {
  CombatButtonKind,
  ControlLayoutConfig,
  CustomizableControlTarget,
  HudSnapshot,
  PointOffset,
  StickerEmoteId,
} from '../game/types';

interface CombatHudProps {
  hud: HudSnapshot;
  announcement: string | null;
  controlConfig: ControlLayoutConfig;
  customizing: boolean;
  onUpdateControlConfig: (next: ControlLayoutConfig) => void;
  onResetControls: () => void;
  onToggleCustomizing: (active: boolean) => void;
  onOpenKeybinds: () => void;
  onJoystick: (nx: number, ny: number) => void;
  onAction: (kind: CombatButtonKind) => void;
  onBlockChange: (held: boolean) => void;
  onEmote: (emoteId: StickerEmoteId) => void;
  onPause: () => void;
}

function useViewportAdaptiveMetrics() {
  const [metrics, setMetrics] = useState(() => computeMetrics());

  function computeMetrics() {
    const vw = typeof window !== 'undefined' ? window.visualViewport?.width || window.innerWidth : 1024;
    const vh = typeof window !== 'undefined' ? window.visualViewport?.height || window.innerHeight : 768;
    const isCoarse = typeof window !== 'undefined' ? window.matchMedia?.('(pointer: coarse)').matches ?? false : false;
    const isDesktop = vw >= 768 && !isCoarse;

    let autoScale = 1.0;
    if (vh < 460) {
      autoScale = Math.max(0.7, Math.min(0.88, vh / 465));
    } else if (vh < 680 || vw < 1024) {
      autoScale = Math.max(0.85, Math.min(0.98, Math.min(vw / 1040, vh / 660)));
    } else {
      autoScale = Math.max(0.92, Math.min(1.1, Math.min(vw / 1260, vh / 750)));
    }

    return { vw, vh, autoScale, isDesktop, isPortrait: vh > vw };
  }

  useEffect(() => {
    const onResize = () => setMetrics(computeMetrics());
    window.addEventListener('resize', onResize);
    window.visualViewport?.addEventListener('resize', onResize);
    return () => {
      window.removeEventListener('resize', onResize);
      window.visualViewport?.removeEventListener('resize', onResize);
    };
  }, []);

  return metrics;
}

function useReadyBurst(cd: number): boolean {
  const prevCdRef = useRef<number>(cd);
  const [burst, setBurst] = useState(false);

  useEffect(() => {
    const prev = prevCdRef.current;
    prevCdRef.current = cd;
    if (prev > 0.06 && cd <= 0.05) {
      setBurst(true);
      const id = window.setTimeout(() => setBurst(false), 580);
      return () => window.clearTimeout(id);
    }
  }, [cd]);

  return burst;
}

/**
 * Distinct bespoke vector emblem for each of the 6 competitive controls:
 * 1. basic  -> Twin Fist + Crescent Kick Shadow-Fight Strike
 * 2. sp1    -> Long-Range Energy Spear / Projectile Trajectory
 * 3. sp2    -> Close-Range Crossed Burst Impact
 * 4. dash   -> Dual Speed Shadow-Step Chevrons
 * 5. shield -> Layered Aegis Guard & Parry Crest
 * 6. rage   -> 8-Spoke Sudarshan Chakra Ultimate Mandala
 */
function ActionGlyph({ kind, className = 'w-5 h-5' }: { kind: CombatButtonKind; className?: string }) {
  switch (kind) {
    case 'basic':
      return (
        <svg viewBox="0 0 44 44" className={`${className} fill-current`}>
          {/* Sculpted Martial Fist */}
          <path d="M9.5 22.5c0-2.1 1.6-3.7 3.7-3.7h1v-1.7a1.8 1.8 0 013.6 0v1.7h1.1a1.8 1.8 0 011.8 1.8v1.3c1 .4 1.8 1.3 1.8 2.6v3.7c0 4.1-3.3 7.4-7.4 7.4h-1c-3.3 0-4.6-2.5-4.6-5.9v-7.2z" />
          {/* Dynamic High Kick Slash Arc */}
          <path d="M19 32.5l6.4-7.6 10-7.7c1.2-.9 2.9-.5 3.6.8.7 1.2.3 2.8-.9 3.6l-9.7 6.8-4.7 6.6c-.8 1.1-2.4 1.3-3.5.5-1-.7-1.9-1.9-1.2-3z" />
          <path
            d="M22.5 8.5c5.8 1.1 10.6 5 12.6 10.5"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.4"
            strokeLinecap="round"
            opacity="0.88"
          />
          <path d="M5.5 16.5l3.2 2M5 23.5h2.8" fill="none" stroke="currentColor" strokeWidth="2.1" strokeLinecap="round" opacity="0.8" />
        </svg>
      );
    case 'sp1':
      return (
        <svg viewBox="0 0 36 36" className={className}>
          {/* Long-Range Projectile Spear & Velocity Trail */}
          <path d="M4 22h11M6 15h6M6 27h8" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" opacity="0.7" />
          <path d="M13 18h14.5l-4.2-4.8L33 18l-9.7 4.8 4.2-4.8" className="fill-current stroke-current" strokeWidth="1.4" strokeLinejoin="round" />
          <circle cx="29" cy="18" r="2.1" className="fill-current" />
        </svg>
      );
    case 'sp2':
      return (
        <svg viewBox="0 0 36 36" className={className}>
          {/* Close-Range Burst / Twin Impact Shockwave */}
          <path
            d="M18 4l3.4 7.2 7.8-2.4-3.8 7.1 6.6 4.6-7.8 1.9 1.6 8.1-6.8-4.4-5.2 6.2-.5-8-8-.8 5.9-5.3-3.9-7.1 7.6 2.9L18 4z"
            className="fill-current opacity-30"
          />
          <path
            d="M10.5 25.5L25.5 10.5M21.5 10.5h4v4M25.5 25.5L10.5 10.5M10.5 14.5v-4h4"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <circle cx="18" cy="18" r="3" className="fill-current" />
        </svg>
      );
    case 'dash':
      return (
        <svg viewBox="0 0 36 36" className={`${className} fill-none stroke-current`}>
          {/* Shadow-Step Twin Speed Chevrons */}
          <path d="M7 10l8 8-8 8" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round" opacity="0.55" />
          <path d="M16 8l10 10-10 10" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M25 18h6" strokeWidth="2.8" strokeLinecap="round" />
        </svg>
      );
    case 'shield':
      return (
        <svg viewBox="0 0 36 36" className={className}>
          {/* Competitive Aegis Shield + Parry Star */}
          <path
            d="M18 4L6.5 8.8v8.4c0 7.2 4.9 13.4 11.5 15.1 6.6-1.7 11.5-7.9 11.5-15.1V8.8L18 4z"
            className="fill-current opacity-22"
          />
          <path
            d="M18 4L6.5 8.8v8.4c0 7.2 4.9 13.4 11.5 15.1 6.6-1.7 11.5-7.9 11.5-15.1V8.8L18 4zm0 2.9l8.5 3.6v6.7c0 5.5-3.5 10.3-8.5 11.9-5-1.6-8.5-6.4-8.5-11.9v-6.7L18 6.9z"
            className="fill-current"
          />
          <path d="M18 11.5l1.6 3.7 3.7 1.6-3.7 1.6L18 22.1l-1.6-3.7-3.7-1.6 3.7-1.6L18 11.5z" className="fill-current" />
        </svg>
      );
    case 'rage':
      return (
        <svg viewBox="0 0 44 44" className={`${className} fill-current`}>
          {/* Intricate 8-Spoke Sudarshan Chakra Ultimate */}
          <circle cx="22" cy="22" r="17.5" fill="none" stroke="currentColor" strokeWidth="1.9" strokeDasharray="4 2.2" />
          <circle cx="22" cy="22" r="9.5" fill="none" stroke="currentColor" strokeWidth="1.4" opacity="0.85" />
          <circle cx="22" cy="22" r="4.2" />
          {[0, 45, 90, 135, 180, 225, 270, 315].map((deg) => (
            <path key={deg} d="M22 3.2 L25 12.2 L19 12.2 Z" transform={`rotate(${deg} 22 22)`} />
          ))}
        </svg>
      );
  }
}

/** Non-interactive sleek status pill strip under top Chakra bar (no duplicate buttons!) */
function SkillStatusStrip({
  sp1Cd,
  sp2Cd,
  dashCd,
  awakened,
  wins,
  practice,
  side,
}: {
  sp1Cd: number;
  sp2Cd: number;
  dashCd: number;
  awakened: boolean;
  wins: number;
  practice: boolean;
  side: 'left' | 'right';
}) {
  const items = [
    { key: 'S1', cd: sp1Cd, color: 'text-amber-300 border-amber-400/50 bg-amber-500/15' },
    { key: 'S2', cd: sp2Cd, color: 'text-orange-300 border-orange-400/50 bg-orange-500/15' },
    { key: 'DS', cd: dashCd, color: 'text-cyan-300 border-cyan-400/50 bg-cyan-500/15' },
  ];

  return (
    <div
      className={`flex items-center gap-2 mt-1.5 ${
        side === 'left' ? 'justify-between pr-1' : 'flex-row-reverse justify-between pl-1'
      }`}
    >
      {/* Non-clickable compact cooldown telemetry */}
      <div className="flex items-center gap-1">
        {items.map((it) => {
          const ready = it.cd <= 0.05;
          return (
            <span
              key={it.key}
              className={`inline-flex items-center gap-1 px-1.5 py-[1px] rounded border font-num text-[9px] font-bold leading-tight ${
                ready ? it.color : 'text-slate-400 border-white/15 bg-black/45'
              }`}
            >
              <span>{it.key}</span>
              {!ready && <span className="text-amber-200">{it.cd.toFixed(1)}</span>}
            </span>
          );
        })}
        {awakened && (
          <span className="px-1.5 py-[1px] rounded bg-amber-400/20 border border-amber-300/70 text-[8.5px] font-extrabold tracking-widest text-amber-200 uppercase">
            JAGARAN
          </span>
        )}
      </div>

      {/* Round Win Diamonds / Practice Label */}
      <div className="flex items-center gap-1.5 shrink-0">
        {practice ? (
          side === 'left' && (
            <span className="text-[9.5px] font-bold tracking-widest text-cyan-300/90 uppercase">
              ABHYAS · ∞
            </span>
          )
        ) : (
          [0, 1].map((idx) => (
            <div
              key={idx}
              className={`w-2.5 h-2.5 rotate-45 border transition-all ${
                wins > idx
                  ? 'bg-amber-400 border-yellow-200 shadow-[0_0_8px_rgba(251,191,36,0.9)]'
                  : 'bg-black/60 border-amber-500/35'
              }`}
            />
          ))
        )}
      </div>
    </div>
  );
}

interface CircularActionButtonProps {
  kind: CombatButtonKind;
  cd?: number;
  maxCd?: number;
  energyPct?: number;
  sizeClass: string;
  baseStyle: string;
  cdAccentHex: string;
  keyHint?: string;
  showKeyHint: boolean;
  showLabel: boolean;
  customizing: boolean;
  isSelected: boolean;
  snapToGrid: boolean;
  buttonScale: number;
  effectiveScale: number;
  offset: PointOffset;
  onSelectTarget: (target: CustomizableControlTarget) => void;
  onDragButton: (kind: CombatButtonKind, next: PointOffset) => void;
  onPress: (e: React.PointerEvent) => void;
  onRelease?: () => void;
  positionStyle: React.CSSProperties;
}

const CircularActionButton: React.FC<CircularActionButtonProps> = ({
  kind,
  cd = 0,
  maxCd = 1,
  energyPct,
  sizeClass,
  baseStyle,
  cdAccentHex,
  keyHint,
  showKeyHint,
  showLabel,
  customizing,
  isSelected,
  snapToGrid,
  buttonScale,
  effectiveScale,
  offset,
  onSelectTarget,
  onDragButton,
  onPress,
  onRelease,
  positionStyle,
}) => {
  const onCooldown = cd > 0.05;
  const burst = useReadyBurst(cd);
  const ratio = onCooldown ? Math.max(0, Math.min(1, cd / maxCd)) : 0;
  const deg = Math.round(ratio * 360);
  const label = ACTION_LABELS[kind].name;
  const isHero = kind === 'basic' || kind === 'rage';

  const dragStateRef = useRef<{
    pointerId: number;
    startX: number;
    startY: number;
    origX: number;
    origY: number;
  } | null>(null);
  const activeHoldPointerRef = useRef<number | null>(null);
  const [pressed, setPressed] = useState(false);

  const onDragRef = useRef(onDragButton);
  onDragRef.current = onDragButton;
  const snapRef = useRef(snapToGrid);
  snapRef.current = snapToGrid;
  const scaleRef = useRef(effectiveScale);
  scaleRef.current = effectiveScale;

  useEffect(() => {
    if (!customizing) {
      dragStateRef.current = null;
      return;
    }
    const onWinMove = (ev: PointerEvent) => {
      const ds = dragStateRef.current;
      if (!ds || ev.pointerId !== ds.pointerId) return;
      const sc = scaleRef.current || 1;
      const dx = (ev.clientX - ds.startX) / sc;
      const dy = (ev.clientY - ds.startY) / sc;
      let nextX = Math.max(-160, Math.min(90, Math.round(ds.origX + dx)));
      let nextY = Math.max(-140, Math.min(70, Math.round(ds.origY + dy)));
      if (snapRef.current) {
        nextX = Math.round(nextX / 10) * 10;
        nextY = Math.round(nextY / 10) * 10;
      }
      onDragRef.current(kind, { x: nextX, y: nextY });
    };
    const onWinUp = (ev: PointerEvent) => {
      if (dragStateRef.current && ev.pointerId === dragStateRef.current.pointerId) {
        dragStateRef.current = null;
      }
    };
    window.addEventListener('pointermove', onWinMove);
    window.addEventListener('pointerup', onWinUp);
    window.addEventListener('pointercancel', onWinUp);
    return () => {
      window.removeEventListener('pointermove', onWinMove);
      window.removeEventListener('pointerup', onWinUp);
      window.removeEventListener('pointercancel', onWinUp);
    };
  }, [customizing, kind]);

  const handlePointerDown = (e: React.PointerEvent<HTMLButtonElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (customizing) {
      onSelectTarget(kind);
      try {
        e.currentTarget.setPointerCapture(e.pointerId);
      } catch {
        // window fallback handles it
      }
      dragStateRef.current = {
        pointerId: e.pointerId,
        startX: e.clientX,
        startY: e.clientY,
        origX: offset.x,
        origY: offset.y,
      };
      return;
    }
    activeHoldPointerRef.current = e.pointerId;
    setPressed(true);
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      // ignore
    }
    onPress(e);
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (customizing) {
      if (dragStateRef.current?.pointerId === e.pointerId) dragStateRef.current = null;
      return;
    }
    if (activeHoldPointerRef.current === e.pointerId) {
      activeHoldPointerRef.current = null;
      setPressed(false);
      onRelease?.();
    }
  };

  return (
    <button
      type="button"
      onPointerDown={handlePointerDown}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
      style={{
        ...positionStyle,
        transform: `translate(${offset.x}px, ${offset.y}px) scale(${buttonScale * (pressed && !customizing ? 0.89 : 1)})`,
      }}
      title={`${label} (${ACTION_LABELS[kind].desc})`}
      className={`touch-none absolute ${sizeClass} rounded-full border-2 flex flex-col items-center justify-center select-none overflow-visible ${
        isHero ? 'btn-medallion-hero' : 'btn-medallion'
      } ${customizing ? 'transition-none' : 'transition-transform duration-75'} ${baseStyle} ${
        burst ? 'animate-ready-burst' : ''
      } ${
        customizing
          ? isSelected
            ? 'cursor-move ring-3 ring-cyan-300 ring-offset-2 ring-offset-black/70 z-30 shadow-[0_0_24px_rgba(34,211,238,0.65)]'
            : 'cursor-move ring-2 ring-amber-300/70 ring-offset-1 ring-offset-black/45'
          : 'cursor-pointer'
      }`}
    >
      {/* Top glass sheen */}
      <span className="absolute inset-[2px] rounded-full bg-gradient-to-b from-white/18 via-transparent to-black/35 pointer-events-none" />

      {/* Ornate concentric inner ring */}
      <span
        className={`absolute ${
          isHero ? 'inset-[5px] border border-amber-200/25' : 'inset-[3.5px] border border-white/12'
        } rounded-full pointer-events-none`}
      />

      {/* Press impact shockwave */}
      {pressed && !customizing && (
        <span
          className="absolute -inset-1.5 rounded-full border-2 pointer-events-none animate-ping opacity-70"
          style={{ borderColor: cdAccentHex }}
        />
      )}

      {onCooldown && (
        <div
          className="absolute inset-0 rounded-full pointer-events-none"
          style={{
            background: `conic-gradient(rgba(7,6,13,0.88) ${deg}deg, rgba(255,255,255,0.06) ${deg}deg)`,
          }}
        />
      )}

      {(onCooldown || typeof energyPct === 'number') && (
        <svg
          viewBox="0 0 44 44"
          className={`absolute inset-0 w-full h-full -rotate-90 pointer-events-none ${
            onCooldown ? 'animate-cd-pulse' : ''
          }`}
        >
          <circle
            cx="22"
            cy="22"
            r="19.5"
            fill="none"
            stroke="rgba(255,255,255,0.12)"
            strokeWidth="2.8"
          />
          <circle
            cx="22"
            cy="22"
            r="19.5"
            fill="none"
            stroke={onCooldown ? cdAccentHex : energyPct! >= 100 ? '#fde047' : '#22d3ee'}
            strokeWidth="3.2"
            strokeLinecap="round"
            pathLength={100}
            strokeDasharray="100"
            strokeDashoffset={onCooldown ? 100 - ratio * 100 : 100 - Math.min(100, energyPct ?? 0)}
          />
        </svg>
      )}

      <div className="relative z-10 flex flex-col items-center justify-center leading-none pointer-events-none">
        <div className={`${onCooldown ? 'opacity-28 scale-88' : 'opacity-100'} transition`}>
          <ActionGlyph
            kind={kind}
            className={
              kind === 'rage'
                ? `w-7 h-7 sm:w-8 sm:h-8 ${(energyPct ?? 0) >= 100 ? 'animate-chakra-spin text-yellow-200 drop-shadow-[0_0_8px_rgba(253,224,71,0.85)]' : ''}`
                : kind === 'basic'
                  ? 'w-8 h-8 sm:w-9 sm:h-9'
                  : 'w-5 h-5 sm:w-[22px] sm:h-[22px]'
            }
          />
        </div>

        {showLabel && (
          <span
            className={`font-extrabold tracking-wider uppercase drop-shadow-[0_1px_3px_rgba(0,0,0,1)] ${
              kind === 'basic' ? 'text-[8.5px] sm:text-[9.5px] mt-0.5' : 'text-[6.5px] sm:text-[7.2px] mt-0.5'
            } ${onCooldown ? 'opacity-60' : 'opacity-95'}`}
          >
            {label}
          </span>
        )}

        {kind === 'rage' && typeof energyPct === 'number' && (
          <span className="font-num text-[7.5px] font-black text-cyan-200 drop-shadow-[0_1px_2px_rgba(0,0,0,1)]">
            {energyPct >= 100 ? 'READY!' : `${Math.floor(energyPct)}%`}
          </span>
        )}
      </div>

      {onCooldown && (
        <div className="absolute inset-0 z-20 flex items-center justify-center pointer-events-none">
          <span className="px-1.5 py-0.5 rounded-full bg-[#07050e]/92 border border-amber-300/85 font-num text-[11px] sm:text-xs font-black text-amber-100 shadow-[0_0_12px_rgba(0,0,0,1)]">
            {cd.toFixed(1)}s
          </span>
        </div>
      )}

      {showKeyHint && keyHint && !customizing && (
        <span className="absolute -bottom-1.5 right-0 px-1.5 py-[1px] rounded-md bg-[#0c0916]/95 border border-amber-400/55 font-num text-[8px] font-black text-amber-200 shadow-md pointer-events-none">
          {keyHint}
        </span>
      )}
    </button>
  );
};

export const CombatHud: React.FC<CombatHudProps> = ({
  hud,
  announcement,
  controlConfig,
  customizing,
  onUpdateControlConfig,
  onResetControls,
  onToggleCustomizing,
  onOpenKeybinds,
  onJoystick,
  onAction,
  onBlockChange,
  onEmote,
  onPause,
}) => {
  const padRef = useRef<HTMLDivElement | null>(null);
  const [knobOffset, setKnobOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [joyVector, setJoyVector] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isStickActive, setIsStickActive] = useState(false);
  const activePointerIdRef = useRef<number | null>(null);
  const [blockActive, setBlockActive] = useState(false);

  const [selectedTarget, setSelectedTarget] = useState<CustomizableControlTarget>('dpad');
  const [customizerCollapsed, setCustomizerCollapsed] = useState(false);
  const [emoteTrayOpen, setEmoteTrayOpen] = useState(false);

  const dpadDragRef = useRef<{
    pointerId: number;
    startX: number;
    startY: number;
    origX: number;
    origY: number;
  } | null>(null);
  const clusterDragRef = useRef<{
    pointerId: number;
    startX: number;
    startY: number;
    origX: number;
    origY: number;
  } | null>(null);

  const { vw, vh, autoScale, isDesktop } = useViewportAdaptiveMetrics();
  const maxDpadX = Math.max(40, Math.round(vw * 0.28));
  const maxClusterX = Math.max(40, Math.round(vw * 0.28));
  const maxDragUp = Math.max(36, Math.round(vh - 245));
  const effectiveScale = Math.max(0.68, Math.min(1.38, autoScale * controlConfig.scale));
  const dpadVisualScale = effectiveScale * (controlConfig.dpadScale || 1);

  const controlsOpacity = customizing
    ? 1
    : controlConfig.touchMode === 'compact' || (controlConfig.touchMode === 'auto' && isDesktop)
      ? Math.min(controlConfig.opacity, 0.72)
      : controlConfig.opacity;

  const p1Pct = Math.max(0, Math.min(100, (hud.p1Hp / hud.p1MaxHp) * 100));
  const p2Pct = Math.max(0, Math.min(100, (hud.p2Hp / hud.p2MaxHp) * 100));
  const p1Chakra = Math.max(0, Math.min(100, hud.p1Rage));
  const p2Chakra = Math.max(0, Math.min(100, hud.p2Rage));

  const localRage = hud.localSlot === 1 ? p1Chakra : p2Chakra;
  const localSp1Cd = hud.localSlot === 1 ? hud.p1Sp1Cd : hud.p2Sp1Cd;
  const localSp2Cd = hud.localSlot === 1 ? hud.p1Sp2Cd : hud.p2Sp2Cd;
  const localDashCd = hud.localSlot === 1 ? hud.p1DashCd : hud.p2DashCd;
  const chakraReady = localRage >= 100;

  const onJoystickRef = useRef(onJoystick);
  onJoystickRef.current = onJoystick;
  const dpadVisualScaleRef = useRef(dpadVisualScale);
  dpadVisualScaleRef.current = dpadVisualScale;
  const configRef = useRef(controlConfig);
  configRef.current = controlConfig;
  const onUpdateConfigRef = useRef(onUpdateControlConfig);
  onUpdateConfigRef.current = onUpdateControlConfig;

  const updateStickFromPoint = (clientX: number, clientY: number) => {
    const el = padRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width * 0.5;
    const cy = rect.top + rect.height * 0.5;
    const maxR = Math.max(28, rect.width * 0.36);

    let dx = clientX - cx;
    let dy = clientY - cy;
    const dist = Math.hypot(dx, dy);

    const deadR = maxR * 0.09;
    let nx = 0;
    let ny = 0;
    if (dist > deadR && dist > 0) {
      const clamped = Math.min(dist, maxR);
      const normMag = (clamped - deadR) / (maxR - deadR);
      nx = (dx / dist) * normMag;
      ny = (dy / dist) * normMag;
      if (dist > maxR) {
        dx = (dx / dist) * maxR;
        dy = (dy / dist) * maxR;
      }
    }

    const sc = dpadVisualScaleRef.current || 1;
    setKnobOffset({ x: dx / sc, y: dy / sc });
    setJoyVector({ x: nx, y: ny });
    onJoystickRef.current(Math.max(-1, Math.min(1, nx)), Math.max(-1, Math.min(1, ny)));
  };

  useEffect(() => {
    const onWinPointerMove = (e: PointerEvent) => {
      if (dpadDragRef.current && e.pointerId === dpadDragRef.current.pointerId) {
        const cfg = configRef.current;
        const dx = e.clientX - dpadDragRef.current.startX;
        const dy = e.clientY - dpadDragRef.current.startY;
        let nx = Math.max(0, Math.min(maxDpadX, Math.round(dpadDragRef.current.origX + dx)));
        let ny = Math.max(-maxDragUp, Math.min(12, Math.round(dpadDragRef.current.origY + dy)));
        if (cfg.snapToGrid) {
          nx = Math.round(nx / 10) * 10;
          ny = Math.round(ny / 10) * 10;
        }
        onUpdateConfigRef.current({ ...cfg, dpadOffset: { x: nx, y: ny } });
        return;
      }

      if (clusterDragRef.current && e.pointerId === clusterDragRef.current.pointerId) {
        const cfg = configRef.current;
        const dx = e.clientX - clusterDragRef.current.startX;
        const dy = e.clientY - clusterDragRef.current.startY;
        let nx = Math.max(-maxClusterX, Math.min(0, Math.round(clusterDragRef.current.origX + dx)));
        let ny = Math.max(-maxDragUp, Math.min(12, Math.round(clusterDragRef.current.origY + dy)));
        if (cfg.snapToGrid) {
          nx = Math.round(nx / 10) * 10;
          ny = Math.round(ny / 10) * 10;
        }
        onUpdateConfigRef.current({ ...cfg, clusterOffset: { x: nx, y: ny } });
        return;
      }

      if (activePointerIdRef.current !== null && e.pointerId === activePointerIdRef.current) {
        updateStickFromPoint(e.clientX, e.clientY);
      }
    };

    const onWinPointerEnd = (e: PointerEvent) => {
      if (dpadDragRef.current && e.pointerId === dpadDragRef.current.pointerId) {
        dpadDragRef.current = null;
      }
      if (clusterDragRef.current && e.pointerId === clusterDragRef.current.pointerId) {
        clusterDragRef.current = null;
      }
      if (activePointerIdRef.current !== null && e.pointerId === activePointerIdRef.current) {
        activePointerIdRef.current = null;
        setIsStickActive(false);
        setKnobOffset({ x: 0, y: 0 });
        setJoyVector({ x: 0, y: 0 });
        onJoystickRef.current(0, 0);
      }
    };

    window.addEventListener('pointermove', onWinPointerMove);
    window.addEventListener('pointerup', onWinPointerEnd);
    window.addEventListener('pointercancel', onWinPointerEnd);
    return () => {
      window.removeEventListener('pointermove', onWinPointerMove);
      window.removeEventListener('pointerup', onWinPointerEnd);
      window.removeEventListener('pointercancel', onWinPointerEnd);
    };
  }, [maxDpadX, maxClusterX, maxDragUp]);

  useEffect(() => {
    const clearAll = () => {
      activePointerIdRef.current = null;
      dpadDragRef.current = null;
      clusterDragRef.current = null;
      setIsStickActive(false);
      setKnobOffset({ x: 0, y: 0 });
      setJoyVector({ x: 0, y: 0 });
      onJoystick(0, 0);
      setBlockActive(false);
      onBlockChange(false);
    };
    window.addEventListener('blur', clearAll);
    document.addEventListener('visibilitychange', clearAll);
    return () => {
      window.removeEventListener('blur', clearAll);
      document.removeEventListener('visibilitychange', clearAll);
    };
  }, [onJoystick, onBlockChange]);

  const handlePadPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      // window listeners handle it
    }
    if (customizing) {
      setSelectedTarget('dpad');
      dpadDragRef.current = {
        pointerId: e.pointerId,
        startX: e.clientX,
        startY: e.clientY,
        origX: controlConfig.dpadOffset.x,
        origY: controlConfig.dpadOffset.y,
      };
      return;
    }
    activePointerIdRef.current = e.pointerId;
    setIsStickActive(true);
    updateStickFromPoint(e.clientX, e.clientY);
  };

  const handleClusterDragDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!customizing) return;
    e.preventDefault();
    e.stopPropagation();
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      // window fallback
    }
    clusterDragRef.current = {
      pointerId: e.pointerId,
      startX: e.clientX,
      startY: e.clientY,
      origX: controlConfig.clusterOffset.x,
      origY: controlConfig.clusterOffset.y,
    };
  };

  const handleButtonOffsetChange = (kind: CombatButtonKind, next: PointOffset) => {
    onUpdateControlConfig({
      ...controlConfig,
      buttonOffsets: {
        ...controlConfig.buttonOffsets,
        [kind]: next,
      },
    });
  };

  const triggerAct = (kind: CombatButtonKind) => (e: React.PointerEvent) => {
    e.preventDefault();
    onAction(kind);
  };

  const selectedName = selectedTarget === 'dpad' ? 'JOYSTICK' : ACTION_LABELS[selectedTarget].name;
  const selectedScale =
    selectedTarget === 'dpad'
      ? controlConfig.dpadScale || 1
      : controlConfig.buttonScales?.[selectedTarget] ?? 1;
  const selectedOffset =
    selectedTarget === 'dpad'
      ? controlConfig.dpadOffset
      : controlConfig.buttonOffsets?.[selectedTarget] ?? { x: 0, y: 0 };

  const setSelectedScale = (val: number) => {
    if (selectedTarget === 'dpad') {
      onUpdateControlConfig({ ...controlConfig, dpadScale: val });
    } else {
      onUpdateControlConfig({
        ...controlConfig,
        buttonScales: { ...controlConfig.buttonScales, [selectedTarget]: val },
      });
    }
  };

  const nudgeSelected = (dx: number, dy: number) => {
    const step = controlConfig.snapToGrid ? 10 : 4;
    if (selectedTarget === 'dpad') {
      onUpdateControlConfig({
        ...controlConfig,
        dpadOffset: {
          x: Math.max(0, Math.min(maxDpadX, controlConfig.dpadOffset.x + dx * step)),
          y: Math.max(-maxDragUp, Math.min(12, controlConfig.dpadOffset.y + dy * step)),
        },
      });
    } else {
      const cur = controlConfig.buttonOffsets?.[selectedTarget] ?? { x: 0, y: 0 };
      handleButtonOffsetChange(selectedTarget, {
        x: Math.max(-160, Math.min(90, cur.x + dx * step)),
        y: Math.max(-140, Math.min(70, cur.y + dy * step)),
      });
    }
  };

  const resetSelectedControl = () => {
    if (selectedTarget === 'dpad') {
      onUpdateControlConfig({
        ...controlConfig,
        dpadScale: 1.0,
        dpadOffset: { x: 0, y: 0 },
      });
    } else {
      const nextOffsets = { ...controlConfig.buttonOffsets };
      const nextScales = { ...controlConfig.buttonScales };
      delete nextOffsets[selectedTarget];
      delete nextScales[selectedTarget];
      onUpdateControlConfig({
        ...controlConfig,
        buttonOffsets: nextOffsets,
        buttonScales: nextScales,
      });
    }
  };

  const showKeyHint = controlConfig.showKeyHints && isDesktop;
  const showLabel = controlConfig.showLabels;

  return (
    <div
      className="fixed inset-0 z-20 pointer-events-none flex flex-col justify-between"
      style={{
        paddingTop: 'max(0.5rem, env(safe-area-inset-top))',
        paddingBottom: 'max(0.55rem, env(safe-area-inset-bottom))',
        paddingLeft: 'max(0.85rem, env(safe-area-inset-left))',
        paddingRight: 'max(0.85rem, env(safe-area-inset-right))',
      }}
    >
      {/* ==================== TOP BAR: CLEAN COMPETITIVE ESPORTS HUD (ZERO DUPLICATE BUTTONS) ==================== */}
      <div className="w-full max-w-6xl mx-auto flex items-start justify-between gap-2.5 sm:gap-5 pointer-events-auto">
        {/* LEFT FIGHTER (P1) */}
        <div className="flex-1 min-w-0 flex flex-col">
          <div className="flex items-baseline justify-between gap-2 mb-1 px-0.5">
            <span className="font-display-in text-xs sm:text-sm tracking-wider text-amber-100 drop-shadow truncate min-w-0">
              {hud.p1Name}
            </span>
            <span className="font-num text-[10px] font-bold text-amber-200/80 shrink-0">
              {hud.p1Hp}/{hud.p1MaxHp}
            </span>
          </div>

          <div className="bar-skew-left relative h-3.5 sm:h-4 w-full bg-[#090712]/88 border border-amber-400/55 shadow-[0_0_12px_rgba(245,158,11,0.2)] overflow-hidden">
            <div
              className="absolute inset-y-0 left-0 bg-amber-100/75 transition-[width] duration-500 ease-out"
              style={{ width: `${p1Pct}%` }}
            />
            <div
              className="absolute inset-y-0 left-0 bg-gradient-to-r from-amber-300 via-orange-500 to-rose-600 transition-[width] duration-100"
              style={{ width: `${p1Pct}%` }}
            />
            <div className="absolute inset-0 bg-gradient-to-b from-white/25 to-transparent pointer-events-none" />
          </div>

          <div className="bar-skew-left relative h-1.5 sm:h-2 w-[88%] mt-1 bg-[#090712]/88 border border-cyan-400/35 overflow-hidden">
            <div
              className={`h-full transition-[width] duration-100 ${
                p1Chakra >= 100
                  ? 'bg-gradient-to-r from-yellow-300 via-amber-400 to-orange-500 chakra-ready-glow'
                  : 'bg-gradient-to-r from-teal-400 via-cyan-400 to-sky-300'
              }`}
              style={{ width: `${p1Chakra}%` }}
            />
          </div>

          <SkillStatusStrip
            sp1Cd={hud.p1Sp1Cd}
            sp2Cd={hud.p1Sp2Cd}
            dashCd={hud.p1DashCd}
            awakened={hud.p1Awakened}
            wins={hud.p1Wins}
            practice={hud.practice}
            side="left"
          />
        </div>

        {/* CENTER: PAUSE + CUSTOMIZE + STICKER EMOTES + ROUND TIMER */}
        <div className="relative flex flex-col items-center shrink-0 px-1 sm:px-2.5 pt-0.5">
          <div className="flex items-center gap-1.5 mb-0.5">
            <button
              type="button"
              onClick={onPause}
              aria-label="Pause Game"
              title="Pause / Settings (Esc)"
              className="w-7 h-7 rounded-md bg-black/45 border border-amber-400/35 flex items-center justify-center text-amber-200 hover:text-amber-100 hover:border-amber-300 active:scale-90 transition cursor-pointer"
            >
              <Pause className="w-3.5 h-3.5 fill-current" />
            </button>
            <button
              type="button"
              onClick={() => onToggleCustomizing(!customizing)}
              aria-label="Customize Controls"
              title="Customize Controls Layout & Size"
              className={`w-7 h-7 rounded-md border flex items-center justify-center transition cursor-pointer ${
                customizing
                  ? 'bg-amber-400 border-yellow-200 text-slate-950'
                  : 'bg-black/45 border-amber-400/35 text-amber-200/85 hover:text-amber-100 hover:border-amber-300'
              }`}
            >
              <Sliders className="w-3.5 h-3.5" />
            </button>
            {!customizing && (
              <button
                type="button"
                onClick={() => setEmoteTrayOpen((v) => !v)}
                aria-label="Sticker Emotes"
                title="In-Match Sticker Emotes (Keys 1-6)"
                className={`w-7 h-7 rounded-md border flex items-center justify-center transition cursor-pointer ${
                  emoteTrayOpen
                    ? 'bg-cyan-400 border-cyan-200 text-slate-950'
                    : 'bg-black/45 border-amber-400/35 text-amber-200/85 hover:text-amber-100 hover:border-cyan-300'
                }`}
              >
                <Smile className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="relative flex flex-col items-center">
            <span
              className={`font-num text-2xl sm:text-4xl font-extrabold leading-none tracking-tight drop-shadow-[0_2px_10px_rgba(0,0,0,0.85)] ${
                hud.timer <= 10 && !hud.practice ? 'text-rose-400 animate-pulse' : 'text-amber-50'
              }`}
            >
              {hud.practice ? '∞' : hud.timer}
            </span>
            <div className="w-9 h-[2px] mt-1 bg-gradient-to-r from-transparent via-amber-400/80 to-transparent" />
            <div className="flex items-center gap-1.5 mt-0.5">
              <span className="text-[9px] font-bold tracking-[0.22em] text-amber-300/80 uppercase">
                {hud.practice ? 'PRACTICE' : `ROUND ${hud.round}`}
              </span>
              {hud.mpPingMs !== null && (
                <span
                  className={`font-num text-[9px] font-extrabold px-1 py-[0.5px] rounded border ${
                    hud.mpPingMs <= 55
                      ? 'text-emerald-300 border-emerald-400/45 bg-emerald-500/15'
                      : hud.mpPingMs <= 115
                        ? 'text-amber-200 border-amber-400/45 bg-amber-500/15'
                        : 'text-rose-300 border-rose-400/45 bg-rose-500/15'
                  }`}
                >
                  {hud.mpPingMs}ms
                </span>
              )}
            </div>
          </div>

          {emoteTrayOpen && !customizing && (
            <div className="mt-1.5 flex items-center gap-1 p-1 rounded-xl border border-cyan-400/45 bg-[#0c0918]/92 shadow-[0_6px_24px_rgba(0,0,0,0.75)] backdrop-blur-md z-30">
              {STICKER_EMOTES.map((st) => (
                <button
                  key={st.id}
                  type="button"
                  onClick={() => {
                    onEmote(st.id);
                    setEmoteTrayOpen(false);
                  }}
                  title={`${st.label} (Key ${st.keyHint})`}
                  className="px-1.5 py-1 rounded-lg bg-black/45 border border-white/10 hover:border-amber-300/70 hover:bg-amber-500/15 active:scale-90 transition flex flex-col items-center cursor-pointer"
                >
                  <span className="text-base sm:text-lg leading-none">{st.emoji}</span>
                  <span className="text-[7.5px] font-extrabold tracking-wide text-amber-100/85 mt-0.5">
                    {st.keyHint}
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* RIGHT FIGHTER (P2) */}
        <div className="flex-1 min-w-0 flex flex-col items-end">
          <div className="flex items-baseline justify-between gap-2 w-full mb-1 px-0.5">
            <span className="font-num text-[10px] font-bold text-amber-200/80 shrink-0">
              {hud.p2Hp}/{hud.p2MaxHp}
            </span>
            <span className="font-display-in text-xs sm:text-sm tracking-wider text-amber-100 drop-shadow truncate text-right min-w-0">
              {hud.p2Name}
            </span>
          </div>

          <div className="bar-skew-right relative h-3.5 sm:h-4 w-full bg-[#090712]/88 border border-amber-400/55 shadow-[0_0_12px_rgba(245,158,11,0.2)] overflow-hidden">
            <div
              className="absolute inset-y-0 right-0 bg-amber-100/75 transition-[width] duration-500 ease-out"
              style={{ width: `${p2Pct}%` }}
            />
            <div
              className="absolute inset-y-0 right-0 bg-gradient-to-l from-amber-300 via-orange-500 to-rose-600 transition-[width] duration-100"
              style={{ width: `${p2Pct}%` }}
            />
            <div className="absolute inset-0 bg-gradient-to-b from-white/25 to-transparent pointer-events-none" />
          </div>

          <div className="bar-skew-right relative h-1.5 sm:h-2 w-[88%] mt-1 bg-[#090712]/88 border border-cyan-400/35 overflow-hidden">
            <div
              className={`absolute inset-y-0 right-0 transition-[width] duration-100 ${
                p2Chakra >= 100
                  ? 'bg-gradient-to-l from-yellow-300 via-amber-400 to-orange-500 chakra-ready-glow'
                  : 'bg-gradient-to-l from-teal-400 via-cyan-400 to-sky-300'
              }`}
              style={{ width: `${p2Chakra}%` }}
            />
          </div>

          <div className="w-full">
            <SkillStatusStrip
              sp1Cd={hud.p2Sp1Cd}
              sp2Cd={hud.p2Sp2Cd}
              dashCd={hud.p2DashCd}
              awakened={hud.p2Awakened}
              wins={hud.p2Wins}
              practice={hud.practice}
              side="right"
            />
          </div>
        </div>
      </div>

      {/* ==================== PRO DETAILED CONTROL CUSTOMIZER STUDIO ==================== */}
      {customizing && (
        <div className="pointer-events-auto mx-auto w-full max-w-2xl rounded-xl border border-amber-400/60 bg-[#0c0918]/94 px-2.5 py-1.5 shadow-[0_8px_32px_rgba(0,0,0,0.7)] backdrop-blur-md">
          <div className="flex flex-wrap items-center justify-between gap-1.5">
            <div className="flex items-center gap-2 min-w-0">
              <span className="px-2 py-0.5 rounded bg-cyan-500/20 border border-cyan-400/50 text-[10px] font-extrabold text-cyan-200 tracking-wider">
                {selectedName}
              </span>
              <span className="font-num text-[10px] text-amber-200/80 hidden sm:inline">
                X:{selectedOffset.x} Y:{selectedOffset.y}
              </span>
            </div>

            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={resetSelectedControl}
                title="Reset Selected Button/Joystick"
                className="px-2 py-1 rounded-lg border border-amber-400/35 text-amber-200 text-[10px] font-bold hover:bg-amber-500/15 cursor-pointer"
              >
                Reset One
              </button>
              <button
                type="button"
                onClick={onResetControls}
                className="px-2 py-1 rounded-lg border border-rose-400/40 text-rose-200 text-[10px] font-bold flex items-center gap-1 hover:bg-rose-500/15 cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                All
              </button>
              <button
                type="button"
                onClick={onOpenKeybinds}
                className="px-2 py-1 rounded-lg border border-cyan-400/40 text-cyan-200 text-[10px] font-bold flex items-center gap-1 hover:bg-cyan-500/15 cursor-pointer"
              >
                <Keyboard className="w-3 h-3" />
                Keys
              </button>
              <button
                type="button"
                onClick={() => setCustomizerCollapsed((c) => !c)}
                title={customizerCollapsed ? 'Expand Studio' : 'Minimize Studio'}
                className="w-6 h-6 rounded-lg border border-white/15 bg-black/40 text-amber-200 flex items-center justify-center cursor-pointer"
              >
                {customizerCollapsed ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
              </button>
              <button
                type="button"
                onClick={() => onToggleCustomizing(false)}
                className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-amber-400 to-orange-500 text-slate-950 font-extrabold text-[11px] flex items-center gap-1 cursor-pointer"
              >
                <Check className="w-3 h-3" />
                Done
              </button>
            </div>
          </div>

          {!customizerCollapsed && (
            <div className="mt-1.5 pt-1.5 border-t border-white/10 space-y-1.5">
              <div className="grid grid-cols-3 gap-2.5 items-center text-[10px]">
                <label className="flex flex-col gap-0.5">
                  <span className="text-cyan-200 font-semibold flex justify-between">
                    <span className="truncate">{selectedTarget === 'dpad' ? 'Stick Size' : 'Btn Size'}</span>
                    <span className="font-num text-cyan-300">{Math.round(selectedScale * 100)}%</span>
                  </span>
                  <input
                    type="range"
                    min={0.75}
                    max={1.45}
                    step={0.05}
                    value={selectedScale}
                    onChange={(e) => setSelectedScale(parseFloat(e.target.value))}
                    className="accent-cyan-400 cursor-pointer h-3"
                  />
                </label>

                <label className="flex flex-col gap-0.5">
                  <span className="text-amber-200/85 font-semibold flex justify-between">
                    <span>All Size</span>
                    <span className="font-num text-amber-300">{Math.round(controlConfig.scale * 100)}%</span>
                  </span>
                  <input
                    type="range"
                    min={0.75}
                    max={1.35}
                    step={0.05}
                    value={controlConfig.scale}
                    onChange={(e) =>
                      onUpdateControlConfig({ ...controlConfig, scale: parseFloat(e.target.value) })
                    }
                    className="accent-amber-400 cursor-pointer h-3"
                  />
                </label>

                <label className="flex flex-col gap-0.5">
                  <span className="text-amber-200/85 font-semibold flex justify-between">
                    <span>Opacity</span>
                    <span className="font-num text-amber-300">{Math.round(controlConfig.opacity * 100)}%</span>
                  </span>
                  <input
                    type="range"
                    min={0.35}
                    max={1.0}
                    step={0.05}
                    value={controlConfig.opacity}
                    onChange={(e) =>
                      onUpdateControlConfig({ ...controlConfig, opacity: parseFloat(e.target.value) })
                    }
                    className="accent-amber-400 cursor-pointer h-3"
                  />
                </label>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 text-[10px]">
                <div className="flex items-center gap-1">
                  <span className="text-[9px] font-bold uppercase text-amber-200/70 mr-0.5">Nudge:</span>
                  <button
                    type="button"
                    onClick={() => nudgeSelected(-1, 0)}
                    className="w-6 h-6 rounded bg-black/50 border border-white/15 text-amber-200 flex items-center justify-center hover:border-cyan-400 cursor-pointer"
                  >
                    <ArrowLeft className="w-3 h-3" />
                  </button>
                  <button
                    type="button"
                    onClick={() => nudgeSelected(0, -1)}
                    className="w-6 h-6 rounded bg-black/50 border border-white/15 text-amber-200 flex items-center justify-center hover:border-cyan-400 cursor-pointer"
                  >
                    <ArrowUp className="w-3 h-3" />
                  </button>
                  <button
                    type="button"
                    onClick={() => nudgeSelected(0, 1)}
                    className="w-6 h-6 rounded bg-black/50 border border-white/15 text-amber-200 flex items-center justify-center hover:border-cyan-400 cursor-pointer"
                  >
                    <ArrowDown className="w-3 h-3" />
                  </button>
                  <button
                    type="button"
                    onClick={() => nudgeSelected(1, 0)}
                    className="w-6 h-6 rounded bg-black/50 border border-white/15 text-amber-200 flex items-center justify-center hover:border-cyan-400 cursor-pointer"
                  >
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() =>
                      onUpdateControlConfig({ ...controlConfig, snapToGrid: !controlConfig.snapToGrid })
                    }
                    className={`px-1.5 py-1 rounded text-[9px] font-bold uppercase border flex items-center gap-1 cursor-pointer ${
                      controlConfig.snapToGrid
                        ? 'bg-cyan-500/25 border-cyan-300 text-cyan-200'
                        : 'bg-black/35 border-white/10 text-slate-400'
                    }`}
                  >
                    <Grid className="w-3 h-3" />
                    Snap
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      onUpdateControlConfig({ ...controlConfig, showLabels: !controlConfig.showLabels })
                    }
                    className={`px-1.5 py-1 rounded text-[9px] font-bold uppercase border flex items-center gap-1 cursor-pointer ${
                      controlConfig.showLabels
                        ? 'bg-amber-400/25 border-amber-300 text-amber-200'
                        : 'bg-black/35 border-white/10 text-slate-400'
                    }`}
                  >
                    <Tag className="w-3 h-3" />
                    Names
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      onUpdateControlConfig({ ...controlConfig, showKeyHints: !controlConfig.showKeyHints })
                    }
                    className={`px-1.5 py-1 rounded text-[9px] font-bold uppercase border cursor-pointer ${
                      controlConfig.showKeyHints
                        ? 'bg-amber-400/25 border-amber-300 text-amber-200'
                        : 'bg-black/35 border-white/10 text-slate-400'
                    }`}
                  >
                    Keys
                  </button>
                </div>

                <div className="flex items-center gap-1">
                  {(['always', 'auto', 'compact'] as const).map((m) => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => onUpdateControlConfig({ ...controlConfig, touchMode: m })}
                      className={`px-1.5 py-1 rounded text-[9px] font-bold uppercase border cursor-pointer ${
                        controlConfig.touchMode === m
                          ? 'bg-amber-400/25 border-amber-300 text-amber-200'
                          : 'bg-black/35 border-white/10 text-slate-400'
                      }`}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ==================== COMBO & CENTER ANNOUNCER ==================== */}
      {!customizing && (
        <div className="relative flex-1 flex items-center justify-center pointer-events-none">
          {(hud.comboCount >= 2 || (hud.practice && hud.maxCombo > 0)) && (
            <div className="absolute top-1.5 left-2 sm:left-6 text-left">
              {hud.comboCount >= 2 && (
                <div
                  key={hud.comboCount}
                  className="animate-comic-slam inline-flex items-center gap-2 px-3 py-1 rounded-xl bg-black/55 border-2 border-amber-300/70 shadow-[3px_3px_0_#090514]"
                >
                  <span className="font-comic text-2xl sm:text-3xl leading-none comic-fill-combo">
                    {hud.comboCount}x COMBO!
                  </span>
                  <span className="comic-badge-pill px-2 py-0.5 rounded-md font-comic text-xs sm:text-sm text-white tracking-wider">
                    {hud.comboDamage} DMG
                  </span>
                </div>
              )}
              {hud.practice && hud.maxCombo > 0 && (
                <div className="mt-1 font-num text-[11px] font-bold tracking-wider text-cyan-200 uppercase drop-shadow-[1px_2px_0_#090514]">
                  Best Combo {hud.maxCombo}x
                </div>
              )}
            </div>
          )}

          {announcement && (
            <div
              key={announcement}
              className="relative px-8 py-3 flex items-center justify-center animate-comic-slam"
            >
              <svg
                viewBox="0 0 260 110"
                className="absolute inset-0 w-full h-full scale-125 pointer-events-none drop-shadow-[4px_5px_0_#090514]"
                aria-hidden="true"
              >
                <defs>
                  <linearGradient id="comicBurstGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#fde047" />
                    <stop offset="50%" stopColor="#f97316" />
                    <stop offset="100%" stopColor="#ec4899" />
                  </linearGradient>
                </defs>
                <polygon
                  points="130,3 149,24 185,8 189,33 229,22 216,49 255,58 220,76 238,101 196,90 185,107 151,92 130,108 109,92 75,107 64,90 22,101 40,76 5,58 44,49 31,22 71,33 75,8 111,24"
                  fill="url(#comicBurstGrad)"
                  stroke="#090514"
                  strokeWidth="4.5"
                  strokeLinejoin="round"
                  opacity="0.92"
                />
                <polygon
                  points="130,14 146,31 174,18 178,39 210,30 199,51 232,58 202,72 217,91 183,82 174,97 146,84 130,98 114,84 86,97 77,82 43,91 58,72 28,58 61,51 50,30 82,39 86,18 114,31"
                  fill="none"
                  stroke="#fffbeb"
                  strokeWidth="2"
                  strokeLinejoin="round"
                  opacity="0.7"
                />
              </svg>
              <div className="relative font-comic text-4xl sm:text-6xl leading-none tracking-wider comic-fill-hero px-2">
                {announcement}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ==================== BOTTOM TWO-THUMB CONTROLS: 1 JOYSTICK + 6 CLEAN BUTTONS ==================== */}
      <div
        data-ui-sfx="none"
        className="relative w-full max-w-6xl mx-auto h-[155px] sm:h-[206px] pointer-events-none"
        style={{ opacity: controlsOpacity }}
      >
        {/* LEFT THUMB: REDESIGNED SHADOW-FIGHT PRO JOYSTICK */}
        <div
          className="absolute bottom-0 left-0"
          style={{
            transform: `translate(${controlConfig.dpadOffset.x}px, ${controlConfig.dpadOffset.y}px) scale(${dpadVisualScale})`,
            transformOrigin: 'bottom left',
          }}
        >
          <div
            ref={padRef}
            onPointerDown={handlePadPointerDown}
            className={`pointer-events-auto relative w-[152px] h-[152px] rounded-full touch-none select-none flex items-center justify-center ${
              customizing
                ? selectedTarget === 'dpad'
                  ? 'cursor-move ring-3 ring-cyan-300 ring-offset-2 ring-offset-black/70 shadow-[0_0_24px_rgba(34,211,238,0.5)]'
                  : 'cursor-move ring-2 ring-amber-300/75 ring-offset-2 ring-offset-black/40'
                : 'cursor-grab active:cursor-grabbing'
            }`}
          >
            {/* Expanded touch halo */}
            <div className="absolute -inset-3 rounded-full pointer-events-auto touch-none" />

            <div className="joystick-bezel absolute inset-0 rounded-full backdrop-blur-[2px] border-2 border-amber-300/55 pointer-events-none" />

            <svg
              viewBox="0 0 120 120"
              className="absolute inset-1.5 w-[calc(100%-12px)] h-[calc(100%-12px)] text-amber-300/40 pointer-events-none"
            >
              {/* Competitive Octagonal Gate Ring */}
              <polygon
                points="38,6 82,6 114,38 114,82 82,114 38,114 6,82 6,38"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.2"
                strokeDasharray="6 3"
              />
              <circle cx="60" cy="60" r="29" fill="none" stroke="currentColor" strokeWidth="1" opacity="0.7" />
              <line x1="60" y1="26" x2="60" y2="94" stroke="currentColor" strokeWidth="0.75" opacity="0.4" />
              <line x1="26" y1="60" x2="94" y2="60" stroke="currentColor" strokeWidth="0.75" opacity="0.4" />
              {/* Sharp Directional Chevrons */}
              <path
                d="M53 16l7-8 7 8"
                fill="none"
                stroke={joyVector.y < -0.58 ? '#22d3ee' : 'rgba(253,224,71,0.9)'}
                strokeWidth="2.6"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M53 104l7 8 7-8"
                fill="none"
                stroke={joyVector.y > 0.54 ? '#22d3ee' : 'rgba(253,224,71,0.9)'}
                strokeWidth="2.6"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M16 53l-8 7 8 7"
                fill="none"
                stroke={joyVector.x < -0.25 ? '#22d3ee' : 'rgba(253,224,71,0.9)'}
                strokeWidth="2.6"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M104 53l8 7-8 7"
                fill="none"
                stroke={joyVector.x > 0.25 ? '#22d3ee' : 'rgba(253,224,71,0.9)'}
                strokeWidth="2.6"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>

            {showLabel && (
              <>
                <span className={`absolute top-5 text-[7px] font-extrabold tracking-widest pointer-events-none ${joyVector.y < -0.58 ? 'text-cyan-300' : 'text-amber-100/75'}`}>
                  JUMP
                </span>
                <span className={`absolute bottom-5 text-[7px] font-extrabold tracking-widest pointer-events-none ${joyVector.y > 0.54 ? 'text-cyan-300' : 'text-amber-100/75'}`}>
                  DUCK
                </span>
                <span className={`absolute left-4.5 text-[7px] font-extrabold tracking-wider pointer-events-none ${joyVector.x < -0.25 ? 'text-cyan-300' : 'text-amber-100/70'}`}>
                  L
                </span>
                <span className={`absolute right-4.5 text-[7px] font-extrabold tracking-wider pointer-events-none ${joyVector.x > 0.25 ? 'text-cyan-300' : 'text-amber-100/70'}`}>
                  R
                </span>
              </>
            )}

            {/* 1:1 Tactile Thumb Puck with Combat Compass Symbol */}
            <div
              style={{ transform: `translate(${knobOffset.x}px, ${knobOffset.y}px)` }}
              className={`relative w-14 h-14 rounded-full border-2 flex items-center justify-center pointer-events-none shadow-[inset_0_2px_4px_rgba(255,255,255,0.35),0_4px_14px_rgba(0,0,0,0.85)] ${
                isStickActive
                  ? 'transition-none bg-gradient-to-br from-amber-400/75 to-orange-600/75 border-amber-100 shadow-[0_0_22px_rgba(251,191,36,0.85)] scale-105'
                  : 'transition-transform duration-150 bg-gradient-to-br from-amber-300/24 to-slate-900/88 border-amber-200/75'
              }`}
            >
              {customizing ? (
                <Move className="w-5 h-5 text-amber-100" />
              ) : (
                <svg viewBox="0 0 24 24" className="w-6 h-6 text-amber-100 drop-shadow">
                  <circle cx="12" cy="12" r="4" className="fill-current" />
                  <path d="M12 2l2.2 3.2h-4.4L12 2zm0 20l2.2-3.2h-4.4L12 22zM2 12l3.2-2.2v4.4L2 12zm20 0l-3.2-2.2v4.4L22 12z" className="fill-current opacity-75" />
                </svg>
              )}
            </div>
          </div>
        </div>

        {/* RIGHT THUMB: SPACIOUS 6-BUTTON TWO-THUMB SHADOW FIGHT ARC (ZERO OVERLAP) */}
        <div
          style={{
            transform: `translate(${controlConfig.clusterOffset.x}px, ${controlConfig.clusterOffset.y}px) scale(${effectiveScale})`,
            transformOrigin: 'bottom right',
          }}
          className="pointer-events-auto absolute bottom-0 right-0 w-[292px] h-[206px]"
        >
          {customizing && (
            <div
              onPointerDown={handleClusterDragDown}
              className="touch-none absolute -top-8 right-0 px-2.5 py-1 rounded-full bg-amber-400 text-slate-950 text-[10px] font-extrabold flex items-center gap-1 cursor-move shadow-lg z-30"
            >
              <Move className="w-3 h-3" />
              Drag All
            </div>
          )}

          {/* 1. SKILL 1 — LONG RANGE */}
          <CircularActionButton
            kind="sp1"
            cd={localSp1Cd}
            maxCd={COOLDOWNS.SP1}
            cdAccentHex="#fbbf24"
            sizeClass="w-[56px] h-[56px]"
            baseStyle={
              localSp1Cd <= 0.05
                ? 'border-amber-300/95 text-amber-200 shadow-[0_0_16px_rgba(251,191,36,0.38)] hover:border-amber-100'
                : 'border-white/20 text-slate-300'
            }
            keyHint={formatKeyLabel(controlConfig.keyBinds.sp1)}
            showKeyHint={showKeyHint}
            showLabel={showLabel}
            customizing={customizing}
            isSelected={selectedTarget === 'sp1'}
            snapToGrid={controlConfig.snapToGrid}
            buttonScale={controlConfig.buttonScales?.sp1 ?? 1}
            effectiveScale={effectiveScale}
            offset={controlConfig.buttonOffsets.sp1 || { x: 0, y: 0 }}
            onSelectTarget={setSelectedTarget}
            onDragButton={handleButtonOffsetChange}
            onPress={triggerAct('sp1')}
            positionStyle={{ top: '6px', left: '80px' }}
          />

          {/* 2. SKILL 2 — CLOSE RANGE */}
          <CircularActionButton
            kind="sp2"
            cd={localSp2Cd}
            maxCd={COOLDOWNS.SP2}
            cdAccentHex="#fb923c"
            sizeClass="w-[56px] h-[56px]"
            baseStyle={
              localSp2Cd <= 0.05
                ? 'border-orange-300/95 text-orange-200 shadow-[0_0_16px_rgba(249,115,22,0.38)] hover:border-orange-100'
                : 'border-white/20 text-slate-300'
            }
            keyHint={formatKeyLabel(controlConfig.keyBinds.sp2)}
            showKeyHint={showKeyHint}
            showLabel={showLabel}
            customizing={customizing}
            isSelected={selectedTarget === 'sp2'}
            snapToGrid={controlConfig.snapToGrid}
            buttonScale={controlConfig.buttonScales?.sp2 ?? 1}
            effectiveScale={effectiveScale}
            offset={controlConfig.buttonOffsets.sp2 || { x: 0, y: 0 }}
            onSelectTarget={setSelectedTarget}
            onDragButton={handleButtonOffsetChange}
            onPress={triggerAct('sp2')}
            positionStyle={{ top: '54px', left: '10px' }}
          />

          {/* 3. SHIELD — GUARD & SKILL PARRY */}
          <CircularActionButton
            kind="shield"
            cdAccentHex="#34d399"
            sizeClass="w-[58px] h-[58px]"
            baseStyle={
              blockActive
                ? 'border-emerald-200 text-emerald-100 shadow-[0_0_22px_rgba(52,211,153,0.85)]'
                : 'border-emerald-300/80 text-emerald-100 shadow-[0_0_14px_rgba(16,185,129,0.26)] hover:border-emerald-200'
            }
            keyHint={formatKeyLabel(controlConfig.keyBinds.shield)}
            showKeyHint={showKeyHint}
            showLabel={showLabel}
            customizing={customizing}
            isSelected={selectedTarget === 'shield'}
            snapToGrid={controlConfig.snapToGrid}
            buttonScale={controlConfig.buttonScales?.shield ?? 1}
            effectiveScale={effectiveScale}
            offset={controlConfig.buttonOffsets.shield || { x: 0, y: 0 }}
            onSelectTarget={setSelectedTarget}
            onDragButton={handleButtonOffsetChange}
            onPress={() => {
              setBlockActive(true);
              onBlockChange(true);
            }}
            onRelease={() => {
              setBlockActive(false);
              onBlockChange(false);
            }}
            positionStyle={{ top: '6px', right: '54px' }}
          />

          {/* 4. DASH — EVASIVE STEP */}
          <CircularActionButton
            kind="dash"
            cd={localDashCd}
            maxCd={COOLDOWNS.DASH}
            cdAccentHex="#22d3ee"
            sizeClass="w-[56px] h-[56px]"
            baseStyle={
              localDashCd <= 0.05
                ? 'border-cyan-300/95 text-cyan-200 shadow-[0_0_16px_rgba(34,211,238,0.38)] hover:border-cyan-100'
                : 'border-white/20 text-slate-300'
            }
            keyHint={formatKeyLabel(controlConfig.keyBinds.dash)}
            showKeyHint={showKeyHint}
            showLabel={showLabel}
            customizing={customizing}
            isSelected={selectedTarget === 'dash'}
            snapToGrid={controlConfig.snapToGrid}
            buttonScale={controlConfig.buttonScales?.dash ?? 1}
            effectiveScale={effectiveScale}
            offset={controlConfig.buttonOffsets.dash || { x: 0, y: 0 }}
            onSelectTarget={setSelectedTarget}
            onDragButton={handleButtonOffsetChange}
            onPress={triggerAct('dash')}
            positionStyle={{ bottom: '68px', right: '2px' }}
          />

          {/* 5. ULTIMATE — 100% CHAKRA BURST */}
          <CircularActionButton
            kind="rage"
            energyPct={localRage}
            cdAccentHex="#fde047"
            sizeClass="w-[66px] h-[66px]"
            baseStyle={
              chakraReady
                ? 'border-yellow-300 text-yellow-100 chakra-ready-glow'
                : 'border-cyan-300/70 text-cyan-100/90 shadow-[0_0_14px_rgba(34,211,238,0.22)]'
            }
            keyHint={formatKeyLabel(controlConfig.keyBinds.rage)}
            showKeyHint={showKeyHint}
            showLabel={showLabel}
            customizing={customizing}
            isSelected={selectedTarget === 'rage'}
            snapToGrid={controlConfig.snapToGrid}
            buttonScale={controlConfig.buttonScales?.rage ?? 1}
            effectiveScale={effectiveScale}
            offset={controlConfig.buttonOffsets.rage || { x: 0, y: 0 }}
            onSelectTarget={setSelectedTarget}
            onDragButton={handleButtonOffsetChange}
            onPress={triggerAct('rage')}
            positionStyle={{ bottom: '12px', left: '20px' }}
          />

          {/* 6. BASIC (PRIMARY HERO) — PUNCH + KICK SHADOW COMBO */}
          <CircularActionButton
            kind="basic"
            cdAccentHex="#fbbf24"
            sizeClass="w-[84px] h-[84px]"
            baseStyle="border-amber-300/95 text-amber-100 shadow-[0_0_24px_rgba(245,158,11,0.36)] hover:border-yellow-200"
            keyHint={formatKeyLabel(controlConfig.keyBinds.basic)}
            showKeyHint={showKeyHint}
            showLabel={showLabel}
            customizing={customizing}
            isSelected={selectedTarget === 'basic'}
            snapToGrid={controlConfig.snapToGrid}
            buttonScale={controlConfig.buttonScales?.basic ?? 1}
            effectiveScale={effectiveScale}
            offset={controlConfig.buttonOffsets.basic || { x: 0, y: 0 }}
            onSelectTarget={setSelectedTarget}
            onDragButton={handleButtonOffsetChange}
            onPress={triggerAct('basic')}
            positionStyle={{ bottom: '8px', right: '78px' }}
          />
        </div>
      </div>
    </div>
  );
};
