import React, { useEffect, useRef } from 'react';
import { Code2, Crown, Flame, Swords, Trophy, UserCheck, X } from 'lucide-react';
import { getCfgById } from '../game/data';
import { drawFighterPosePreview } from '../game/engine';
import { LeaderboardEntry } from '../services/socialHub';

interface PublicProfileModalProps {
  profile: LeaderboardEntry | null;
  loading?: boolean;
  isMe?: boolean;
  roomCode?: string;
  onJoinRoomCode?: (code: string) => void;
  onClose: () => void;
}

export const PublicProfileModal: React.FC<PublicProfileModalProps> = ({
  profile,
  loading = false,
  isMe = false,
  roomCode,
  onJoinRoomCode,
  onClose,
}) => {
  const stageRef = useRef<HTMLCanvasElement | null>(null);
  const fighterId = profile?.favoriteFighterId || 'munna_bhaiya';

  useEffect(() => {
    if (!profile) return;
    let raf = 0;
    let last = 0;
    const render = (now: number) => {
      raf = window.requestAnimationFrame(render);
      if (now - last < 34) return;
      last = now;
      if (stageRef.current) {
        drawFighterPosePreview(stageRef.current, fighterId, 'victory', now * 0.001);
      }
    };
    raf = window.requestAnimationFrame(render);
    return () => window.cancelAnimationFrame(raf);
  }, [profile, fighterId]);

  if (!profile && !loading) return null;

  const cfg = getCfgById(fighterId);
  const total = profile?.matchesPlayed || 0;
  const wins = profile?.wins || 0;
  const losses = profile?.losses || 0;
  const winRate = total > 0 ? Math.round((wins / total) * 100) : 0;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-2.5 sm:p-4 bg-black/82 backdrop-blur-xs">
      <div className="w-full max-w-xl max-h-[calc(100dvh-1rem)] flex flex-col overflow-hidden rounded-2xl border border-amber-400/45 bg-[#0e0b1a]/98 shadow-[0_0_50px_rgba(245,158,11,0.28)]">
        {/* Header */}
        <div className="shrink-0 flex items-center justify-between px-4 py-2.5 border-b border-white/10 bg-black/35">
          <div className="flex items-center gap-2 min-w-0">
            <Trophy className="w-4 h-4 text-amber-300 shrink-0" />
            <h3 className="font-display-in text-base sm:text-lg tracking-wider text-amber-200 truncate">
              YODDHA PROFILE STATUS
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Player Profile"
            className="w-8 h-8 rounded-lg border border-white/15 bg-white/5 flex items-center justify-center text-amber-200 hover:border-amber-300 cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        {loading || !profile ? (
          <div className="p-8 text-center text-xs text-amber-200/75">Loading player status...</div>
        ) : (
          <div className="p-3.5 sm:p-4 grid grid-cols-[170px_1fr] sm:grid-cols-[195px_1fr] gap-3.5 items-stretch overflow-y-auto roster-scroll">
            {/* Left Live Character Showcase */}
            <div className="rounded-xl border border-white/10 bg-[#080612] flex flex-col justify-between p-2 overflow-hidden">
              <canvas ref={stageRef} width={210} height={180} className="w-full h-36 sm:h-40 object-contain" />
              <div className="text-center border-t border-white/10 pt-1.5">
                <div className="text-[9px] uppercase tracking-widest text-amber-300/75 font-bold">Main Warrior</div>
                <div className="font-display-in text-sm text-amber-100 truncate">{cfg.name}</div>
              </div>
            </div>

            {/* Right Identity & Stats */}
            <div className="flex flex-col justify-between gap-2.5 min-w-0">
              <div className="flex items-center gap-2.5 p-2.5 rounded-xl bg-black/40 border border-white/10">
                {profile.photoUrl ? (
                  <img
                    src={profile.photoUrl}
                    alt=""
                    referrerPolicy="no-referrer"
                    className="w-11 h-11 rounded-full border border-amber-300/60 object-cover shrink-0"
                  />
                ) : (
                  <div className="w-11 h-11 rounded-full border border-amber-300/50 bg-amber-500/15 flex items-center justify-center shrink-0">
                    <UserCheck className="w-5 h-5 text-amber-300" />
                  </div>
                )}
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="font-display-in text-lg text-amber-100 truncate">{profile.akharaName}</span>
                    {profile.isDeveloper && (
                      <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-gradient-to-r from-amber-400 to-yellow-300 text-slate-950 text-[9px] font-black uppercase tracking-wider shadow-[0_0_12px_rgba(251,191,36,0.45)]">
                        <Code2 className="w-2.5 h-2.5" />
                        DEV
                      </span>
                    )}
                    {isMe && (
                      <span className="text-[9px] font-extrabold text-emerald-300 uppercase tracking-wider">
                        (You)
                      </span>
                    )}
                  </div>
                  <div className="text-[11px] text-amber-200/75 flex items-center gap-1.5 mt-0.5">
                    <Crown className="w-3 h-3 text-amber-300 shrink-0" />
                    <span className="font-num font-bold text-amber-300 tabular-nums">{profile.rankPoints}</span>
                    <span>Akhara Rank Points</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 text-center font-num">
                <div className="p-2 rounded-xl bg-black/35 border border-white/10">
                  <div className="text-[9px] font-sans font-bold uppercase text-slate-400">Matches</div>
                  <div className="text-base font-extrabold text-amber-100 tabular-nums">{total}</div>
                </div>
                <div className="p-2 rounded-xl bg-black/35 border border-emerald-400/25">
                  <div className="text-[9px] font-sans font-bold uppercase text-emerald-300/80">Wins</div>
                  <div className="text-base font-extrabold text-emerald-300 tabular-nums">{wins}</div>
                </div>
                <div className="p-2 rounded-xl bg-black/35 border border-rose-400/25">
                  <div className="text-[9px] font-sans font-bold uppercase text-rose-300/80">Losses</div>
                  <div className="text-base font-extrabold text-rose-300 tabular-nums">{losses}</div>
                </div>
                <div className="p-2 rounded-xl bg-black/35 border border-cyan-400/25">
                  <div className="text-[9px] font-sans font-bold uppercase text-cyan-300/80">Win Rate</div>
                  <div className="text-base font-extrabold text-cyan-300 tabular-nums">{winRate}%</div>
                </div>
                <div className="p-2 rounded-xl bg-black/35 border border-amber-400/25 col-span-2 flex items-center justify-center gap-2">
                  <Flame className="w-4 h-4 text-orange-400 shrink-0" />
                  <div className="text-left">
                    <div className="text-[9px] font-sans font-bold uppercase text-amber-300/75 leading-none">
                      Best Combo Streak
                    </div>
                    <div className="text-sm font-black text-amber-200 tabular-nums">{profile.bestCombo}x Hits</div>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-1">
                {roomCode && onJoinRoomCode && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onJoinRoomCode(roomCode);
                    }}
                    className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-400 to-teal-400 text-slate-950 font-extrabold text-xs flex items-center gap-1.5 hover:brightness-110 cursor-pointer"
                  >
                    <Swords className="w-3.5 h-3.5" />
                    Join Room {roomCode}
                  </button>
                )}
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl border border-white/15 bg-white/5 text-amber-100 text-xs font-bold hover:border-amber-300 cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
