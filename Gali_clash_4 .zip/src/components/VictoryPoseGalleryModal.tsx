import React, { useEffect, useRef, useState } from 'react';
import { User } from 'firebase/auth';
import { Check, Code2, Coins, Crown, Gem, Lock, LogIn, RotateCcw, Sparkles, Swords, X } from 'lucide-react';
import { sound } from '../game/audio';
import { CosmeticCurrency, getEquippedSkinForFighter } from '../game/cosmetics';
import { FIGHTERS, getCfgById } from '../game/data';
import { drawCharFace, drawFighterPosePreview } from '../game/engine';
import { FighterConfig } from '../game/types';
import {
  getSelectedVictoryPoseId,
  getVictoryPoseById,
  getVictoryPosesForFighter,
  isVictoryPoseUnlocked,
  loadSelectedVictoryPoses,
  saveSelectedVictoryPoseId,
} from '../game/victoryPoses';
import { getEffectivePosePricing, LiveCmsConfig } from '../services/devCms';
import { PlayerProfile } from '../services/playerAccount';

interface VictoryPoseGalleryModalProps {
  open: boolean;
  authUser: User | null;
  profile: PlayerProfile | null;
  isDeveloperMode?: boolean;
  cmsConfig?: LiveCmsConfig | null;
  initialFighterId?: string;
  favoriteFighterId?: string;
  equippedSkinIds?: string[];
  auraId?: string;
  onSelectFighter?: (fighterId: string) => void;
  onUnlockPose: (fighterId: string, poseId: string, payCurrency: CosmeticCurrency) => Promise<void>;
  onRequireLogin: () => void;
  onOpenBuyGota: () => void;
  onClose: () => void;
}

function MiniFace({ cfg, skinId }: { cfg: FighterConfig; skinId?: string }) {
  const ref = useRef<HTMLCanvasElement | null>(null);
  useEffect(() => {
    if (ref.current) drawCharFace(ref.current, cfg, skinId);
  }, [cfg, skinId]);
  return <canvas ref={ref} className="w-9 h-9 sm:w-10 sm:h-10 rounded-full shrink-0" />;
}

export const VictoryPoseGalleryModal: React.FC<VictoryPoseGalleryModalProps> = ({
  open,
  authUser,
  profile,
  isDeveloperMode = false,
  cmsConfig,
  initialFighterId,
  favoriteFighterId,
  equippedSkinIds,
  auraId,
  onSelectFighter,
  onUnlockPose,
  onRequireLogin,
  onOpenBuyGota,
  onClose,
}) => {
  const [selectedId, setSelectedId] = useState<string>(initialFighterId || FIGHTERS[0].id);
  const [poseMode, setPoseMode] = useState<'victory' | 'defeat'>('victory');
  const [selectedPoseMap, setSelectedPoseMap] = useState<Record<string, string>>(() =>
    loadSelectedVictoryPoses(),
  );
  const [previewPoseId, setPreviewPoseId] = useState<string | null>(null);
  const [poseBurstKey, setPoseBurstKey] = useState(0);
  const [busyCurrency, setBusyCurrency] = useState<CosmeticCurrency | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);
  const stageCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const selectedSkinId = getEquippedSkinForFighter(equippedSkinIds, selectedId)?.id;

  const unlockedPoses = profile?.unlockedPoses || [];
  const isDev = Boolean(profile?.isDeveloper) || Boolean(isDeveloperMode);
  const futiKodi = profile?.futiKodi ?? 0;
  const gota = profile?.gota ?? 0;

  const fighterPoses = getVictoryPosesForFighter(selectedId);
  const equippedPoseId = selectedPoseMap[selectedId] || getSelectedVictoryPoseId(selectedId);
  const safeEquippedPoseId = isVictoryPoseUnlocked(selectedId, equippedPoseId, unlockedPoses)
    ? equippedPoseId
    : fighterPoses[0].id;
  const shownPoseId = previewPoseId || safeEquippedPoseId;
  const activePose = getVictoryPoseById(selectedId, shownPoseId);
  const activePosePrice = getEffectivePosePricing(selectedId, activePose.id, cmsConfig);
  const isShownPoseUnlocked = isVictoryPoseUnlocked(selectedId, activePose.id, unlockedPoses);

  useEffect(() => {
    if (open) {
      setSelectedPoseMap(loadSelectedVictoryPoses());
      setPreviewPoseId(null);
      setFeedback(null);
      if (initialFighterId) {
        setSelectedId(initialFighterId);
        setPoseMode('victory');
      }
    }
  }, [open, initialFighterId]);

  useEffect(() => {
    if (!open) return;
    let raf = 0;
    let lastDraw = 0;
    const render = (now: number) => {
      raf = window.requestAnimationFrame(render);
      if (now - lastDraw < 32) return;
      lastDraw = now;
      if (stageCanvasRef.current) {
        drawFighterPosePreview(
          stageCanvasRef.current,
          selectedId,
          poseMode,
          now * 0.001,
          selectedSkinId,
          auraId,
          activePose.id,
        );
      }
    };
    raf = window.requestAnimationFrame(render);
    return () => window.cancelAnimationFrame(raf);
  }, [open, selectedId, poseMode, poseBurstKey, selectedSkinId, auraId, activePose.id]);

  if (!open) return null;

  const cfg = getCfgById(selectedId);

  const handleChoosePose = (poseId: string) => {
    sound.ensureAudio();
    setFeedback(null);
    setPoseMode('victory');
    if (isVictoryPoseUnlocked(selectedId, poseId, unlockedPoses)) {
      saveSelectedVictoryPoseId(selectedId, poseId);
      setSelectedPoseMap((prev) => ({ ...prev, [selectedId]: poseId }));
      setPreviewPoseId(null);
    } else {
      setPreviewPoseId(poseId);
    }
  };

  const handleUnlockPose = async (payCurrency: CosmeticCurrency) => {
    if (isShownPoseUnlocked) return;

    if (!isDev) {
      if (payCurrency === 'futi_kodi' && futiKodi < activePosePrice.fkPrice) {
        setFeedback(
          `Need ${activePosePrice.fkPrice - futiKodi} more Futi Kodi (+80 Win / +35 Play) or unlock for ${activePosePrice.gotaPrice} Gota!`,
        );
        return;
      }
      if (payCurrency === 'gota' && gota < activePosePrice.gotaPrice) {
        onOpenBuyGota();
        return;
      }
    }

    setBusyCurrency(payCurrency);
    setFeedback(null);
    try {
      await onUnlockPose(selectedId, activePose.id, payCurrency);
      saveSelectedVictoryPoseId(selectedId, activePose.id);
      setSelectedPoseMap((prev) => ({ ...prev, [selectedId]: activePose.id }));
      setPreviewPoseId(null);
      setFeedback(`Unlocked & equipped "${activePose.poseName}"!`);
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'Could not unlock victory pose.');
    } finally {
      setBusyCurrency(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-3 bg-black/82 backdrop-blur-xs">
      <div className="w-full max-w-4xl h-[min(565px,calc(100dvh-1rem))] flex flex-col overflow-hidden rounded-2xl border-2 border-amber-400/55 bg-[#0d0a19]/98 shadow-[0_0_55px_rgba(245,158,11,0.28)]">
        {/* Fixed Header */}
        <div className="shrink-0 flex items-center justify-between gap-2 px-3 sm:px-4 py-2 border-b border-amber-400/20 bg-gradient-to-r from-amber-500/18 via-transparent to-cyan-500/15">
          <div className="flex items-center gap-2 min-w-0">
            <Crown className="w-5 h-5 text-amber-300 shrink-0" />
            <div className="min-w-0">
              <h3 className="font-display-in text-base sm:text-xl tracking-wider text-amber-200 leading-none truncate">
                GALI CLASH · VICTORY POSE GALLERY
              </h3>
              <p className="text-[10px] text-amber-100/65 mt-0.5 truncate">
                Pose 1 Free · Unlock Pose 2 &amp; 3 with Futi Kodi or Gota
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {isDev && (
              <span className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-gradient-to-r from-amber-400 to-yellow-300 text-slate-950 text-[10px] font-black uppercase">
                <Code2 className="w-3 h-3" />
                DEV ∞
              </span>
            )}
            <div className="px-2 py-1 rounded-lg border border-cyan-400/35 bg-cyan-500/12 flex items-center gap-1">
              <Coins className="w-3.5 h-3.5 text-cyan-300" />
              <span className="font-num text-xs font-extrabold text-cyan-100 tabular-nums">
                {isDev ? '∞' : futiKodi}
              </span>
            </div>
            <button
              type="button"
              onClick={onOpenBuyGota}
              title="Get Gota Packs (₹15+)"
              className="px-2 py-1 rounded-lg border border-amber-400/45 bg-amber-500/15 flex items-center gap-1 hover:border-amber-300 cursor-pointer"
            >
              <Gem className="w-3.5 h-3.5 text-amber-300" />
              <span className="font-num text-xs font-extrabold text-amber-100 tabular-nums">
                {isDev ? '∞' : gota}
              </span>
              {!isDev && <span className="text-[10px] font-black text-amber-300">+</span>}
            </button>
            {!authUser && (
              <button
                type="button"
                onClick={onRequireLogin}
                className="px-2 py-1 rounded-lg border border-amber-400/45 bg-amber-500/15 text-amber-200 text-[10px] font-bold flex items-center gap-1 cursor-pointer"
              >
                <LogIn className="w-3 h-3" />
                <span className="hidden sm:inline">Login</span>
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              aria-label="Close Pose Gallery"
              className="w-8 h-8 rounded-lg border border-amber-400/35 bg-black/45 flex items-center justify-center text-amber-200 hover:bg-amber-400/15 cursor-pointer shrink-0"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 2-Column Landscape Gallery */}
        <div className="flex-1 min-h-0 grid grid-cols-[1.08fr_1.15fr] gap-2.5 sm:gap-4 p-2.5 sm:p-3.5">
          {/* Left: Animated Stage Preview + 3 Pose Variants + Unlock Controls */}
          <div className="min-h-0 flex flex-col gap-1 rounded-xl border border-amber-400/25 bg-[#080611] p-2 sm:p-2.5 overflow-y-auto roster-scroll">
            <div className="flex items-center justify-between gap-2 shrink-0">
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => setPoseMode('victory')}
                  className={`px-2 py-0.5 rounded-lg text-[10px] font-extrabold uppercase tracking-wider border cursor-pointer transition ${
                    poseMode === 'victory'
                      ? 'bg-amber-400/25 border-amber-300 text-amber-200'
                      : 'bg-black/40 border-white/10 text-slate-400'
                  }`}
                >
                  Victory Poses (3)
                </button>
                <button
                  type="button"
                  onClick={() => setPoseMode('defeat')}
                  className={`px-2 py-0.5 rounded-lg text-[10px] font-extrabold uppercase tracking-wider border cursor-pointer transition ${
                    poseMode === 'defeat'
                      ? 'bg-rose-500/25 border-rose-400 text-rose-200'
                      : 'bg-black/40 border-white/10 text-slate-400'
                  }`}
                >
                  Defeat Stance
                </button>
              </div>
              <button
                type="button"
                data-ui-sfx="none"
                onClick={() => {
                  sound.ensureAudio();
                  sound.playVictoryStinger(cfg.id);
                  setPoseBurstKey((k) => k + 1);
                }}
                title="Replay Victory Fanfare"
                className="px-2 py-0.5 rounded-lg border border-cyan-400/35 bg-cyan-500/10 text-cyan-200 text-[10px] font-bold flex items-center gap-1 hover:bg-cyan-500/20 cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                Fanfare
              </button>
            </div>

            <div className="relative flex-1 min-h-[125px] shrink-0 flex items-center justify-center my-0.5">
              <canvas
                ref={stageCanvasRef}
                width={320}
                height={200}
                className="w-full h-full min-h-[125px] max-h-[205px] object-contain"
              />
              <span
                className="absolute bottom-1 right-1 px-2 py-0.5 rounded-md border text-[9px] font-extrabold uppercase tracking-wider flex items-center gap-1"
                style={{
                  borderColor: `${cfg.aura}77`,
                  backgroundColor: 'rgba(9,7,18,0.88)',
                  color: cfg.glow,
                }}
              >
                {poseMode === 'victory' && !isShownPoseUnlocked && <Lock className="w-2.5 h-2.5 text-amber-300" />}
                {poseMode === 'victory' ? activePose.poseName : 'Defeated Knee Stance'}
              </span>
            </div>

            {/* 3 Selectable Victory Pose Variants */}
            <div className="shrink-0 grid grid-cols-3 gap-1.5">
              {fighterPoses.map((pose, idx) => {
                const isUnlocked = isVictoryPoseUnlocked(selectedId, pose.id, unlockedPoses);
                const isShown = activePose.id === pose.id && poseMode === 'victory';
                const isEquipped = safeEquippedPoseId === pose.id;
                const price = getEffectivePosePricing(selectedId, pose.id, cmsConfig);
                return (
                  <button
                    key={pose.id}
                    type="button"
                    data-ui-sfx="select"
                    onClick={() => handleChoosePose(pose.id)}
                    className={`text-left px-[8px] py-[5px] rounded-lg border transition cursor-pointer flex flex-col justify-between ${
                      isShown
                        ? isUnlocked
                          ? 'bg-amber-400/22 border-amber-300 text-amber-100 shadow-[0_0_12px_rgba(251,191,36,0.2)]'
                          : 'bg-rose-500/16 border-rose-400/75 text-amber-100'
                        : 'bg-black/45 border-white/10 text-slate-300 hover:border-amber-300/45'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-1 text-[9px] font-extrabold uppercase tracking-wider text-amber-300/90 leading-none">
                      <span>Pose {idx + 1}</span>
                      {price.flashLabel && !isUnlocked ? (
                        <span className="px-1 py-[1px] rounded bg-rose-500 text-white text-[7.5px] font-black uppercase">
                          {price.flashLabel}
                        </span>
                      ) : isEquipped ? (
                        <Check className="w-2.5 h-2.5 text-emerald-300 shrink-0" />
                      ) : isUnlocked ? (
                        <span className="text-[8px] text-emerald-300/90 font-bold">Open</span>
                      ) : (
                        <Lock className="w-2.5 h-2.5 text-amber-300/80 shrink-0" />
                      )}
                    </div>
                    <div className="text-[11px] font-bold leading-[1.15] whitespace-normal break-words mt-0.5">
                      {pose.poseName}
                    </div>
                    {!isUnlocked && (
                      <div className="text-[9px] text-cyan-200/85 font-semibold leading-tight mt-0.5 whitespace-nowrap tabular-nums">
                        {price.fkPrice} FK / {price.gotaPrice} Gota
                      </div>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Compact Single-Line Dual-Currency Unlock Bar when a Locked Pose (Pose 2 or Pose 3) is Selected */}
            {poseMode === 'victory' && !isShownPoseUnlocked ? (
              <div className="shrink-0 px-[10px] py-[6px] rounded-xl border border-amber-400/40 bg-amber-500/10 flex flex-col gap-1">
                <div className="flex items-center justify-between gap-1.5 min-w-0">
                  <span className="text-[10px] font-bold text-amber-200 flex items-center gap-1 min-w-0 truncate">
                    <Lock className="w-3 h-3 text-amber-300 shrink-0" />
                    <span className="truncate">Unlock Pose {activePosePrice.index}</span>
                    {activePosePrice.flashLabel && (
                      <span className="px-1 py-[1px] rounded bg-rose-500 text-white text-[8px] font-black uppercase shrink-0">
                        {activePosePrice.flashLabel}
                      </span>
                    )}
                  </span>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      data-ui-sfx={authUser && (isDev || futiKodi >= activePosePrice.fkPrice) ? 'unlock' : 'locked'}
                      disabled={busyCurrency !== null}
                      onClick={() => void handleUnlockPose('futi_kodi')}
                      className={`px-[10px] py-[6px] rounded-lg text-[10px] font-extrabold leading-none flex items-center justify-center gap-1 whitespace-nowrap transition cursor-pointer ${
                        isDev || futiKodi >= activePosePrice.fkPrice
                          ? 'bg-cyan-400 text-slate-950 hover:brightness-110'
                          : 'bg-cyan-500/15 text-cyan-200 border border-cyan-400/35 hover:bg-cyan-500/25'
                      }`}
                    >
                      <Coins className="w-3 h-3 shrink-0" />
                      {busyCurrency === 'futi_kodi' ? 'Unlocking...' : `Unlock ${activePosePrice.fkPrice} FK`}
                    </button>
                    <button
                      type="button"
                      data-ui-sfx={authUser && (isDev || gota >= activePosePrice.gotaPrice) ? 'unlock' : 'locked'}
                      disabled={busyCurrency !== null}
                      onClick={() => void handleUnlockPose('gota')}
                      className={`px-[10px] py-[6px] rounded-lg text-[10px] font-extrabold leading-none flex items-center justify-center gap-1 whitespace-nowrap transition cursor-pointer ${
                        isDev || gota >= activePosePrice.gotaPrice
                          ? 'bg-gradient-to-r from-amber-400 to-rose-500 text-slate-950 hover:brightness-110'
                          : 'bg-amber-500/15 text-amber-200 border border-amber-400/35 hover:bg-amber-500/25'
                      }`}
                    >
                      <Gem className="w-3 h-3 shrink-0" />
                      {busyCurrency === 'gota' ? 'Unlocking...' : `Unlock ${activePosePrice.gotaPrice} Gota`}
                    </button>
                  </div>
                </div>
                {feedback && <div className="text-[9.5px] text-amber-200 font-semibold leading-tight">{feedback}</div>}
              </div>
            ) : feedback ? (
              <div className="shrink-0 px-[10px] py-[5px] rounded-lg bg-emerald-500/15 border border-emerald-400/40 text-[10px] text-emerald-300 font-semibold truncate">
                {feedback}
              </div>
            ) : null}

            <div className="shrink-0 border-t border-white/10 pt-1">
              <div className="flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <div className="font-display-in text-sm sm:text-base text-amber-200 leading-tight whitespace-normal break-words">
                    {cfg.name}
                  </div>
                  <div className="text-[10px] text-cyan-300/85 font-semibold truncate">
                    {poseMode === 'victory' ? activePose.vibe : `${cfg.title} · Ready for Rematch`}
                  </div>
                </div>
                {onSelectFighter && (
                  <button
                    type="button"
                    data-ui-sfx="unlock"
                    onClick={() => {
                      onSelectFighter(cfg.id);
                      onClose();
                    }}
                    className="shrink-0 px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-rose-500 text-slate-950 text-[11px] font-extrabold flex items-center gap-1 cursor-pointer hover:brightness-110"
                  >
                    <Swords className="w-3.5 h-3.5" />
                    Equip Fighter
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Right: 10 Warriors Grid */}
          <div className="min-h-0 overflow-y-auto roster-scroll pr-1">
            <div className="grid grid-cols-2 gap-2">
              {FIGHTERS.map((f) => {
                const isSelected = f.id === selectedId;
                const isFav = f.id === favoriteFighterId;
                const fPose = getVictoryPoseById(f.id, selectedPoseMap[f.id]);
                const fPoseUnlocked = isVictoryPoseUnlocked(f.id, fPose.id, unlockedPoses);
                const shownFPose = fPoseUnlocked ? fPose : getVictoryPosesForFighter(f.id)[0];
                const unlockedCount = getVictoryPosesForFighter(f.id).filter((p) =>
                  isVictoryPoseUnlocked(f.id, p.id, unlockedPoses),
                ).length;

                return (
                  <button
                    key={f.id}
                    type="button"
                    data-ui-sfx="select"
                    onClick={() => {
                      sound.ensureAudio();
                      setSelectedId(f.id);
                      setPreviewPoseId(null);
                      setFeedback(null);
                    }}
                    className={`relative text-left p-2 rounded-xl border transition flex items-center gap-2 cursor-pointer ${
                      isSelected
                        ? 'border-amber-400 bg-amber-500/18 shadow-[0_0_16px_rgba(251,191,36,0.22)]'
                        : 'border-white/10 bg-black/35 hover:border-amber-300/45'
                    }`}
                  >
                    <MiniFace cfg={f} skinId={getEquippedSkinForFighter(equippedSkinIds, f.id)?.id} />
                    <div className="min-w-0 flex-1">
                      <div className="font-display-in text-[11px] sm:text-[13px] leading-[1.12] text-amber-100 whitespace-normal break-words pr-4">
                        {f.name}
                      </div>
                      <div className="text-[9.5px] text-amber-300/80 font-semibold truncate mt-0.5">
                        {shownFPose.poseName}
                      </div>
                      <div className="text-[9px] text-slate-400 truncate">
                        {unlockedCount}/3 Poses · {f.title}
                      </div>
                    </div>
                    {isFav && (
                      <span
                        title="Saved Main Yoddha"
                        className="absolute top-1.5 right-1.5 text-emerald-300"
                      >
                        <Sparkles className="w-3 h-3" />
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
