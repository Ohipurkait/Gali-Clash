import React, { useState } from 'react';
import { Check, Coins, ScrollText, Sparkles, X } from 'lucide-react';
import { sound } from '../game/audio';
import { DailyQuestItem } from '../services/dailyQuests';

interface DailyQuestsModalProps {
  open: boolean;
  quests: DailyQuestItem[];
  onClaimQuest: (quest: DailyQuestItem) => Promise<void>;
  onClose: () => void;
  onToast: (msg: string) => void;
}

export const DailyQuestsModal: React.FC<DailyQuestsModalProps> = ({
  open,
  quests,
  onClaimQuest,
  onClose,
  onToast,
}) => {
  const [claimingSlot, setClaimingSlot] = useState<string | null>(null);

  if (!open) return null;

  const readyCount = quests.filter((q) => q.progress >= q.targetCount && !q.claimed).length;
  const completedCount = quests.filter((q) => q.claimed).length;

  const handleClaim = async (quest: DailyQuestItem) => {
    if (claimingSlot) return;
    setClaimingSlot(quest.slot);
    try {
      await onClaimQuest(quest);
      sound.playUiSfx('unlock');
    } catch (err) {
      sound.playUiSfx('locked');
      onToast(err instanceof Error ? err.message : 'Could not claim reward.');
    } finally {
      setClaimingSlot(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-black/82 backdrop-blur-xs">
      <div className="w-full max-w-xl max-h-[calc(100dvh-1rem)] flex flex-col overflow-hidden rounded-2xl border-2 border-amber-400/55 bg-[#0e0a1b]/98 shadow-[0_0_55px_rgba(245,158,11,0.3)]">
        {/* Header */}
        <div className="shrink-0 flex items-center justify-between gap-2 px-4 py-2.5 border-b border-amber-400/20 bg-gradient-to-r from-amber-500/18 via-transparent to-emerald-500/12">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-xl border border-amber-400/50 bg-amber-500/15 flex items-center justify-center shrink-0">
              <ScrollText className="w-4 h-4 text-amber-300" />
            </div>
            <div className="min-w-0">
              <h3 className="font-display-in text-lg sm:text-xl tracking-wider text-amber-200 leading-none truncate">
                AAJ KE TASK · DAILY QUESTS
              </h3>
              <p className="text-[10px] text-amber-200/70 mt-0.5 truncate">
                Refreshes daily at midnight · {completedCount}/3 Claimed
                {readyCount > 0 ? ` · ${readyCount} Ready!` : ''}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close Daily Quests"
            className="w-8 h-8 rounded-lg border border-amber-400/30 bg-black/45 flex items-center justify-center text-amber-200 hover:bg-amber-400/15 cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Quest Cards */}
        <div className="flex-1 min-h-0 overflow-y-auto roster-scroll p-3.5 sm:p-4 space-y-2.5">
          {quests.map((q) => {
            const pct = Math.min(100, Math.round((q.progress / Math.max(1, q.targetCount)) * 100));
            const isComplete = q.progress >= q.targetCount;
            const canClaim = isComplete && !q.claimed;
            const tierColor =
              q.tierLabel === 'Easy'
                ? 'border-emerald-400/45 bg-emerald-500/12 text-emerald-200'
                : q.tierLabel === 'Yoddha'
                  ? 'border-cyan-400/45 bg-cyan-500/12 text-cyan-200'
                  : 'border-amber-400/55 bg-amber-500/15 text-amber-200';

            return (
              <div
                key={q.questKey}
                className={`p-3 rounded-xl border transition ${
                  q.claimed
                    ? 'border-emerald-500/30 bg-emerald-950/20 opacity-85'
                    : canClaim
                      ? 'border-amber-400 bg-gradient-to-r from-amber-500/18 via-[#151026] to-emerald-500/12 shadow-[0_0_20px_rgba(251,191,36,0.22)]'
                      : 'border-white/12 bg-black/40'
                }`}
              >
                <div className="flex items-start justify-between gap-2.5">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className={`px-1.5 py-[1px] rounded border text-[9px] font-black uppercase tracking-wider ${tierColor}`}>
                        {q.tierLabel}
                      </span>
                      <span className="font-display-in text-sm sm:text-base text-amber-100 leading-tight">
                        {q.title}
                      </span>
                    </div>
                    <p className="text-xs text-amber-50/80 mt-0.5 leading-snug">
                      {q.description}
                    </p>
                  </div>

                  {/* Reward Pill + Action */}
                  <div className="flex flex-col items-end gap-1.5 shrink-0">
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-amber-400/20 border border-amber-300/50 font-num text-[11px] font-black text-amber-200">
                      <Coins className="w-3 h-3 text-amber-300" />
                      +{q.rewardFk} FK
                    </span>

                    {q.claimed ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-500/20 border border-emerald-400/50 text-[10.5px] font-extrabold text-emerald-200">
                        <Check className="w-3 h-3" />
                        Claimed
                      </span>
                    ) : canClaim ? (
                      <button
                        type="button"
                        data-ui-sfx="none"
                        disabled={claimingSlot === q.slot}
                        onClick={() => void handleClaim(q)}
                        className="px-3 py-1 rounded-lg bg-gradient-to-r from-amber-400 via-yellow-300 to-emerald-400 text-slate-950 text-[11px] font-black tracking-wide flex items-center gap-1 shadow-[0_0_14px_rgba(251,191,36,0.45)] hover:brightness-110 active:scale-[0.97] cursor-pointer disabled:opacity-60"
                      >
                        <Sparkles className="w-3 h-3" />
                        {claimingSlot === q.slot ? 'Claiming...' : 'Claim FK'}
                      </button>
                    ) : (
                      <span className="px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 text-[10px] font-bold text-slate-400">
                        In Progress
                      </span>
                    )}
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="mt-2.5 flex items-center gap-2">
                  <div className="flex-1 h-2 rounded-full bg-black/60 border border-white/10 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        q.claimed || isComplete
                          ? 'bg-gradient-to-r from-emerald-400 to-amber-300'
                          : 'bg-gradient-to-r from-amber-500 to-orange-400'
                      }`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                  <span className="font-num text-[11px] font-extrabold text-amber-200/90 tabular-nums shrink-0">
                    ({q.progress}/{q.targetCount})
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
