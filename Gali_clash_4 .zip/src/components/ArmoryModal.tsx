import React, { useEffect, useRef, useState } from 'react';
import { User } from 'firebase/auth';
import {
  Backpack,
  Check,
  Code2,
  Coins,
  Crown,
  Eye,
  Gem,
  Lock,
  LogIn,
  Package,
  ShieldCheck,
  ShoppingBag,
  X,
} from 'lucide-react';
import {
  ALL_COSMETICS,
  AURAS,
  CosmeticCurrency,
  CosmeticItem,
  DEFAULT_AURA_ID,
  getAllAuras,
  getAllCosmetics,
  getAllSkins,
  getAuraById,
  getEquippedSkinForFighter,
  getSkinById,
  GOTA_PACKS,
  GotaPack,
  isDevUnreleasedCosmeticId,
  SKINS,
} from '../game/cosmetics';
import { FIGHTERS, getCfgById } from '../game/data';
import { drawCosmeticThumbnail, drawFighterPosePreview } from '../game/engine';
import {
  CmsBundleDef,
  computeBundleRegularGotaValue,
  decodeBundleToken,
  getEffectiveCosmeticPricing,
  LiveCmsConfig,
} from '../services/devCms';
import { PlayerProfile } from '../services/playerAccount';

interface ArmoryModalProps {
  open: boolean;
  onClose: () => void;
  authUser: User | null;
  profile: PlayerProfile | null;
  isDeveloperMode?: boolean;
  cmsConfig?: LiveCmsConfig | null;
  unreleasedCosmetics?: CosmeticItem[];
  devSessionUnlockedIds?: string[];
  initialFighterId: string;
  initialTab?: 'store' | 'inventory';
  initialStoreFilter?: 'fighter' | 'all_skins' | 'aura' | 'bundles' | 'gota_packs';
  onRequireLogin: () => void;
  onUnlockCosmetic: (item: CosmeticItem, payCurrency: CosmeticCurrency) => Promise<void>;
  onPurchaseBundle?: (bundle: CmsBundleDef) => Promise<void>;
  onEquipCosmetic: (category: 'skin' | 'aura', id: string) => Promise<void>;
  onUnequipFighterSkin: (fighterId: string) => Promise<void>;
  onUnequipAura: () => Promise<void>;
}

type ArmoryMode = 'store' | 'inventory';
type StoreFilter = 'fighter' | 'all_skins' | 'aura' | 'bundles' | 'gota_packs';
type InventoryFilter = 'all' | 'fighter' | 'skins' | 'auras';

interface CosmeticThumbProps {
  fighterId: string;
  skinId?: string | null;
  auraId?: string | null;
  isAuraCard: boolean;
  isCrownPremium: boolean;
  animate: boolean;
}

const CosmeticThumbCanvas: React.FC<CosmeticThumbProps> = ({
  fighterId,
  skinId,
  auraId,
  isAuraCard,
  isCrownPremium,
  animate,
}) => {
  const ref = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    drawCosmeticThumbnail(el, fighterId, skinId, auraId, isAuraCard, 0.85);
    if (!animate) return;

    let raf = 0;
    let last = 0;
    const loop = (now: number) => {
      raf = window.requestAnimationFrame(loop);
      if (now - last < 48) return;
      last = now;
      if (ref.current) {
        drawCosmeticThumbnail(ref.current, fighterId, skinId, auraId, isAuraCard, now * 0.001);
      }
    };
    raf = window.requestAnimationFrame(loop);
    return () => window.cancelAnimationFrame(raf);
  }, [fighterId, skinId, auraId, isAuraCard, animate]);

  return (
    <div className="relative w-[52px] h-[52px] shrink-0 rounded-xl border border-white/20 bg-[#090714] overflow-hidden shadow-inner">
      <canvas ref={ref} className="w-[52px] h-[52px] block" />
      {isCrownPremium && (
        <span
          title="Crown Exclusive (Gota Only)"
          className="absolute top-0.5 right-0.5 w-4 h-4 rounded-md bg-gradient-to-br from-amber-300 to-amber-500 text-slate-950 flex items-center justify-center shadow"
        >
          <Crown className="w-2.5 h-2.5" />
        </span>
      )}
    </div>
  );
};

export const ArmoryModal: React.FC<ArmoryModalProps> = ({
  open,
  onClose,
  authUser,
  profile,
  isDeveloperMode = false,
  cmsConfig,
  unreleasedCosmetics = [],
  devSessionUnlockedIds = [],
  initialFighterId,
  initialTab = 'store',
  initialStoreFilter,
  onRequireLogin,
  onUnlockCosmetic,
  onPurchaseBundle,
  onEquipCosmetic,
  onUnequipFighterSkin,
  onUnequipAura,
}) => {
  const [viewMode, setViewMode] = useState<ArmoryMode>(initialTab);
  const [storeFilter, setStoreFilter] = useState<StoreFilter>(initialStoreFilter || 'fighter');
  const [inventoryFilter, setInventoryFilter] = useState<InventoryFilter>('all');
  const [previewFighterId, setPreviewFighterId] = useState(initialFighterId);
  const [previewSkinId, setPreviewSkinId] = useState('');
  const [previewAuraId, setPreviewAuraId] = useState(DEFAULT_AURA_ID);
  const [poseMode, setPoseMode] = useState<'victory' | 'defeat'>('victory');
  const [hoveredCardId, setHoveredCardId] = useState<string | null>(null);
  const [busyKey, setBusyKey] = useState<string | null>(null);
  const [selectedPack, setSelectedPack] = useState<GotaPack | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);
  const stageRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (!open) return;
    setViewMode(initialTab);
    if (initialStoreFilter) setStoreFilter(initialStoreFilter);
  }, [open, initialTab, initialStoreFilter]);

  useEffect(() => {
    if (!open) return;
    setPreviewFighterId(initialFighterId);
    const eqSkin = getEquippedSkinForFighter(profile?.equippedSkinIds, initialFighterId);
    setPreviewSkinId(eqSkin?.id || '');
    setPreviewAuraId(profile?.equippedAuraId || DEFAULT_AURA_ID);
    setSelectedPack(null);
    setFeedback(null);
  }, [open, initialFighterId, profile?.equippedSkinIds, profile?.equippedAuraId]);

  useEffect(() => {
    if (!open) return;
    let raf = 0;
    const render = (now: number) => {
      if (stageRef.current) {
        drawFighterPosePreview(
          stageRef.current,
          previewFighterId,
          poseMode,
          now * 0.001,
          previewSkinId,
          previewAuraId,
        );
      }
      raf = window.requestAnimationFrame(render);
    };
    raf = window.requestAnimationFrame(render);
    return () => window.cancelAnimationFrame(raf);
  }, [open, previewFighterId, poseMode, previewSkinId, previewAuraId]);

  if (!open) return null;

  const isDev = Boolean(profile?.isDeveloper) || Boolean(isDeveloperMode);
  const unlockedSet = new Set([
    ...(profile?.unlockedCosmetics || [DEFAULT_AURA_ID]),
    ...(isDev ? devSessionUnlockedIds : []),
  ]);
  const unlockedPosesSet = new Set(profile?.unlockedPoses || []);
  const equippedSkinIds = profile?.equippedSkinIds || [];
  const equippedAura = profile?.equippedAuraId || DEFAULT_AURA_ID;
  const futiKodi = profile?.futiKodi ?? 0;
  const gota = profile?.gota ?? 0;

  const catalogSkins = isDev ? getAllSkins(true) : SKINS;
  const catalogAuras = isDev ? getAllAuras(true) : AURAS;
  const catalogAll = isDev ? getAllCosmetics(true) : ALL_COSMETICS;
  const activeBundles = (cmsConfig?.bundles || []).filter((b) => b.active);

  // Keep unreleasedCosmetics referenced for prop reactivity cleanly
  void unreleasedCosmetics;

  const fighterSkins = catalogSkins.filter((s) => s.fighterId === previewFighterId);
  const currentEquippedFighterSkin = getEquippedSkinForFighter(equippedSkinIds, previewFighterId);
  const currentEquippedAura = getAuraById(equippedAura);

  // Owned / Inventory lists
  const ownedSkins = catalogSkins.filter((s) => unlockedSet.has(s.id));
  const ownedFighterSkins = ownedSkins.filter((s) => s.fighterId === previewFighterId);
  const ownedAuras = catalogAuras.filter((a) => unlockedSet.has(a.id));
  const ownedAll: CosmeticItem[] = [...ownedSkins, ...ownedAuras];

  const items: CosmeticItem[] =
    viewMode === 'inventory'
      ? inventoryFilter === 'all'
        ? ownedAll
        : inventoryFilter === 'fighter'
          ? ownedFighterSkins
          : inventoryFilter === 'skins'
            ? ownedSkins
            : ownedAuras
      : storeFilter === 'fighter'
        ? fighterSkins
        : storeFilter === 'all_skins'
          ? catalogSkins
          : storeFilter === 'aura'
            ? catalogAuras
            : [];

  const activeFighter = getCfgById(previewFighterId);
  const activeSkin = getSkinById(previewSkinId);
  const activeAura = getAuraById(previewAuraId);

  const handleFighterDropdownChange = (nextFighterId: string) => {
    setPreviewFighterId(nextFighterId);
    const eqSkin = getEquippedSkinForFighter(equippedSkinIds, nextFighterId);
    setPreviewSkinId(eqSkin?.id || '');
    setFeedback(null);
  };

  const handleSelectPreview = (item: CosmeticItem) => {
    setSelectedPack(null);
    setFeedback(null);
    if (item.category === 'skin') {
      setPreviewFighterId(item.fighterId);
      setPreviewSkinId(item.id);
    } else {
      setPreviewAuraId(item.id);
    }
  };

  const handleEquipItem = async (item: CosmeticItem) => {
    handleSelectPreview(item);
    setBusyKey(item.id);
    try {
      await onEquipCosmetic(item.category, item.id);
      setFeedback(`Equipped ${item.name}!`);
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'Could not equip item.');
    } finally {
      setBusyKey(null);
    }
  };

  const handleUnequipItem = async (item: CosmeticItem) => {
    setFeedback(null);
    setBusyKey(item.id);
    try {
      if (item.category === 'skin') {
        await onUnequipFighterSkin(item.fighterId);
        if (previewFighterId === item.fighterId) {
          setPreviewSkinId('');
        }
        setFeedback(`Unequipped ${item.name} — Classic look active.`);
      } else {
        await onUnequipAura();
        setPreviewAuraId(DEFAULT_AURA_ID);
        setFeedback(`Unequipped ${item.name} — Classic aura restored.`);
      }
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'Could not unequip item.');
    } finally {
      setBusyKey(null);
    }
  };

  const handleUnlockWithCurrency = async (item: CosmeticItem, payCurrency: CosmeticCurrency) => {
    handleSelectPreview(item);
    const eff = getEffectiveCosmeticPricing(item, cmsConfig);

    if (payCurrency === 'futi_kodi') {
      if (eff.fkPrice === null) {
        setFeedback('Premium Crown cosmetic — unlock with Gota!');
        return;
      }
      if (!isDev && futiKodi < eff.fkPrice) {
        setFeedback(`Need ${eff.fkPrice - futiKodi} more Futi Kodi (+80 Win / +35 Play) or unlock for ${eff.gotaPrice} Gota!`);
        return;
      }
    } else if (!isDev && gota < eff.gotaPrice) {
      setFeedback(`Need ${eff.gotaPrice - gota} more Gota — grab a ₹15+ Gota pack!`);
      setViewMode('store');
      setStoreFilter('gota_packs');
      return;
    }

    const lockKey = `${item.id}_${payCurrency}`;
    setBusyKey(lockKey);
    try {
      await onUnlockCosmetic(item, payCurrency);
      setFeedback(`Unlocked & equipped ${item.name}!`);
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'Could not unlock cosmetic.');
    } finally {
      setBusyKey(null);
    }
  };

  const handleBuyBundle = async (bundle: CmsBundleDef) => {
    if (!onPurchaseBundle) return;
    if (!isDev && gota < bundle.gotaPrice) {
      setFeedback(`Need ${bundle.gotaPrice - gota} more Gota — grab a ₹15+ Gota pack!`);
      setStoreFilter('gota_packs');
      return;
    }
    setBusyKey(`bundle_${bundle.id}`);
    setFeedback(null);
    try {
      await onPurchaseBundle(bundle);
      setFeedback(`Unlocked Bundle: ${bundle.title}!`);
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'Could not unlock bundle.');
    } finally {
      setBusyKey(null);
    }
  };

  const handleUnequipCurrentSkin = async () => {
    setPreviewSkinId('');
    setBusyKey('stage_unequip_skin');
    try {
      await onUnequipFighterSkin(previewFighterId);
      setFeedback(`${activeFighter.name} unequipped to Classic look.`);
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'Could not unequip skin.');
    } finally {
      setBusyKey(null);
    }
  };

  const handleUnequipCurrentAura = async () => {
    setPreviewAuraId(DEFAULT_AURA_ID);
    setBusyKey('stage_unequip_aura');
    try {
      await onUnequipAura();
      setFeedback('Special aura unequipped — Asli Chamak active.');
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'Could not unequip aura.');
    } finally {
      setBusyKey(null);
    }
  };

  const previewSkinIsOwned = Boolean(previewSkinId && unlockedSet.has(previewSkinId));
  const previewSkinIsEquipped = Boolean(previewSkinId && equippedSkinIds.includes(previewSkinId));
  const previewAuraIsOwned = unlockedSet.has(previewAuraId);
  const previewAuraIsEquipped = equippedAura === previewAuraId;

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-1.5 sm:p-3 bg-[#07060d]/90 backdrop-blur-md">
      <div className="w-full max-w-5xl h-[min(565px,calc(100dvh-0.75rem))] flex flex-col rounded-2xl border border-amber-400/40 bg-[#100d1d]/97 shadow-2xl overflow-hidden">
        {/* Header with Store / Inventory Switcher */}
        <div className="shrink-0 flex items-center justify-between gap-2 px-3 sm:px-4 py-2 border-b border-amber-400/15 bg-black/35">
          <div className="min-w-0 flex items-center gap-2 sm:gap-3">
            <div className="flex items-center gap-1 p-0.5 rounded-xl bg-black/55 border border-white/12 shrink-0">
              <button
                type="button"
                onClick={() => {
                  setViewMode('store');
                  setSelectedPack(null);
                  setFeedback(null);
                }}
                className={`px-2.5 sm:px-3 py-1 rounded-lg text-[11px] sm:text-xs font-extrabold flex items-center gap-1.5 transition cursor-pointer ${
                  viewMode === 'store'
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'text-amber-100/75 hover:text-amber-100'
                }`}
              >
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>Store</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setViewMode('inventory');
                  setSelectedPack(null);
                  setFeedback(null);
                }}
                className={`px-2.5 sm:px-3 py-1 rounded-lg text-[11px] sm:text-xs font-extrabold flex items-center gap-1.5 transition cursor-pointer ${
                  viewMode === 'inventory'
                    ? 'bg-emerald-400 text-slate-950 shadow-sm'
                    : 'text-amber-100/75 hover:text-amber-100'
                }`}
              >
                <Backpack className="w-3.5 h-3.5" />
                <span>Inventory ({ownedAll.length})</span>
              </button>
            </div>

            <span className="hidden md:inline-flex items-center gap-1 text-[10px] text-emerald-300 font-semibold border-l border-white/15 pl-2.5 whitespace-nowrap">
              <ShieldCheck className="w-3.5 h-3.5" />
              Cosmetic Only · Equal Power
            </span>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {isDev && (
              <span className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-gradient-to-r from-amber-400 to-yellow-300 text-slate-950 text-[10px] font-black uppercase tracking-wider">
                <Code2 className="w-3 h-3" />
                DEV ∞
              </span>
            )}
            <div
              title="Free Currency — Earned every match"
              className="px-2.5 py-1 rounded-lg border border-cyan-400/35 bg-cyan-500/12 flex items-center gap-1"
            >
              <Coins className="w-3.5 h-3.5 text-cyan-300" />
              <span className="font-num text-xs font-extrabold text-cyan-100 tabular-nums">
                {isDev ? '∞' : futiKodi}
              </span>
              <span className="text-[10px] font-semibold text-cyan-200/80 hidden sm:inline">Futi Kodi</span>
            </div>
            <button
              type="button"
              onClick={() => {
                setViewMode('store');
                setStoreFilter('gota_packs');
              }}
              title="Paid Currency — Buy Gota Packs (₹15+)"
              className="px-2.5 py-1 rounded-lg border border-amber-400/45 bg-gradient-to-r from-amber-500/20 to-rose-500/20 flex items-center gap-1 hover:border-amber-300 cursor-pointer"
            >
              <Gem className="w-3.5 h-3.5 text-amber-300" />
              <span className="font-num text-xs font-extrabold text-amber-100 tabular-nums">
                {isDev ? '∞' : gota}
              </span>
              <span className="text-[10px] font-semibold text-amber-200/90 hidden sm:inline">Gota</span>
              {!isDev && <span className="text-[10px] font-black text-amber-300 ml-0.5">+</span>}
            </button>
            {!authUser && (
              <button
                type="button"
                onClick={onRequireLogin}
                className="px-2 py-1 rounded-lg border border-amber-400/45 bg-amber-500/15 text-amber-200 text-[10px] font-bold flex items-center gap-1 hover:bg-amber-500/25 cursor-pointer whitespace-nowrap"
              >
                <LogIn className="w-3 h-3" />
                <span className="hidden md:inline">Cloud Sync</span>
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              aria-label="Close Store & Inventory"
              className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg border border-white/15 bg-white/5 text-amber-200 flex items-center justify-center hover:border-amber-300 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Bounded 2-Column Landscape Body */}
        <div className="flex-1 min-h-0 grid grid-cols-[210px_1fr] sm:grid-cols-[250px_1fr] lg:grid-cols-[290px_1fr] overflow-hidden">
          {/* Left Live Try-On & Loadout Stage */}
          <div className="min-h-0 flex flex-col justify-between p-2 sm:p-3 gap-1.5 border-r border-white/10 bg-[#0b0816]/85 overflow-hidden">
            <div className="shrink-0 flex items-center justify-between gap-1.5">
              <select
                value={previewFighterId}
                data-ui-sfx="select"
                onChange={(e) => handleFighterDropdownChange(e.target.value)}
                aria-label="Preview Fighter"
                className="flex-1 min-w-0 px-2 py-1 rounded-lg bg-[#151028] border border-amber-400/30 text-[11px] font-bold text-amber-100 focus:outline-none focus:border-amber-300"
              >
                {FIGHTERS.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.name}
                  </option>
                ))}
              </select>
              <div className="flex items-center gap-0.5 p-0.5 rounded-lg bg-black/40 border border-white/10 shrink-0">
                <button
                  type="button"
                  onClick={() => setPoseMode('victory')}
                  className={`px-1.5 py-0.5 rounded text-[10px] font-bold cursor-pointer ${
                    poseMode === 'victory' ? 'bg-amber-500 text-slate-950' : 'text-amber-100/70'
                  }`}
                >
                  Win
                </button>
                <button
                  type="button"
                  onClick={() => setPoseMode('defeat')}
                  className={`px-1.5 py-0.5 rounded text-[10px] font-bold cursor-pointer ${
                    poseMode === 'defeat' ? 'bg-rose-500 text-white' : 'text-amber-100/70'
                  }`}
                >
                  Defeat
                </button>
              </div>
            </div>

            <div className="relative flex-1 min-h-0 rounded-xl border border-white/10 bg-[#080612] overflow-hidden">
              <canvas ref={stageRef} width={300} height={240} className="w-full h-full object-contain" />
              <div className="absolute bottom-1.5 left-2 right-2 flex items-center justify-between gap-1 text-[9.5px] text-amber-100/85 pointer-events-none bg-black/50 px-1.5 py-0.5 rounded">
                <span className="truncate font-bold">{activeFighter.name}</span>
                <span className="truncate text-amber-300">
                  {activeSkin?.name || 'Classic'} · {activeAura.name}
                </span>
              </div>
            </div>

            {/* Active Equipped Loadout Quick Equip / Unequip Controls */}
            <div className="shrink-0 space-y-1 bg-black/35 border border-white/10 rounded-xl p-1.5 text-[10px]">
              <div className="flex items-center justify-between gap-1.5">
                <div className="min-w-0 truncate text-amber-100/80">
                  <span className="text-amber-300/75 font-bold">Skin:</span>{' '}
                  <span className="font-semibold text-amber-100">
                    {currentEquippedFighterSkin ? currentEquippedFighterSkin.name : 'Classic (Default)'}
                  </span>
                </div>
                {previewSkinIsOwned && !previewSkinIsEquipped && activeSkin ? (
                  <button
                    type="button"
                    data-ui-sfx={authUser ? 'unlock' : 'locked'}
                    disabled={busyKey === activeSkin.id}
                    onClick={() => void handleEquipItem(activeSkin)}
                    className="shrink-0 px-2 py-0.5 rounded bg-amber-500 text-slate-950 font-extrabold text-[9.5px] hover:brightness-110 cursor-pointer"
                  >
                    Equip
                  </button>
                ) : currentEquippedFighterSkin ? (
                  <button
                    type="button"
                    disabled={busyKey === 'stage_unequip_skin'}
                    onClick={() => void handleUnequipCurrentSkin()}
                    className="shrink-0 px-2 py-0.5 rounded border border-rose-400/50 bg-rose-500/15 text-rose-200 font-bold text-[9.5px] hover:bg-rose-500/25 cursor-pointer"
                  >
                    Unequip
                  </button>
                ) : null}
              </div>

              <div className="flex items-center justify-between gap-1.5 pt-1 border-t border-white/8">
                <div className="min-w-0 truncate text-amber-100/80">
                  <span className="text-cyan-300/80 font-bold">Aura:</span>{' '}
                  <span className="font-semibold text-amber-100">{currentEquippedAura.name}</span>
                </div>
                {previewAuraIsOwned && !previewAuraIsEquipped ? (
                  <button
                    type="button"
                    data-ui-sfx={authUser ? 'unlock' : 'locked'}
                    disabled={busyKey === activeAura.id}
                    onClick={() => void handleEquipItem(activeAura)}
                    className="shrink-0 px-2 py-0.5 rounded bg-amber-500 text-slate-950 font-extrabold text-[9.5px] hover:brightness-110 cursor-pointer"
                  >
                    Equip
                  </button>
                ) : currentEquippedAura.id !== DEFAULT_AURA_ID ? (
                  <button
                    type="button"
                    disabled={busyKey === 'stage_unequip_aura'}
                    onClick={() => void handleUnequipCurrentAura()}
                    className="shrink-0 px-2 py-0.5 rounded border border-rose-400/50 bg-rose-500/15 text-rose-200 font-bold text-[9.5px] hover:bg-rose-500/25 cursor-pointer"
                  >
                    Unequip
                  </button>
                ) : null}
              </div>
            </div>

            {/* Feedback / Reward Line */}
            <div className="shrink-0 flex items-center justify-between gap-1.5 text-[10px] text-amber-100/75 leading-tight px-0.5">
              <span className="truncate">
                {feedback ? (
                  <span className="text-emerald-300 font-semibold">{feedback}</span>
                ) : (
                  <>
                    Match: <strong className="text-cyan-300">+80 Win</strong> ·{' '}
                    <strong className="text-cyan-300">+35 Play</strong>
                  </>
                )}
              </span>
            </div>
          </div>

          {/* Right Panel: Inventory OR Store */}
          <div className="flex flex-col min-h-0 p-2 sm:p-3 overflow-hidden">
            {/* Compact Filter Tabs */}
            <div className="shrink-0 flex items-center justify-between gap-2 mb-2">
              {viewMode === 'inventory' ? (
                <div className="flex items-center gap-1 p-0.5 rounded-xl bg-black/45 border border-white/10 overflow-x-auto">
                  {(
                    [
                      { id: 'all', label: `All Owned (${ownedAll.length})` },
                      { id: 'fighter', label: `For Fighter (${ownedFighterSkins.length})` },
                      { id: 'skins', label: `Skins (${ownedSkins.length})` },
                      { id: 'auras', label: `Auras (${ownedAuras.length})` },
                    ] as const
                  ).map((tab) => (
                    <button
                      key={tab.id}
                      type="button"
                      onClick={() => setInventoryFilter(tab.id)}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer whitespace-nowrap shrink-0 ${
                        inventoryFilter === tab.id
                          ? 'bg-emerald-400 text-slate-950'
                          : 'text-amber-100/75 hover:text-amber-100'
                      }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>
              ) : (
                <div className="flex items-center gap-1 p-0.5 rounded-xl bg-black/45 border border-white/10 overflow-x-auto">
                  {(
                    [
                      { id: 'fighter', label: `For Fighter (${fighterSkins.length})` },
                      { id: 'all_skins', label: `All Skins (${catalogSkins.length})` },
                      { id: 'aura', label: `Auras (${catalogAuras.length})` },
                      { id: 'bundles', label: `Bundles (${activeBundles.length})` },
                      { id: 'gota_packs', label: 'Buy Gota (₹15+)' },
                    ] as const
                  ).map((tab) => (
                    <button
                      key={tab.id}
                      type="button"
                      onClick={() => {
                        setStoreFilter(tab.id);
                        setSelectedPack(null);
                      }}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer whitespace-nowrap shrink-0 ${
                        storeFilter === tab.id
                          ? tab.id === 'gota_packs'
                            ? 'bg-gradient-to-r from-amber-400 to-rose-500 text-slate-950'
                            : tab.id === 'bundles'
                              ? 'bg-gradient-to-r from-emerald-400 to-cyan-400 text-slate-950'
                              : 'bg-amber-500 text-slate-950'
                          : 'text-amber-100/75 hover:text-amber-100'
                      }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>
              )}

              <div className="hidden lg:block text-[10px] text-amber-200/70 tabular-nums shrink-0">
                Owned {unlockedSet.size}/{catalogAll.length}
              </div>
            </div>

            {viewMode === 'inventory' && !authUser && (
              <div className="shrink-0 mb-2 px-3 py-2 rounded-xl border border-amber-400/35 bg-amber-500/10 flex items-center justify-between gap-2 text-[11px]">
                <span className="text-amber-100/85">
                  Sign in with Gmail to save &amp; equip unlocked skins and auras across devices.
                </span>
                <button
                  type="button"
                  onClick={onRequireLogin}
                  className="shrink-0 px-2.5 py-1 rounded-lg bg-amber-500 text-slate-950 font-extrabold text-[10.5px] cursor-pointer"
                >
                  Login
                </button>
              </div>
            )}

            {/* Scrollable Body Area */}
            {viewMode === 'store' && storeFilter === 'bundles' ? (
              <div className="flex-1 min-h-0 overflow-y-auto roster-scroll pr-1 space-y-2.5">
                {activeBundles.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center p-6 rounded-xl border border-white/10 bg-black/25">
                    <Package className="w-9 h-9 text-amber-300/60 mb-2" />
                    <div className="font-display-in text-lg text-amber-100">No Active Bundles Right Now</div>
                    <p className="text-xs text-amber-100/65 max-w-sm mt-1">
                      Check back soon for limited-time Akhara festival bundles, or browse individual Fighter Skins &amp; Auras.
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                    {activeBundles.map((bundle) => {
                      const decodedItems = bundle.itemIds
                        .map((tok) => decodeBundleToken(tok))
                        .filter((d): d is NonNullable<typeof d> => d !== null);
                      const regularGota = computeBundleRegularGotaValue(bundle);
                      const allOwned =
                        decodedItems.length > 0 &&
                        decodedItems.every((d) =>
                          d.kind === 'cosmetic'
                            ? unlockedSet.has(d.cosmetic.id)
                            : unlockedPosesSet.has(d.pose.id),
                        );
                      const canAfford = isDev || gota >= bundle.gotaPrice;
                      const savingPct =
                        regularGota > bundle.gotaPrice
                          ? Math.round(((regularGota - bundle.gotaPrice) / regularGota) * 100)
                          : 0;

                      return (
                        <div
                          key={bundle.id}
                          className="rounded-2xl border border-emerald-400/45 bg-gradient-to-br from-[#141126] via-[#101829] to-[#1a1024] p-3 flex flex-col justify-between gap-2.5 shadow-lg"
                        >
                          <div className="space-y-1.5">
                            <div className="flex items-start justify-between gap-2">
                              <div className="min-w-0">
                                <div className="font-display-in text-base text-amber-100 leading-tight truncate">
                                  {bundle.title}
                                </div>
                                <p className="text-[10.5px] text-amber-100/70 line-clamp-1">{bundle.subtitle}</p>
                              </div>
                              {(bundle.badgeText || savingPct > 0) && (
                                <span className="px-2 py-0.5 rounded-md bg-gradient-to-r from-amber-400 to-rose-500 text-slate-950 text-[9px] font-black uppercase tracking-wider shrink-0">
                                  {bundle.badgeText || `SAVE ${savingPct}%`}
                                </span>
                              )}
                            </div>

                            <div className="flex flex-wrap gap-1">
                              {decodedItems.map((entry, idx) => {
                                const itemOwned =
                                  entry.kind === 'cosmetic'
                                    ? unlockedSet.has(entry.cosmetic.id)
                                    : unlockedPosesSet.has(entry.pose.id);
                                return (
                                  <span
                                    key={`${bundle.id}_item_${idx}`}
                                    className={`px-1.5 py-0.5 rounded-md border text-[9.5px] font-bold flex items-center gap-1 ${
                                      itemOwned
                                        ? 'border-emerald-400/40 bg-emerald-500/15 text-emerald-200'
                                        : 'border-white/15 bg-black/40 text-amber-100/90'
                                    }`}
                                  >
                                    {itemOwned && <Check className="w-2.5 h-2.5 text-emerald-300" />}
                                    {entry.kind === 'cosmetic' ? entry.cosmetic.name : `${entry.pose.poseName} (Pose)`}
                                  </span>
                                );
                              })}
                            </div>
                          </div>

                          <div className="flex items-center justify-between gap-2 pt-2 border-t border-white/10">
                            <div className="flex items-baseline gap-1.5 tabular-nums">
                              <span className="font-num text-base font-black text-amber-300 flex items-center gap-1">
                                <Gem className="w-3.5 h-3.5" />
                                {bundle.gotaPrice} Gota
                              </span>
                              {regularGota > bundle.gotaPrice && (
                                <span className="text-[10.5px] text-slate-400 line-through">
                                  {regularGota} Gota
                                </span>
                              )}
                            </div>

                            {allOwned ? (
                              <span className="px-2.5 py-1 rounded-lg bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-[10.5px] font-extrabold flex items-center gap-1">
                                <Check className="w-3 h-3" />
                                All Owned
                              </span>
                            ) : (
                              <button
                                type="button"
                                data-ui-sfx={canAfford ? 'unlock' : 'locked'}
                                disabled={busyKey === `bundle_${bundle.id}`}
                                onClick={() => void handleBuyBundle(bundle)}
                                className={`px-3 py-1.5 rounded-lg text-[10.5px] font-black flex items-center gap-1 cursor-pointer transition ${
                                  canAfford
                                    ? 'bg-gradient-to-r from-emerald-400 to-cyan-400 text-slate-950 hover:brightness-110'
                                    : 'bg-amber-500/15 text-amber-200 border border-amber-400/35 hover:bg-amber-500/25'
                                }`}
                              >
                                <Package className="w-3.5 h-3.5" />
                                {busyKey === `bundle_${bundle.id}`
                                  ? 'Unlocking...'
                                  : canAfford
                                    ? `Unlock Bundle`
                                    : 'Get Gota'}
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            ) : viewMode === 'store' && storeFilter === 'gota_packs' ? (
              <div className="flex-1 min-h-0 overflow-y-auto roster-scroll pr-1 space-y-2.5">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  {GOTA_PACKS.map((pack) => (
                    <div
                      key={pack.id}
                      onClick={() => setSelectedPack(pack)}
                      className={`relative rounded-xl border p-3 flex flex-col justify-between gap-2.5 transition cursor-pointer ${
                        pack.popular
                          ? 'border-amber-400 bg-gradient-to-b from-amber-500/18 to-rose-500/12 shadow-[0_0_18px_rgba(245,158,11,0.2)]'
                          : 'border-white/15 bg-[#151126] hover:border-amber-300/60'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-1">
                        <span className="text-[10px] font-bold text-amber-300/90 uppercase tracking-wide">
                          {pack.name}
                        </span>
                        {pack.popular && (
                          <span className="px-1.5 py-0.5 rounded bg-amber-400 text-slate-950 text-[9px] font-black uppercase tracking-wider shrink-0">
                            Best Value
                          </span>
                        )}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <Gem className="w-5 h-5 text-amber-300 shrink-0" />
                          <span className="font-num text-2xl font-black text-amber-100 tabular-nums">
                            {pack.gotaAmount}
                          </span>
                          <span className="text-xs font-bold text-amber-200">Gota</span>
                        </div>
                        <div className="text-[11px] text-emerald-300 font-semibold mt-1">{pack.bonusText}</div>
                      </div>
                      <button
                        type="button"
                        data-ui-sfx="unlock"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedPack(pack);
                          window.open(pack.paymentUrl, '_blank', 'noopener,noreferrer');
                        }}
                        className="w-full py-2 rounded-lg bg-gradient-to-r from-amber-400 to-rose-500 text-slate-950 text-xs font-black tracking-wide hover:brightness-110 cursor-pointer"
                      >
                        Buy ₹{pack.inrPrice}
                      </button>
                    </div>
                  ))}
                </div>

                {selectedPack ? (
                  <div className="p-2.5 rounded-xl border border-amber-400/45 bg-amber-500/10 text-[11px] text-amber-100 space-y-1.5">
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <div className="font-bold text-amber-300 flex items-center gap-1.5">
                        <Crown className="w-3.5 h-3.5 shrink-0" />
                        <span>
                          {selectedPack.name}: ₹{selectedPack.inrPrice} → {selectedPack.gotaAmount} Gota ({selectedPack.bonusText})
                        </span>
                      </div>
                      <a
                        href={selectedPack.paymentUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-emerald-400 to-cyan-400 text-slate-950 text-[10.5px] font-black uppercase tracking-wider hover:brightness-110 shrink-0"
                      >
                        Open Razorpay Checkout
                      </a>
                    </div>
                    <p className="text-amber-100/80 leading-snug">
                      Secure Razorpay checkout opened in a new tab. Use the button above if your browser blocked the popup, or share your Player ID after payment for instant Gota delivery.
                    </p>
                  </div>
                ) : (
                  <div className="p-2.5 rounded-xl border border-white/10 bg-black/30 text-[11px] text-amber-100/75 leading-snug">
                    <strong className="text-amber-300">2 Currencies · Grind or Fast-Track:</strong> Earn free{' '}
                    <span className="text-cyan-300 font-bold">Futi Kodi</span> (+80 Win / +35 Play) to unlock Standard &amp; Mid-Tier skins (480–680 FK) or auras (550 FK), OR grab{' '}
                    <span className="text-amber-300 font-bold">Gota</span> packs starting at ₹15 for 50 Gota to unlock ANY skin (15–45 Gota), aura (15–35 Gota), or victory pose (12–18 Gota) instantly!
                  </div>
                )}
              </div>
            ) : items.length === 0 ? (
              <div className="flex-1 min-h-0 flex flex-col items-center justify-center text-center p-6 rounded-xl border border-white/10 bg-black/25">
                <Backpack className="w-9 h-9 text-amber-300/60 mb-2" />
                <div className="font-display-in text-lg text-amber-100">
                  {inventoryFilter === 'fighter'
                    ? `No unlocked skins for ${activeFighter.name} yet`
                    : 'Your Skins Inventory is Empty'}
                </div>
                <p className="text-xs text-amber-100/65 max-w-sm mt-1">
                  Unlock cultural skins &amp; festive auras in the Store using match Futi Kodi or Gota, then equip or unequip them anytime right here.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setViewMode('store');
                    setStoreFilter(inventoryFilter === 'auras' ? 'aura' : 'fighter');
                  }}
                  className="mt-4 px-4 py-2 rounded-xl bg-amber-500 text-slate-950 text-xs font-extrabold flex items-center gap-1.5 hover:brightness-110 cursor-pointer"
                >
                  <ShoppingBag className="w-3.5 h-3.5" />
                  Browse Store
                </button>
              </div>
            ) : (
              <div className="flex-1 min-h-0 overflow-y-auto roster-scroll pr-1 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 content-start">
                {items.map((item) => {
                  const isUnlocked = unlockedSet.has(item.id);
                  const isEquipped =
                    (item.category === 'skin' && equippedSkinIds.includes(item.id)) ||
                    (item.category === 'aura' && equippedAura === item.id);
                  const isPreviewing =
                    (item.category === 'skin' && previewSkinId === item.id) ||
                    (item.category === 'aura' && previewAuraId === item.id);
                  const ownerFighter = item.category === 'skin' ? getCfgById(item.fighterId).name : 'All 10 Warriors';
                  const effPricing = getEffectiveCosmeticPricing(item, cmsConfig);
                  const isCrownPremium = effPricing.fkPrice === null;
                  const canAffordFk = effPricing.fkPrice !== null && (isDev || futiKodi >= effPricing.fkPrice);
                  const canAffordGota = isDev || gota >= effPricing.gotaPrice;
                  const isDefaultBaseAura = item.category === 'aura' && item.id === DEFAULT_AURA_ID;
                  const isDevProto = isDevUnreleasedCosmeticId(item.id);

                  const thumbFighterId = item.category === 'skin' ? item.fighterId : previewFighterId;
                  const thumbSkinId = item.category === 'skin' ? item.id : previewSkinId;
                  const thumbAuraId = item.category === 'aura' ? item.id : previewAuraId;

                  return (
                    <div
                      key={item.id}
                      role="button"
                      tabIndex={0}
                      data-ui-sfx="select"
                      onClick={() => handleSelectPreview(item)}
                      onMouseEnter={() => setHoveredCardId(item.id)}
                      onMouseLeave={() => setHoveredCardId((cur) => (cur === item.id ? null : cur))}
                      className={`rounded-xl border p-2 flex flex-col justify-between gap-2 transition cursor-pointer ${
                        isEquipped
                          ? 'border-emerald-400/70 bg-emerald-500/12'
                          : isPreviewing
                            ? 'border-amber-400 bg-amber-500/12'
                            : 'border-white/10 bg-[#141024]/90 hover:border-amber-300/45'
                      }`}
                    >
                      <div className="flex items-start gap-2">
                        <CosmeticThumbCanvas
                          fighterId={thumbFighterId}
                          skinId={thumbSkinId}
                          auraId={thumbAuraId}
                          isAuraCard={item.category === 'aura'}
                          isCrownPremium={isCrownPremium}
                          animate={hoveredCardId === item.id || isPreviewing}
                        />
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center justify-between gap-1">
                            <div className="text-[9px] font-bold uppercase tracking-wider truncate text-amber-300/85">
                              {ownerFighter}
                            </div>
                            <div className="flex items-center gap-1 shrink-0">
                              {isDevProto && (
                                <span className="px-1 py-0.2 rounded bg-cyan-400 text-slate-950 text-[8px] font-black uppercase">
                                  DEV TEST
                                </span>
                              )}
                              {effPricing.flashLabel && (
                                <span className="px-1 py-0.2 rounded bg-rose-500 text-white text-[8px] font-black uppercase">
                                  {effPricing.flashLabel}
                                </span>
                              )}
                              <button
                                type="button"
                                data-ui-sfx="select"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleSelectPreview(item);
                                }}
                                title="Try On Preview"
                                className="p-0.5 rounded border border-white/12 bg-white/5 text-amber-200 hover:border-amber-300 cursor-pointer shrink-0"
                              >
                                <Eye className="w-3 h-3" />
                              </button>
                            </div>
                          </div>
                          <div className="font-display-in text-[13px] sm:text-sm text-amber-100 truncate leading-tight mt-0.5">
                            {item.name}
                          </div>
                          <p className="text-[9.5px] text-amber-100/65 line-clamp-1">{item.subtitle}</p>
                        </div>
                      </div>

                      <div className="flex items-center justify-between gap-1.5 pt-1.5 border-t border-white/10">
                        {isUnlocked ? (
                          <>
                            <span
                              className={`text-[10.5px] font-extrabold flex items-center gap-1 ${
                                isEquipped ? 'text-emerald-300' : 'text-amber-200/85'
                              }`}
                            >
                              {isEquipped ? (
                                <>
                                  <Check className="w-3 h-3" />
                                  Equipped
                                </>
                              ) : isDefaultBaseAura ? (
                                'Base Aura'
                              ) : (
                                'Owned'
                              )}
                            </span>
                            {isEquipped ? (
                              isDefaultBaseAura ? (
                                <span className="px-2 py-1 rounded-lg text-[10px] font-bold bg-emerald-500/18 text-emerald-300 border border-emerald-400/35 whitespace-nowrap">
                                  Default Active
                                </span>
                              ) : (
                                <button
                                  type="button"
                                  disabled={busyKey === item.id}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    void handleUnequipItem(item);
                                  }}
                                  className="px-2.5 py-1 rounded-lg text-[10.5px] font-extrabold border border-rose-400/55 bg-rose-500/18 text-rose-200 hover:bg-rose-500/30 transition whitespace-nowrap shrink-0 cursor-pointer"
                                >
                                  {busyKey === item.id ? 'Saving...' : 'Unequip'}
                                </button>
                              )
                            ) : (
                              <button
                                type="button"
                                data-ui-sfx={authUser ? 'unlock' : 'locked'}
                                disabled={busyKey === item.id}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  void handleEquipItem(item);
                                }}
                                className="px-2.5 py-1 rounded-lg text-[10.5px] font-extrabold bg-amber-500 text-slate-950 hover:brightness-110 transition whitespace-nowrap shrink-0 cursor-pointer"
                              >
                                {busyKey === item.id ? 'Saving...' : 'Equip'}
                              </button>
                            )}
                          </>
                        ) : effPricing.fkPrice !== null ? (
                          /* Dual-Currency Unlock: Standard & Mid-Tier items (FK OR Gota) */
                          <div className="w-full flex items-center gap-1">
                            <button
                              type="button"
                              data-ui-sfx={authUser && canAffordFk ? 'unlock' : 'locked'}
                              disabled={busyKey === `${item.id}_futi_kodi` || busyKey === `${item.id}_gota`}
                              onClick={(e) => {
                                e.stopPropagation();
                                void handleUnlockWithCurrency(item, 'futi_kodi');
                              }}
                              title={`Unlock using ${effPricing.fkPrice} Futi Kodi`}
                              className={`flex-1 py-1 px-1.5 rounded-lg text-[10px] font-extrabold tabular-nums transition flex items-center justify-center gap-1 whitespace-nowrap cursor-pointer ${
                                canAffordFk
                                  ? 'bg-cyan-400 text-slate-950 hover:brightness-110'
                                  : 'bg-cyan-500/12 text-cyan-200/80 border border-cyan-400/30 hover:bg-cyan-500/20'
                              }`}
                            >
                              <Coins className="w-3 h-3 shrink-0" />
                              {busyKey === `${item.id}_futi_kodi` ? '...' : `${effPricing.fkPrice} FK`}
                            </button>
                            <span className="text-[9px] font-bold text-slate-400 uppercase px-0.5">or</span>
                            <button
                              type="button"
                              data-ui-sfx={authUser && canAffordGota ? 'unlock' : 'locked'}
                              disabled={busyKey === `${item.id}_futi_kodi` || busyKey === `${item.id}_gota`}
                              onClick={(e) => {
                                e.stopPropagation();
                                void handleUnlockWithCurrency(item, 'gota');
                              }}
                              title={`Unlock using ${effPricing.gotaPrice} Gota`}
                              className={`flex-1 py-1 px-1.5 rounded-lg text-[10px] font-extrabold tabular-nums transition flex items-center justify-center gap-1 whitespace-nowrap cursor-pointer ${
                                canAffordGota
                                  ? 'bg-gradient-to-r from-amber-400 to-rose-500 text-slate-950 hover:brightness-110'
                                  : 'bg-amber-500/15 text-amber-200 border border-amber-400/35 hover:bg-amber-500/25'
                              }`}
                            >
                              <Gem className="w-3 h-3 shrink-0" />
                              {busyKey === `${item.id}_gota` ? '...' : `${effPricing.gotaPrice} Gota`}
                            </button>
                          </div>
                        ) : (
                          /* Premium Crown Item: Gota Only */
                          <>
                            <span className="text-[10.5px] font-extrabold text-amber-300 tabular-nums flex items-center gap-1">
                              <Gem className="w-3 h-3" />
                              {effPricing.gotaPrice} Gota
                              {effPricing.isDiscounted && (
                                <span className="text-[9px] text-slate-400 line-through">
                                  {effPricing.baseGotaPrice}
                                </span>
                              )}
                            </span>
                            <button
                              type="button"
                              data-ui-sfx={authUser && canAffordGota ? 'unlock' : 'locked'}
                              disabled={busyKey === `${item.id}_gota`}
                              onClick={(e) => {
                                e.stopPropagation();
                                void handleUnlockWithCurrency(item, 'gota');
                              }}
                              className={`px-2.5 py-1 rounded-lg text-[10.5px] font-extrabold transition flex items-center gap-1 whitespace-nowrap shrink-0 cursor-pointer ${
                                canAffordGota
                                  ? 'bg-gradient-to-r from-amber-400 to-rose-500 text-slate-950 hover:brightness-110'
                                  : 'bg-amber-500/15 text-amber-200 border border-amber-400/35 hover:bg-amber-500/25'
                              }`}
                            >
                              <Lock className="w-3 h-3" />
                              {busyKey === `${item.id}_gota`
                                ? 'Saving...'
                                : canAffordGota
                                  ? `Unlock ${effPricing.gotaPrice}`
                                  : 'Get Gota'}
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
