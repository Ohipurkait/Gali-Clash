import React, { useEffect, useMemo, useRef } from 'react';
import { Coins, Flame, History, Swords, Trash2, Trophy, X } from 'lucide-react';
import { ARENAS, getCfgById } from '../game/data';
import { drawCharFace } from '../game/engine';
import { FighterConfig } from '../game/types';
import { computeMatchHistoryStats, MatchHistoryEntry } from '../services/matchHistory';

function MiniFighterFace({ cfg }: { cfg: FighterConfig }) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  useEffect(() => {
    if (canvasRef.current) drawCharFace(canvasRef.current, cfg);
  }, [cfg]);
  return <canvas ref={canvasRef} className="w-9 h-9 rounded-full border border-white/15 shrink-0 bg-[#090712]" />;
}

function formatMatchTimestamp(ts: number): string {
  const diffSec = Math.max(0, Math.floor((Date.now() - ts) / 1000));
  if (diffSec < 60) return 'Just now';
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h ago`;
  const d = new Date(ts);
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

interface MatchHistoryModalProps {
  open: boolean;
  entries: MatchHistoryEntry[];
  onClearHistory: () => void;
  onClose: () => void;
}

export const MatchHistoryModal: React.FC<MatchHistoryModalProps> = ({
  open,
  entries,
  onClearHistory,
  onClose,
}) => {
  const stats = useMemo(() => computeMatchHistoryStats(entries), [entries]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-black/80 backdrop-blur-xs">
      <div className="w-full max-w-2xl max-h-[calc(100dvh-1rem)] flex flex-col overflow-hidden rounded-2xl border-2 border-amber-400/50 bg-[#0f0c1d] shadow-[0_0_50px_rgba(245,158,11,0.25)]">
        {/* Header */}
        <div className="shrink-0 flex items-center justify-between gap-2 px-4 py-2.5 border-b border-amber-400/20 bg-gradient-to-r from-amber-500/15 via-transparent to-cyan-500/10">
          <div className="flex items-center gap-2 min-w-0">
            <History className="w-4 h-4 text-amber-300 shrink-0" />
            <div className="min-w-0">
              <h3 className="font-display-in text-base sm:text-xl tracking-wider text-amber-200 leading-none truncate">
                AKHARA MATCH HISTORY
              </h3>
              <p className="text-[10px] text-amber-100/60 mt-0.5 truncate">
                Device-local battle log · Up to last 30 matches
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            {entries.length > 0 && (
              <button
                type="button"
                data-ui-sfx="select"
                onClick={onClearHistory}
                className="h-7 sm:h-8 px-2.5 rounded-lg border border-rose-400/45 bg-rose-500/15 text-rose-200 hover:bg-rose-500/25 text-[10.5px] font-bold flex items-center gap-1 cursor-pointer transition"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear History</span>
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              aria-label="Close Match History"
              className="w-8 h-8 rounded-lg border border-amber-400/30 bg-black/40 flex items-center justify-center text-amber-200 hover:bg-amber-400/15 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Summary Stats Bar */}
        <div className="shrink-0 grid grid-cols-3 gap-2 px-4 pt-3 pb-2">
          <div className="p-2 rounded-xl bg-black/40 border border-white/10 text-center">
            <div className="text-[9px] font-bold uppercase tracking-wider text-amber-200/70">Total Matches</div>
            <div className="font-num text-lg sm:text-xl font-black text-amber-100 leading-tight mt-0.5">
              {stats.totalMatches}
            </div>
          </div>
          <div className="p-2 rounded-xl bg-black/40 border border-emerald-400/25 text-center">
            <div className="text-[9px] font-bold uppercase tracking-wider text-emerald-300/80">Win Rate %</div>
            <div className="font-num text-lg sm:text-xl font-black text-emerald-300 leading-tight mt-0.5">
              {stats.winRatePct}%
            </div>
          </div>
          <div className="p-2 rounded-xl bg-black/40 border border-cyan-400/25 text-center">
            <div className="text-[9px] font-bold uppercase tracking-wider text-cyan-300/80 flex items-center justify-center gap-1">
              <Flame className="w-3 h-3 text-amber-300" />
              Best Streak
            </div>
            <div className="font-num text-lg sm:text-xl font-black text-cyan-300 leading-tight mt-0.5">
              {stats.bestStreak}
            </div>
          </div>
        </div>

        {/* Scrollable Match Cards */}
        <div className="flex-1 min-h-0 overflow-y-auto roster-scroll px-4 pb-4 pt-1 space-y-2">
          {entries.length === 0 ? (
            <div className="py-10 text-center space-y-2 rounded-xl border border-white/10 bg-black/30">
              <Trophy className="w-8 h-8 text-amber-300/50 mx-auto" />
              <div className="font-display-in text-base text-amber-100/85">NO MATCHES RECORDED YET</div>
              <p className="text-xs text-slate-400 max-w-xs mx-auto">
                Complete a Player vs Bot or 1v1 match in the Akhara and your battle log will appear right here.
              </p>
            </div>
          ) : (
            entries.map((item) => {
              const pCfg = getCfgById(item.playerFighterId);
              const oCfg = getCfgById(item.opponentFighterId);
              const arenaName = ARENAS[item.arenaId]?.name || item.arenaId;
              const isWin = item.result === 'WIN';
              return (
                <div
                  key={item.id}
                  className={`rounded-xl border p-2.5 flex items-center justify-between gap-2.5 ${
                    isWin
                      ? 'border-emerald-400/35 bg-gradient-to-r from-emerald-500/10 via-black/45 to-black/35'
                      : 'border-rose-400/30 bg-gradient-to-r from-rose-500/10 via-black/45 to-black/35'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0 flex-1">
                    <span
                      className={`px-2 py-1 rounded-lg font-num text-[10.5px] font-black tracking-wider uppercase shrink-0 border ${
                        isWin
                          ? 'bg-emerald-500/20 border-emerald-400/55 text-emerald-200'
                          : 'bg-rose-500/20 border-rose-400/55 text-rose-200'
                      }`}
                    >
                      {item.result}
                    </span>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <MiniFighterFace cfg={pCfg} />
                      <Swords className="w-3.5 h-3.5 text-amber-300/75" />
                      <MiniFighterFace cfg={oCfg} />
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-extrabold text-amber-100 truncate">
                        {pCfg.name} <span className="text-amber-300/60 font-semibold">vs</span> {oCfg.name}
                      </div>
                      <div className="flex items-center gap-1.5 flex-wrap text-[10px] text-slate-300/85 mt-0.5">
                        <span className="px-1.5 py-[1px] rounded bg-white/10 text-cyan-200 font-bold uppercase text-[9px]">
                          {item.mode}
                        </span>
                        <span className="truncate">{arenaName}</span>
                        <span className="text-slate-500">·</span>
                        <span className="text-slate-400">{formatMatchTimestamp(item.timestamp)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2.5 shrink-0 font-num text-right">
                    <div>
                      <div className="text-[8.5px] uppercase text-slate-400">Rounds</div>
                      <div className={`text-xs font-black ${isWin ? 'text-emerald-300' : 'text-rose-300'}`}>
                        {item.roundsScore}
                      </div>
                    </div>
                    <div>
                      <div className="text-[8.5px] uppercase text-slate-400">Combo</div>
                      <div className="text-xs font-black text-cyan-300">{item.maxCombo}x</div>
                    </div>
                    <div className="min-w-[46px]">
                      <div className="text-[8.5px] uppercase text-slate-400">Reward</div>
                      <div className="text-xs font-black text-amber-300 inline-flex items-center justify-end gap-0.5">
                        <Coins className="w-3 h-3" />+{item.futiKodiEarned}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
