import React, { useEffect, useRef, useState } from 'react';
import { User } from 'firebase/auth';
import {
  Check,
  Copy,
  LogIn,
  RefreshCw,
  Swords,
  UserMinus,
  UserPlus,
  Users,
  X,
} from 'lucide-react';
import { getCfgById } from '../game/data';
import { drawCharFace } from '../game/engine';
import { FriendEntry, FriendRequestItem } from '../services/friends';

interface FriendsPanelProps {
  playerId: string;
  authUser: User | null;
  friends: FriendEntry[];
  incomingRequests: FriendRequestItem[];
  authBusy: boolean;
  onGmailLogin: () => Promise<void>;
  onCopyPlayerId: () => void;
  onSendFriendRequest: (targetPlayerId: string) => Promise<void>;
  onAcceptRequest: (req: FriendRequestItem) => Promise<void>;
  onDeclineRequest: (reqId: string) => Promise<void>;
  onRemoveFriend: (friendPlayerId: string) => Promise<void>;
  onChallengeFriend: (friend: FriendEntry) => Promise<void>;
  onRefreshFriends: () => Promise<void>;
  compact?: boolean;
}

function FriendAvatar({ fighterId }: { fighterId: string }) {
  const ref = useRef<HTMLCanvasElement | null>(null);
  const cfg = getCfgById(fighterId);
  useEffect(() => {
    if (ref.current) drawCharFace(ref.current, cfg);
  }, [cfg]);
  return <canvas ref={ref} className="w-8 h-8 rounded-full shrink-0 border border-white/15" title={cfg.name} />;
}

export const FriendsPanel: React.FC<FriendsPanelProps> = ({
  playerId,
  authUser,
  friends,
  incomingRequests,
  authBusy,
  onGmailLogin,
  onCopyPlayerId,
  onSendFriendRequest,
  onAcceptRequest,
  onDeclineRequest,
  onRemoveFriend,
  onChallengeFriend,
  onRefreshFriends,
  compact = false,
}) => {
  const [targetIdInput, setTargetIdInput] = useState('');
  const [sendingReq, setSendingReq] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetIdInput.trim() || sendingReq) return;
    setSendingReq(true);
    try {
      await onSendFriendRequest(targetIdInput);
      setTargetIdInput('');
    } finally {
      setSendingReq(false);
    }
  };

  const handleRefresh = async () => {
    if (refreshing) return;
    setRefreshing(true);
    try {
      await onRefreshFriends();
    } finally {
      setRefreshing(false);
    }
  };

  return (
    <div className={`flex flex-col ${compact ? 'gap-1.5' : 'gap-2.5'} h-full min-h-0`}>
      {/* Top Player ID + Add Friend Form */}
      <div className={`shrink-0 ${compact ? 'space-y-1.5' : 'space-y-2'}`}>
        <div
          className={`flex items-center justify-between gap-2 rounded-xl border border-cyan-400/30 bg-black/45 ${
            compact ? 'px-2 py-1' : 'px-2.5 py-1.5'
          }`}
        >
          <div className="min-w-0 flex items-center gap-1.5 sm:gap-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-300/80">Your ID:</span>
            <span className="font-num text-xs sm:text-sm font-black tracking-widest text-cyan-100 truncate">
              {playerId}
            </span>
          </div>
          <div className="flex items-center gap-1 shrink-0">
            <button
              type="button"
              data-ui-sfx="select"
              onClick={onCopyPlayerId}
              className="px-2 py-0.5 sm:py-1 rounded-lg bg-cyan-400/15 border border-cyan-300/40 text-cyan-100 text-[10px] font-extrabold flex items-center gap-1 hover:bg-cyan-400/25 cursor-pointer"
            >
              <Copy className="w-3 h-3" />
              Copy ID
            </button>
            {authUser && (
              <button
                type="button"
                onClick={() => void handleRefresh()}
                disabled={refreshing}
                title="Refresh Online Status"
                className="p-1 sm:p-1.5 rounded-lg border border-white/15 bg-black/40 text-amber-200 hover:border-amber-300 cursor-pointer"
              >
                <RefreshCw className={`w-3 h-3 ${refreshing ? 'animate-spin' : ''}`} />
              </button>
            )}
          </div>
        </div>

        {authUser ? (
          <form onSubmit={handleSend} className="flex items-center gap-1.5">
            <input
              type="text"
              value={targetIdInput}
              onChange={(e) => setTargetIdInput(e.target.value.toUpperCase())}
              maxLength={12}
              placeholder={compact ? "Friend's ID (GC-XXXXXX)" : "Enter Friend's Player ID (e.g. GC-7X9K2M)"}
              className={`flex-1 min-w-0 px-2.5 rounded-xl bg-[#07050e] border border-amber-400/35 font-num tracking-wider text-amber-50 uppercase focus:outline-none focus:border-amber-300 ${
                compact ? 'py-1 text-[11px]' : 'py-1.5 text-xs'
              }`}
            />
            <button
              type="submit"
              disabled={sendingReq || !targetIdInput.trim()}
              className={`shrink-0 px-2.5 sm:px-3 rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 text-slate-950 font-black flex items-center gap-1 hover:brightness-110 disabled:opacity-50 cursor-pointer ${
                compact ? 'py-1 text-[11px]' : 'py-1.5 text-xs'
              }`}
            >
              <UserPlus className="w-3.5 h-3.5" />
              {sendingReq ? '...' : 'Add'}
            </button>
          </form>
        ) : (
          <div
            className={`flex items-center justify-between gap-2 rounded-xl border border-amber-400/35 bg-amber-500/10 ${
              compact ? 'p-2' : 'p-2.5'
            }`}
          >
            <span className={`${compact ? 'text-[10px]' : 'text-[11px]'} text-amber-100/85 leading-snug`}>
              Friend Requests aur 1v1 Invite ke liye Gmail Login karein.
            </span>
            <button
              type="button"
              onClick={() => void onGmailLogin()}
              disabled={authBusy}
              className="shrink-0 px-2.5 py-1 rounded-lg bg-gradient-to-r from-amber-400 to-rose-500 text-slate-950 font-extrabold text-[10.5px] flex items-center gap-1 cursor-pointer"
            >
              <LogIn className="w-3 h-3" />
              {authBusy ? '...' : 'Gmail Login'}
            </button>
          </div>
        )}
      </div>

      {/* Scrollable Incoming Requests + Friends List */}
      <div className={`flex-1 min-h-0 overflow-y-auto roster-scroll ${compact ? 'space-y-1.5' : 'space-y-3'} pr-0.5`}>
        {/* Incoming Requests Section */}
        {incomingRequests.length > 0 && (
          <div className="space-y-1">
            <div className="flex items-center justify-between px-1">
              <span className="text-[10px] font-black uppercase tracking-[0.18em] text-rose-300">
                Incoming Requests ({incomingRequests.length})
              </span>
            </div>
            {incomingRequests.map((req) => (
              <div
                key={req.id}
                className={`flex items-center justify-between gap-2 rounded-xl border border-rose-400/45 bg-rose-500/10 ${
                  compact ? 'p-1.5' : 'p-2'
                }`}
              >
                <div className="flex items-center gap-2 min-w-0">
                  <FriendAvatar fighterId={req.fromFighterId} />
                  <div className="min-w-0">
                    <div className="text-xs font-extrabold text-amber-100 truncate">{req.fromName}</div>
                    <div className="font-num text-[10px] text-rose-200/80 truncate">
                      {req.fromPlayerId} · {getCfgById(req.fromFighterId).name}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    type="button"
                    disabled={busyId === req.id}
                    onClick={async () => {
                      setBusyId(req.id);
                      try {
                        await onAcceptRequest(req);
                      } finally {
                        setBusyId(null);
                      }
                    }}
                    className="px-2 py-1 rounded-lg bg-emerald-400 text-slate-950 text-[10px] font-black flex items-center gap-1 hover:brightness-110 cursor-pointer disabled:opacity-50"
                  >
                    <Check className="w-3 h-3" />
                    Accept
                  </button>
                  <button
                    type="button"
                    disabled={busyId === req.id}
                    onClick={async () => {
                      setBusyId(req.id);
                      try {
                        await onDeclineRequest(req.id);
                      } finally {
                        setBusyId(null);
                      }
                    }}
                    className="px-2 py-1 rounded-lg border border-rose-400/45 bg-black/40 text-rose-200 text-[10px] font-bold flex items-center gap-1 hover:bg-rose-500/20 cursor-pointer disabled:opacity-50"
                  >
                    <X className="w-3 h-3" />
                    Decline
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Friends List Section */}
        <div className="space-y-1">
          <div className="flex items-center justify-between px-1">
            <span className="text-[10px] font-black uppercase tracking-[0.18em] text-amber-300/80 flex items-center gap-1">
              <Users className="w-3 h-3" />
              Friends List ({friends.length})
            </span>
            <span className="text-[9.5px] text-slate-400">No Team Code Needed</span>
          </div>

          {friends.length === 0 ? (
            <div
              className={`text-center rounded-xl border border-white/10 bg-black/30 px-3 ${
                compact ? 'py-3' : 'py-6'
              }`}
            >
              <p className={`${compact ? 'text-[11px]' : 'text-xs'} text-amber-100/75 leading-snug`}>
                Abhi koi dost add nahi hai. Upar friend ka <span className="font-num text-cyan-300">GC-XXXXXX</span> Player ID daal kar request bhejo!
              </p>
            </div>
          ) : (
            friends.map((f) => (
              <div
                key={f.id}
                className={`flex items-center justify-between gap-2 rounded-xl border border-white/12 bg-black/40 hover:border-amber-400/40 transition ${
                  compact ? 'p-1.5' : 'p-2'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="relative shrink-0">
                    <FriendAvatar fighterId={f.friendFighterId} />
                    <span
                      title={f.online ? 'Online' : 'Offline'}
                      className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-[#0d0a19] ${
                        f.online ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.9)]' : 'bg-slate-500'
                      }`}
                    />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-extrabold text-amber-100 truncate">{f.friendName}</span>
                      <span
                        className={`text-[9px] font-extrabold uppercase ${
                          f.online ? 'text-emerald-300' : 'text-slate-400'
                        }`}
                      >
                        {f.online ? '● Online' : '○ Offline'}
                      </span>
                    </div>
                    <div className="font-num text-[10px] text-cyan-200/75 truncate">
                      {f.friendPlayerId} · {getCfgById(f.friendFighterId).name}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    disabled={busyId === f.id}
                    onClick={async () => {
                      setBusyId(f.id);
                      try {
                        await onChallengeFriend(f);
                      } finally {
                        setBusyId(null);
                      }
                    }}
                    className="px-2.5 py-1.5 rounded-lg bg-gradient-to-r from-amber-400 via-orange-400 to-rose-500 text-slate-950 text-[10.5px] font-black flex items-center gap-1 hover:brightness-110 active:scale-[0.97] cursor-pointer disabled:opacity-50"
                  >
                    <Swords className="w-3 h-3" />
                    1v1 Invite
                  </button>
                  <button
                    type="button"
                    disabled={busyId === f.id}
                    title="Remove Friend"
                    onClick={async () => {
                      setBusyId(f.id);
                      try {
                        await onRemoveFriend(f.friendPlayerId);
                      } finally {
                        setBusyId(null);
                      }
                    }}
                    className="p-1.5 rounded-lg border border-white/10 text-slate-400 hover:text-rose-300 hover:border-rose-400/40 cursor-pointer disabled:opacity-50"
                  >
                    <UserMinus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
