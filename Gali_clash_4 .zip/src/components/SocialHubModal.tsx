import React, { useEffect, useRef, useState } from 'react';
import { User } from 'firebase/auth';
import {
  Award,
  Code2,
  Crown,
  Eye,
  Flame,
  LogIn,
  MessageSquare,
  Send,
  Swords,
  Trash2,
  Trophy,
  Users,
  X,
} from 'lucide-react';
import { getCfgById } from '../game/data';
import { drawCharFace } from '../game/engine';
import { FriendEntry, FriendRequestItem } from '../services/friends';
import { PlayerProfile } from '../services/playerAccount';
import {
  ChatMessageTag,
  deleteOwnChatMessage,
  fetchPublicPlayerProfile,
  GlobalChatMessage,
  LeaderboardEntry,
  sendGlobalChatMessage,
  subscribeGlobalChat,
  subscribeLeaderboard,
} from '../services/socialHub';
import { FriendsPanel } from './FriendsPanel';
import { PublicProfileModal } from './PublicProfileModal';

export type SocialHubTab = 'leaderboard' | 'chat' | 'friends';

interface SocialHubModalProps {
  open: boolean;
  initialTab?: SocialHubTab;
  authUser: User | null;
  playerProfile: PlayerProfile | null;
  playerId: string;
  friends: FriendEntry[];
  incomingRequests: FriendRequestItem[];
  activeMpCode?: string;
  onGmailLogin: () => Promise<void>;
  authBusy: boolean;
  onJoinCodeFromChat: (code: string) => void;
  onCopyPlayerId: () => void;
  onSendFriendRequest: (targetPlayerId: string) => Promise<void>;
  onAcceptRequest: (req: FriendRequestItem) => Promise<void>;
  onDeclineRequest: (reqId: string) => Promise<void>;
  onRemoveFriend: (friendPlayerId: string) => Promise<void>;
  onChallengeFriend: (friend: FriendEntry) => Promise<void>;
  onRefreshFriends: () => Promise<void>;
  onClose: () => void;
  onToast: (msg: string) => void;
}

function SmallFighterBadge({ fighterId }: { fighterId: string }) {
  const ref = useRef<HTMLCanvasElement | null>(null);
  const cfg = getCfgById(fighterId);
  useEffect(() => {
    if (ref.current) drawCharFace(ref.current, cfg);
  }, [cfg]);
  return <canvas ref={ref} className="w-7 h-7 rounded-full shrink-0" title={cfg.name} />;
}

export const SocialHubModal: React.FC<SocialHubModalProps> = ({
  open,
  initialTab = 'leaderboard',
  authUser,
  playerProfile,
  playerId,
  friends,
  incomingRequests,
  activeMpCode,
  onGmailLogin,
  authBusy,
  onJoinCodeFromChat,
  onCopyPlayerId,
  onSendFriendRequest,
  onAcceptRequest,
  onDeclineRequest,
  onRemoveFriend,
  onChallengeFriend,
  onRefreshFriends,
  onClose,
  onToast,
}) => {
  const [tab, setTab] = useState<SocialHubTab>(initialTab);
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [messages, setMessages] = useState<GlobalChatMessage[]>([]);
  const [lbLoading, setLbLoading] = useState(true);
  const [chatLoading, setChatLoading] = useState(true);

  const [draft, setDraft] = useState('');
  const [tag, setTag] = useState<ChatMessageTag>('chat');
  const [sending, setSending] = useState(false);
  const [inspectedProfile, setInspectedProfile] = useState<LeaderboardEntry | null>(null);
  const [inspectLoading, setInspectLoading] = useState(false);
  const [inspectRoomCode, setInspectRoomCode] = useState<string | undefined>(undefined);
  const chatBottomRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (open) setTab(initialTab);
  }, [open, initialTab]);

  useEffect(() => {
    if (!open) return;
    setLbLoading(true);
    setChatLoading(true);

    const unsubLb = subscribeLeaderboard(
      (data) => {
        setEntries(data);
        setLbLoading(false);
      },
      () => setLbLoading(false),
    );

    const unsubChat = subscribeGlobalChat(
      (msgs) => {
        setMessages(msgs);
        setChatLoading(false);
      },
      () => setChatLoading(false),
    );

    return () => {
      unsubLb();
      unsubChat();
    };
  }, [open]);

  useEffect(() => {
    if (open && tab === 'chat') {
      chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [open, tab, messages.length]);

  if (!open) return null;

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!authUser || sending) return;
    const text = draft.trim();
    if (!text) return;

    setSending(true);
    try {
      await sendGlobalChatMessage({
        uid: authUser.uid,
        akharaName: playerProfile?.akharaName || authUser.displayName || 'Desi Yoddha',
        photoUrl: playerProfile?.photoUrl || authUser.photoURL,
        text,
        tag,
        roomCode: tag === 'challenge' && activeMpCode ? activeMpCode : '',
        isDeveloper: Boolean(playerProfile?.isDeveloper),
      });
      setDraft('');
    } catch {
      onToast('Could not send chat message.');
    } finally {
      setSending(false);
    }
  };

  const handleQuickChallengePost = async () => {
    if (!authUser || !activeMpCode || sending) return;
    setSending(true);
    try {
      await sendGlobalChatMessage({
        uid: authUser.uid,
        akharaName: playerProfile?.akharaName || authUser.displayName || 'Desi Yoddha',
        photoUrl: playerProfile?.photoUrl || authUser.photoURL,
        text: `1v1 Akhara Challenge! Join mera room code ${activeMpCode}!`,
        tag: 'challenge',
        roomCode: activeMpCode,
        isDeveloper: Boolean(playerProfile?.isDeveloper),
      });
      onToast('1v1 Challenge posted in Global Chat!');
    } catch {
      onToast('Could not post 1v1 challenge.');
    } finally {
      setSending(false);
    }
  };

  const handleInspectPlayer = async (
    uid: string,
    fallback?: { akharaName: string; photoUrl: string; isDeveloper?: boolean; roomCode?: string },
  ) => {
    setInspectRoomCode(fallback?.roomCode);
    const cached = entries.find((item) => item.uid === uid);
    if (cached) {
      setInspectedProfile(cached);
      setInspectLoading(false);
      return;
    }
    setInspectLoading(true);
    setInspectedProfile(null);
    try {
      const fetched = await fetchPublicPlayerProfile(uid);
      if (fetched) {
        setInspectedProfile(fetched);
      } else if (fallback) {
        setInspectedProfile({
          uid,
          akharaName: fallback.akharaName,
          photoUrl: fallback.photoUrl,
          favoriteFighterId: 'munna_bhaiya',
          wins: 0,
          losses: 0,
          matchesPlayed: 0,
          bestCombo: 0,
          rankPoints: 0,
          isDeveloper: Boolean(fallback.isDeveloper),
        });
      } else {
        onToast('Player stats unavailable.');
      }
    } catch {
      onToast('Could not load player status.');
    } finally {
      setInspectLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-black/82 backdrop-blur-xs">
      <div className="w-full max-w-3xl h-[min(520px,calc(100dvh-1.25rem))] flex flex-col overflow-hidden rounded-2xl border-2 border-amber-400/55 bg-[#0d0a19]/98 shadow-[0_0_55px_rgba(245,158,11,0.28)]">
        {/* Header with Tab Switcher */}
        <div className="shrink-0 flex items-center justify-between gap-2 px-3.5 sm:px-4 py-2.5 border-b border-amber-400/20 bg-gradient-to-r from-amber-500/18 via-transparent to-cyan-500/15">
          <div className="flex items-center gap-1.5 sm:gap-2 overflow-x-auto">
            <button
              type="button"
              onClick={() => setTab('leaderboard')}
              className={`px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-extrabold tracking-wide flex items-center gap-1.5 border transition cursor-pointer shrink-0 ${
                tab === 'leaderboard'
                  ? 'bg-amber-400/25 border-amber-300 text-amber-100 shadow-[0_0_12px_rgba(251,191,36,0.25)]'
                  : 'bg-black/35 border-white/10 text-slate-300 hover:text-amber-200'
              }`}
            >
              <Trophy className="w-3.5 h-3.5 text-amber-300" />
              <span>Ranks</span>
              <span className="hidden sm:inline">Leaderboard</span>
            </button>
            <button
              type="button"
              onClick={() => setTab('chat')}
              className={`px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-extrabold tracking-wide flex items-center gap-1.5 border transition cursor-pointer shrink-0 ${
                tab === 'chat'
                  ? 'bg-cyan-400/22 border-cyan-300 text-cyan-100 shadow-[0_0_12px_rgba(34,211,238,0.25)]'
                  : 'bg-black/35 border-white/10 text-slate-300 hover:text-cyan-200'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5 text-cyan-300" />
              <span>Chat</span>
              <span className="hidden sm:inline">Akhara</span>
            </button>
            <button
              type="button"
              onClick={() => setTab('friends')}
              className={`relative px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-extrabold tracking-wide flex items-center gap-1.5 border transition cursor-pointer shrink-0 ${
                tab === 'friends'
                  ? 'bg-emerald-400/22 border-emerald-300 text-emerald-100 shadow-[0_0_12px_rgba(52,211,153,0.25)]'
                  : 'bg-black/35 border-white/10 text-slate-300 hover:text-emerald-200'
              }`}
            >
              <Users className="w-3.5 h-3.5 text-emerald-300" />
              <span>Friends</span>
              {incomingRequests.length > 0 && (
                <span className="px-1.5 min-w-[16px] h-[16px] rounded-full bg-rose-500 text-white font-num text-[9.5px] font-black flex items-center justify-center">
                  {incomingRequests.length}
                </span>
              )}
            </button>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close Social Hub"
            className="w-8 h-8 rounded-lg border border-amber-400/35 bg-black/45 flex items-center justify-center text-amber-200 hover:bg-amber-400/15 cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        {tab === 'friends' ? (
          <div className="flex-1 min-h-0 flex flex-col p-3 sm:p-4">
            <FriendsPanel
              playerId={playerId}
              authUser={authUser}
              friends={friends}
              incomingRequests={incomingRequests}
              authBusy={authBusy}
              onGmailLogin={onGmailLogin}
              onCopyPlayerId={onCopyPlayerId}
              onSendFriendRequest={onSendFriendRequest}
              onAcceptRequest={onAcceptRequest}
              onDeclineRequest={onDeclineRequest}
              onRemoveFriend={onRemoveFriend}
              onChallengeFriend={onChallengeFriend}
              onRefreshFriends={onRefreshFriends}
            />
          </div>
        ) : tab === 'leaderboard' ? (
          <div className="flex-1 min-h-0 flex flex-col p-3 sm:p-4 gap-2">
            <div className="shrink-0 flex items-center justify-between text-[11px] text-amber-200/75 px-1">
              <span>Points = Wins × 100 + Best Combo × 5</span>
              {!authUser && (
                <button
                  type="button"
                  onClick={() => void onGmailLogin()}
                  disabled={authBusy}
                  className="px-2.5 py-1 rounded-lg bg-amber-400/20 border border-amber-300/50 text-amber-200 font-bold flex items-center gap-1 hover:bg-amber-400/30 cursor-pointer"
                >
                  <LogIn className="w-3 h-3" />
                  Join Rank (Gmail)
                </button>
              )}
            </div>

            <div className="flex-1 min-h-0 overflow-y-auto roster-scroll space-y-1.5 pr-1">
              {lbLoading ? (
                <div className="py-12 text-center text-xs text-amber-200/60">Loading Akhara Champions...</div>
              ) : entries.length === 0 ? (
                <div className="py-12 text-center text-xs text-amber-100/70">
                  Abhi koi ranked player nahi hai. Gmail login karke pehla match jeeto!
                </div>
              ) : (
                entries.map((entry, idx) => {
                  const rank = idx + 1;
                  const isMe = authUser?.uid === entry.uid;
                  const cfg = getCfgById(entry.favoriteFighterId);
                  return (
                    <button
                      type="button"
                      key={entry.uid}
                      onClick={() => void handleInspectPlayer(entry.uid)}
                      className={`w-full text-left flex items-center justify-between gap-2.5 px-3 py-2 rounded-xl border transition cursor-pointer hover:border-amber-300/75 ${
                        isMe
                          ? 'border-emerald-400/60 bg-emerald-500/12'
                          : rank === 1
                            ? 'border-amber-400/50 bg-amber-500/10'
                            : 'border-white/10 bg-black/35'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="w-7 text-center shrink-0 font-num font-black text-sm">
                          {rank === 1 ? (
                            <Crown className="w-5 h-5 text-yellow-300 mx-auto" />
                          ) : rank === 2 ? (
                            <Award className="w-5 h-5 text-slate-200 mx-auto" />
                          ) : rank === 3 ? (
                            <Award className="w-5 h-5 text-amber-500 mx-auto" />
                          ) : (
                            <span className="text-slate-400">#{rank}</span>
                          )}
                        </div>
                        <SmallFighterBadge fighterId={entry.favoriteFighterId} />
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="font-bold text-xs sm:text-sm text-amber-100 truncate">
                              {entry.akharaName}
                            </span>
                            {entry.isDeveloper && (
                              <span className="inline-flex items-center gap-0.5 px-1.5 py-[1px] rounded bg-gradient-to-r from-amber-400 to-yellow-300 text-slate-950 text-[8.5px] font-black uppercase tracking-wider">
                                <Code2 className="w-2.5 h-2.5" />
                                DEV
                              </span>
                            )}
                            {isMe && (
                              <span className="text-[9px] font-extrabold text-emerald-300 uppercase">
                                (You)
                              </span>
                            )}
                          </div>
                          <div className="text-[10px] text-slate-400 truncate">
                            Main: <span className="text-cyan-300/90">{cfg.name}</span> · {entry.matchesPlayed} Matches
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 sm:gap-4 shrink-0 text-right font-num">
                        <div>
                          <div className="text-[9px] text-slate-400 uppercase">W / L</div>
                          <div className="text-xs font-bold">
                            <span className="text-emerald-300">{entry.wins}</span>
                            <span className="text-slate-500">/</span>
                            <span className="text-rose-300">{entry.losses}</span>
                          </div>
                        </div>
                        <div className="hidden sm:block">
                          <div className="text-[9px] text-slate-400 uppercase">Combo</div>
                          <div className="text-xs font-bold text-cyan-300">{entry.bestCombo}x</div>
                        </div>
                        <div className="min-w-[60px]">
                          <div className="text-[9px] text-amber-300/75 uppercase">Points</div>
                          <div className="text-sm font-black text-amber-300">{entry.rankPoints}</div>
                        </div>
                        <Eye className="w-3.5 h-3.5 text-amber-300/60 hidden sm:block" />
                      </div>
                    </button>
                  );
                })
              )}
            </div>
          </div>
        ) : (
          <div className="flex-1 min-h-0 flex flex-col p-3 sm:p-4 gap-2">
            <div className="flex-1 min-h-0 overflow-y-auto roster-scroll space-y-2 pr-1">
              {chatLoading ? (
                <div className="py-12 text-center text-xs text-cyan-200/60">Connecting to Global Akhara Chat...</div>
              ) : messages.length === 0 ? (
                <div className="py-12 text-center text-xs text-amber-100/70">
                  Koi message nahi hai abhi — "Namaste!" bol kar Akhara chat shuru karo!
                </div>
              ) : (
                messages.map((m) => {
                  const isMine = authUser?.uid === m.uid;
                  return (
                    <div
                      key={m.id}
                      className={`p-2.5 rounded-xl border text-xs ${
                        m.tag === 'challenge'
                          ? 'border-amber-400/50 bg-amber-500/10'
                          : isMine
                            ? 'border-cyan-400/35 bg-cyan-500/10'
                            : 'border-white/10 bg-black/38'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <button
                          type="button"
                          onClick={() =>
                            void handleInspectPlayer(m.uid, {
                              akharaName: m.akharaName,
                              photoUrl: m.photoUrl,
                              isDeveloper: m.isDeveloper,
                              roomCode: m.roomCode || undefined,
                            })
                          }
                          title="View Player Profile Status"
                          className="flex items-center gap-1.5 min-w-0 hover:underline cursor-pointer"
                        >
                          {m.photoUrl ? (
                            <img
                              src={m.photoUrl}
                              alt=""
                              referrerPolicy="no-referrer"
                              className="w-4 h-4 rounded-full object-cover shrink-0"
                            />
                          ) : (
                            <Flame className="w-3.5 h-3.5 text-amber-300 shrink-0" />
                          )}
                          <span className="font-bold text-amber-200 truncate">{m.akharaName}</span>
                          {m.isDeveloper && (
                            <span className="inline-flex items-center gap-0.5 px-1.5 py-[1px] rounded bg-gradient-to-r from-amber-400 to-yellow-300 text-slate-950 text-[8.5px] font-black uppercase tracking-wider">
                              <Code2 className="w-2.5 h-2.5" />
                              DEV
                            </span>
                          )}
                          {m.tag === 'challenge' && (
                            <span className="px-1.5 py-[1px] rounded bg-amber-400/20 border border-amber-300/60 text-[8.5px] font-extrabold text-amber-200 uppercase">
                              1v1 Challenge
                            </span>
                          )}
                          {m.tag === 'gg' && (
                            <span className="px-1.5 py-[1px] rounded bg-emerald-400/20 border border-emerald-300/60 text-[8.5px] font-extrabold text-emerald-200 uppercase">
                              GG!
                            </span>
                          )}
                        </button>
                        <div className="flex items-center gap-1.5 shrink-0">
                          {m.roomCode && (
                            <button
                              type="button"
                              onClick={() => onJoinCodeFromChat(m.roomCode)}
                              className="px-2 py-0.5 rounded-md bg-gradient-to-r from-cyan-400 to-teal-400 text-slate-950 font-num font-black text-[10px] flex items-center gap-1 cursor-pointer hover:brightness-110"
                            >
                              <Swords className="w-3 h-3" />
                              Join {m.roomCode}
                            </button>
                          )}
                          {isMine && (
                            <button
                              type="button"
                              onClick={() => void deleteOwnChatMessage(m.id)}
                              title="Delete your message"
                              className="p-1 rounded text-rose-300/70 hover:text-rose-300 cursor-pointer"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      </div>
                      <p className="text-amber-50/90 break-words leading-snug">{m.text}</p>
                    </div>
                  );
                })
              )}
              <div ref={chatBottomRef} />
            </div>

            {/* Chat Input Footer */}
            {authUser ? (
              <form onSubmit={handleSend} className="shrink-0 flex flex-wrap sm:flex-nowrap items-center gap-1.5 pt-1 border-t border-white/10">
                <div className="flex items-center gap-1 shrink-0">
                  {(['chat', 'gg', 'challenge'] as ChatMessageTag[]).map((t) => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => setTag(t)}
                      className={`px-2 py-1.5 rounded-lg text-[10px] font-extrabold uppercase border cursor-pointer ${
                        tag === t
                          ? t === 'challenge'
                            ? 'bg-amber-400/25 border-amber-300 text-amber-200'
                            : t === 'gg'
                              ? 'bg-emerald-400/25 border-emerald-300 text-emerald-200'
                              : 'bg-cyan-400/25 border-cyan-300 text-cyan-100'
                          : 'bg-black/40 border-white/10 text-slate-400'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                  {activeMpCode && (
                    <button
                      type="button"
                      onClick={() => void handleQuickChallengePost()}
                      disabled={sending}
                      title={`Post 1v1 Code ${activeMpCode} in Chat`}
                      className="px-2 py-1.5 rounded-lg bg-amber-500/20 border border-amber-400/50 text-amber-200 text-[10px] font-extrabold hover:bg-amber-500/30 cursor-pointer"
                    >
                      Share {activeMpCode}
                    </button>
                  )}
                </div>

                <input
                  type="text"
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  maxLength={180}
                  placeholder="Akhara mein sabhi se baat karo..."
                  className="flex-1 min-w-[160px] px-3 py-1.5 rounded-xl bg-[#07050e] border border-cyan-400/35 text-xs text-amber-50 focus:outline-none focus:border-cyan-300"
                />
                <button
                  type="submit"
                  disabled={sending || !draft.trim()}
                  className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-cyan-400 to-teal-400 text-slate-950 font-extrabold text-xs flex items-center gap-1 disabled:opacity-50 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  Send
                </button>
              </form>
            ) : (
              <div className="shrink-0 flex items-center justify-between gap-3 pt-2 border-t border-white/10">
                <span className="text-xs text-amber-100/75">
                  Global Chat mein likhne aur Leaderboard rank ke liye free Gmail Login karein.
                </span>
                <button
                  type="button"
                  onClick={() => void onGmailLogin()}
                  disabled={authBusy}
                  className="shrink-0 px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-rose-500 text-slate-950 font-extrabold text-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  {authBusy ? 'Signing in...' : 'Gmail Login'}
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      <PublicProfileModal
        profile={inspectedProfile}
        loading={inspectLoading}
        isMe={!!inspectedProfile && authUser?.uid === inspectedProfile.uid}
        roomCode={inspectRoomCode}
        onJoinRoomCode={(code) => {
          onClose();
          onJoinCodeFromChat(code);
        }}
        onClose={() => {
          setInspectedProfile(null);
          setInspectLoading(false);
        }}
      />
    </div>
  );
};
