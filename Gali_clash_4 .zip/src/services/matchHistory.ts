import { ArenaId } from '../game/types';

export type MatchHistoryMode = 'Bot' | '1v1' | 'Practice';
export type MatchHistoryResult = 'WIN' | 'LOSS';

export interface MatchHistoryEntry {
  id: string;
  timestamp: number;
  mode: MatchHistoryMode;
  result: MatchHistoryResult;
  playerFighterId: string;
  opponentFighterId: string;
  arenaId: ArenaId;
  roundsScore: string;
  maxCombo: number;
  futiKodiEarned: number;
}

export interface MatchHistoryStats {
  totalMatches: number;
  wins: number;
  losses: number;
  winRatePct: number;
  bestStreak: number;
}

const MATCH_HISTORY_STORAGE_KEY = 'gc_match_history_v1';
const MAX_HISTORY_ENTRIES = 30;

function isValidMode(v: unknown): v is MatchHistoryMode {
  return v === 'Bot' || v === '1v1' || v === 'Practice';
}

function isValidResult(v: unknown): v is MatchHistoryResult {
  return v === 'WIN' || v === 'LOSS';
}

function isValidArenaId(v: unknown): v is ArenaId {
  return v === 'chandni' || v === 'howrah' || v === 'banaras';
}

export function loadMatchHistory(): MatchHistoryEntry[] {
  try {
    const raw = window.localStorage.getItem(MATCH_HISTORY_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    const valid: MatchHistoryEntry[] = [];
    for (const item of parsed) {
      if (!item || typeof item !== 'object') continue;
      if (
        typeof item.id !== 'string' ||
        typeof item.timestamp !== 'number' ||
        !isValidMode(item.mode) ||
        !isValidResult(item.result) ||
        typeof item.playerFighterId !== 'string' ||
        typeof item.opponentFighterId !== 'string' ||
        !isValidArenaId(item.arenaId) ||
        typeof item.roundsScore !== 'string'
      ) {
        continue;
      }
      valid.push({
        id: item.id,
        timestamp: item.timestamp,
        mode: item.mode,
        result: item.result,
        playerFighterId: item.playerFighterId,
        opponentFighterId: item.opponentFighterId,
        arenaId: item.arenaId,
        roundsScore: item.roundsScore,
        maxCombo: typeof item.maxCombo === 'number' && Number.isFinite(item.maxCombo) ? Math.max(0, Math.floor(item.maxCombo)) : 0,
        futiKodiEarned:
          typeof item.futiKodiEarned === 'number' && Number.isFinite(item.futiKodiEarned)
            ? Math.max(0, Math.floor(item.futiKodiEarned))
            : 0,
      });
      if (valid.length >= MAX_HISTORY_ENTRIES) break;
    }
    return valid;
  } catch {
    return [];
  }
}

function saveMatchHistory(entries: MatchHistoryEntry[]): MatchHistoryEntry[] {
  const capped = entries.slice(0, MAX_HISTORY_ENTRIES);
  try {
    window.localStorage.setItem(MATCH_HISTORY_STORAGE_KEY, JSON.stringify(capped));
  } catch {
    // Ignore storage quota issues safely
  }
  return capped;
}

export function appendMatchHistoryEntry(
  entry: Omit<MatchHistoryEntry, 'id' | 'timestamp'> & { id?: string; timestamp?: number },
): MatchHistoryEntry[] {
  const existing = loadMatchHistory();
  const ts = entry.timestamp ?? Date.now();
  const nextItem: MatchHistoryEntry = {
    id: entry.id || `mh_${ts}_${Math.random().toString(36).slice(2, 7)}`,
    timestamp: ts,
    mode: entry.mode,
    result: entry.result,
    playerFighterId: entry.playerFighterId,
    opponentFighterId: entry.opponentFighterId,
    arenaId: entry.arenaId,
    roundsScore: entry.roundsScore,
    maxCombo: Math.max(0, Math.floor(entry.maxCombo || 0)),
    futiKodiEarned: Math.max(0, Math.floor(entry.futiKodiEarned || 0)),
  };
  return saveMatchHistory([nextItem, ...existing]);
}

export function clearMatchHistory(): MatchHistoryEntry[] {
  try {
    window.localStorage.removeItem(MATCH_HISTORY_STORAGE_KEY);
  } catch {
    // Ignore
  }
  return [];
}

export function computeMatchHistoryStats(entries: MatchHistoryEntry[]): MatchHistoryStats {
  const totalMatches = entries.length;
  if (totalMatches === 0) {
    return { totalMatches: 0, wins: 0, losses: 0, winRatePct: 0, bestStreak: 0 };
  }

  let wins = 0;
  let losses = 0;
  let bestStreak = 0;
  let currentStreak = 0;

  // Iterate oldest -> newest to compute chronological win streak accurately
  for (let i = entries.length - 1; i >= 0; i--) {
    const e = entries[i];
    if (e.result === 'WIN') {
      wins++;
      currentStreak++;
      if (currentStreak > bestStreak) bestStreak = currentStreak;
    } else {
      losses++;
      currentStreak = 0;
    }
  }

  const winRatePct = Math.round((wins / totalMatches) * 100);
  return { totalMatches, wins, losses, winRatePct, bestStreak };
}
