import { doc, getDoc, serverTimestamp, setDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  ALL_COSMETICS,
  AuraDef,
  CosmeticItem,
  DEFAULT_AURA_ID,
  getAllCosmetics,
  getSkinById,
  SkinDef,
} from '../game/cosmetics';
import { ALL_UNLOCKABLE_POSE_IDS, FIGHTER_VICTORY_POSES, getVictoryPosePrice, VictoryPoseDef } from '../game/victoryPoses';

export type LobbyThemeId = 'normal_night' | 'diwali_diya' | 'blood_moon' | 'holi_rang';

export interface LobbyThemeMeta {
  id: LobbyThemeId;
  name: string;
  tagline: string;
  accentColor: string;
  previewGradient: string;
}

export const LOBBY_THEMES: LobbyThemeMeta[] = [
  {
    id: 'normal_night',
    name: 'Normal Night',
    tagline: 'Classic Kolkata dusk, crescent moon & heritage warm lamps',
    accentColor: '#fbbf24',
    previewGradient: 'linear-gradient(135deg, #050816 0%, #321b42 60%, #9a4a2b 100%)',
  },
  {
    id: 'diwali_diya',
    name: 'Diwali Diya Glow',
    tagline: 'Golden palace illumination, blazing plinth diyas & sky fuljhadi',
    accentColor: '#f59e0b',
    previewGradient: 'linear-gradient(135deg, #1b0c04 0%, #78350f 55%, #f59e0b 100%)',
  },
  {
    id: 'blood_moon',
    name: 'Blood Moon Akhara',
    tagline: 'Crimson eclipse sky, scarlet water glow & rising shadow embers',
    accentColor: '#f43f5e',
    previewGradient: 'linear-gradient(135deg, #090207 0%, #4c0519 55%, #be123c 100%)',
  },
  {
    id: 'holi_rang',
    name: 'Holi Rang Utsav',
    tagline: 'Vibrant gulal twilight motes, festive prism uplights & marigold toran',
    accentColor: '#ec4899',
    previewGradient: 'linear-gradient(135deg, #16092b 0%, #701a75 55%, #0ea5e9 100%)',
  },
];

export interface CmsPriceOverride {
  fkPrice?: number | null;
  gotaPrice?: number;
  flashLabel?: string;
}

export interface CmsBundleDef {
  id: string;
  title: string;
  subtitle: string;
  itemIds: string[]; // cosmetic IDs (skin_* / aura_*) or 'pose:<fighterId>:<poseId>'
  gotaPrice: number;
  badgeText?: string;
  active: boolean;
  createdAtMs: number;
}

export interface LiveCmsConfig {
  priceOverrides: Record<string, CmsPriceOverride>;
  bundles: CmsBundleDef[];
  lobbyTheme: LobbyThemeId;
  updatedAtMs: number;
}

export interface DevUnreleasedSessionState {
  unlockedIds: string[];
  equippedSkinIds: string[];
  equippedAuraId: string | null;
}

const LIVE_CMS_STORAGE_KEY = 'gc_live_cms_config_v1';
const DEV_UNRELEASED_ITEMS_KEY = 'gc_dev_unreleased_cosmetics_v1';
const DEV_UNRELEASED_SESSION_KEY = 'gc_dev_unreleased_session_v1';
const LIVE_CMS_DOC_PATH = 'liveCmsConfig/global';

export function createDefaultLiveCmsConfig(): LiveCmsConfig {
  return {
    priceOverrides: {},
    bundles: [],
    lobbyTheme: 'normal_night',
    updatedAtMs: 0,
  };
}

function sanitizeLobbyTheme(val: unknown): LobbyThemeId {
  if (val === 'diwali_diya' || val === 'blood_moon' || val === 'holi_rang' || val === 'normal_night') {
    return val;
  }
  return 'normal_night';
}

function sanitizePositiveInt(val: unknown, max = 1000000): number | undefined {
  if (typeof val !== 'number' || !Number.isFinite(val)) return undefined;
  return Math.max(0, Math.min(max, Math.round(val)));
}

export function normalizeLiveCmsConfig(raw: unknown): LiveCmsConfig {
  if (!raw || typeof raw !== 'object') return createDefaultLiveCmsConfig();
  const obj = raw as Record<string, unknown>;

  const priceOverrides: Record<string, CmsPriceOverride> = {};
  if (obj.priceOverrides && typeof obj.priceOverrides === 'object') {
    for (const [key, val] of Object.entries(obj.priceOverrides as Record<string, unknown>)) {
      if (!/^[a-zA-Z0-9_:-]{1,64}$/.test(key) || !val || typeof val !== 'object') continue;
      const v = val as Record<string, unknown>;
      const entry: CmsPriceOverride = {};
      if (v.fkPrice === null) {
        entry.fkPrice = null;
      } else {
        const fk = sanitizePositiveInt(v.fkPrice, 1000000);
        if (fk !== undefined) entry.fkPrice = fk;
      }
      const gota = sanitizePositiveInt(v.gotaPrice, 100000);
      if (gota !== undefined) entry.gotaPrice = gota;
      if (typeof v.flashLabel === 'string' && v.flashLabel.trim()) {
        entry.flashLabel = v.flashLabel.trim().slice(0, 24);
      }
      if (entry.fkPrice !== undefined || entry.gotaPrice !== undefined || entry.flashLabel) {
        priceOverrides[key] = entry;
      }
    }
  }

  const bundles: CmsBundleDef[] = [];
  if (Array.isArray(obj.bundles)) {
    for (const rawB of obj.bundles.slice(0, 20)) {
      if (!rawB || typeof rawB !== 'object') continue;
      const b = rawB as Record<string, unknown>;
      const id = typeof b.id === 'string' && /^[a-zA-Z0-9_-]{3,64}$/.test(b.id) ? b.id : '';
      const title = typeof b.title === 'string' ? b.title.trim().slice(0, 48) : '';
      if (!id || !title) continue;
      const itemIds = Array.isArray(b.itemIds)
        ? Array.from(
            new Set(
              b.itemIds
                .filter((x): x is string => typeof x === 'string' && x.length >= 2 && x.length <= 80)
                .slice(0, 12),
            ),
          )
        : [];
      if (itemIds.length === 0) continue;
      const gotaPrice = Math.max(1, sanitizePositiveInt(b.gotaPrice, 100000) ?? 25);
      bundles.push({
        id,
        title,
        subtitle: typeof b.subtitle === 'string' ? b.subtitle.trim().slice(0, 80) : '',
        itemIds,
        gotaPrice,
        badgeText: typeof b.badgeText === 'string' ? b.badgeText.trim().slice(0, 20) : undefined,
        active: b.active !== false,
        createdAtMs: typeof b.createdAtMs === 'number' && Number.isFinite(b.createdAtMs) ? b.createdAtMs : Date.now(),
      });
    }
  }

  return {
    priceOverrides,
    bundles,
    lobbyTheme: sanitizeLobbyTheme(obj.lobbyTheme),
    updatedAtMs: typeof obj.updatedAtMs === 'number' && Number.isFinite(obj.updatedAtMs) ? obj.updatedAtMs : Date.now(),
  };
}

export function loadLocalLiveCmsConfig(): LiveCmsConfig {
  try {
    const raw = window.localStorage.getItem(LIVE_CMS_STORAGE_KEY);
    if (!raw) return createDefaultLiveCmsConfig();
    return normalizeLiveCmsConfig(JSON.parse(raw));
  } catch {
    return createDefaultLiveCmsConfig();
  }
}

export function saveLocalLiveCmsConfig(cfg: LiveCmsConfig): LiveCmsConfig {
  const normalized = normalizeLiveCmsConfig(cfg);
  try {
    window.localStorage.setItem(LIVE_CMS_STORAGE_KEY, JSON.stringify(normalized));
  } catch {
    // ignore storage quota errors
  }
  return normalized;
}

export async function fetchLiveCmsConfig(): Promise<LiveCmsConfig | null> {
  try {
    const snap = await getDoc(doc(db, 'liveCmsConfig', 'global'));
    if (!snap.exists()) return null;
    const normalized = normalizeLiveCmsConfig(snap.data());
    saveLocalLiveCmsConfig(normalized);
    return normalized;
  } catch {
    // Non-blocking fallback to local cache if offline or uninitialized
    return null;
  }
}

export async function publishLiveCmsConfig(
  cfg: LiveCmsConfig,
  options: { syncCloud: boolean; isFirestoreDeveloper: boolean },
): Promise<{ config: LiveCmsConfig; syncedCloud: boolean }> {
  const next = saveLocalLiveCmsConfig({ ...cfg, updatedAtMs: Date.now() });
  if (!options.syncCloud || !options.isFirestoreDeveloper) {
    return { config: next, syncedCloud: false };
  }

  const ref = doc(db, 'liveCmsConfig', 'global');
  try {
    await setDoc(ref, {
      priceOverrides: next.priceOverrides,
      bundles: next.bundles,
      lobbyTheme: next.lobbyTheme,
      updatedAtMs: next.updatedAtMs,
      updatedAt: serverTimestamp(),
    });
    return { config: next, syncedCloud: true };
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, LIVE_CMS_DOC_PATH);
  }
}

// ==================== DEVELOPER-ONLY UNRELEASED COSMETICS STORAGE ====================
// Isolated in dedicated developer keys so regular players' storage & Firestore docs stay lean.

export function loadDevUnreleasedCosmetics(): CosmeticItem[] {
  try {
    const raw = window.localStorage.getItem(DEV_UNRELEASED_ITEMS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter((item): item is CosmeticItem => {
        if (!item || typeof item !== 'object') return false;
        const c = item as Partial<CosmeticItem>;
        return typeof c.id === 'string' && c.id.startsWith('dev_') && (c.category === 'skin' || c.category === 'aura');
      })
      .map((item) => ({ ...item, isDevUnreleased: true }))
      .slice(0, 30);
  } catch {
    return [];
  }
}

export function saveDevUnreleasedCosmetics(items: CosmeticItem[]): CosmeticItem[] {
  const sanitized = items
    .map((item) => ({ ...item, isDevUnreleased: true }))
    .slice(0, 30);
  try {
    window.localStorage.setItem(DEV_UNRELEASED_ITEMS_KEY, JSON.stringify(sanitized));
  } catch {
    // ignore storage quota errors
  }
  return sanitized;
}

export function loadDevUnreleasedSession(): DevUnreleasedSessionState {
  try {
    const raw = window.localStorage.getItem(DEV_UNRELEASED_SESSION_KEY);
    if (!raw) return { unlockedIds: [], equippedSkinIds: [], equippedAuraId: null };
    const parsed = JSON.parse(raw) as Partial<DevUnreleasedSessionState>;
    return {
      unlockedIds: Array.isArray(parsed.unlockedIds)
        ? parsed.unlockedIds.filter((id): id is string => typeof id === 'string')
        : [],
      equippedSkinIds: Array.isArray(parsed.equippedSkinIds)
        ? parsed.equippedSkinIds.filter((id): id is string => typeof id === 'string')
        : [],
      equippedAuraId: typeof parsed.equippedAuraId === 'string' ? parsed.equippedAuraId : null,
    };
  } catch {
    return { unlockedIds: [], equippedSkinIds: [], equippedAuraId: null };
  }
}

export function saveDevUnreleasedSession(session: DevUnreleasedSessionState): DevUnreleasedSessionState {
  const next: DevUnreleasedSessionState = {
    unlockedIds: Array.from(new Set(session.unlockedIds)),
    equippedSkinIds: Array.from(new Set(session.equippedSkinIds)),
    equippedAuraId: session.equippedAuraId,
  };
  try {
    window.localStorage.setItem(DEV_UNRELEASED_SESSION_KEY, JSON.stringify(next));
  } catch {
    // ignore
  }
  return next;
}

export function equipDevUnreleasedInSession(
  session: DevUnreleasedSessionState,
  category: 'skin' | 'aura',
  cosmeticId: string,
): DevUnreleasedSessionState {
  const unlockedIds = session.unlockedIds.includes(cosmeticId)
    ? session.unlockedIds
    : [...session.unlockedIds, cosmeticId];
  if (category === 'aura') {
    return saveDevUnreleasedSession({
      ...session,
      unlockedIds,
      equippedAuraId: cosmeticId,
    });
  }
  const skin = getSkinById(cosmeticId);
  const filtered = skin
    ? session.equippedSkinIds.filter((id) => getSkinById(id)?.fighterId !== skin.fighterId)
    : session.equippedSkinIds;
  return saveDevUnreleasedSession({
    ...session,
    unlockedIds,
    equippedSkinIds: [...filtered, cosmeticId],
  });
}

// ==================== EFFECTIVE PRICING & BUNDLE ITEM HELPERS ====================

export interface EffectiveCosmeticPricing {
  fkPrice: number | null;
  gotaPrice: number;
  baseFkPrice: number | null;
  baseGotaPrice: number;
  hasOverride: boolean;
  isDiscounted: boolean;
  flashLabel?: string;
}

export function getEffectiveCosmeticPricing(
  item: CosmeticItem,
  cmsConfig?: LiveCmsConfig | null,
): EffectiveCosmeticPricing {
  const baseFkPrice = item.fkPrice;
  const baseGotaPrice = item.gotaPrice;
  const ov = cmsConfig?.priceOverrides?.[item.id];
  if (!ov || item.id === DEFAULT_AURA_ID) {
    return {
      fkPrice: baseFkPrice,
      gotaPrice: baseGotaPrice,
      baseFkPrice,
      baseGotaPrice,
      hasOverride: false,
      isDiscounted: false,
    };
  }
  const fkPrice = ov.fkPrice !== undefined ? ov.fkPrice : baseFkPrice;
  const gotaPrice = ov.gotaPrice !== undefined ? Math.max(1, ov.gotaPrice) : baseGotaPrice;
  const changed = fkPrice !== baseFkPrice || gotaPrice !== baseGotaPrice || Boolean(ov.flashLabel);
  const isDiscounted =
    (fkPrice !== null && baseFkPrice !== null && fkPrice < baseFkPrice) || gotaPrice < baseGotaPrice;

  return {
    fkPrice,
    gotaPrice,
    baseFkPrice,
    baseGotaPrice,
    hasOverride: changed,
    isDiscounted,
    flashLabel: ov.flashLabel,
  };
}

export interface EffectivePosePricing {
  index: 1 | 2 | 3;
  isFreeDefault: boolean;
  fkPrice: number;
  gotaPrice: number;
  baseFkPrice: number;
  baseGotaPrice: number;
  hasOverride: boolean;
  isDiscounted: boolean;
  flashLabel?: string;
}

export function getEffectivePosePricing(
  fighterId: string,
  poseId: string,
  cmsConfig?: LiveCmsConfig | null,
): EffectivePosePricing {
  const base = getVictoryPosePrice(fighterId, poseId);
  if (base.isFreeDefault) {
    return {
      ...base,
      baseFkPrice: 0,
      baseGotaPrice: 0,
      hasOverride: false,
      isDiscounted: false,
    };
  }
  const ov = cmsConfig?.priceOverrides?.[poseId];
  if (!ov) {
    return {
      ...base,
      baseFkPrice: base.fkPrice,
      baseGotaPrice: base.gotaPrice,
      hasOverride: false,
      isDiscounted: false,
    };
  }
  const fkPrice = typeof ov.fkPrice === 'number' ? Math.max(1, ov.fkPrice) : base.fkPrice;
  const gotaPrice = typeof ov.gotaPrice === 'number' ? Math.max(1, ov.gotaPrice) : base.gotaPrice;
  const hasOverride = fkPrice !== base.fkPrice || gotaPrice !== base.gotaPrice || Boolean(ov.flashLabel);
  const isDiscounted = fkPrice < base.fkPrice || gotaPrice < base.gotaPrice;
  return {
    index: base.index,
    isFreeDefault: false,
    fkPrice,
    gotaPrice,
    baseFkPrice: base.fkPrice,
    baseGotaPrice: base.gotaPrice,
    hasOverride,
    isDiscounted,
    flashLabel: ov.flashLabel,
  };
}

export function encodePoseBundleToken(fighterId: string, poseId: string): string {
  return `pose:${fighterId}:${poseId}`;
}

export function decodeBundleToken(token: string):
  | { kind: 'cosmetic'; cosmetic: CosmeticItem }
  | { kind: 'pose'; fighterId: string; pose: VictoryPoseDef; gotaValue: number }
  | null {
  if (token.startsWith('pose:')) {
    const parts = token.split(':');
    if (parts.length !== 3) return null;
    const [, fighterId, poseId] = parts;
    const list = FIGHTER_VICTORY_POSES[fighterId];
    const pose = list?.find((p) => p.id === poseId);
    if (!pose) return null;
    const price = getVictoryPosePrice(fighterId, poseId);
    return { kind: 'pose', fighterId, pose, gotaValue: price.gotaPrice };
  }
  const cosmetic =
    getAllCosmetics(true).find((c) => c.id === token) || ALL_COSMETICS.find((c) => c.id === token);
  if (!cosmetic) return null;
  return { kind: 'cosmetic', cosmetic };
}

export function computeBundleRegularGotaValue(bundle: CmsBundleDef): number {
  let total = 0;
  for (const token of bundle.itemIds) {
    const decoded = decodeBundleToken(token);
    if (!decoded) continue;
    total += decoded.kind === 'cosmetic' ? decoded.cosmetic.gotaPrice : decoded.gotaValue;
  }
  return total;
}

export function isBundleSelectablePoseId(poseId: string): boolean {
  return ALL_UNLOCKABLE_POSE_IDS.includes(poseId);
}

export function buildDevTestSkinDef(input: {
  fighterId: string;
  name: string;
  subtitle: string;
  tunic: string;
  tunicDark: string;
  pants: string;
  pantsDark: string;
  trim: string;
  aura: string;
  glow: string;
  eye: string;
  motif: NonNullable<SkinDef['palette']['motif']>;
  shiny: boolean;
  fkPrice: number | null;
  gotaPrice: number;
}): SkinDef {
  const slug =
    input.name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '_')
      .replace(/^_+|_+$/g, '')
      .slice(0, 20) || 'custom';
  const id = `dev_skin_${slug}_${Date.now().toString(36)}`;
  return {
    id,
    category: 'skin',
    fighterId: input.fighterId,
    name: input.name.trim().slice(0, 36) || 'Prototype Skin',
    subtitle: input.subtitle.trim().slice(0, 64) || 'Developer Test Prototype',
    currency: input.fkPrice === null ? 'gota' : 'futi_kodi',
    price: input.fkPrice ?? input.gotaPrice,
    fkPrice: input.fkPrice,
    gotaPrice: Math.max(1, Math.round(input.gotaPrice)),
    isDevUnreleased: true,
    palette: {
      tunic: input.tunic,
      tunicDark: input.tunicDark,
      pants: input.pants,
      pantsDark: input.pantsDark,
      trim: input.trim,
      aura: input.aura,
      glow: input.glow,
      eye: input.eye,
      shiny: input.shiny,
      motif: input.motif,
    },
  };
}

export function buildDevTestAuraDef(input: {
  name: string;
  subtitle: string;
  ringColor: string;
  sparkColor: string;
  secondaryColor: string;
  style: Exclude<AuraDef['style'], 'none'>;
  fkPrice: number | null;
  gotaPrice: number;
}): AuraDef {
  const slug =
    input.name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '_')
      .replace(/^_+|_+$/g, '')
      .slice(0, 20) || 'aura';
  const id = `dev_aura_${slug}_${Date.now().toString(36)}`;
  return {
    id,
    category: 'aura',
    name: input.name.trim().slice(0, 36) || 'Prototype Aura',
    subtitle: input.subtitle.trim().slice(0, 64) || 'Developer Test FX',
    currency: input.fkPrice === null ? 'gota' : 'futi_kodi',
    price: input.fkPrice ?? input.gotaPrice,
    fkPrice: input.fkPrice,
    gotaPrice: Math.max(1, Math.round(input.gotaPrice)),
    ringColor: input.ringColor,
    sparkColor: input.sparkColor,
    secondaryColor: input.secondaryColor,
    style: input.style,
    isDevUnreleased: true,
  };
}
