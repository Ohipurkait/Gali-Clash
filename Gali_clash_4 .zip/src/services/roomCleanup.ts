import { getApp } from 'firebase/app';
import { getDatabase, onDisconnect, ref, remove, set } from 'firebase/database';
import firebaseConfig from '../../firebase-applet-config.json';

let activeRoomCode: string | null = null;

function hasRtdbConfigured(): boolean {
  const cfg = firebaseConfig as Record<string, unknown>;
  return typeof cfg.databaseURL === 'string' && cfg.databaseURL.trim().length > 0;
}

export async function registerActiveRoomLifecycle(roomCode: string, role: 'host' | 'guest'): Promise<void> {
  const cleanCode = String(roomCode || '').trim().toUpperCase().replace(/[^A-Z0-9-]/g, '');
  if (!cleanCode) return;
  activeRoomCode = cleanCode;

  if (!hasRtdbConfigured()) return;
  try {
    const rtdb = getDatabase(getApp());
    const roomRef = ref(rtdb, `rooms/${cleanCode}`);
    await onDisconnect(roomRef).remove();
    if (role === 'host') {
      await set(roomRef, {
        code: cleanCode,
        hostActive: true,
        updatedAt: Date.now(),
      });
    }
  } catch {
    // Non-blocking: PeerJS + BroadcastChannel remain primary transports
  }
}

export async function cleanupActiveRoomLifecycle(roomCode?: string | null): Promise<void> {
  const target = String(roomCode || activeRoomCode || '')
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9-]/g, '');
  activeRoomCode = null;
  if (!target || !hasRtdbConfigured()) return;

  try {
    const rtdb = getDatabase(getApp());
    await remove(ref(rtdb, `rooms/${target}`));
  } catch {
    // Ignore transient cleanup failures on disconnect
  }
}
