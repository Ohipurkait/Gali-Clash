import { signInWithPopup, signOut, User } from 'firebase/auth';
import {
  deleteField,
  doc,
  getDoc,
  onSnapshot,
  runTransaction,
  serverTimestamp,
  setDoc,
  Timestamp,
  Unsubscribe,
  updateDoc,
  writeBatch,
} from 'firebase/firestore';
import {
  auth,
  db,
  ensureFirestoreOnline,
  googleProvider,
  handleFirestoreError,
  OperationType,
} from '../firebase';
import {
  ALL_COSMETIC_IDS,
  ALL_SKIN_IDS,
  CosmeticCurrency,
  CosmeticItem,
  DEFAULT_AURA_ID,
  getEquippedSkinForFighter,
  getSkinById,
} from '../game/cosmetics';
import { ArenaId } from '../game/types';
import { ALL_UNLOCKABLE_POSE_IDS } from '../game/victoryPoses';
import {
  CmsBundleDef,
  decodeBundleToken,
  getEffectiveCosmeticPricing,
  getEffectivePosePricing,
  LiveCmsConfig,
} from './devCms';

export interface PlayerProfile {
  uid: string;
  akharaName: string;
  photoUrl: string;
  favoriteFighterId: string;
  favoriteArenaId: ArenaId;
  wins: number;
  losses: number;
  matchesPlayed: number;
  bestCombo: number;
  futiKodi: number;
  gota: number;
  unlockedCosmetics: string[];
  unlockedPoses: string[];
  equippedSkinIds: string[];
  equippedAuraId: string;
  isDeveloper: boolean;
  lastClaimedMailId?: string;
  lastClaimedQuestKey?: string;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

type RawPlayerDoc = Partial<PlayerProfile> & {
  coins?: number;
  equippedSkinId?: string;
};

const ARENA_IDS: ArenaId[] = ['chandni', 'howrah', 'banaras'];
const FIGHTER_ID_RE = /^[a-z0-9_]+$/;
const STARTER_FUTI_KODI = 150;
const STARTER_GOTA = 0;
const STARTER_COSMETICS = [DEFAULT_AURA_ID];
const CACHED_PROFILE_PREFIX = 'gc_cached_profile_';
const LOCAL_LOADOUT_KEY = 'gc_local_loadout_v1';
const GUEST_WALLET_KEY = 'gc_guest_wallet_v1';

export interface LocalLoadout {
  fighterId: string;
  arenaId: ArenaId;
}

export function loadLocalLoadout(): LocalLoadout {
  try {
    const raw = window.localStorage.getItem(LOCAL_LOADOUT_KEY);
    if (!raw) return { fighterId: 'munna_bhaiya', arenaId: 'chandni' };
    const parsed = JSON.parse(raw) as Partial<LocalLoadout>;
    return {
      fighterId: typeof parsed.fighterId === 'string' && FIGHTER_ID_RE.test(parsed.fighterId)
        ? parsed.fighterId
        : 'munna_bhaiya',
      arenaId: ARENA_IDS.includes(parsed.arenaId as ArenaId) ? (parsed.arenaId as ArenaId) : 'chandni',
    };
  } catch {
    return { fighterId: 'munna_bhaiya', arenaId: 'chandni' };
  }
}

export function saveLocalLoadout(fighterId: string, arenaId: ArenaId): void {
  try {
    window.localStorage.setItem(
      LOCAL_LOADOUT_KEY,
      JSON.stringify({
        fighterId: sanitizeFighterId(fighterId),
        arenaId: sanitizeArenaId(arenaId),
      }),
    );
  } catch {
    // ignore storage quota errors
  }
}

export function readCachedPlayerProfile(uid: string): PlayerProfile | null {
  try {
    const raw = window.localStorage.getItem(`${CACHED_PROFILE_PREFIX}${uid}`);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as RawPlayerDoc;
    return normalizePlayerProfile({ ...parsed, uid });
  } catch {
    return null;
  }
}

export function writeCachedPlayerProfile(profile: PlayerProfile): void {
  if (!profile.uid) return;
  try {
    const serializable = {
      uid: profile.uid,
      akharaName: profile.akharaName,
      photoUrl: profile.photoUrl,
      favoriteFighterId: profile.favoriteFighterId,
      favoriteArenaId: profile.favoriteArenaId,
      wins: profile.wins,
      losses: profile.losses,
      matchesPlayed: profile.matchesPlayed,
      bestCombo: profile.bestCombo,
      futiKodi: profile.futiKodi,
      gota: profile.gota,
      unlockedCosmetics: profile.unlockedCosmetics,
      unlockedPoses: profile.unlockedPoses,
      equippedSkinIds: profile.equippedSkinIds,
      equippedAuraId: profile.equippedAuraId,
      isDeveloper: profile.isDeveloper,
      lastClaimedMailId: profile.lastClaimedMailId,
      lastClaimedQuestKey: profile.lastClaimedQuestKey,
    };
    window.localStorage.setItem(`${CACHED_PROFILE_PREFIX}${profile.uid}`, JSON.stringify(serializable));
  } catch {
    // ignore storage quota errors
  }
}

export function readGuestWallet(isDevActive = false): PlayerProfile {
  const loadout = loadLocalLoadout();
  try {
    const raw = window.localStorage.getItem(GUEST_WALLET_KEY);
    const parsed = raw ? (JSON.parse(raw) as RawPlayerDoc) : {};
    const base = normalizePlayerProfile({
      ...parsed,
      uid: 'guest',
      akharaName: 'Desi Yoddha',
      favoriteFighterId: loadout.fighterId,
      favoriteArenaId: loadout.arenaId,
      isDeveloper: isDevActive,
    });
    if (isDevActive) {
      return { ...base, isDeveloper: true, futiKodi: 9999999, gota: 9999999 };
    }
    return base;
  } catch {
    return normalizePlayerProfile({
      uid: 'guest',
      akharaName: 'Desi Yoddha',
      favoriteFighterId: loadout.fighterId,
      favoriteArenaId: loadout.arenaId,
      isDeveloper: isDevActive,
    });
  }
}

export function writeGuestWallet(wallet: PlayerProfile): PlayerProfile {
  const normalized = normalizePlayerProfile({ ...wallet, uid: 'guest', isDeveloper: false });
  try {
    const toSave = {
      wins: normalized.wins,
      losses: normalized.losses,
      matchesPlayed: normalized.matchesPlayed,
      bestCombo: normalized.bestCombo,
      futiKodi: normalized.futiKodi,
      gota: normalized.gota,
      unlockedCosmetics: normalized.unlockedCosmetics,
      unlockedPoses: normalized.unlockedPoses,
      equippedSkinIds: normalized.equippedSkinIds,
      equippedAuraId: normalized.equippedAuraId,
      favoriteFighterId: normalized.favoriteFighterId,
      favoriteArenaId: normalized.favoriteArenaId,
    };
    window.localStorage.setItem(GUEST_WALLET_KEY, JSON.stringify(toSave));
  } catch {
    // ignore storage quota errors
  }
  return normalized;
}

export function sanitizeAkharaName(raw: string | null | undefined, emailFallback?: string | null): string {
  const cleaned = String(raw || '')
    .replace(/\s+/g, ' ')
    .trim();
  if (cleaned.length >= 2) return cleaned.slice(0, 32);
  const fromEmail = String(emailFallback || '')
    .split('@')[0]
    .replace(/[^a-zA-Z0-9_ -]/g, '')
    .trim();
  if (fromEmail.length >= 2) return fromEmail.slice(0, 32);
  return 'Desi Yoddha';
}

function sanitizeFighterId(id: string): string {
  if (FIGHTER_ID_RE.test(id) && id.length >= 1 && id.length <= 40) return id;
  return 'munna_bhaiya';
}

function sanitizeArenaId(id: string): ArenaId {
  return ARENA_IDS.includes(id as ArenaId) ? (id as ArenaId) : 'chandni';
}

function sanitizePhotoUrl(url: string | null | undefined): string {
  return String(url || '').slice(0, 512);
}

export function normalizePlayerProfile(raw: RawPlayerDoc): PlayerProfile {
  const unlocked = Array.isArray(raw.unlockedCosmetics)
    ? Array.from(new Set(raw.unlockedCosmetics.filter((id) => ALL_COSMETIC_IDS.includes(id))))
    : [...STARTER_COSMETICS];
  if (!unlocked.includes(DEFAULT_AURA_ID)) unlocked.unshift(DEFAULT_AURA_ID);

  const unlockedPoses = Array.isArray(raw.unlockedPoses)
    ? Array.from(new Set(raw.unlockedPoses.filter((id) => ALL_UNLOCKABLE_POSE_IDS.includes(id)))).slice(0, 20)
    : [];

  // Deduplicate equipped skins to at most 1 per fighter and only if unlocked
  const seenFighters = new Set<string>();
  const equippedSkinIds: string[] = [];
  if (Array.isArray(raw.equippedSkinIds)) {
    for (const sid of raw.equippedSkinIds) {
      if (!ALL_SKIN_IDS.includes(sid) || !unlocked.includes(sid)) continue;
      const skin = getSkinById(sid);
      if (!skin || seenFighters.has(skin.fighterId)) continue;
      seenFighters.add(skin.fighterId);
      equippedSkinIds.push(sid);
    }
  }

  const equippedAuraId =
    typeof raw.equippedAuraId === 'string' && unlocked.includes(raw.equippedAuraId)
      ? raw.equippedAuraId
      : DEFAULT_AURA_ID;

  const fallbackFutiKodi = typeof raw.coins === 'number' && Number.isFinite(raw.coins) ? raw.coins : STARTER_FUTI_KODI;

  return {
    uid: String(raw.uid || ''),
    akharaName: sanitizeAkharaName(raw.akharaName),
    photoUrl: sanitizePhotoUrl(raw.photoUrl),
    favoriteFighterId: sanitizeFighterId(raw.favoriteFighterId || 'munna_bhaiya'),
    favoriteArenaId: sanitizeArenaId(raw.favoriteArenaId || 'chandni'),
    wins: typeof raw.wins === 'number' && Number.isFinite(raw.wins) ? Math.max(0, Math.round(raw.wins)) : 0,
    losses: typeof raw.losses === 'number' && Number.isFinite(raw.losses) ? Math.max(0, Math.round(raw.losses)) : 0,
    matchesPlayed:
      typeof raw.matchesPlayed === 'number' && Number.isFinite(raw.matchesPlayed)
        ? Math.max(0, Math.round(raw.matchesPlayed))
        : 0,
    bestCombo:
      typeof raw.bestCombo === 'number' && Number.isFinite(raw.bestCombo) ? Math.max(0, Math.round(raw.bestCombo)) : 0,
    futiKodi:
      typeof raw.futiKodi === 'number' && Number.isFinite(raw.futiKodi)
        ? Math.max(0, Math.round(raw.futiKodi))
        : Math.max(0, Math.round(fallbackFutiKodi)),
    gota: typeof raw.gota === 'number' && Number.isFinite(raw.gota) ? Math.max(0, Math.round(raw.gota)) : STARTER_GOTA,
    unlockedCosmetics: unlocked,
    unlockedPoses,
    equippedSkinIds,
    equippedAuraId,
    isDeveloper: Boolean(raw.isDeveloper),
    lastClaimedMailId: typeof raw.lastClaimedMailId === 'string' ? raw.lastClaimedMailId : undefined,
    lastClaimedQuestKey: typeof raw.lastClaimedQuestKey === 'string' ? raw.lastClaimedQuestKey : undefined,
    createdAt: raw.createdAt,
    updatedAt: raw.updatedAt,
  };
}

export function getEquippedSkinIdForFighter(profile: PlayerProfile | null | undefined, fighterId: string): string {
  return getEquippedSkinForFighter(profile?.equippedSkinIds, fighterId)?.id || '';
}

export async function signInWithGmail(): Promise<User> {
  const result = await signInWithPopup(auth, googleProvider);
  return result.user;
}

export async function logoutAccount(): Promise<void> {
  await signOut(auth);
}

async function withTransientRetry<T>(fn: () => Promise<T>): Promise<T> {
  try {
    return await fn();
  } catch (err) {
    const code = (err as { code?: string } | null)?.code || '';
    const msg = err instanceof Error ? err.message.toLowerCase() : '';
    if (code === 'unavailable' || msg.includes('offline') || msg.includes('unavailable')) {
      await ensureFirestoreOnline();
      await new Promise((r) => window.setTimeout(r, 900));
      return await fn();
    }
    throw err;
  }
}

async function syncLeaderboardEntry(profile: PlayerProfile): Promise<void> {
  const lbPath = `leaderboard/${profile.uid}`;
  const lbRef = doc(db, 'leaderboard', profile.uid);
  const wins = Math.max(0, Math.min(1000000, Math.round(profile.wins || 0)));
  const losses = Math.max(0, Math.min(1000000, Math.round(profile.losses || 0)));
  const matchesPlayed = Math.max(0, Math.min(2000000, Math.round(profile.matchesPlayed || 0)));
  const bestCombo = Math.max(0, Math.min(999, Math.round(profile.bestCombo || 0)));
  const rankPoints = wins * 100 + bestCombo * 5;

  let exists = false;
  let existingIsDev: boolean | undefined;
  try {
    const snap = await withTransientRetry(() => getDoc(lbRef));
    exists = snap.exists();
    if (exists) {
      existingIsDev = snap.data()?.isDeveloper as boolean | undefined;
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, lbPath);
  }

  const isDev = Boolean(profile.isDeveloper);
  if (!exists) {
    try {
      await setDoc(lbRef, {
        uid: profile.uid,
        akharaName: sanitizeAkharaName(profile.akharaName),
        photoUrl: sanitizePhotoUrl(profile.photoUrl),
        favoriteFighterId: sanitizeFighterId(profile.favoriteFighterId),
        wins,
        losses,
        matchesPlayed,
        bestCombo,
        rankPoints,
        isDeveloper: isDev,
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, lbPath);
    }
  } else if (existingIsDev !== isDev) {
    try {
      await updateDoc(lbRef, {
        isDeveloper: isDev,
        updatedAt: serverTimestamp(),
      });
    } catch {
      // Ignore transient leaderboard badge sync error
    }
  }
}

export async function ensurePlayerAccountDocuments(
  user: User,
  preferredFighterId: string,
  preferredArenaId: ArenaId,
): Promise<PlayerProfile> {
  const profilePath = `players/${user.uid}`;
  const profileRef = doc(db, 'players', user.uid);
  const privatePath = `players/${user.uid}/private/account`;
  const privateRef = doc(db, 'players', user.uid, 'private', 'account');

  let existingRaw: RawPlayerDoc | null = null;
  try {
    const snap = await withTransientRetry(() => getDoc(profileRef));
    if (snap.exists()) {
      existingRaw = snap.data() as RawPlayerDoc;
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, profilePath);
  }

  if (!existingRaw) {
    const freshProfile: Omit<PlayerProfile, 'createdAt' | 'updatedAt'> & {
      createdAt: ReturnType<typeof serverTimestamp>;
      updatedAt: ReturnType<typeof serverTimestamp>;
    } = {
      uid: user.uid,
      akharaName: sanitizeAkharaName(user.displayName, user.email),
      photoUrl: sanitizePhotoUrl(user.photoURL),
      favoriteFighterId: sanitizeFighterId(preferredFighterId),
      favoriteArenaId: sanitizeArenaId(preferredArenaId),
      wins: 0,
      losses: 0,
      matchesPlayed: 0,
      bestCombo: 0,
      futiKodi: STARTER_FUTI_KODI,
      gota: STARTER_GOTA,
      unlockedCosmetics: [...STARTER_COSMETICS],
      unlockedPoses: [],
      equippedSkinIds: [],
      equippedAuraId: DEFAULT_AURA_ID,
      isDeveloper: false,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };
    try {
      await setDoc(profileRef, freshProfile);
      const createdSnap = await getDoc(profileRef);
      existingRaw = createdSnap.data() as RawPlayerDoc;
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, profilePath);
    }
  } else if (
    typeof existingRaw.futiKodi !== 'number' ||
    typeof existingRaw.gota !== 'number' ||
    !Array.isArray(existingRaw.equippedSkinIds) ||
    !Array.isArray(existingRaw.unlockedCosmetics) ||
    !Array.isArray(existingRaw.unlockedPoses) ||
    !existingRaw.equippedAuraId ||
    typeof existingRaw.isDeveloper !== 'boolean' ||
    'coins' in existingRaw ||
    'equippedSkinId' in existingRaw
  ) {
    // Clean backfill preserving existing unlocked cosmetics & balances
    const migratedFutiKodi =
      typeof existingRaw.futiKodi === 'number' && Number.isFinite(existingRaw.futiKodi)
        ? Math.max(0, Math.round(existingRaw.futiKodi))
        : typeof existingRaw.coins === 'number' && Number.isFinite(existingRaw.coins)
          ? Math.max(0, Math.round(existingRaw.coins))
          : STARTER_FUTI_KODI;
    const migratedGota =
      typeof existingRaw.gota === 'number' && Number.isFinite(existingRaw.gota)
        ? Math.max(0, Math.round(existingRaw.gota))
        : STARTER_GOTA;
    const migratedUnlocked =
      Array.isArray(existingRaw.unlockedCosmetics) && existingRaw.unlockedCosmetics.length > 0
        ? Array.from(new Set(existingRaw.unlockedCosmetics.filter((id) => ALL_COSMETIC_IDS.includes(id))))
        : [...STARTER_COSMETICS];
    if (!migratedUnlocked.includes(DEFAULT_AURA_ID)) migratedUnlocked.unshift(DEFAULT_AURA_ID);
    const migratedPoses = Array.isArray(existingRaw.unlockedPoses)
      ? Array.from(new Set(existingRaw.unlockedPoses.filter((id) => ALL_UNLOCKABLE_POSE_IDS.includes(id)))).slice(0, 20)
      : [];
    const migratedEquippedSkins = Array.isArray(existingRaw.equippedSkinIds)
      ? existingRaw.equippedSkinIds.filter((id) => ALL_SKIN_IDS.includes(id) && migratedUnlocked.includes(id)).slice(0, 10)
      : [];
    const migratedAura =
      typeof existingRaw.equippedAuraId === 'string' && migratedUnlocked.includes(existingRaw.equippedAuraId)
        ? existingRaw.equippedAuraId
        : DEFAULT_AURA_ID;

    try {
      const patchPayload: Record<string, unknown> = {
        futiKodi: migratedFutiKodi,
        gota: migratedGota,
        unlockedCosmetics: migratedUnlocked,
        unlockedPoses: migratedPoses,
        equippedSkinIds: migratedEquippedSkins,
        equippedAuraId: migratedAura,
        isDeveloper: typeof existingRaw.isDeveloper === 'boolean' ? existingRaw.isDeveloper : false,
        updatedAt: serverTimestamp(),
      };
      if ('coins' in existingRaw) patchPayload.coins = deleteField();
      if ('equippedSkinId' in existingRaw) patchPayload.equippedSkinId = deleteField();

      await updateDoc(profileRef, patchPayload);
      const refreshed = await getDoc(profileRef);
      if (refreshed.exists()) {
        existingRaw = refreshed.data() as RawPlayerDoc;
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, profilePath);
    }
  }

  // Keep isolated PII document synced with the user's verified Gmail
  const email = String(user.email || '').trim().slice(0, 254);
  if (email.length >= 3) {
    let privateExists = false;
    let existingEmail = '';
    try {
      const privSnap = await getDoc(privateRef);
      if (privSnap.exists()) {
        privateExists = true;
        existingEmail = String(privSnap.data()?.email || '');
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, privatePath);
    }

    if (!privateExists) {
      try {
        await setDoc(privateRef, {
          uid: user.uid,
          email,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, privatePath);
      }
    } else if (existingEmail !== email) {
      try {
        await updateDoc(privateRef, {
          email,
          updatedAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, privatePath);
      }
    }
  }

  const normalized = normalizePlayerProfile(existingRaw || {});
  writeCachedPlayerProfile(normalized);
  await syncLeaderboardEntry(normalized);
  return normalized;
}

export function subscribePlayerProfile(
  uid: string,
  onProfile: (profile: PlayerProfile | null) => void,
): Unsubscribe {
  const path = `players/${uid}`;
  const ref = doc(db, 'players', uid);
  return onSnapshot(
    ref,
    (snap) => {
      if (snap.exists()) {
        const normalized = normalizePlayerProfile(snap.data() as RawPlayerDoc);
        writeCachedPlayerProfile(normalized);
        onProfile(normalized);
      } else {
        onProfile(null);
      }
    },
    (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    },
  );
}

export async function updateAkharaName(uid: string, rawName: string, photoUrl?: string | null): Promise<string> {
  const path = `players/${uid}`;
  const ref = doc(db, 'players', uid);
  const lbRef = doc(db, 'leaderboard', uid);
  const akharaName = sanitizeAkharaName(rawName);
  try {
    const payload: Record<string, unknown> = {
      akharaName,
      updatedAt: serverTimestamp(),
    };
    if (typeof photoUrl === 'string') {
      payload.photoUrl = sanitizePhotoUrl(photoUrl);
    }
    await updateDoc(ref, payload);
    try {
      await updateDoc(lbRef, payload);
    } catch {
      // Ignore if leaderboard entry does not exist yet
    }
    return akharaName;
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function updatePlayerLoadout(
  uid: string,
  fighterId: string,
  arenaId: ArenaId,
): Promise<void> {
  const path = `players/${uid}`;
  const ref = doc(db, 'players', uid);
  const lbRef = doc(db, 'leaderboard', uid);
  const safeFighter = sanitizeFighterId(fighterId);
  try {
    await updateDoc(ref, {
      favoriteFighterId: safeFighter,
      favoriteArenaId: sanitizeArenaId(arenaId),
      updatedAt: serverTimestamp(),
    });
    try {
      await updateDoc(lbRef, {
        favoriteFighterId: safeFighter,
        updatedAt: serverTimestamp(),
      });
    } catch {
      // Ignore if leaderboard entry not yet created
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

function buildNextEquippedSkins(curEquipped: string[], newSkinId: string): string[] {
  const newSkin = getSkinById(newSkinId);
  if (!newSkin) return curEquipped;
  const filtered = curEquipped.filter((id) => {
    const existingSkin = getSkinById(id);
    return existingSkin && existingSkin.fighterId !== newSkin.fighterId;
  });
  return [...filtered, newSkin.id].slice(0, 10);
}

export async function unlockCosmeticItem(
  uid: string,
  item: CosmeticItem,
  payCurrency?: CosmeticCurrency,
  cmsConfig?: LiveCmsConfig | null,
): Promise<void> {
  const effective = getEffectiveCosmeticPricing(item, cmsConfig);
  if (effective.gotaPrice <= 0 || !ALL_COSMETIC_IDS.includes(item.id)) {
    throw new Error('This cosmetic is already free.');
  }
  const chosenCurrency: CosmeticCurrency = payCurrency || item.currency;
  if (chosenCurrency === 'futi_kodi' && effective.fkPrice === null) {
    throw new Error('Premium Crown cosmetics can only be unlocked with Gota.');
  }
  const cost = chosenCurrency === 'futi_kodi' ? (effective.fkPrice as number) : effective.gotaPrice;

  const path = `players/${uid}`;
  const ref = doc(db, 'players', uid);
  try {
    await runTransaction(db, async (tx) => {
      const snap = await tx.get(ref);
      if (!snap.exists()) return;
      const cur = normalizePlayerProfile(snap.data() as RawPlayerDoc);
      if (cur.unlockedCosmetics.includes(item.id)) return;

      if (!cur.isDeveloper) {
        if (chosenCurrency === 'futi_kodi') {
          if (cur.futiKodi < cost) {
            throw new Error(`Need ${cost} Futi Kodi.`);
          }
        } else {
          if (cur.gota < cost) {
            throw new Error(`Need ${cost} Gota.`);
          }
        }
      }

      const nextFutiKodi = cur.isDeveloper
        ? 9999999
        : chosenCurrency === 'futi_kodi'
          ? cur.futiKodi - cost
          : cur.futiKodi;
      const nextGota = cur.isDeveloper
        ? 9999999
        : chosenCurrency === 'gota'
          ? cur.gota - cost
          : cur.gota;
      const nextUnlocked = [...cur.unlockedCosmetics, item.id];
      const nextEquippedSkins =
        item.category === 'skin' ? buildNextEquippedSkins(cur.equippedSkinIds, item.id) : cur.equippedSkinIds;
      const nextAura = item.category === 'aura' ? item.id : cur.equippedAuraId;

      tx.update(ref, {
        futiKodi: nextFutiKodi,
        gota: nextGota,
        unlockedCosmetics: nextUnlocked,
        equippedSkinIds: nextEquippedSkins,
        equippedAuraId: nextAura,
        updatedAt: serverTimestamp(),
      });
    });
  } catch (error) {
    if (
      error instanceof Error &&
      (error.message.includes('Futi Kodi') || error.message.includes('Gota') || error.message.includes('Premium'))
    ) {
      throw error;
    }
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function unlockVictoryPose(
  uid: string,
  fighterId: string,
  poseId: string,
  payCurrency: CosmeticCurrency,
  cmsConfig?: LiveCmsConfig | null,
): Promise<void> {
  if (!ALL_UNLOCKABLE_POSE_IDS.includes(poseId)) {
    throw new Error('This victory pose is already free.');
  }
  const pricing = getEffectivePosePricing(fighterId, poseId, cmsConfig);
  const cost = payCurrency === 'futi_kodi' ? pricing.fkPrice : pricing.gotaPrice;
  if (cost <= 0) {
    throw new Error('This victory pose is already free.');
  }

  const path = `players/${uid}`;
  const ref = doc(db, 'players', uid);
  try {
    await runTransaction(db, async (tx) => {
      const snap = await tx.get(ref);
      if (!snap.exists()) return;
      const cur = normalizePlayerProfile(snap.data() as RawPlayerDoc);
      if (cur.unlockedPoses.includes(poseId)) return;

      if (!cur.isDeveloper) {
        if (payCurrency === 'futi_kodi') {
          if (cur.futiKodi < cost) {
            throw new Error(`Need ${cost} Futi Kodi.`);
          }
        } else {
          if (cur.gota < cost) {
            throw new Error(`Need ${cost} Gota.`);
          }
        }
      }

      const nextFutiKodi = cur.isDeveloper
        ? 9999999
        : payCurrency === 'futi_kodi'
          ? cur.futiKodi - cost
          : cur.futiKodi;
      const nextGota = cur.isDeveloper
        ? 9999999
        : payCurrency === 'gota'
          ? cur.gota - cost
          : cur.gota;
      const nextUnlockedPoses = [...cur.unlockedPoses, poseId];

      tx.update(ref, {
        futiKodi: nextFutiKodi,
        gota: nextGota,
        unlockedPoses: nextUnlockedPoses,
        updatedAt: serverTimestamp(),
      });
    });
  } catch (error) {
    if (error instanceof Error && (error.message.includes('Futi Kodi') || error.message.includes('Gota'))) {
      throw error;
    }
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function purchaseBundleCloud(uid: string, bundle: CmsBundleDef): Promise<void> {
  const path = `players/${uid}`;
  const ref = doc(db, 'players', uid);
  const cost = Math.max(1, Math.round(bundle.gotaPrice));

  const cosmeticIdsToAdd: string[] = [];
  const poseIdsToAdd: string[] = [];
  let equipAuraId: string | null = null;
  const equipSkinIds: string[] = [];

  for (const token of bundle.itemIds) {
    const decoded = decodeBundleToken(token);
    if (!decoded) continue;
    if (decoded.kind === 'cosmetic') {
      if (ALL_COSMETIC_IDS.includes(decoded.cosmetic.id)) {
        cosmeticIdsToAdd.push(decoded.cosmetic.id);
        if (decoded.cosmetic.category === 'skin') {
          equipSkinIds.push(decoded.cosmetic.id);
        } else if (decoded.cosmetic.category === 'aura') {
          equipAuraId = decoded.cosmetic.id;
        }
      }
    } else if (ALL_UNLOCKABLE_POSE_IDS.includes(decoded.pose.id)) {
      poseIdsToAdd.push(decoded.pose.id);
    }
  }

  try {
    await runTransaction(db, async (tx) => {
      const snap = await tx.get(ref);
      if (!snap.exists()) return;
      const cur = normalizePlayerProfile(snap.data() as RawPlayerDoc);

      const newCosmetics = cosmeticIdsToAdd.filter((id) => !cur.unlockedCosmetics.includes(id));
      const newPoses = poseIdsToAdd.filter((id) => !cur.unlockedPoses.includes(id));
      if (newCosmetics.length === 0 && newPoses.length === 0) return;

      if (!cur.isDeveloper && cur.gota < cost) {
        throw new Error(`Need ${cost} Gota.`);
      }

      const nextGota = cur.isDeveloper ? 9999999 : cur.gota - cost;
      const nextFutiKodi = cur.isDeveloper ? 9999999 : cur.futiKodi;
      const nextUnlockedCosmetics = Array.from(new Set([...cur.unlockedCosmetics, ...newCosmetics])).slice(0, 40);
      const nextUnlockedPoses = Array.from(new Set([...cur.unlockedPoses, ...newPoses])).slice(0, 20);
      let nextEquippedSkins = [...cur.equippedSkinIds];
      for (const sid of equipSkinIds) {
        if (nextUnlockedCosmetics.includes(sid)) {
          nextEquippedSkins = buildNextEquippedSkins(nextEquippedSkins, sid);
        }
      }
      const nextAura =
        equipAuraId && nextUnlockedCosmetics.includes(equipAuraId) ? equipAuraId : cur.equippedAuraId;

      tx.update(ref, {
        futiKodi: nextFutiKodi,
        gota: nextGota,
        unlockedCosmetics: nextUnlockedCosmetics,
        unlockedPoses: nextUnlockedPoses,
        equippedSkinIds: nextEquippedSkins,
        equippedAuraId: nextAura,
        updatedAt: serverTimestamp(),
      });
    });
  } catch (error) {
    if (error instanceof Error && error.message.includes('Gota')) {
      throw error;
    }
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

const DEV_MODE_STORAGE_KEY = 'gc_dev_mode';

function devModeStorageKey(uid?: string | null): string {
  return uid ? `${DEV_MODE_STORAGE_KEY}_${uid}` : DEV_MODE_STORAGE_KEY;
}

function devBackupStorageKey(uid: string): string {
  return `gc_dev_saved_balances_${uid}`;
}

export function getSavedLocalDevMode(uid?: string | null): boolean {
  try {
    if (uid) {
      const perUid = window.localStorage.getItem(devModeStorageKey(uid));
      if (perUid !== null) return perUid === '1';
    }
    return window.localStorage.getItem(DEV_MODE_STORAGE_KEY) === '1';
  } catch {
    return false;
  }
}

export function setSavedLocalDevMode(active: boolean, uid?: string | null): void {
  try {
    window.localStorage.setItem(DEV_MODE_STORAGE_KEY, active ? '1' : '0');
    if (uid) {
      window.localStorage.setItem(devModeStorageKey(uid), active ? '1' : '0');
    }
  } catch {
    // ignore storage quota errors
  }
}

function saveLocalPreDevBalances(uid: string, futiKodi: number, gota: number): void {
  try {
    window.localStorage.setItem(
      devBackupStorageKey(uid),
      JSON.stringify({ futiKodi: Math.max(0, Math.round(futiKodi)), gota: Math.max(0, Math.round(gota)) }),
    );
  } catch {
    // ignore
  }
}

function readLocalPreDevBalances(uid: string): { futiKodi: number; gota: number } | null {
  try {
    const raw = window.localStorage.getItem(devBackupStorageKey(uid));
    if (!raw) return null;
    const parsed = JSON.parse(raw) as { futiKodi?: unknown; gota?: unknown };
    if (typeof parsed.futiKodi === 'number' && typeof parsed.gota === 'number') {
      return {
        futiKodi: Math.max(0, Math.min(10000000, Math.round(parsed.futiKodi))),
        gota: Math.max(0, Math.min(10000000, Math.round(parsed.gota))),
      };
    }
    return null;
  } catch {
    return null;
  }
}

export async function unlockDeveloperMode(uid: string, rawCode: string): Promise<void> {
  const code = String(rawCode || '').trim().toUpperCase();
  if (!code) {
    throw new Error('Please enter a Developer Code.');
  }
  if (code !== 'OHIIT1310') {
    throw new Error('Invalid Developer Code.');
  }
  const playerRef = doc(db, 'players', uid);
  const devRef = doc(db, 'players', uid, 'private', 'dev');
  const lbRef = doc(db, 'leaderboard', uid);

  let savedFutiKodi = STARTER_FUTI_KODI;
  let savedGota = STARTER_GOTA;
  let alreadyDev = false;
  try {
    const pSnap = await getDoc(playerRef);
    if (pSnap.exists()) {
      const cur = normalizePlayerProfile(pSnap.data() as RawPlayerDoc);
      alreadyDev = cur.isDeveloper;
      if (!cur.isDeveloper) {
        savedFutiKodi = cur.futiKodi;
        savedGota = cur.gota;
      }
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `players/${uid}`);
  }

  if (alreadyDev) {
    setSavedLocalDevMode(true, uid);
    return;
  }

  saveLocalPreDevBalances(uid, savedFutiKodi, savedGota);

  let lbExists = false;
  try {
    const lbSnap = await getDoc(lbRef);
    lbExists = lbSnap.exists();
  } catch {
    lbExists = false;
  }

  let devExists = false;
  try {
    const devSnap = await getDoc(devRef);
    devExists = devSnap.exists();
  } catch {
    devExists = false;
  }

  try {
    const batch = writeBatch(db);
    if (!devExists) {
      batch.set(devRef, {
        uid,
        code,
        savedFutiKodi,
        savedGota,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } else {
      batch.update(devRef, {
        code,
        savedFutiKodi,
        savedGota,
        updatedAt: serverTimestamp(),
      });
    }
    batch.update(playerRef, {
      isDeveloper: true,
      futiKodi: 9999999,
      gota: 9999999,
      updatedAt: serverTimestamp(),
    });
    if (lbExists) {
      batch.update(lbRef, {
        isDeveloper: true,
        updatedAt: serverTimestamp(),
      });
    }
    await batch.commit();
    setSavedLocalDevMode(true, uid);
  } catch (error) {
    const msg = error instanceof Error ? error.message.toLowerCase() : '';
    if (msg.includes('permission') || msg.includes('insufficient')) {
      throw new Error('Invalid Developer Code.');
    }
    handleFirestoreError(error, OperationType.UPDATE, `players/${uid}`);
  }
}

export async function deactivateDeveloperMode(uid: string): Promise<{ futiKodi: number; gota: number }> {
  const playerRef = doc(db, 'players', uid);
  const devRef = doc(db, 'players', uid, 'private', 'dev');
  const lbRef = doc(db, 'leaderboard', uid);

  let restoredFutiKodi = STARTER_FUTI_KODI;
  let restoredGota = STARTER_GOTA;
  let hasServerSaved = false;

  try {
    const devSnap = await getDoc(devRef);
    if (devSnap.exists()) {
      const d = devSnap.data() as { savedFutiKodi?: unknown; savedGota?: unknown };
      if (typeof d.savedFutiKodi === 'number' && typeof d.savedGota === 'number') {
        restoredFutiKodi = Math.max(0, Math.min(10000000, Math.round(d.savedFutiKodi)));
        restoredGota = Math.max(0, Math.min(10000000, Math.round(d.savedGota)));
        hasServerSaved = true;
      }
    }
  } catch {
    // fallback below
  }

  if (!hasServerSaved) {
    const localSaved = readLocalPreDevBalances(uid);
    if (localSaved && localSaved.futiKodi < 9999999 && localSaved.gota < 9999999) {
      // Only use local backup if server rule branch matches (legacy fallback is 150 / 0)
      restoredFutiKodi = STARTER_FUTI_KODI;
      restoredGota = STARTER_GOTA;
    }
  }

  let lbExists = false;
  try {
    const lbSnap = await getDoc(lbRef);
    lbExists = lbSnap.exists();
  } catch {
    lbExists = false;
  }

  try {
    const batch = writeBatch(db);
    batch.update(playerRef, {
      isDeveloper: false,
      futiKodi: restoredFutiKodi,
      gota: restoredGota,
      updatedAt: serverTimestamp(),
    });
    if (lbExists) {
      batch.update(lbRef, {
        isDeveloper: false,
        updatedAt: serverTimestamp(),
      });
    }
    await batch.commit();
    setSavedLocalDevMode(false, uid);
    return { futiKodi: restoredFutiKodi, gota: restoredGota };
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `players/${uid}`);
  }
}

export async function equipCosmeticItem(uid: string, category: 'skin' | 'aura', cosmeticId: string): Promise<void> {
  const path = `players/${uid}`;
  const ref = doc(db, 'players', uid);
  try {
    await runTransaction(db, async (tx) => {
      const snap = await tx.get(ref);
      if (!snap.exists()) return;
      const cur = normalizePlayerProfile(snap.data() as RawPlayerDoc);
      if (!cur.unlockedCosmetics.includes(cosmeticId)) {
        throw new Error('Cosmetic is not unlocked yet.');
      }
      const nextEquippedSkins =
        category === 'skin' ? buildNextEquippedSkins(cur.equippedSkinIds, cosmeticId) : cur.equippedSkinIds;
      const nextAura = category === 'aura' ? cosmeticId : cur.equippedAuraId;

      tx.update(ref, {
        equippedSkinIds: nextEquippedSkins,
        equippedAuraId: nextAura,
        updatedAt: serverTimestamp(),
      });
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function unequipSkinForFighter(uid: string, fighterId: string): Promise<void> {
  const path = `players/${uid}`;
  const ref = doc(db, 'players', uid);
  try {
    await runTransaction(db, async (tx) => {
      const snap = await tx.get(ref);
      if (!snap.exists()) return;
      const cur = normalizePlayerProfile(snap.data() as RawPlayerDoc);
      const nextEquippedSkins = cur.equippedSkinIds.filter((id) => getSkinById(id)?.fighterId !== fighterId);
      tx.update(ref, {
        equippedSkinIds: nextEquippedSkins,
        updatedAt: serverTimestamp(),
      });
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function unequipAuraCosmetic(uid: string): Promise<void> {
  const path = `players/${uid}`;
  const ref = doc(db, 'players', uid);
  try {
    await runTransaction(db, async (tx) => {
      const snap = await tx.get(ref);
      if (!snap.exists()) return;
      tx.update(ref, {
        equippedAuraId: DEFAULT_AURA_ID,
        updatedAt: serverTimestamp(),
      });
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export function computeMatchFutiKodiEarned(didWin: boolean, comboStreak: number): number {
  const base = didWin ? 80 : 35;
  const comboBonus = comboStreak >= 5 ? 15 : 0;
  return base + comboBonus;
}

export async function recordPlayerMatchResult(
  uid: string,
  didWin: boolean,
  comboStreak: number,
  fighterId: string,
  arenaId: ArenaId,
): Promise<number> {
  const path = `players/${uid}`;
  const ref = doc(db, 'players', uid);
  const lbRef = doc(db, 'leaderboard', uid);
  const safeCombo = Math.max(0, Math.min(999, Math.round(comboStreak)));
  const safeFighter = sanitizeFighterId(fighterId);
  const safeArena = sanitizeArenaId(arenaId);
  const earnedFutiKodi = computeMatchFutiKodiEarned(didWin, safeCombo);

  try {
    await runTransaction(db, async (tx) => {
      const snap = await tx.get(ref);
      if (!snap.exists()) return;
      const cur = normalizePlayerProfile(snap.data() as RawPlayerDoc);
      const lbSnap = await tx.get(lbRef);

      const nextWins = Math.min(1000000, cur.wins + (didWin ? 1 : 0));
      const nextLosses = Math.min(1000000, cur.losses + (didWin ? 0 : 1));
      const nextMatches = Math.min(2000000, cur.matchesPlayed + 1);
      const nextBestCombo = Math.max(cur.bestCombo || 0, safeCombo);
      const nextRankPoints = nextWins * 100 + nextBestCombo * 5;
      const nextFutiKodi = Math.min(10000000, cur.futiKodi + earnedFutiKodi);

      tx.update(ref, {
        wins: nextWins,
        losses: nextLosses,
        matchesPlayed: nextMatches,
        bestCombo: nextBestCombo,
        futiKodi: nextFutiKodi,
        favoriteFighterId: safeFighter,
        favoriteArenaId: safeArena,
        updatedAt: serverTimestamp(),
      });

      if (lbSnap.exists()) {
        tx.update(lbRef, {
          wins: nextWins,
          losses: nextLosses,
          matchesPlayed: nextMatches,
          bestCombo: nextBestCombo,
          rankPoints: nextRankPoints,
          favoriteFighterId: safeFighter,
          updatedAt: serverTimestamp(),
        });
      }
    });
    return earnedFutiKodi;
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export function unlockCosmeticLocal(
  item: CosmeticItem,
  payCurrency: CosmeticCurrency,
  isDevActive: boolean,
  cmsConfig?: LiveCmsConfig | null,
): PlayerProfile {
  const effective = getEffectiveCosmeticPricing(item, cmsConfig);
  if (effective.gotaPrice <= 0 || !ALL_COSMETIC_IDS.includes(item.id)) {
    throw new Error('This cosmetic is already free.');
  }
  if (payCurrency === 'futi_kodi' && effective.fkPrice === null) {
    throw new Error('Premium Crown cosmetics can only be unlocked with Gota.');
  }
  const cost = payCurrency === 'futi_kodi' ? (effective.fkPrice as number) : effective.gotaPrice;
  const cur = readGuestWallet(false);
  if (!cur.unlockedCosmetics.includes(item.id)) {
    if (!isDevActive) {
      if (payCurrency === 'futi_kodi' && cur.futiKodi < cost) {
        throw new Error(`Need ${cost} Futi Kodi.`);
      }
      if (payCurrency === 'gota' && cur.gota < cost) {
        throw new Error(`Need ${cost} Gota.`);
      }
    }
    const nextFutiKodi = isDevActive ? cur.futiKodi : payCurrency === 'futi_kodi' ? cur.futiKodi - cost : cur.futiKodi;
    const nextGota = isDevActive ? cur.gota : payCurrency === 'gota' ? cur.gota - cost : cur.gota;
    const nextUnlocked = [...cur.unlockedCosmetics, item.id];
    const nextEquippedSkins =
      item.category === 'skin' ? buildNextEquippedSkins(cur.equippedSkinIds, item.id) : cur.equippedSkinIds;
    const nextAura = item.category === 'aura' ? item.id : cur.equippedAuraId;
    writeGuestWallet({
      ...cur,
      futiKodi: nextFutiKodi,
      gota: nextGota,
      unlockedCosmetics: nextUnlocked,
      equippedSkinIds: nextEquippedSkins,
      equippedAuraId: nextAura,
    });
  }
  return readGuestWallet(isDevActive);
}

export function equipCosmeticLocal(
  category: 'skin' | 'aura',
  cosmeticId: string,
  isDevActive: boolean,
): PlayerProfile {
  const cur = readGuestWallet(false);
  if (!cur.unlockedCosmetics.includes(cosmeticId)) {
    throw new Error('Cosmetic is not unlocked yet.');
  }
  const nextEquippedSkins =
    category === 'skin' ? buildNextEquippedSkins(cur.equippedSkinIds, cosmeticId) : cur.equippedSkinIds;
  const nextAura = category === 'aura' ? cosmeticId : cur.equippedAuraId;
  writeGuestWallet({
    ...cur,
    equippedSkinIds: nextEquippedSkins,
    equippedAuraId: nextAura,
  });
  return readGuestWallet(isDevActive);
}

export function unequipSkinForFighterLocal(fighterId: string, isDevActive: boolean): PlayerProfile {
  const cur = readGuestWallet(false);
  const nextEquippedSkins = cur.equippedSkinIds.filter((id) => getSkinById(id)?.fighterId !== fighterId);
  writeGuestWallet({
    ...cur,
    equippedSkinIds: nextEquippedSkins,
  });
  return readGuestWallet(isDevActive);
}

export function unequipAuraLocal(isDevActive: boolean): PlayerProfile {
  const cur = readGuestWallet(false);
  writeGuestWallet({
    ...cur,
    equippedAuraId: DEFAULT_AURA_ID,
  });
  return readGuestWallet(isDevActive);
}

export function unlockVictoryPoseLocal(
  fighterId: string,
  poseId: string,
  payCurrency: CosmeticCurrency,
  isDevActive: boolean,
  cmsConfig?: LiveCmsConfig | null,
): PlayerProfile {
  if (!ALL_UNLOCKABLE_POSE_IDS.includes(poseId)) {
    throw new Error('This victory pose is already free.');
  }
  const pricing = getEffectivePosePricing(fighterId, poseId, cmsConfig);
  const cost = payCurrency === 'futi_kodi' ? pricing.fkPrice : pricing.gotaPrice;
  if (cost <= 0) {
    throw new Error('This victory pose is already free.');
  }
  const cur = readGuestWallet(false);
  if (!cur.unlockedPoses.includes(poseId)) {
    if (!isDevActive) {
      if (payCurrency === 'futi_kodi' && cur.futiKodi < cost) {
        throw new Error(`Need ${cost} Futi Kodi.`);
      }
      if (payCurrency === 'gota' && cur.gota < cost) {
        throw new Error(`Need ${cost} Gota.`);
      }
    }
    const nextFutiKodi = isDevActive ? cur.futiKodi : payCurrency === 'futi_kodi' ? cur.futiKodi - cost : cur.futiKodi;
    const nextGota = isDevActive ? cur.gota : payCurrency === 'gota' ? cur.gota - cost : cur.gota;
    writeGuestWallet({
      ...cur,
      futiKodi: nextFutiKodi,
      gota: nextGota,
      unlockedPoses: [...cur.unlockedPoses, poseId],
    });
  }
  return readGuestWallet(isDevActive);
}

export function purchaseBundleLocal(bundle: CmsBundleDef, isDevActive: boolean): PlayerProfile {
  const cur = readGuestWallet(false);
  const cost = Math.max(1, Math.round(bundle.gotaPrice));

  const cosmeticIdsToAdd: string[] = [];
  const poseIdsToAdd: string[] = [];
  let equipAuraId: string | null = null;
  const equipSkinIds: string[] = [];

  for (const token of bundle.itemIds) {
    const decoded = decodeBundleToken(token);
    if (!decoded) continue;
    if (decoded.kind === 'cosmetic') {
      if (ALL_COSMETIC_IDS.includes(decoded.cosmetic.id)) {
        cosmeticIdsToAdd.push(decoded.cosmetic.id);
        if (decoded.cosmetic.category === 'skin') {
          equipSkinIds.push(decoded.cosmetic.id);
        } else if (decoded.cosmetic.category === 'aura') {
          equipAuraId = decoded.cosmetic.id;
        }
      }
    } else if (ALL_UNLOCKABLE_POSE_IDS.includes(decoded.pose.id)) {
      poseIdsToAdd.push(decoded.pose.id);
    }
  }

  const newCosmetics = cosmeticIdsToAdd.filter((id) => !cur.unlockedCosmetics.includes(id));
  const newPoses = poseIdsToAdd.filter((id) => !cur.unlockedPoses.includes(id));
  if (newCosmetics.length > 0 || newPoses.length > 0) {
    if (!isDevActive && cur.gota < cost) {
      throw new Error(`Need ${cost} Gota.`);
    }
    const nextGota = isDevActive ? cur.gota : cur.gota - cost;
    const nextUnlockedCosmetics = Array.from(new Set([...cur.unlockedCosmetics, ...newCosmetics])).slice(0, 40);
    const nextUnlockedPoses = Array.from(new Set([...cur.unlockedPoses, ...newPoses])).slice(0, 20);
    let nextEquippedSkins = [...cur.equippedSkinIds];
    for (const sid of equipSkinIds) {
      if (nextUnlockedCosmetics.includes(sid)) {
        nextEquippedSkins = buildNextEquippedSkins(nextEquippedSkins, sid);
      }
    }
    const nextAura =
      equipAuraId && nextUnlockedCosmetics.includes(equipAuraId) ? equipAuraId : cur.equippedAuraId;

    writeGuestWallet({
      ...cur,
      gota: nextGota,
      unlockedCosmetics: nextUnlockedCosmetics,
      unlockedPoses: nextUnlockedPoses,
      equippedSkinIds: nextEquippedSkins,
      equippedAuraId: nextAura,
    });
  }
  return readGuestWallet(isDevActive);
}

export function recordGuestMatchResult(
  didWin: boolean,
  comboStreak: number,
  fighterId: string,
  arenaId: ArenaId,
  isDevActive: boolean,
): { earned: number; wallet: PlayerProfile } {
  const cur = readGuestWallet(false);
  const safeCombo = Math.max(0, Math.min(999, Math.round(comboStreak)));
  const earned = computeMatchFutiKodiEarned(didWin, safeCombo);
  writeGuestWallet({
    ...cur,
    wins: Math.min(1000000, cur.wins + (didWin ? 1 : 0)),
    losses: Math.min(1000000, cur.losses + (didWin ? 0 : 1)),
    matchesPlayed: Math.min(2000000, cur.matchesPlayed + 1),
    bestCombo: Math.max(cur.bestCombo || 0, safeCombo),
    futiKodi: Math.min(10000000, cur.futiKodi + earned),
    favoriteFighterId: sanitizeFighterId(fighterId),
    favoriteArenaId: sanitizeArenaId(arenaId),
  });
  return { earned, wallet: readGuestWallet(isDevActive) };
}

