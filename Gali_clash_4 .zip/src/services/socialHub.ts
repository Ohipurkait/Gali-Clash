import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDoc,
  limit,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  Timestamp,
  Unsubscribe,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { sanitizeAkharaName } from './playerAccount';

export interface LeaderboardEntry {
  uid: string;
  akharaName: string;
  photoUrl: string;
  favoriteFighterId: string;
  wins: number;
  losses: number;
  matchesPlayed: number;
  bestCombo: number;
  rankPoints: number;
  isDeveloper?: boolean;
  updatedAt?: Timestamp;
}

export type ChatMessageTag = 'chat' | 'challenge' | 'gg';

export interface GlobalChatMessage {
  id: string;
  uid: string;
  akharaName: string;
  photoUrl: string;
  text: string;
  tag: ChatMessageTag;
  roomCode: string;
  isDeveloper?: boolean;
  createdAt?: Timestamp | null;
}

export function subscribeLeaderboard(
  onEntries: (entries: LeaderboardEntry[]) => void,
  onError?: (err: unknown) => void,
): Unsubscribe {
  const colRef = collection(db, 'leaderboard');
  const q = query(colRef, orderBy('rankPoints', 'desc'), limit(20));
  return onSnapshot(
    q,
    (snap) => {
      const list: LeaderboardEntry[] = [];
      snap.forEach((docSnap) => {
        list.push(docSnap.data() as LeaderboardEntry);
      });
      onEntries(list);
    },
    (error) => {
      if (onError) onError(error);
      try {
        handleFirestoreError(error, OperationType.LIST, 'leaderboard');
      } catch {
        // Already surfaced via onError
      }
    },
  );
}

export function subscribeGlobalChat(
  onMessages: (messages: GlobalChatMessage[]) => void,
  onError?: (err: unknown) => void,
): Unsubscribe {
  const colRef = collection(db, 'globalChat');
  const q = query(colRef, orderBy('createdAt', 'desc'), limit(20));
  return onSnapshot(
    q,
    (snap) => {
      const items: GlobalChatMessage[] = [];
      snap.forEach((docSnap) => {
        const d = docSnap.data() as Omit<GlobalChatMessage, 'id'>;
        items.push({ id: docSnap.id, ...d });
      });
      // Reverse to chronological order for chat feed
      items.reverse();
      onMessages(items);
    },
    (error) => {
      if (onError) onError(error);
      try {
        handleFirestoreError(error, OperationType.LIST, 'globalChat');
      } catch {
        // Already surfaced via onError
      }
    },
  );
}

export async function fetchPublicPlayerProfile(uid: string): Promise<LeaderboardEntry | null> {
  const path = `leaderboard/${uid}`;
  try {
    const snap = await getDoc(doc(db, 'leaderboard', uid));
    return snap.exists() ? (snap.data() as LeaderboardEntry) : null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function sendGlobalChatMessage(params: {
  uid: string;
  akharaName: string;
  photoUrl?: string | null;
  text: string;
  tag: ChatMessageTag;
  roomCode?: string;
  isDeveloper?: boolean;
}): Promise<void> {
  const cleanText = String(params.text || '').replace(/\s+/g, ' ').trim().slice(0, 180);
  if (!cleanText) return;

  const cleanRoom = String(params.roomCode || '').trim().toUpperCase().slice(0, 10);
  const payload = {
    uid: params.uid,
    akharaName: sanitizeAkharaName(params.akharaName),
    photoUrl: String(params.photoUrl || '').slice(0, 512),
    text: cleanText,
    tag: params.tag,
    roomCode: cleanRoom,
    isDeveloper: Boolean(params.isDeveloper),
    createdAt: serverTimestamp(),
  };

  try {
    await addDoc(collection(db, 'globalChat'), payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, 'globalChat');
  }
}

export async function deleteOwnChatMessage(msgId: string): Promise<void> {
  const path = `globalChat/${msgId}`;
  try {
    await deleteDoc(doc(db, 'globalChat', msgId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}
