import { User } from 'firebase/auth';
import { doc, getDoc, serverTimestamp, updateDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { ARENAS, FIGHTERS } from '../game/data';
import { ArenaId } from '../game/types';
import {
  normalizePlayerProfile,
  PlayerProfile,
  readGuestWallet,
  writeCachedPlayerProfile,
  writeGuestWallet,
} from './playerAccount';

export type QuestSlotId = 'slot1' | 'slot2' | 'slot3';

export type QuestMetricKind =
  | 'play_match'
  | 'basic_hit'
  | 'play_fighter'
  | 'special_fighter'
  | 'win_fighter'
  | 'win_arena'
  | 'counter_hit';

export interface DailyQuestItem {
  slot: QuestSlotId;
  questKey: string; // YYYY-MM-DD:slotN
  tierLabel: 'Easy' | 'Yoddha' | 'Master';
  title: string;
  description: string;
  metric: QuestMetricKind;
  targetFighterId?: string;
  targetArenaId?: ArenaId;
  targetCount: number;
  rewardFk: number; // strictly 10..50
  progress: number;
  claimed: boolean;
}

interface StoredDailyQuests {
  dateString: string;
  dateKey: string; // YYYY-MM-DD
  progressBySlot: Record<QuestSlotId, number>;
  claimedBySlot: Record<QuestSlotId, boolean>;
}

const DAILY_QUESTS_KEY = 'gc_daily_quests_v1';

export function getTodayStrings(): { dateString: string; dateKey: string } {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return {
    dateString: now.toDateString(),
    dateKey: `${y}-${m}-${d}`,
  };
}

function hashSeed(input: string): number {
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h >>> 0);
}

interface QuestTemplate {
  slot: QuestSlotId;
  tierLabel: 'Easy' | 'Yoddha' | 'Master';
  title: string;
  description: string;
  metric: QuestMetricKind;
  targetFighterId?: string;
  targetArenaId?: ArenaId;
  targetCount: number;
  rewardFk: number;
}

function buildDailyQuestTemplates(dateString: string, dateKey: string): QuestTemplate[] {
  const h = hashSeed(dateString);

  // Slot 1: Easy Warmup (10 FK to 15 FK)
  const slot1Pool: Omit<QuestTemplate, 'slot' | 'tierLabel'>[] = [
    {
      title: 'Akhara Warmup',
      description: 'Play 1 Match in Bot or 1v1 mode',
      metric: 'play_match',
      targetCount: 1,
      rewardFk: 10,
    },
    {
      title: 'Gali Brawler',
      description: 'Land 5 Punches or Kicks in real matches',
      metric: 'basic_hit',
      targetCount: 5,
      rewardFk: 15,
    },
  ];
  const s1 = slot1Pool[h % slot1Pool.length];

  // Slot 2: Specific Fighter Challenge (20 FK to 30 FK)
  const f2 = FIGHTERS[(h >>> 3) % FIGHTERS.length];
  const slot2Variant = (h >>> 7) % 3;
  const s2: Omit<QuestTemplate, 'slot' | 'tierLabel'> =
    slot2Variant === 0
      ? {
          title: `${f2.name} Call-Up`,
          description: `Play 1 Match with ${f2.name}`,
          metric: 'play_fighter',
          targetFighterId: f2.id,
          targetCount: 1,
          rewardFk: 20,
        }
      : slot2Variant === 1
        ? {
            title: `${f2.name} Shastra`,
            description: `Use Shastra/Astra 3 times with ${f2.name}`,
            metric: 'special_fighter',
            targetFighterId: f2.id,
            targetCount: 3,
            rewardFk: 25,
          }
        : {
            title: `${f2.name} Victory`,
            description: `Win 1 Match with ${f2.name}`,
            metric: 'win_fighter',
            targetFighterId: f2.id,
            targetCount: 1,
            rewardFk: 30,
          };

  // Slot 3: Mastery Challenge (35 FK to 50 FK)
  const f3 = FIGHTERS[((h >>> 11) + 3) % FIGHTERS.length];
  const arenaIds: ArenaId[] = ['chandni', 'howrah', 'banaras'];
  const a3Id = arenaIds[(h >>> 15) % arenaIds.length];
  const a3 = ARENAS[a3Id];
  const slot3Variant = (h >>> 19) % 3;
  const s3: Omit<QuestTemplate, 'slot' | 'tierLabel'> =
    slot3Variant === 0
      ? {
          title: `${f3.name} Ustad`,
          description: `Win 3 Matches with ${f3.name}`,
          metric: 'win_fighter',
          targetFighterId: f3.id,
          targetCount: 3,
          rewardFk: 50,
        }
      : slot3Variant === 1
        ? {
            title: `${a3.name} King`,
            description: `Win 2 Matches in ${a3.name}`,
            metric: 'win_arena',
            targetArenaId: a3Id,
            targetCount: 2,
            rewardFk: 40,
          }
        : {
            title: 'Counter Ustad',
            description: 'Land 3 Counter-Hits against rivals',
            metric: 'counter_hit',
            targetCount: 3,
            rewardFk: 35,
          };

  void dateKey;
  return [
    { slot: 'slot1', tierLabel: 'Easy', ...s1 },
    { slot: 'slot2', tierLabel: 'Yoddha', ...s2 },
    { slot: 'slot3', tierLabel: 'Master', ...s3 },
  ];
}

function readStoredState(dateString: string, dateKey: string): StoredDailyQuests {
  const empty: StoredDailyQuests = {
    dateString,
    dateKey,
    progressBySlot: { slot1: 0, slot2: 0, slot3: 0 },
    claimedBySlot: { slot1: false, slot2: false, slot3: false },
  };
  try {
    const raw = window.localStorage.getItem(DAILY_QUESTS_KEY);
    if (!raw) return empty;
    const parsed = JSON.parse(raw) as Partial<StoredDailyQuests>;
    if (parsed.dateString !== dateString) {
      return empty;
    }
    return {
      dateString,
      dateKey,
      progressBySlot: {
        slot1: Math.max(0, Number(parsed.progressBySlot?.slot1) || 0),
        slot2: Math.max(0, Number(parsed.progressBySlot?.slot2) || 0),
        slot3: Math.max(0, Number(parsed.progressBySlot?.slot3) || 0),
      },
      claimedBySlot: {
        slot1: Boolean(parsed.claimedBySlot?.slot1),
        slot2: Boolean(parsed.claimedBySlot?.slot2),
        slot3: Boolean(parsed.claimedBySlot?.slot3),
      },
    };
  } catch {
    return empty;
  }
}

function writeStoredState(state: StoredDailyQuests): void {
  try {
    window.localStorage.setItem(DAILY_QUESTS_KEY, JSON.stringify(state));
  } catch {
    // ignore storage errors
  }
}

export function loadDailyQuests(): DailyQuestItem[] {
  const { dateString, dateKey } = getTodayStrings();
  const templates = buildDailyQuestTemplates(dateString, dateKey);
  const stored = readStoredState(dateString, dateKey);
  writeStoredState(stored);

  return templates.map((tpl) => {
    const rawProg = stored.progressBySlot[tpl.slot] || 0;
    return {
      ...tpl,
      questKey: `${dateKey}:${tpl.slot}`,
      progress: Math.min(tpl.targetCount, rawProg),
      claimed: Boolean(stored.claimedBySlot[tpl.slot]),
    };
  });
}

export function recordDailyQuestCombatMetric(metric: {
  kind: 'basic_hit' | 'special_use' | 'counter_hit';
  fighterId: string;
  arenaId: ArenaId;
}): DailyQuestItem[] {
  const { dateString, dateKey } = getTodayStrings();
  const templates = buildDailyQuestTemplates(dateString, dateKey);
  const stored = readStoredState(dateString, dateKey);
  let changed = false;

  for (const tpl of templates) {
    const cur = stored.progressBySlot[tpl.slot] || 0;
    if (cur >= tpl.targetCount) continue;

    if (tpl.metric === 'basic_hit' && metric.kind === 'basic_hit') {
      stored.progressBySlot[tpl.slot] = Math.min(tpl.targetCount, cur + 1);
      changed = true;
    } else if (
      tpl.metric === 'special_fighter' &&
      metric.kind === 'special_use' &&
      tpl.targetFighterId === metric.fighterId
    ) {
      stored.progressBySlot[tpl.slot] = Math.min(tpl.targetCount, cur + 1);
      changed = true;
    } else if (tpl.metric === 'counter_hit' && metric.kind === 'counter_hit') {
      stored.progressBySlot[tpl.slot] = Math.min(tpl.targetCount, cur + 1);
      changed = true;
    }
  }

  if (changed) writeStoredState(stored);
  return loadDailyQuests();
}

export function recordDailyQuestMatchComplete(params: {
  fighterId: string;
  arenaId: ArenaId;
  didWin: boolean;
}): DailyQuestItem[] {
  const { dateString, dateKey } = getTodayStrings();
  const templates = buildDailyQuestTemplates(dateString, dateKey);
  const stored = readStoredState(dateString, dateKey);
  let changed = false;

  for (const tpl of templates) {
    const cur = stored.progressBySlot[tpl.slot] || 0;
    if (cur >= tpl.targetCount) continue;

    if (tpl.metric === 'play_match') {
      stored.progressBySlot[tpl.slot] = Math.min(tpl.targetCount, cur + 1);
      changed = true;
    } else if (tpl.metric === 'play_fighter' && tpl.targetFighterId === params.fighterId) {
      stored.progressBySlot[tpl.slot] = Math.min(tpl.targetCount, cur + 1);
      changed = true;
    } else if (
      tpl.metric === 'win_fighter' &&
      params.didWin &&
      tpl.targetFighterId === params.fighterId
    ) {
      stored.progressBySlot[tpl.slot] = Math.min(tpl.targetCount, cur + 1);
      changed = true;
    } else if (
      tpl.metric === 'win_arena' &&
      params.didWin &&
      tpl.targetArenaId === params.arenaId
    ) {
      stored.progressBySlot[tpl.slot] = Math.min(tpl.targetCount, cur + 1);
      changed = true;
    }
  }

  if (changed) writeStoredState(stored);
  return loadDailyQuests();
}

export async function claimDailyQuestReward(params: {
  quest: DailyQuestItem;
  authUser: User | null;
  isLocalDevMode: boolean;
}): Promise<{ quests: DailyQuestItem[]; updatedProfile: PlayerProfile | null }> {
  const { quest, authUser, isLocalDevMode } = params;
  const { dateString, dateKey } = getTodayStrings();
  const stored = readStoredState(dateString, dateKey);

  if (stored.claimedBySlot[quest.slot]) {
    throw new Error('Quest reward already claimed today.');
  }
  if ((stored.progressBySlot[quest.slot] || 0) < quest.targetCount) {
    throw new Error('Complete the task first to claim FK.');
  }

  let updatedProfile: PlayerProfile | null = null;
  if (authUser) {
    const playerRef = doc(db, 'players', authUser.uid);
    const path = `players/${authUser.uid}`;
    try {
      const snap = await getDoc(playerRef);
      if (snap.exists()) {
        const cur = normalizePlayerProfile(snap.data() as Partial<PlayerProfile>);
        const nextFutiKodi = cur.isDeveloper ? 9999999 : Math.min(10000000, cur.futiKodi + quest.rewardFk);
        await updateDoc(playerRef, {
          futiKodi: nextFutiKodi,
          lastClaimedQuestKey: quest.questKey,
          updatedAt: serverTimestamp(),
        });
        const nextProfile: PlayerProfile = {
          ...cur,
          futiKodi: nextFutiKodi,
          lastClaimedQuestKey: quest.questKey,
        };
        updatedProfile = nextProfile;
        writeCachedPlayerProfile(nextProfile);
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  } else {
    const curGuest = readGuestWallet(false);
    const nextFutiKodi = Math.min(10000000, curGuest.futiKodi + quest.rewardFk);
    writeGuestWallet({ ...curGuest, futiKodi: nextFutiKodi });
    updatedProfile = readGuestWallet(isLocalDevMode);
  }

  stored.claimedBySlot[quest.slot] = true;
  writeStoredState(stored);
  return {
    quests: loadDailyQuests(),
    updatedProfile,
  };
}
