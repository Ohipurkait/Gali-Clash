import { User } from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  limit,
  query,
  serverTimestamp,
  Timestamp,
  where,
  writeBatch,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { getAuraById, getSkinById } from '../game/cosmetics';
import { getCfgById } from '../game/data';
import { ALL_UNLOCKABLE_POSE_IDS, FIGHTER_VICTORY_POSES } from '../game/victoryPoses';
import {
  normalizePlayerProfile,
  PlayerProfile,
  readGuestWallet,
  writeCachedPlayerProfile,
  writeGuestWallet,
} from './playerAccount';

export type MailGiftType = 'futi_kodi' | 'gota' | 'skin' | 'aura' | 'pose';

export interface DevGiftMail {
  id: string;
  targetPlayerId: string; // GC-XXXXXX or ALL
  senderName: string;
  title: string;
  message: string;
  giftType: MailGiftType;
  giftAmount: number;
  giftItemId: string;
  createdAtMs: number;
  localOnly?: boolean;
}

const PLAYER_ID_KEY = 'gc_player_id';
const LOCAL_MAILS_KEY = 'gc_local_mails_v1';
const CLAIMED_MAILS_PREFIX = 'gc_claimed_mails_';
const ID_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const PLAYER_ID_RE = /^GC-[A-Z0-9]{6}$/;

export function getOrCreatePlayerId(): string {
  try {
    const existing = window.localStorage.getItem(PLAYER_ID_KEY);
    if (existing && PLAYER_ID_RE.test(existing)) {
      return existing;
    }
    let code = '';
    const bytes = new Uint8Array(6);
    if (typeof window !== 'undefined' && window.crypto?.getRandomValues) {
      window.crypto.getRandomValues(bytes);
      for (let i = 0; i < 6; i++) {
        code += ID_ALPHABET[bytes[i] % ID_ALPHABET.length];
      }
    } else {
      for (let i = 0; i < 6; i++) {
        code += ID_ALPHABET[Math.floor(Math.random() * ID_ALPHABET.length)];
      }
    }
    const generated = `GC-${code}`;
    window.localStorage.setItem(PLAYER_ID_KEY, generated);
    return generated;
  } catch {
    return 'GC-YODDHA';
  }
}

export function normalizeTargetPlayerId(raw: string): string {
  const trimmed = String(raw || '').trim().toUpperCase().replace(/\s+/g, '');
  if (trimmed === 'ALL') return 'ALL';
  if (/^[A-Z0-9]{6}$/.test(trimmed)) return `GC-${trimmed}`;
  return trimmed;
}

export function isValidTargetPlayerId(target: string): boolean {
  return target === 'ALL' || PLAYER_ID_RE.test(target);
}

function getClaimedMailIds(playerId: string): Set<string> {
  try {
    const raw = window.localStorage.getItem(`${CLAIMED_MAILS_PREFIX}${playerId}`);
    if (!raw) return new Set();
    const parsed = JSON.parse(raw) as unknown;
    return Array.isArray(parsed) ? new Set(parsed.filter((x) => typeof x === 'string')) : new Set();
  } catch {
    return new Set();
  }
}

function markMailClaimedLocally(playerId: string, mailId: string): void {
  try {
    const set = getClaimedMailIds(playerId);
    set.add(mailId);
    const trimmed = Array.from(set).slice(-80);
    window.localStorage.setItem(`${CLAIMED_MAILS_PREFIX}${playerId}`, JSON.stringify(trimmed));
  } catch {
    // ignore storage errors
  }
}

function readLocalMails(): DevGiftMail[] {
  try {
    const raw = window.localStorage.getItem(LOCAL_MAILS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((m): m is DevGiftMail => Boolean(m && typeof m === 'object' && typeof (m as DevGiftMail).id === 'string'));
  } catch {
    return [];
  }
}

function writeLocalMails(list: DevGiftMail[]): void {
  try {
    window.localStorage.setItem(LOCAL_MAILS_KEY, JSON.stringify(list.slice(-30)));
  } catch {
    // ignore storage errors
  }
}

export function removeLocalMailById(mailId: string): void {
  const next = readLocalMails().filter((m) => m.id !== mailId);
  writeLocalMails(next);
}

export interface UnlockablePoseOption {
  id: string;
  fighterId: string;
  fighterName: string;
  poseName: string;
  tierLabel: string;
}

export function getAllUnlockablePoseOptions(): UnlockablePoseOption[] {
  const out: UnlockablePoseOption[] = [];
  for (const [fighterId, list] of Object.entries(FIGHTER_VICTORY_POSES)) {
    const fighterName = getCfgById(fighterId).name;
    list.forEach((pose, idx) => {
      if (idx === 0) return;
      out.push({
        id: pose.id,
        fighterId,
        fighterName,
        poseName: pose.poseName,
        tierLabel: idx === 1 ? 'Pose 2' : 'Pose 3',
      });
    });
  }
  return out;
}

export function formatGiftBadgeText(mail: DevGiftMail): string {
  if (mail.giftType === 'futi_kodi') {
    return `🎁 +${mail.giftAmount} Futi Kodi`;
  }
  if (mail.giftType === 'gota') {
    return `💎 +${mail.giftAmount} Gota`;
  }
  if (mail.giftType === 'skin') {
    const skin = getSkinById(mail.giftItemId);
    return `👑 Skin: ${skin ? skin.name : mail.giftItemId}`;
  }
  if (mail.giftType === 'aura') {
    const aura = getAuraById(mail.giftItemId);
    return `✨ Aura: ${aura.name}`;
  }
  const pose = getAllUnlockablePoseOptions().find((p) => p.id === mail.giftItemId);
  return `🏆 Pose: ${pose ? `${pose.fighterName} · ${pose.poseName}` : mail.giftItemId}`;
}

export async function fetchPlayerMailbox(playerId: string): Promise<DevGiftMail[]> {
  const claimed = getClaimedMailIds(playerId);
  const localMatches = readLocalMails().filter(
    (m) => (m.targetPlayerId === playerId || m.targetPlayerId === 'ALL') && !claimed.has(m.id),
  );

  const byId = new Map<string, DevGiftMail>();
  for (const lm of localMatches) {
    byId.set(lm.id, lm);
  }

  if (typeof navigator === 'undefined' || navigator.onLine !== false) {
    try {
      const q = query(
        collection(db, 'mails'),
        where('targetPlayerId', 'in', [playerId, 'ALL']),
        limit(20),
      );
      const snap = await getDocs(q);
      snap.forEach((docSnap) => {
        const d = docSnap.data() as {
          id?: string;
          targetPlayerId?: string;
          senderName?: string;
          title?: string;
          message?: string;
          giftType?: MailGiftType;
          giftAmount?: number;
          giftItemId?: string;
          createdAt?: Timestamp | null;
        };
        const mailId = d.id || docSnap.id;
        if (claimed.has(mailId)) return;
        const createdAtMs = d.createdAt && typeof d.createdAt.toMillis === 'function' ? d.createdAt.toMillis() : Date.now();
        byId.set(mailId, {
          id: mailId,
          targetPlayerId: String(d.targetPlayerId || playerId),
          senderName: String(d.senderName || 'DEV TEAM • Ohi Purkait'),
          title: String(d.title || 'Akhara Gift'),
          message: String(d.message || ''),
          giftType: (d.giftType as MailGiftType) || 'futi_kodi',
          giftAmount: typeof d.giftAmount === 'number' ? d.giftAmount : 0,
          giftItemId: String(d.giftItemId || ''),
          createdAtMs,
          localOnly: false,
        });
      });
    } catch {
      // Spark-safe offline/fallback: keep local fallback mails silently
    }
  }

  return Array.from(byId.values()).sort((a, b) => b.createdAtMs - a.createdAtMs);
}

export async function sendDeveloperGiftMail(params: {
  authUser: User | null;
  isFirestoreDeveloper: boolean;
  targetPlayerId: string;
  title: string;
  message: string;
  giftType: MailGiftType;
  giftAmount: number;
  giftItemId: string;
}): Promise<{ mail: DevGiftMail; syncedCloud: boolean }> {
  const target = normalizeTargetPlayerId(params.targetPlayerId);
  if (!isValidTargetPlayerId(target)) {
    throw new Error('Enter a valid Player ID (e.g. GC-7X9K2M) or ALL.');
  }

  const cleanTitle = String(params.title || '').replace(/\s+/g, ' ').trim().slice(0, 80);
  const cleanMessage = String(params.message || '').replace(/\s+/g, ' ').trim().slice(0, 240);
  if (!cleanTitle) throw new Error('Please enter a Mail Subject.');
  if (!cleanMessage) throw new Error('Please enter a short Message.');

  let giftAmount = 0;
  let giftItemId = '';
  if (params.giftType === 'futi_kodi' || params.giftType === 'gota') {
    const parsedAmt = Math.round(Number(params.giftAmount) || 0);
    if (parsedAmt < 1 || parsedAmt > 1000000) {
      throw new Error('Currency gift amount must be between 1 and 1,000,000.');
    }
    giftAmount = parsedAmt;
  } else if (params.giftType === 'skin' || params.giftType === 'aura') {
    if (!params.giftItemId) throw new Error('Please select a cosmetic item.');
    giftItemId = params.giftItemId;
  } else if (params.giftType === 'pose') {
    if (!ALL_UNLOCKABLE_POSE_IDS.includes(params.giftItemId)) {
      throw new Error('Please select an unlockable victory pose.');
    }
    giftItemId = params.giftItemId;
  }

  const mailId = `mail_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
  const createdAtMs = Date.now();
  const baseMail: DevGiftMail = {
    id: mailId,
    targetPlayerId: target,
    senderName: 'DEV TEAM • Ohi Purkait',
    title: cleanTitle,
    message: cleanMessage,
    giftType: params.giftType,
    giftAmount,
    giftItemId,
    createdAtMs,
    localOnly: true,
  };

  let syncedCloud = false;
  if (params.authUser && params.isFirestoreDeveloper) {
    const mailRef = doc(db, 'mails', mailId);
    try {
      const batch = writeBatch(db);
      batch.set(mailRef, {
        id: mailId,
        targetPlayerId: target,
        senderName: 'DEV TEAM • Ohi Purkait',
        title: cleanTitle,
        message: cleanMessage,
        giftType: params.giftType,
        giftAmount,
        giftItemId,
        createdAt: serverTimestamp(),
      });
      await batch.commit();
      syncedCloud = true;
      baseMail.localOnly = false;
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `mails/${mailId}`);
    }
  }

  // Also cache locally when offline/guest or when targeting self/ALL in local mode
  if (!syncedCloud) {
    const existing = readLocalMails();
    writeLocalMails([...existing, baseMail]);
  }

  return { mail: baseMail, syncedCloud };
}

function applyGiftToProfile(cur: PlayerProfile, mail: DevGiftMail): PlayerProfile {
  let futiKodi = cur.futiKodi;
  let gota = cur.gota;
  let unlockedCosmetics = [...cur.unlockedCosmetics];
  let unlockedPoses = [...cur.unlockedPoses];

  if (mail.giftType === 'futi_kodi') {
    futiKodi = cur.isDeveloper ? cur.futiKodi : Math.min(10000000, cur.futiKodi + mail.giftAmount);
  } else if (mail.giftType === 'gota') {
    gota = cur.isDeveloper ? cur.gota : Math.min(10000000, cur.gota + mail.giftAmount);
  } else if ((mail.giftType === 'skin' || mail.giftType === 'aura') && mail.giftItemId) {
    if (!unlockedCosmetics.includes(mail.giftItemId)) {
      unlockedCosmetics = [...unlockedCosmetics, mail.giftItemId];
    }
  } else if (mail.giftType === 'pose' && mail.giftItemId) {
    if (!unlockedPoses.includes(mail.giftItemId)) {
      unlockedPoses = [...unlockedPoses, mail.giftItemId];
    }
  }

  return normalizePlayerProfile({
    ...cur,
    futiKodi,
    gota,
    unlockedCosmetics,
    unlockedPoses,
    lastClaimedMailId: mail.id,
  });
}

export async function claimPlayerGiftMail(params: {
  playerId: string;
  mail: DevGiftMail;
  authUser: User | null;
  currentProfile: PlayerProfile | null;
  isLocalDevMode: boolean;
}): Promise<{ updatedProfile: PlayerProfile | null; badgeText: string }> {
  const { playerId, mail, authUser, currentProfile, isLocalDevMode } = params;
  const badgeText = formatGiftBadgeText(mail);

  if (authUser && !mail.localOnly) {
    const playerRef = doc(db, 'players', authUser.uid);
    const mailRef = doc(db, 'mails', mail.id);

    try {
      const [pSnap, mSnap] = await Promise.all([getDoc(playerRef), getDoc(mailRef)]);
      if (pSnap.exists() && mSnap.exists()) {
        const cur = normalizePlayerProfile(pSnap.data() as Partial<PlayerProfile>);
        const next = applyGiftToProfile(cur, mail);

        const batch = writeBatch(db);
        batch.update(playerRef, {
          futiKodi: next.futiKodi,
          gota: next.gota,
          unlockedCosmetics: next.unlockedCosmetics,
          unlockedPoses: next.unlockedPoses,
          lastClaimedMailId: mail.id,
          updatedAt: serverTimestamp(),
        });
        if (mail.targetPlayerId !== 'ALL') {
          batch.delete(mailRef);
        }
        await batch.commit();

        writeCachedPlayerProfile(next);
        markMailClaimedLocally(playerId, mail.id);
        removeLocalMailById(mail.id);
        return { updatedProfile: next, badgeText };
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `players/${authUser.uid}`);
    }
  }

  // Local / Guest / Offline fallback claim
  markMailClaimedLocally(playerId, mail.id);
  if (mail.targetPlayerId !== 'ALL') {
    removeLocalMailById(mail.id);
  }

  if (!authUser) {
    const curGuest = readGuestWallet(false);
    const updatedGuest = applyGiftToProfile(curGuest, mail);
    writeGuestWallet(updatedGuest);
    return { updatedProfile: readGuestWallet(isLocalDevMode), badgeText };
  }

  if (currentProfile) {
    const updated = applyGiftToProfile(currentProfile, mail);
    writeCachedPlayerProfile(updated);
    return { updatedProfile: updated, badgeText };
  }

  return { updatedProfile: null, badgeText };
}
