import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  limit,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  Timestamp,
  Unsubscribe,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { sanitizeAkharaName } from './playerAccount';

export interface FriendRequestItem {
  id: string;
  fromPlayerId: string;
  fromUid: string;
  fromName: string;
  fromFighterId: string;
  toPlayerId: string;
  createdAtMs: number;
}

export interface FriendEntry {
  id: string;
  ownerPlayerId: string;
  ownerUid: string;
  friendPlayerId: string;
  friendUid: string;
  friendName: string;
  friendFighterId: string;
  online: boolean;
  updatedAtMs: number;
}

export interface DirectMatchInvite {
  id: string;
  fromPlayerId: string;
  fromUid: string;
  fromName: string;
  fromFighterId: string;
  toPlayerId: string;
  roomCode: string;
  status: 'pending' | 'accepted' | 'declined';
  createdAtMs: number;
}

const PLAYER_ID_RE = /^GC-[A-Z0-9]{6}$/;
const FIGHTER_ID_RE = /^[a-z0-9_]+$/;
const FRIENDS_CACHE_PREFIX = 'gc_friends_cache_v1_';

export function normalizeFriendPlayerId(raw: string): string {
  const cleaned = String(raw || '').trim().toUpperCase().replace(/\s+/g, '');
  if (/^[A-Z0-9]{6}$/.test(cleaned)) return `GC-${cleaned}`;
  return cleaned;
}

export function isValidPlayerIdFormat(id: string): boolean {
  return PLAYER_ID_RE.test(id);
}

function sanitizeFighter(id: string): string {
  return FIGHTER_ID_RE.test(id) && id.length <= 40 ? id : 'munna_bhaiya';
}

function readCachedFriends(myPlayerId: string): FriendEntry[] {
  try {
    const raw = window.localStorage.getItem(`${FRIENDS_CACHE_PREFIX}${myPlayerId}`);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as unknown;
    return Array.isArray(parsed) ? (parsed as FriendEntry[]) : [];
  } catch {
    return [];
  }
}

function writeCachedFriends(myPlayerId: string, friends: FriendEntry[]): void {
  try {
    window.localStorage.setItem(`${FRIENDS_CACHE_PREFIX}${myPlayerId}`, JSON.stringify(friends.slice(0, 20)));
  } catch {
    // ignore quota errors
  }
}

export async function syncPlayerDirectoryPresence(params: {
  playerId: string;
  uid: string;
  akharaName: string;
  favoriteFighterId: string;
  online: boolean;
}): Promise<void> {
  if (!isValidPlayerIdFormat(params.playerId) || !params.uid) return;
  const dirRef = doc(db, 'playerDirectory', params.playerId);
  try {
    await setDoc(dirRef, {
      playerId: params.playerId,
      uid: params.uid,
      akharaName: sanitizeAkharaName(params.akharaName),
      favoriteFighterId: sanitizeFighter(params.favoriteFighterId),
      online: Boolean(params.online),
      updatedAt: serverTimestamp(),
    });
  } catch {
    // Ignore transient network errors during background presence updates
  }

  // Optional Realtime Database presence hook if databaseURL is configured
  const maybeDbUrl = (firebaseConfig as { databaseURL?: string }).databaseURL;
  if (maybeDbUrl && params.online) {
    try {
      const rtdbMod = await import('firebase/database');
      const rtdb = rtdbMod.getDatabase();
      const statusRef = rtdbMod.ref(rtdb, `presence/${params.playerId}`);
      await rtdbMod.set(statusRef, {
        state: 'online',
        name: sanitizeAkharaName(params.akharaName),
        fighterId: sanitizeFighter(params.favoriteFighterId),
        ts: rtdbMod.serverTimestamp(),
      });
      await rtdbMod.onDisconnect(statusRef).set({
        state: 'offline',
        name: sanitizeAkharaName(params.akharaName),
        fighterId: sanitizeFighter(params.favoriteFighterId),
        ts: rtdbMod.serverTimestamp(),
      });
    } catch {
      // RTDB not enabled on this project; Firestore presence handles online state
    }
  }
}

export async function sendFriendRequest(params: {
  myPlayerId: string;
  myUid: string;
  myName: string;
  myFighterId: string;
  targetPlayerId: string;
}): Promise<void> {
  const target = normalizeFriendPlayerId(params.targetPlayerId);
  if (!isValidPlayerIdFormat(target)) {
    throw new Error('Enter a valid Player ID (e.g. GC-7X9K2M).');
  }
  if (target === params.myPlayerId) {
    throw new Error('You cannot send a Friend Request to yourself.');
  }

  const existingFriendRef = doc(db, 'friends', `${params.myPlayerId}_${target}`);
  try {
    const friendSnap = await getDoc(existingFriendRef);
    if (friendSnap.exists()) {
      throw new Error(`${target} is already in your Friends List!`);
    }
  } catch (err) {
    if (err instanceof Error && err.message.includes('Friends List')) throw err;
  }

  const reqId = `${target}_${params.myPlayerId}`;
  const reqRef = doc(db, 'friendRequests', reqId);
  try {
    await setDoc(reqRef, {
      id: reqId,
      fromPlayerId: params.myPlayerId,
      fromUid: params.myUid,
      fromName: sanitizeAkharaName(params.myName),
      fromFighterId: sanitizeFighter(params.myFighterId),
      toPlayerId: target,
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `friendRequests/${reqId}`);
  }
}

export function subscribeIncomingFriendRequests(
  myPlayerId: string,
  enabled: boolean,
  onRequests: (list: FriendRequestItem[]) => void,
  onError?: (err: unknown) => void,
): Unsubscribe {
  if (!enabled || !isValidPlayerIdFormat(myPlayerId)) {
    onRequests([]);
    return () => {};
  }
  const q = query(
    collection(db, 'friendRequests'),
    where('toPlayerId', '==', myPlayerId),
    limit(20),
  );
  return onSnapshot(
    q,
    (snap) => {
      const items: FriendRequestItem[] = [];
      snap.forEach((docSnap) => {
        const d = docSnap.data() as {
          id?: string;
          fromPlayerId?: string;
          fromUid?: string;
          fromName?: string;
          fromFighterId?: string;
          toPlayerId?: string;
          createdAt?: Timestamp | null;
        };
        items.push({
          id: d.id || docSnap.id,
          fromPlayerId: String(d.fromPlayerId || ''),
          fromUid: String(d.fromUid || ''),
          fromName: String(d.fromName || 'Desi Yoddha'),
          fromFighterId: String(d.fromFighterId || 'munna_bhaiya'),
          toPlayerId: String(d.toPlayerId || myPlayerId),
          createdAtMs: d.createdAt && typeof d.createdAt.toMillis === 'function' ? d.createdAt.toMillis() : Date.now(),
        });
      });
      items.sort((a, b) => b.createdAtMs - a.createdAtMs);
      onRequests(items);
    },
    (error) => {
      if (onError) onError(error);
    },
  );
}

export async function acceptFriendRequest(params: {
  myPlayerId: string;
  myUid: string;
  myName: string;
  myFighterId: string;
  req: FriendRequestItem;
}): Promise<void> {
  const { myPlayerId, myUid, myName, myFighterId, req } = params;

  // Ensure our playerDirectory entry exists first so Firestore rules verify ownership of toPlayerId
  await syncPlayerDirectoryPresence({
    playerId: myPlayerId,
    uid: myUid,
    akharaName: myName,
    favoriteFighterId: myFighterId,
    online: true,
  });

  const myLinkId = `${myPlayerId}_${req.fromPlayerId}`;
  const theirLinkId = `${req.fromPlayerId}_${myPlayerId}`;
  const batch = writeBatch(db);

  batch.set(doc(db, 'friends', myLinkId), {
    id: myLinkId,
    ownerPlayerId: myPlayerId,
    ownerUid: myUid,
    friendPlayerId: req.fromPlayerId,
    friendUid: req.fromUid,
    friendName: sanitizeAkharaName(req.fromName),
    friendFighterId: sanitizeFighter(req.fromFighterId),
    createdAt: serverTimestamp(),
  });

  batch.set(doc(db, 'friends', theirLinkId), {
    id: theirLinkId,
    ownerPlayerId: req.fromPlayerId,
    ownerUid: req.fromUid,
    friendPlayerId: myPlayerId,
    friendUid: myUid,
    friendName: sanitizeAkharaName(myName),
    friendFighterId: sanitizeFighter(myFighterId),
    createdAt: serverTimestamp(),
  });

  batch.delete(doc(db, 'friendRequests', req.id));

  try {
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `friends/${myLinkId}`);
  }
}

export async function declineFriendRequest(reqId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'friendRequests', reqId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `friendRequests/${reqId}`);
  }
}

export async function removeFriend(params: {
  myPlayerId: string;
  friendPlayerId: string;
}): Promise<void> {
  const myLinkId = `${params.myPlayerId}_${params.friendPlayerId}`;
  const theirLinkId = `${params.friendPlayerId}_${params.myPlayerId}`;
  try {
    await deleteDoc(doc(db, 'friends', myLinkId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `friends/${myLinkId}`);
  }
  try {
    await deleteDoc(doc(db, 'friends', theirLinkId));
  } catch {
    // Ignore if already removed
  }
}

export async function enrichFriendsPresence(friends: FriendEntry[]): Promise<FriendEntry[]> {
  if (friends.length === 0) return [];
  const results = await Promise.all(
    friends.map(async (f) => {
      try {
        const snap = await getDoc(doc(db, 'playerDirectory', f.friendPlayerId));
        if (!snap.exists()) return f;
        const d = snap.data() as {
          akharaName?: string;
          favoriteFighterId?: string;
          online?: boolean;
          updatedAt?: Timestamp | null;
        };
        const updatedAtMs =
          d.updatedAt && typeof d.updatedAt.toMillis === 'function' ? d.updatedAt.toMillis() : f.updatedAtMs;
        const isFresh = Date.now() - updatedAtMs < 25 * 60 * 1000;
        return {
          ...f,
          friendName: d.akharaName ? sanitizeAkharaName(d.akharaName) : f.friendName,
          friendFighterId: d.favoriteFighterId ? sanitizeFighter(d.favoriteFighterId) : f.friendFighterId,
          online: Boolean(d.online && isFresh),
          updatedAtMs,
        };
      } catch {
        return f;
      }
    }),
  );
  return results;
}

export function subscribeFriendsList(
  myPlayerId: string,
  myUid: string | null,
  onFriends: (friends: FriendEntry[]) => void,
  onError?: (err: unknown) => void,
): Unsubscribe {
  if (!myUid || !isValidPlayerIdFormat(myPlayerId)) {
    onFriends(readCachedFriends(myPlayerId));
    return () => {};
  }

  const cached = readCachedFriends(myPlayerId);
  if (cached.length > 0) {
    onFriends(cached);
  }

  const q = query(
    collection(db, 'friends'),
    where('ownerUid', '==', myUid),
    limit(20),
  );

  return onSnapshot(
    q,
    async (snap) => {
      const baseList: FriendEntry[] = [];
      snap.forEach((docSnap) => {
        const d = docSnap.data() as {
          id?: string;
          ownerPlayerId?: string;
          ownerUid?: string;
          friendPlayerId?: string;
          friendUid?: string;
          friendName?: string;
          friendFighterId?: string;
        };
        baseList.push({
          id: d.id || docSnap.id,
          ownerPlayerId: String(d.ownerPlayerId || myPlayerId),
          ownerUid: String(d.ownerUid || myUid),
          friendPlayerId: String(d.friendPlayerId || ''),
          friendUid: String(d.friendUid || ''),
          friendName: String(d.friendName || 'Desi Yoddha'),
          friendFighterId: String(d.friendFighterId || 'munna_bhaiya'),
          online: false,
          updatedAtMs: 0,
        });
      });

      const enriched = await enrichFriendsPresence(baseList);
      enriched.sort((a, b) => Number(b.online) - Number(a.online) || a.friendName.localeCompare(b.friendName));
      writeCachedFriends(myPlayerId, enriched);
      onFriends(enriched);
    },
    (error) => {
      if (onError) onError(error);
    },
  );
}

export async function sendDirectMatchInvite(params: {
  fromPlayerId: string;
  fromUid: string;
  fromName: string;
  fromFighterId: string;
  toPlayerId: string;
  roomCode: string;
}): Promise<string> {
  const inviteId = `${params.toPlayerId}_${params.fromPlayerId}`;
  const ref = doc(db, 'invites', inviteId);
  try {
    await setDoc(ref, {
      id: inviteId,
      fromPlayerId: params.fromPlayerId,
      fromUid: params.fromUid,
      fromName: sanitizeAkharaName(params.fromName),
      fromFighterId: sanitizeFighter(params.fromFighterId),
      toPlayerId: params.toPlayerId,
      roomCode: String(params.roomCode || '').trim().toUpperCase().slice(0, 10),
      status: 'pending',
      createdAt: serverTimestamp(),
    });
    return inviteId;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `invites/${inviteId}`);
  }
}

export async function deleteDirectMatchInvite(inviteId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'invites', inviteId));
  } catch {
    // Ignore already deleted invites
  }
}

export async function respondToDirectMatchInvite(
  inviteId: string,
  status: 'accepted' | 'declined',
  myPlayerId: string,
  myUid: string,
  myName: string,
  myFighterId: string,
): Promise<void> {
  await syncPlayerDirectoryPresence({
    playerId: myPlayerId,
    uid: myUid,
    akharaName: myName,
    favoriteFighterId: myFighterId,
    online: true,
  });
  const ref = doc(db, 'invites', inviteId);
  try {
    await updateDoc(ref, { status });
  } catch {
    // Ignore if invite expired or was cancelled by sender
  }
}

export function subscribeIncomingInvites(
  myPlayerId: string,
  enabled: boolean,
  onInvites: (list: DirectMatchInvite[]) => void,
): Unsubscribe {
  if (!enabled || !isValidPlayerIdFormat(myPlayerId)) {
    onInvites([]);
    return () => {};
  }
  const q = query(
    collection(db, 'invites'),
    where('toPlayerId', '==', myPlayerId),
    limit(20),
  );
  return onSnapshot(
    q,
    (snap) => {
      const now = Date.now();
      const pending: DirectMatchInvite[] = [];
      snap.forEach((docSnap) => {
        const d = docSnap.data() as {
          id?: string;
          fromPlayerId?: string;
          fromUid?: string;
          fromName?: string;
          fromFighterId?: string;
          toPlayerId?: string;
          roomCode?: string;
          status?: 'pending' | 'accepted' | 'declined';
          createdAt?: Timestamp | null;
        };
        const createdAtMs =
          d.createdAt && typeof d.createdAt.toMillis === 'function' ? d.createdAt.toMillis() : now;
        // Filter out stale invites (> 10 minutes) and non-pending invites client-side (zero composite index!)
        if (d.status === 'pending' && now - createdAtMs < 10 * 60 * 1000 && d.roomCode) {
          pending.push({
            id: d.id || docSnap.id,
            fromPlayerId: String(d.fromPlayerId || ''),
            fromUid: String(d.fromUid || ''),
            fromName: String(d.fromName || 'Yoddha'),
            fromFighterId: String(d.fromFighterId || 'munna_bhaiya'),
            toPlayerId: String(d.toPlayerId || myPlayerId),
            roomCode: String(d.roomCode),
            status: 'pending',
            createdAtMs,
          });
        }
      });
      pending.sort((a, b) => b.createdAtMs - a.createdAtMs);
      onInvites(pending);
    },
    () => {
      onInvites([]);
    },
  );
}

export function subscribeSentInviteStatus(
  inviteId: string | null,
  onUpdate: (status: 'pending' | 'accepted' | 'declined' | 'cancelled') => void,
): Unsubscribe {
  if (!inviteId) return () => {};
  const ref = doc(db, 'invites', inviteId);
  return onSnapshot(
    ref,
    (snap) => {
      if (!snap.exists()) {
        onUpdate('cancelled');
        return;
      }
      const d = snap.data() as { status?: 'pending' | 'accepted' | 'declined' };
      onUpdate(d.status || 'pending');
    },
    () => {
      // ignore transient listener error
    },
  );
}
